from django.urls import path
from .views import *
from . import views
from .views import RegisterView, LoginView, ForgetPasswordView, ResetPasswordView, CustomerSearchAPIView #UserView, logoutView, 
from rest_framework.authtoken import views as auth_view
from .Viewset import OrderViewset as Orders

urlpatterns = [
        path('login/', LoginView.as_view()),
        path('register_auth/', RegisterView.as_view()),
        path('forgot_password/', ForgetPasswordView.as_view()),
        path('reset_password/',ResetPasswordView.as_view()),
        path('role_list/', views.roles_list, name='role_based'),

        path('customer_search/', views.customer_search, name='customer_search'),
        path('customer_list/', views.customer_list, name="customer_list"),
        path('particular_list/', views.particular_list, name="particular_lits"),
        path('customer/', CustomerSearchAPIView.as_view(), name='customers-search'),
        path('customername_list/', views.customername_list, name="customername_list"),
        path('getBillNumber', views.get_bill_number, name='get_bill_number'),
    path('getCustomerByBill', views.get_customer_by_bill, name='get_customer_by_bill'),
    path('saveData/', views.save_measurement_formDate, name='save_measurement_formDate'),
    path('measurements', views.get_measurements_by_customer, name="get_measurements_by_customer"),
    path('particulars_order/', views.particular_order_save, name='particulars_order'),
    path('order_list/', Orders.order_list, name='order_list')
]


    # path('registration/', views.process_customer_entry, name='process_customer_entry'),
    # path('role_based/',views.role_based,name='role_based'),
    # path('login/',views.validate_login,name='validate_login'),
    # path('reset_password/<str:user_name>/<str:email>/<str:password>/',views.reset_password,name='reset_password'),
    # path('request_forgot_password/', views.request_password_reset, name='request_password_reset'),
    # path('forgot_password/<str:user_name>/<str:email>/<str:password>/', views.forgot_password, name='forgot_password'),


    
    
    



    # path('user_view/', UserView.as_view()),
    # path('change_password/<str:user_name>/<str:email>/<str:password>/', views.change_password, name='change_password')

    # path('logout_auth', logoutView.as_view()),


# urlpatterns+=[
#     path("api/auth-token/", auth_view.obtain_auth_token),
# ]