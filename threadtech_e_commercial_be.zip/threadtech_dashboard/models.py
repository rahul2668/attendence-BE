from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager
from django.utils.translation import gettext_lazy as _
from django.utils import timezone

class BaseModel(models.Model):
    created_by = models.ForeignKey("UserAuth", null=True, blank=True, on_delete=models.SET_NULL, related_name='%(app_label)s_%(class)s_created_by')
    modified_by = models.ForeignKey("UserAuth", null=True, blank=True, on_delete=models.SET_NULL, related_name='%(app_label)s_%(class)s_modified_by')
    created_at = models.DateTimeField(auto_now_add=True)
    modified_at = models.DateTimeField(auto_now=True)
    record_status = models.BooleanField(default=True)

    class Meta:
        abstract = True
 
class RoleMaster(models.Model):
    role = models.CharField(max_length=20, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    active = models.BooleanField(default=True)

    class Meta:
        db_table = 'roles_table'

class UserDetails(BaseModel):
    username = models.CharField(max_length=225)
    email = models.CharField(max_length=50, default='')
    address = models.CharField(max_length=225)
    mobile_number = models.CharField(max_length=15)
    role = models.ForeignKey(RoleMaster, on_delete=models.PROTECT, default=None, null=True, blank=True)

    class Meta:
        db_table = 'user_details'

class ParticularPriceMaster(BaseModel):
    particular_name = models.CharField(max_length=50)
    customer_price = models.DecimalField(max_digits=7, decimal_places=2)
    worker_price = models.DecimalField(max_digits=7, decimal_places=2)

    class Meta:
        db_table = 'particular_price_master_table'

class WorkerDetails(BaseModel):
    workername = models.CharField(max_length=225)
    email = models.CharField(max_length=50, default='')
    address = models.CharField(max_length=225)
    mobile_number = models.CharField(max_length=15)
    user = models.ForeignKey(UserDetails, on_delete=models.PROTECT, default=None, null=True, blank=True)
    role = models.ForeignKey(RoleMaster, on_delete=models.PROTECT, default='', null=True, blank=True)

    class Meta:
        db_table = 'worker_details'

class CustomerDetails(BaseModel):
    customername = models.CharField(max_length=225)
    email = models.CharField(max_length=50, default='')
    address = models.CharField(max_length=225)
    mobile_number = models.CharField(max_length=15)
    user = models.ForeignKey(UserDetails, on_delete=models.PROTECT, related_name='customer_details_created_by', null=True, blank=True)
    role = models.ForeignKey(RoleMaster, on_delete=models.PROTECT, null=True, blank=True)

    class Meta:
        db_table = 'customer_details'
 
class Orders(models.Model):
    bill_no_oid_cid = models.CharField(max_length=100, blank=True, null=True)
    bill_no = models.CharField(max_length=225)  
    user = models.ForeignKey(UserDetails, on_delete=models.PROTECT)
    customer = models.ForeignKey(CustomerDetails, on_delete=models.PROTECT)
    particular = models.ForeignKey(ParticularPriceMaster, on_delete=models.PROTECT)
    particular_name = models.CharField(max_length=225, null=False)
    # measurements = models.TextField(verbose_name='Customer Measurements', blank=False, null=False)
    qty = models.IntegerField(default=1, null=True, blank=True)
    order_date = models.DateTimeField()
    trail_date = models.DateTimeField(blank=True, null=True)
    trail_status = models.CharField(max_length=10, blank=True, null=True)
    delivery_date = models.DateTimeField()
    delivery_status = models.CharField(max_length=10, blank=True, null=True)
    order_status = models.BooleanField(default=False)
    comments = models.TextField(blank=True, null=True)
    remark = models.TextField(blank=True, null=True)
    design_pattern = models.TextField(blank=True, null=True)
    qty_total_amount = models.DecimalField(max_digits=7, decimal_places=2, default=0.00)
    # total = models.DecimalField(max_digits=7, decimal_places=2, default=0.00)
    class Meta:
        db_table='orders_table'

class Measurements(BaseModel):
    customer = models.ForeignKey(CustomerDetails, on_delete=models.PROTECT)
    particular = models.ForeignKey(ParticularPriceMaster, on_delete=models.PROTECT)
    particular_name =  models.CharField(max_length=225, null=False)
    measurements = models.JSONField(blank=False, null=False)
    comments = models.TextField(blank=True, null=True)

class WorkerStatus(models.Model):
    user_id = models.ForeignKey(UserDetails, on_delete=models.PROTECT)
    order_id = models.ForeignKey(Orders, on_delete=models.PROTECT)
    # worker_id = models.ForeignKey(WorkerDetails, on_delete=models.PROTECT)
    worker_id = models.IntegerField(blank=True, null=True)
    particular_id = models.IntegerField()
    qty = models.IntegerField(default=1, null=True, blank=True)
    assigned_date = models.DateTimeField(null=True)
    completed_date = models.DateTimeField(null=True)
    work_status = models.CharField(max_length=255, blank=True, null=True)
    worker_remark = models.TextField(blank=True, null=True)
    worker_comment = models.TextField(blank=True, null=True)
    remark = models.TextField(blank=True, null=True)
    comment = models.TextField(blank=True, null=True)
    amount = models.DecimalField(max_digits=7, decimal_places=2, null=True)
    paid = models.DecimalField(max_digits=7, decimal_places=2, null=True)
    paid_date = models.DateTimeField(null=True)
    prepaid = models.DecimalField(max_digits=7, decimal_places=2, null=True)
    prepaid_date = models.DateTimeField(null=True)
    pay_status = models.CharField(max_length=10, blank=True, null=True)
 
    class Meta:
        db_table='worker_status'
 
class BillDetails(models.Model):
    bill_no = models.ForeignKey(Orders, on_delete=models.PROTECT, related_name='bill')
    order_date = models.DateTimeField()
    customer_id = models.ForeignKey(CustomerDetails, on_delete=models.PROTECT, related_name='customer_bills')
    customer_name = models.ForeignKey(CustomerDetails, on_delete=models.PROTECT)
    qty_total_amount = models.DecimalField(max_digits=7, decimal_places=2, default=0.00)
    # total = models.DecimalField(max_digits=7, decimal_places=2)
    prepaid_amount = models.DecimalField(max_digits=7, decimal_places=2)
    prepaid_date = models.DateTimeField()
    prepaid_mode = models.CharField(max_length=15)
    paid_amount = models.DecimalField(max_digits=7, decimal_places=2)
    paid_date = models.DateTimeField()
    pay_mode = models.CharField(max_length=15)
    design_amount = models.DecimalField(max_digits=7, decimal_places=2)
    pay_status = models.CharField(max_length=10)
   
    class Meta:
        db_table='billing_details'


class BaseTable(models.Model): 
    bill_no = models.BigAutoField(primary_key=True)
    cust_id = models.ForeignKey(CustomerDetails, on_delete=models.PROTECT)
    cust_name = models.CharField(max_length=50, null=True, blank=True)
    particular = models.ForeignKey(ParticularPriceMaster, on_delete=models.PROTECT)
    particular_name = models.CharField(max_length=50, null=True, blank=True)
    measurement_id = models.ForeignKey(Measurements, on_delete=models.PROTECT, null=True, blank=True)
    user = models.ForeignKey(UserDetails, on_delete=models.PROTECT)
    user_name = models.CharField(max_length=50, null=True, blank=True)
    design_pattern = models.CharField(max_length=50, null=True, blank=True)
    design_amt = models.DecimalField(max_digits=7, decimal_places=2, null=True)
    qty = models.IntegerField(default=1, null=True, blank=True)
    qty_total_amount = models.DecimalField(max_digits=7, decimal_places=2, default=0.00)
    ord_date = models.DateTimeField(null=True)
    ord_status = models.CharField(max_length=50, null=True, blank=True)
    trail_date = models.DateTimeField(null=True)
    trail_status = models.CharField(max_length=50, null=True, blank=True)
    delivery_date = models.DateTimeField(null=True)
    delivery_status = models.CharField(max_length=50, null=True, blank=True)
    ord_comments = models.CharField(max_length=100, null=True, blank=True)
    ord_remark = models.CharField(max_length=100, null=True, blank=True)
    wrk_assigned_date = models.DateTimeField(null=True)
    wrk_completed_date = models.DateTimeField(null=True)
    wrk_status = models.CharField(max_length=50, null=True, blank=True)
    wrk_remark = models.CharField(max_length=100, null=True, blank=True)
    wrk_comment = models.CharField(max_length=100, null=True, blank=True)
    user_comment = models.CharField(max_length=100, null=True, blank=True)
    user_remark = models.CharField(max_length=100, null=True, blank=True)
    wrk_amount = models.DecimalField(max_digits=7, decimal_places=2, default=0.00)
    wrk_design_amt = models.DecimalField(max_digits=7, decimal_places=2, default=0.00)
    wrk_paid = models.DecimalField(max_digits=7, decimal_places=2, default=0.00)
    wrk_paid_date = models.DateTimeField(null=True)
    wrk_prepaid = models.DecimalField(max_digits=7, decimal_places=2, default=0.00)
    wrk_prepaid_date = models.DateTimeField(null=True)
    wrk_pay_status = models.CharField(max_length=50, null=True, blank=True)
    cust_advance_amt = models.DecimalField(max_digits=7, decimal_places=2, default=0.00)
    cust_advance_paid_date = models.DateTimeField(null=True)
    cust_advance_prepaid_mode = models.CharField(max_length=50, null=True, blank=True)
    cust_paid_amt = models.DecimalField(max_digits=7, decimal_places=2, default=0.00)
    cust_paid_date = models.DateTimeField(null=True)
    cust_pay_mode = models.CharField(max_length=50, null=True, blank=True)
    cust_pay_status = models.CharField(max_length=50, null=True, blank=True)
    class Meta:
        db_table='base_table'

    







# create a table for measurment to save--> bill no, shirt, shirt comment ,













class UserManager(BaseUserManager):
    def create_user(self, username: str, password: str = None, **extra_fields):
        user=self.model(username=username)
        user.username = username
        if password:
            user.set_password(password)
        else:
            user.set_unusable_password()
        user.save(using=self._db)
        return user


# # It will store the login details of the users
# class UserAuth(models.Model):
class UserAuth(AbstractBaseUser,BaseModel):
    username = models.CharField(max_length=100, unique=True,verbose_name=_("UserName"))
    user = models.ForeignKey(UserDetails, on_delete=models.PROTECT, related_name='login_ids', null=True, blank=True)
    customer = models.ForeignKey(CustomerDetails, on_delete=models.PROTECT, null=True, blank=True)
    worker = models.ForeignKey(WorkerDetails, on_delete=models.PROTECT, null=True, blank=True)
    login_type = models.ForeignKey(RoleMaster, on_delete=models.PROTECT)
    email = models.CharField(max_length=50, default='')
    password = models.CharField(max_length=100, null=False, blank=False)
    login_at = models.DateTimeField(null=True, blank=True)
    logout_at = models.DateTimeField(null=True, blank=True)
    login_attempt_3 = models.IntegerField(default=0, null=True, blank=True)
    active = models.BooleanField(default=False)
    REQUIRED_FIELDS = ['email']
    USERNAME_FIELD = "username"
    objects=UserManager()
 
    class Meta:
        db_table='user_auth'

class UserToken(models.Model):
    user=models.OneToOneField(UserAuth,related_name='user_token',on_delete=models.CASCADE)
    token=models.TextField(null=True)

    def __str__(self) -> str:
        return self.user.username
    class Meta:
        db_table='user_token'

# authentication

# class UserLogin(models.Model):
#     username = models.CharField(max_length=100, null=True, blank=True)
#     user = models.ForeignKey(UserDetails, on_delete=models.PROTECT, related_name='login_ids', null=True, blank=True)
#     email = models.EmailField()
#     password = models.CharField(max_length=100, null=False, blank=False)

#     login_at = models.DateTimeField(null=True, blank=True)
#     logout_at = models.DateTimeField(null=True, blank=True)
#     login_attempt_3 = models.IntegerField(default=0, null=True, blank=True)
#     active = models.BooleanField(default=False)

#     # username = None
#     USERNAME_FIELD='email'
#     REQUIRED_FIELD=[]
 
#     class Meta:
#         db_table='user_login'

# class UserLogin(models.Model):
#     username = models.CharField(max_length=100, null=True, blank=True)
#     # user = models.ForeignKey(UserDetails, on_delete=models.PROTECT, related_name='login_ids', null=True, blank=True)
#     # customer = models.ForeignKey(CustomerDetails, on_delete=models.PROTECT, null=True, blank=True)
#     # worker = models.ForeignKey(WorkerDetails, on_delete=models.PROTECT, null=True, blank=True)
#     # login_type = models.ForeignKey(RoleMaster, on_delete=models.PROTECT)
#     email = models.EmailField()
#     password = models.CharField(max_length=100, null=False, blank=False)
#     login_at = models.DateTimeField(null=True, blank=True)
#     logout_at = models.DateTimeField(null=True, blank=True)
#     login_attempt_3 = models.IntegerField(default=0, null=True, blank=True)
#     active = models.BooleanField(default=False)
#     REQUIRED_FIELDS = ['email']
#     USERNAME_FIELD = "username"
 
#     class Meta:
#         db_table='user_login'




# class MasterTable(models.Model):
#     # Foreign key relationships to other tables
#     order = models.ForeignKey('Orders', on_delete=models.CASCADE)
#     worker_status = models.ForeignKey('WorkerStatus', on_delete=models.CASCADE)
#     bill_details = models.ForeignKey('BillDetails', on_delete=models.CASCADE)
#     particular = models.ForeignKey('ParticularPriceMaster', on_delete=models.CASCADE)
#     user = models.ForeignKey('UserAuth', on_delete=models.CASCADE)
    
#     # Additional fields
#     particular_name = models.CharField(max_length=225)
#     qty = models.IntegerField(null=True, blank=True)
#     order_date = models.DateTimeField()
#     trail_date = models.DateTimeField()
#     trail_status = models.CharField(max_length=10)
#     delivery_date = models.DateTimeField()
#     delivery_status = models.CharField(max_length=10)
#     order_status = models.IntegerField()
#     comments = models.TextField(blank=True, null=True)
#     remark = models.TextField(blank=True, null=True)
#     design_pattern = models.TextField(blank=True, null=True)


# work_week
# work_date
# worker_name
# work_type
# bill_no
# qty
# design_type
# working_from_home
# order_date
# delivery_date
# trial_date
# cutter_name
# shirt_maker_stitching_amount
# trouser_maker_stitching_amount
# added_time
# task_owner


