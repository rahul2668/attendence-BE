# import jwt
# from django.conf import settings
# from django.http import JsonResponse

# class JWTAuthenticationMiddleware:
#     def __init__(self, get_response):
#         self.get_response = get_response


#     def __call__(self, request):
#         import pdb;pdb.set_trace()
#         if request.path == '/api/login/':
#             # Skip authentication check for login endpoint
#             response = self.get_response(request)
#             return response
        
#         if 'HTTP_AUTHORIZATION' in request.META:
#             try:
#                 token = request.META['HTTP_AUTHORIZATION'].split(' ')[1]
#                 decoded_token = jwt.decode(token, settings.SECRET_KEY, algorithms=['HS256'])
#                 request.user = decoded_token
#             except jwt.ExpiredSignatureError:
#                 return JsonResponse({'error': 'Token expired'}, status=401)
#             except jwt.InvalidTokenError:
#                 return JsonResponse({'error': 'Invalid token'}, status=401)
#         else:
#             return JsonResponse({'error': 'Token required'}, status=401)

#         response = self.get_response(request)
#         return response
    

from rest_framework.response import Response
from rest_framework import status
from rest_framework_simplejwt.tokens import  AccessToken
from threadtech_dashboard.models import UserAuth
from django.http import HttpResponseForbidden


class UserMiddleWare:
    def __init__(self, get_response):
        self.get_response = get_response

    # def __call__(self, request):
    #     access_token = request.headers.get("Authorization",None)
    #     if access_token:
    #         access_token=access_token.split(" ")[1].strip('"')
    #         token = AccessToken(access_token)
    #         username = token['username']
    #         password = token['passsword']
    #         try:
    #             user=UserAuth.objects.get(username=username, password=password)
    #             if user.is_delete or (hasattr(user,"user_token") and user.user_token.token !=access_token) :
    #                 return HttpResponseForbidden(
    #                     {"authentication.login.userDeactivatedContactAdminNotify"},
    #                     status=status.HTTP_401_UNAUTHORIZED,
    #                 )
    #         except (AttributeError,UserAuth.DoesNotExist):
    #             return HttpResponseForbidden(
    #                     {"authentication.login.userNotFoundNotify"},
    #                     status=status.HTTP_401_UNAUTHORIZED,
    #                 )
    #         except Exception: pass

    #     response = self.get_response(request)
    #     return response
   
   
   
    def __call__(self, request):
        access_token = request.headers.get("Authorization", None)
        if access_token:
            access_token_parts = access_token.split(" ")
            if len(access_token_parts) == 2:  # Check if the header contains two parts
                access_token = access_token_parts[1].strip('"')
                token = AccessToken(access_token)
                username = token['username']
                password = token['password']
                try:
                    user = UserAuth.objects.get(username=username, password=password)
                    if user.is_delete or (hasattr(user, "user_token") and user.user_token.token != access_token):
                        return HttpResponseForbidden(
                            {"authentication.login.userDeactivatedContactAdminNotify"},
                            status=status.HTTP_401_UNAUTHORIZED,
                        )
                except (AttributeError, UserAuth.DoesNotExist):
                    return HttpResponseForbidden(
                        {"authentication.login.userNotFoundNotify"},
                        status=status.HTTP_401_UNAUTHORIZED,
                    )
                except Exception:
                    pass

        response = self.get_response(request)
        return response