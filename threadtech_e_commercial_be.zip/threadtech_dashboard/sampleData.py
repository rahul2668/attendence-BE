from .models import UserDetails ,UserLogin
from django.db import models
from django.contrib.auth.models import AbstractUser


class UserLogin(models.Model):
    user_name = models.CharField(max_length=100, null=True, blank=True)
    user = models.ForeignKey(UserDetails, on_delete=models.PROTECT, related_name='login_ids', null=True, blank=True)
    email = models.EmailField()
    password = models.CharField(max_length=100, null=False, blank=False)

    login_at = models.DateTimeField(null=True, blank=True)
    logout_at = models.DateTimeField(null=True, blank=True)
    login_attempt_3 = models.IntegerField(default=0, null=True, blank=True)
    active = models.BooleanField(default=False)

    # username = None
    USERNAME_FIELD='email'
    REQUIRED_FIELD=[]
 
    class Meta:
        db_table='user_login'

# in setting file add 
AUTH_USER_MODEL='user.User' #it should be model path



# authentication/token generate
# middleware for all API's except login




@api_view(['POST'])
def forgot_password(request,user_name,password,email):
    data = request.data
    new_password = data.get('new_password')
    Confirm_Password = data.get('Confirm_Password')
    # print("new password",new_password)
    # print("Confirm_Password",Confirm_Password)

    if new_password != Confirm_Password:
        raise ValidationError("New password and confirm password do not match")

    try:
        user = UserLogin.objects.get(user_name=user_name,email=email,password=password)
    except UserLogin.DoesNotExist:
        raise ValidationError("User with this email does not exist.")

    # Update the user's password and mark them as active
    user.password=Confirm_Password
    user.is_active = True
    user.save()
    if new_password == Confirm_Password:
        UserLogin.objects.filter(user_name=user_name, email=email, password=password).update(password=user.password, active=True)
        return Response("User password is updated please login") 

@api_view(['POST'])
def request_password_reset(request):
    data = request.data
    user_name=data.get('user_name')
    email = data.get('email')
    password=data.get('password')
    try:
        user = UserLogin.objects.get(user_name=user_name,email=email,password=password)
    except user.DoesNotExist:
        raise ValidationError("User with this email does not exist.")

    # reset_link = reverse('password_reset_confirm') + f'?email={email}'

    subject = "Forgot Password"
    message = f'To change password, you can log in using this password. {request.build_absolute_uri("http://localhost:3000/forgot_password/{}/{}/{}".format(user_name, email,password))}'
    from_email = settings.DEFAULT_FROM_EMAIL
    recipient_list = [email]
    send_mail(subject, message, from_email, recipient_list)
    return Response("Password reset link sent successfully. Please check your email.")


        

    
# @api_view(['POST'])
# @login_required
# def validate_login(request):
    # data = request.data
    # user_name = data.get('user_name')
    # password = data.get('password')
    # if not user_name:
    #     raise ValidationError("Please Enter User Name")
    # if not password:
    #     raise ValidationError("Please Enter Password")
    # user_details = UserLogin.objects.filter(user_name=user_name).first()
    
    # if not user_details.user_name:
    #     raise ValidationError("Invalid User")
    # if user_details.password != password:
    #     raise ValidationError("Invalid Password")
    # user_role = user_details.login_type.role

    # authenticated = True
    # if authenticated:
    #     payload = {
    #         "username": user_name,
    #         "role": user_role,
    #         # "password": password
    #     }
    #     secret_key = "test@123"
    #     token = jwt.encode(payload, secret_key, algorithm="HS256")        
    #     return Response({"message":"Login Successful", "token":token, "status": "SUCCESS"})
    # else:
    #     return Response({'message': 'Login successful', 'data': {'user_name': user_name, 'role': user_role}})
def validate_login(request):
    try:
        JWT_SECRET_KEY='test@123'
        data = request.data
        user_name = data.get('user_name')
        password = data.get('password')
        if not user_name:
            raise ValidationError("Please Enter User Name")
        if not password:
            raise ValidationError("Please Enter Password")

        try:
            user_details = UserLogin.objects.filter(user_name=user_name).first()
    
            if not user_details.user_name:
                raise ValidationError("Invalid User")
            if user_details.password != password:
                raise ValidationError("Invalid Password")
            user_role = user_details.login_type.role
            
        except:
            return JsonResponse({'error':'Invalid Username/Password'})
        
        if user_details:

            payload = {'user_name': user_details.user_name}
            secret_key = JWT_SECRET_KEY
            jwt_token = jwt.encode(payload, secret_key, algorithm='HS256')
            return JsonResponse({'token': jwt_token})
        else:
            return JsonResponse({'error': 'Invalid username/password'})
    except Exception as e:
        return JsonResponse({'error': str(e)})



28/05/2024


@api_view(['POST'])
def process_customer_entry(request):
    role = request.data.get('role')
    user_name = request.data.get('user_name')
    email = request.data.get('email')
    mobile_number = request.data.get('mobile_number')
    address = request.data.get('address')
    if not role:
        raise ValidationError("Invalid role")
    if not user_name:
        raise ValidationError("Please Select Username")
    if not email:
        raise ValidationError("Please Select Email")
    if not mobile_number:
        raise ValidationError("Please Select Mobile Number")
    if not address:
        raise ValidationError("Please Select Address")
    import pdb;pdb.set_trace()
    temp_password = get_random_string(length=6)
    role_id = RoleMaster.objects.filter(role=role).first()
    if role == "User" or role == 'Admin':
        user_details_check = UserDetails.objects.filter(user_name=user_name, role=role_id)
        if user_details_check:
            raise ValidationError("User Already Exist from User Detail Table")
        user_details = UserDetails.objects.create(user_name=user_name, address=address, role=role_id, mobile_number=mobile_number)
        user_detail_name = user_details.user_name
        user_check = UserAuth.objects.filter(user_name=user_detail_name, email=email, login_type=role_id)
        if user_check:
            raise ValidationError("User Already Exist from Login Detail Table")
        UserAuth.objects.create(user_id = user_details.id, user_name=user_name, email=email, password=temp_password, login_type=role_id)

    # if role == "Worker":
    #     user_id = UserDetails.objects.filter(user_name=user_name, role=role_id).first()
    #     wrk_obj_check = WorkerDetails.objects.filter(worker_name=user_name, email=email, mobile_number=mobile_number)
    #     if wrk_obj_check:
    #         raise ValidationError("Worker Already Exist from Worker Detail Table")
    #     worker_details = WorkerDetails.objects.create(worker_name=user_name, email=email, mobile_number=mobile_number, address=address,user_id=user_id)
    #     worker_details_name = worker_details.worker_name
    #     user_check = UserLogin.objects.filter(user_name=worker_details_name, email=email, login_type=role_id)
    #     if user_check:
    #         raise ValidationError("User Already Exist from Login Detail Table")
    #     UserLogin.objects.create(worker_id = worker_details.id, user_name=user_name, email=email, password=temp_password, login_type=role_id)            

    # if role == "Customer":
    #     user_id = UserDetails.objects.filter(user_name=user_name, role=role_id).first()
    #     cust_obj_check = CustomerDetails.objects.filter(customer_name=user_name, email=email, mobile_number=mobile_number)
    #     if cust_obj_check:
    #         raise ValidationError("Customer Already Exist from Customer Detail Table")
    #     customer_details = CustomerDetails.objects.create(customer_name=user_name, email=email, mobile_number=mobile_number, address=address,user_id=user_id)
    #     customer_details_name = customer_details.customer_name

    #     user_check = UserLogin.objects.filter(user_name=customer_details_name, email=email, login_type=role_id)
    #     if user_check:
    #         raise ValidationError("User Already Exist from Login Detail Table")
    #     UserLogin.objects.create(customer_id = customer_details.id, user_name=user_name, email=email, password=temp_password, login_type=role_id)            
                    


    subject='Setup a new password'
    # message = f'Hi, your temporary password is: {temp_password}. You can log in using this password. {request.build_absolute_uri("api/anotherform/" + "user_name:"+ user_name + "/" + "email:"+email + "/" + "temp_password:"+temp_password + "/")}'
    # message = f'Hi, your temporary password is: {temp_password}. You can log in using this password. {("http://127.0.0.1:8000/api/anotherform/" + "user_name:"+ user_name + "/" + "email:"+email + "/" + "temp_password:"+temp_password + "/")}'
    message = f'Hi, your temporary password is: {temp_password}. You can log in using this password. {request.build_absolute_uri("http://localhost:3000/reset_password/{}/{}/{}".format(user_name, email,temp_password))}'
    from_email = settings.DEFAULT_FROM_EMAIL
    recipient_list = [email]
    send_mail(subject, message, from_email, recipient_list)
    return Response("Check your email to setup your account")



# @api_view(['GET'])
# def another_form(request,user_name,email,temp_password):
    # return render(request,template_name='pass.html', context={'user_name': user_name, 'email': email, 'temp_password': temp_password})

@api_view(['GET'])
def role_based(request):
        # role = request.data.get('role')
        role_data = RoleMaster.objects.filter(active=True)
        if role_data.exists():
            serializer = RoleSerializer(role_data, many=True).data
            return Response(serializer)
        else:
            return Response("doesnot exist")



        # return Response(serializer.data)
  
        
class UserView(APIView):
    def get(self, request):
        token = request.COOKIES.get("jwt")
        if not token:
            raise AuthenticationFailed("Unauthenticated")
        try:
            payload = jwt.decode(token, 'secret', algorithms=['HS256'])
        except:
            raise AuthenticationFailed("Unauthenticated")

        user = UserAuth.objects.get(id = payload['id'])
        serializer = UserAuthSerializer(user).data
        return Response(serializer)
        

class logoutView(APIView):
    def post(self, request):
        response = Response()
        response.delete_cookie('jwt')
        response.data = {"message": "success"}
        return response


def get_access_token_for_user(user, request):
    # if PlantConfig.objects.all().exists():
    #     function_ids = list(PlantConfigFunction.objects.values_list('function_id', flat=True))
    #     for item in RolePermission.objects.exclude(function_master_id__in=function_ids):
    #         item.view=False
    #         item.create=False
    #         item.edit=False
    #         item.delete=False
    #         item.save()
    response={}
    login(request,user)
    serializer = UserAuthLoginSerializer(user, context={"request": request})
    
    token_data = serializer.data
    token_data['login_type'] = user.login_type

    access_token = AccessToken.for_user(user)
    access_token['user_data'] = dict(token_data)
    # access_token['plant_data']=plant_data
    access_token=str(access_token)
    if UserToken.objects.filter(user=user).exists():
        user.user_token.token=access_token
        user.user_token.save()
    else:
        UserToken.objects.create(user=user,token=access_token)
    response["message"] = "authentication.login.loginSuccessNotify"
    response['access_token']=access_token
    return response   

# @permission_classes((AllowAny,))
# class SimpleUserLoginView(APIView):
#     def post(self,request):
#         data=request.data
#         username= data.get("username",None)
#         password= data.get("password",None)
#         if not username or not password :
#             return Response({"message": "authentication.login.userNameOrPasswordIsEmptyNotify"}, status=status.HTTP_400_BAD_REQUEST)
#         check_user=UserAuth.objects.filter(username__iexact=username).first()
#         import pdb;pdb.set_trace()
#         user=authenticate(request=request,username=username,password=password)
#         if user:
#             if user.is_delete:
#                 return Response({"message":"authentication.login.userDeactivatedContactAdminNotify"}, status=status.HTTP_401_UNAUTHORIZED)
#             response = get_access_token_for_user(user, request)
#             return Response(response, status=status.HTTP_200_OK)
#         elif  check_user is None:
#             return Response({"message":"authentication.login.userNotFoundNotify"},status=status.HTTP_404_NOT_FOUND)
#         else:
#             return Response({"message": "authentication.login.passwordIsNotCorrectNotify"}, status=status.HTTP_404_NOT_FOUND)



@api_view(['POST'])
@permission_classes((AllowAny,))
def change_password(request, user_name, email, password):
        response = {}
        data = request.data
        temp_password = data.get('temp_password')
        set_password=data.get('set_password')
        confirm_password=data.get('confirm_password')
        if not temp_password:
            raise ValidationError("Please Enter Valid Temp password")
        if not set_password:
            raise ValidationError("Please Enter Valid New password")
        if not confirm_password:
            raise ValidationError("Please Enter Valid Confirm password")

        import pdb;pdb.set_trace()
        try:
            user = authenticate(username=user_name, password=temp_password)
            if user is not None:
                password_match = user.check_password(confirm_password)
                if password_match:
                    response["message"] = "Change Password - New Password Must Be Different"
                    status_code = status.HTTP_400_BAD_REQUEST
                    return Response(response, status=status_code)
                password = make_password(confirm_password)
                user.password = password
                user.save()
                response["message"] = "authentication.changePassword.passwordChangedSuccessNotify"
                status_code = status.HTTP_200_OK
            else:
                response["message"] = "authentication.changePassword.oldPasswordWrongNotify"
                status_code = status.HTTP_400_BAD_REQUEST
        except Exception as e:
            response["message"] = "authentication.changePassword.errorOccurredWhileChangePasswordNotify"
            status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
 
        return Response(response, status=status_code)