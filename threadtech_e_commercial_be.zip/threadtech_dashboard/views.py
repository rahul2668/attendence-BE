from django.shortcuts import render
from django.shortcuts import render, redirect
from django.http import HttpResponse, JsonResponse
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.exceptions import ValidationError
from .serializers import RoleSerializer,UserDetailSerializer, UserAuthSerializer,UserAuthLoginSerializer,UserAuthForgetPasswordSerializer, UserAuthResetPasswordSerializer, CustomerDetailsSerializer, CustomerNameSerializer, ParticularPriceMasterSerializer
from rest_framework.response import Response
from .models import CustomerDetails,WorkerDetails,UserDetails,RoleMaster, UserAuth, UserToken, ParticularPriceMaster, Measurements, Orders, WorkerStatus, BaseTable
from django.core.mail import send_mail
from django.utils.crypto import get_random_string
from django.db.models import Q
# from django.conf import settings
import jwt
from django.conf import settings
from django.http import JsonResponse
# from threadtech_e_commercial import settings
from django.contrib.auth.decorators import login_required
from rest_framework.views import APIView
import jwt, datetime
from django.contrib.auth import authenticate,login

from rest_framework.exceptions import AuthenticationFailed
from rest_framework_simplejwt.tokens import (RefreshToken, AccessToken)
from django.contrib.auth.hashers import make_password
from rest_framework.permissions import AllowAny
from decimal import Decimal
from django.utils import timezone
from collections import defaultdict


class LoginView(APIView):
    def post(self, request):
        username = request.data['username']
        password = request.data['password']
        user = UserAuth.objects.filter(username=username).first()
        if not user:
            raise AuthenticationFailed("User not found")
        if not user.check_password(password):
            raise AuthenticationFailed("Incorrect Password")
        user_role = user.login_type.role
        payload = {
            'id': user.id,

            'exp':datetime.datetime.utcnow() + datetime.timedelta(minutes=60),
            'iat': datetime.datetime.utcnow()
        }
        user.login_at = datetime.datetime.now()
        user.save()
        token = jwt.encode(payload, 'secret', algorithm='HS256') #.decode('utf-8')
        # response = Response()
        # response.set_cookie(key='jwt', value=token, httponly=True)
        # response.data = {"jwt": token, "status": "SUCCESS"} #headers={"Authorization": f'Bearer {token}'}
        # return response
    #    response = Response()
        # response.set_cookie(key='jwt', value=token, httponly=True)
        response_data = {"token": token, "status": "SUCCESS", "login_type": user_role, "username": username, "user_id": user.id} #headers={"Authorization": f'Bearer {token}'}
        return Response(response_data, headers={'Authorization': f'Bearer {token}'})

class ForgetPasswordView(APIView):
    def post(self, request):
        username = request.data['username']
        email = request.data['email']
        user = UserAuth.objects.filter(username=username).first()
        if not user:
            raise AuthenticationFailed("User not found")
        email_check = user.email
        if email_check != email:
            raise AuthenticationFailed("Email Doesn't exist")
        temp_password = get_random_string(length=6)
        data = {'password': temp_password}
        serializer = UserAuthForgetPasswordSerializer(user, data=data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()

        subject = "Forgot Password"
        message = f'To change password, use: {temp_password} . and you can log in using this password. {request.build_absolute_uri("http://localhost:3000/reset_password/{}/{}".format(username, email))}'
        from_email = settings.DEFAULT_FROM_EMAIL
        recipient_list = [email]
        send_mail(subject, message, from_email, recipient_list)
        response_data = {"message": "Password reset link sent successfully. Please check your email.", "status": "SUCCESS"}
        return Response(response_data)
    
class ResetPasswordView(APIView):
    def post(self, request):
        data = request.data
        username = data.get('username')
        email = data.get("email")
        temp_password = data.get('temp_password')
        new_password=data.get('new_password')
        confirm_password=data.get('confirm_password')
        if not temp_password:
            raise AuthenticationFailed("Please Enter Valid Temp password")
        if not new_password:
            raise AuthenticationFailed("Please Enter Valid New password")
        if not confirm_password:
            raise AuthenticationFailed("Please Enter Valid Confirm password")
        if new_password != confirm_password:
            raise AuthenticationFailed("New password and confirm password do not match")
        user_obj = UserAuth.objects.filter(username=username, email=email).first() #password=temp_password
        if not user_obj or not user_obj.check_password(temp_password):
            raise AuthenticationFailed("Invalid username/email/temporary password")
        user_data = {"username": username, "email": email, "password": new_password}
        serializer = UserAuthResetPasswordSerializer(user_obj, data=user_data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({"message": "User password is updated, please login", "status": "SUCCESS"})
        else:
            test = serializer.errors
            return Response({"message":test, "status":"FAILED"})
      

class RegisterView(APIView):
    def post(self, request):
        role = request.data.get('role')
        username = request.data.get('username')
        email = request.data.get('email')
        mobile_number = request.data.get('mobile_no')
        address = request.data.get('address')
        if not role:
            raise ValidationError("Invalid role")
        if not username:
            raise ValidationError("Invalid username")
        if not email:
            raise ValidationError("Invalid Email")
        if not mobile_number:
            raise ValidationError("Invalid mobile number")
        if not address:
            raise ValidationError("Invalid Address")
        temp_password = get_random_string(length=6)
        role_instance = RoleMaster.objects.filter(role=role).first()
        if role_instance:
            if role == "User" or role == 'Admin':
                user_details_check = UserDetails.objects.filter(username=username, role=role_instance)
                if user_details_check:
                    raise ValidationError("User Already Exist from User Detail Table")

                user_details = UserDetails.objects.create(username=username, address=address, role=role_instance, mobile_number=mobile_number, email=email)
                user_detail_name = user_details.username
                user_check = UserAuth.objects.filter(username=user_detail_name, email=email, login_type=role_instance)
                if user_check:
                    raise ValidationError("User Already Exist from Login Detail Table")
                # test = {"user_id":user_details.id,"username": username, "email": email, "password":temp_password, "login_type": role_instance.id}
        
            if role == "Customer":
                user_details_check = CustomerDetails.objects.filter(customername=username, role=role_instance)
                if user_details_check:
                    raise ValidationError("User Already Exist from User Detail Table")
                user_details = CustomerDetails.objects.create(customername=username, address=address, role=role_instance, mobile_number=mobile_number, email=email)
                user_detail_name = user_details.customername
                user_check = UserAuth.objects.filter(username=user_detail_name, email=email, login_type=role_instance)
                if user_check:
                    raise ValidationError("Customer Already Exist from Login Detail Table")
                # test = {"user_id":user_details.id,"username": username, "email": email, "password":temp_password, "login_type": role_instance.id}
            
            if role == "Worker":
                user_details_check = WorkerDetails.objects.filter(workername=username, role=role_instance)
                if user_details_check:
                    raise ValidationError("User Already Exist from User Detail Table")
                user_details = WorkerDetails.objects.create(workername=username, address=address, role=role_instance, mobile_number=mobile_number, email=email)
                user_detail_name = user_details.workername
                user_check = UserAuth.objects.filter(username=user_detail_name, email=email, login_type=role_instance)
                if user_check:
                    raise ValidationError("Customer Already Exist from Login Detail Table")
            test = {"user_id":user_details.id,"username": username, "email": email, "password":temp_password, "login_type": role_instance.id}

        serializer = UserAuthSerializer(data=test)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        import pdb;pdb.set_trace()
        subject='Setup a new password'
        
        message = f'Hi, your temporary password is: {temp_password}. You can log in using this password. {request.build_absolute_uri("http://localhost:3000/reset_password/{}/{}".format(username, email))}'
        from_email = settings.DEFAULT_FROM_EMAIL
        recipient_list = [email]
        send_mail(subject, message, from_email, recipient_list)
        response_data = {"message": "Please Check your email to setup your account.", "status": "SUCCESS"}
        return Response(response_data)
    
@api_view(['GET'])
def roles_list(request):
    # role_obj = RoleMaster.objects.all().values()
    # return Response(role_obj)
    role_data = RoleMaster.objects.filter(active=True)
    if role_data.exists():
        serializer = RoleSerializer(role_data, many=True).data
        return Response(serializer)
    else:
        return Response("doesnot exist")

@api_view(['GET'])
def users_info(request):
    user_name = request.GET.get('user_name')
    email = request.GET.get('email')
    mobile_number = request.GET.get('mobile_number')
    address = request.GET.get('address')        
    if UserDetails.objects.filter(user_name=user_name,email=email,mobile_number=mobile_number,address=address).exists():
        user_details_instance = UserDetails.objects.get(user_name=user_name, email=email, mobile_number=mobile_number, address=address)
        serializer = UserDetailSerializer(user_details_instance,many=True)
        print('serializer values are',serializer.data)
        return Response(serializer.data)
    else:
        return Response({'message': 'No user found with the provided criteria'}, status=404)

@api_view(['POST'])
def customer_search(request):
    import pdb;pdb.set_trace()
    data = request.data
    search = data.get("searchData")
    customer_obj = CustomerDetails.objects.filter(id=search).values()
    return Response(customer_obj)

@api_view(['GET'])
def customer_list(request):
    # import pdb;pdb.set_trace()
    # data = request.data
    # search = data.get("searchData")
    customer_obj = CustomerDetails.objects.filter(record_status=True)
    serializer = CustomerDetailsSerializer(customer_obj, many=True)
    return Response({"status": "SUCCESS", "body":serializer.data})

@api_view(['GET'])
def customername_list(request):
    # import pdb;pdb.set_trace()
    # data = request.data
    # search = data.get("searchData")
    customer_obj = CustomerDetails.objects.filter(record_status=True)
    serializer = CustomerNameSerializer(customer_obj, many=True)
    return Response({"status": "SUCCESS", "body":serializer.data})

@api_view(['GET'])
def particular_list(request):
    part_obj = ParticularPriceMaster.objects.filter(record_status=True).order_by('id')
    # .values('id', 'particular_name', 'customer_price').order_by('id')
    serializer = ParticularPriceMasterSerializer(part_obj, many=True).data
    return Response({"status":"SUCCESS", "body": serializer})

class CustomerSearchAPIView(APIView):
    serializer_class = CustomerDetailsSerializer

    def get(self, request, *args, **kwargs):
        # import pdb;pdb.set_trace()
        search_term = request.query_params.get('searchTerm', None)
        queryset = CustomerDetails.objects.all()
        if search_term:
            queryset = queryset.filter(
                Q(customername__icontains=search_term) |
                Q(email__icontains=search_term) |
                Q(address__icontains=search_term) |
                Q(mobile_number__icontains=search_term) 
            )
        serializer = self.serializer_class(queryset, many=True)
        # return Response(serializer.data, status=status.HTTP_200_OK)
        return Response({"status": "SUCCESS", "body": serializer.data})
    
@api_view(['GET'])
def get_bill_number(request):
    print("entereyddddddd")
    customer_id = request.GET.get('customerId')
    print("----", customer_id)
    if not customer_id:
        raise ValidationError("Customer ID is required")

    try:
        bill = CustomerDetails.objects.filter(id=customer_id).first()
        return Response({"billNumber": bill.id})
    except CustomerDetails.DoesNotExist:
        raise ValidationError("Bill not found for the given customer ID")

@api_view(['GET'])
def get_customer_by_bill(request):
    bill_number = request.GET.get('billNumber')
    if not bill_number:
        raise ValidationError("Bill number is required")

    try:
        # bill = Bill.objects.get(number=bill_number)
        customer = CustomerDetails.objects.filter(id=bill_number).first()
        if not customer:
            raise ValidationError("Bill number doesn't exist")
        return Response({"customerName": customer.customername, "customerId": customer.id})
    except:
        raise ValidationError("Customer not found for the given bill number")
    

@api_view(['POST'])
def save_measurement_formDate(request):
    form_data = request.data.get('formData')
    selected_customer_id = request.data.get('selectedCustomerId')
    
    if not selected_customer_id:
        raise ValidationError('Selected customer ID is required.')
    
    try:
        customer = CustomerDetails.objects.get(id=selected_customer_id)
    except CustomerDetails.DoesNotExist:
        raise ValidationError('Customer not found.')

    for key, value in form_data.items():
        particular_id = value.get('particular_id')
        measurement_id = value.get('measurement_id')
        if not particular_id:
            raise ValidationError(f'Particular ID is required for {key}.')
        
        try:
            particular = ParticularPriceMaster.objects.get(id=particular_id)
        except ParticularPriceMaster.DoesNotExist:
            raise ValidationError(f'Particular with ID {particular_id} not found.')
        
        if measurement_id:
            try:
                measurement = Measurements.objects.get(id=measurement_id)
            except:
                raise ValidationError(f'Measurement with ID {measurement_id} not found')
            measurement.measurements = value.get('fields', [])
            measurement.comments = value.get('textarea', '')
            measurement.save()
        else:

            if Measurements.objects.filter(customer=customer, particular=particular).exists():
                raise ValidationError(f'Record for particular ID {particular_id} already exists for this customer.')


            Measurements.objects.create(
                customer=customer,
                particular=particular,
                particular_name=key,
                measurements=value.get('fields', []),
                comments=value.get('textarea', '')
            )

    return Response({'message': 'Form data submitted successfully!', "status":"SUCCESS"})


@api_view(['GET'])
def get_measurements_by_customer(request):
    # import pdb;pdb.set_trace()
    try:
        customer_id = request.GET.get('customerId')
        customer = CustomerDetails.objects.get(id=customer_id)
        measurements = Measurements.objects.filter(customer=customer)
        data = {}
        for measurement in measurements:
            data[measurement.particular_name] = {
                'particular_id': measurement.particular.id,
                'fields': measurement.measurements,
                'textarea': measurement.comments,
                'measurement_id': measurement.id
            }
        return Response({'status': 'SUCCESS', 'data': data})
    except CustomerDetails.DoesNotExist:
        return Response({'status': 'FAIL', 'error': 'Customer not found'})
    except Exception as e:
        return Response({'status': 'FAIL', 'error': str(e)})
    
@api_view(['POST'])
def particular_order_saverr(request):
    print("----- enter to API")
    import pdb;pdb.set_trace()
    data = request.data
    particular_obj = data.get("particular_details")
    # worker_status = data.get("order_details")
    customer_name = data.get("customer_name")
    customer_id = data.get("customer_id")
    total_amount = data.get("total_amount")
    user_id = data.get("user_id")

    if not particular_obj:
        raise ValidationError("Please select particular fields")
    try:
        user = UserDetails.objects.get(id=user_id)
        customer = CustomerDetails.objects.get(id=customer_id)
    except UserDetails.DoesNotExist:
        raise ValidationError("User not found")
    except CustomerDetails.DoesNotExist:
        raise ValidationError("Customer not found")
    
    for row in particular_obj:
        particular_id = row['particular_id']
        particular_name = row['particular_name']
        quantity = row['quantity']
        qty_total_amount = row['qty_total_amount']
        order_date = row['order_date']
        trail_date = row['trail_date']
        delivery_date = row['delivery_date']

        if not particular_id or not particular_name:
            raise ValidationError("please select Particular from List")
        if not quantity:
            raise ValidationError("please select quantity atleast 1")
        if not order_date:
            raise ValidationError("Please Select Order date")
        if not delivery_date:
            raise ValidationError("PLease Select Delivery date")
        try:
            particular = ParticularPriceMaster.objects.get(id=particular_id)
        except ParticularPriceMaster.DoesNotExist:
            raise ValidationError("Particular not found")
        
        order_creation = Orders.objects.create(user=user, customer=customer, particular=particular, particular_name=particular_name, qty=quantity, order_date=order_date, trail_date=trail_date, delivery_date=delivery_date, qty_total_amount=qty_total_amount, bill_no=customer_id)
    
    # for row in particular_obj:
    #     user_id = user_id
    #     order_id = order_creation.id
    #     particular_id = row['particular_id']
    #     qty = row['quantity']
    #     work_status = 'open'


        
    return Response({"status": "SUCCESS", "message":"Form data submitted successfully"})

# @api_view(['POST'])
# def particular_order_save(request):
#     try:
#         json_data = request.data
        
#         particular_details = json_data.get('particular_details', [])
#         total_amount = json_data.get('total_amount', '0.00')
#         customer_name = json_data.get('customer_name', '')
#         customer_id = json_data.get('customer_id', '')
#         user_id = json_data.get('user_id', '')

#         # Fetch user and customer objects
#         user = UserDetails.objects.get(id=user_id)
#         customer = CustomerDetails.objects.get(id=customer_id)

#         # Process each particular detail
#         for detail in particular_details:
#             particular_id = detail.get('particular_id')
#             particular_name = detail.get('particular_name')
#             quantity = detail.get('quantity', 1)
#             qty_total_amount = Decimal(detail.get('qty_total_amount', '0.00'))
#             order_date = detail.get('order_date')  # Assuming order_date is a string in "yyyy-mm-dd" format

#             # Convert order_date_str to datetime object
#             # order_date = datetime.strptime(order_date_str, '%Y-%m-%d').date() if order_date_str else None

#             # Fetch particular object
#             particular = ParticularPriceMaster.objects.get(id=particular_id)

#             # Insert or update Orders table
#             try:
#                 order_instance, created = Orders.objects.get_or_create(
#                     particular=particular,
#                     user=user,
#                     customer=customer,
#                     defaults={
#                         'particular_name': particular_name,
#                         'qty': quantity,
#                         'qty_total_amount': qty_total_amount,
#                         'order_date': order_date,
#                         'trail_date': detail.get('trail_date'),
#                         'delivery_date': detail.get('delivery_date'),
#                     }
#                 )

#                 if not created:
#                     # Update qty_total_amount if record already exists
#                     order_instance.qty_total_amount += qty_total_amount
#                     # Update qty field to reflect total quantity
#                     order_instance.qty += quantity
#                     order_instance.save()
#                 else:
#                     # If created new, just set the qty field
#                     order_instance.qty = quantity
#                     order_instance.save()

#                 # Insert into WorkerStatus table
#                 WorkerStatus.objects.create(
#                     user_id=user,
#                     order_id=order_instance,
#                     particular_id=particular_id,
#                     qty=quantity,
#                     assigned_date=timezone.now(),
#                     completed_date=timezone.now(),
#                     work_status='Open',  # Adjust as per your logic
#                     worker_remark='',
#                     worker_comment='',
#                     remark='',
#                     comment='',
#                     amount=None,  # Adjust as per your logic
#                     paid=None,  # Adjust as per your logic
#                     paid_date=timezone.now(),  # Adjust as per your logic
#                     prepaid=None,  # Adjust as per your logic
#                     prepaid_date=timezone.now(),  # Adjust as per your logic
#                     pay_status='',  # Adjust as per your logic
#                 )

#             except Orders.MultipleObjectsReturned:
#                 # Handle case where multiple Orders instances are found
#                 raise ValidationError('Multiple Orders instances found for the given criteria.')

#         return Response({'message': 'Successfully processed orders.', 'status': 'SUCCESS'})

#     except Exception as e:
#         return Response({'message': str(e), 'status': 'ERROR'}, status=400)

@api_view(['POST'])
def particular_order_save(request):
    import pdb;pdb.set_trace()
    try:
        json_data = request.data
        
        particular_details = json_data.get('particular_details', [])
        order_date = json_data.get('order_date', "")
        total_amount = json_data.get('total_amount', '0.00')
        customer_name = json_data.get('customer_name', '')
        customer_id = json_data.get('customer_id', '')
        user_id = json_data.get('user_id', '')

        # Fetch user and customer objects
        user = UserDetails.objects.get(id=user_id)
        customer = CustomerDetails.objects.get(id=customer_id)

        # Dictionary to store total quantity per particular
        particular_qty_dict = {}

        # Process each particular detail
        for detail in particular_details:
            particular_id = detail.get('particular_id')
            particular_name = detail.get('particular_name')
            quantity = detail.get('quantity', 1)
            qty_total_amount = Decimal(detail.get('qty_total_amount', '0.00'))
            # order_date = detail.get('order_date')  # Assuming order_date is a string in "yyyy-mm-dd" format

            # Validate required fields
            if not (particular_id and particular_name and quantity and order_date):
                raise ValidationError("Missing required fields")

            # Update the total quantity for the particular
            if particular_id in particular_qty_dict:
                particular_qty_dict[particular_id] += quantity
            else:
                particular_qty_dict[particular_id] = quantity
            import pdb;pdb.set_trace()
            # Create new Orders instance
            particular = ParticularPriceMaster.objects.get(id=particular_id)
            order_instance = BaseTable.objects.create(
                user=user,
                user_name = user.username,
                cust_id=customer,
                cust_name=customer_name,
                particular=particular,
                particular_name=particular_name,
                qty=quantity,
                qty_total_amount=qty_total_amount,
                ord_date=order_date,
                trail_date=detail.get('trail_date'),
                delivery_date=detail.get('delivery_date'),

            )
            # order_instance = Orders.objects.create(
            #     user=user,
            #     customer=customer,
            #     particular_id=particular_id,
            #     particular_name=particular_name,
            #     qty=quantity,
            #     qty_total_amount=qty_total_amount,
            #     order_date=order_date,
            #     trail_date=detail.get('trail_date'),
            #     delivery_date=detail.get('delivery_date'),
            # )

            # Insert into WorkerStatus table
            # WorkerStatus.objects.create(
            #     user_id=user,
            #     order_id=order_instance,
            #     particular_id=particular_id,
            #     qty=quantity,
            #     assigned_date=timezone.now(),
            #     completed_date=timezone.now(),
            #     work_status='Open',  # Adjust as per your logic
            #     worker_remark='',
            #     worker_comment='',
            #     remark='',
            #     comment='',
            #     amount=None,  # Adjust as per your logic
            #     paid=None,  # Adjust as per your logic
            #     paid_date=timezone.now(),  # Adjust as per your logic
            #     prepaid=None,  # Adjust as per your logic
            #     prepaid_date=timezone.now(),  # Adjust as per your logic
            #     pay_status='',  # Adjust as per your logic
            # )

        # Update the qty field for each particular based on the total quantity calculated
        # for particular_id, total_qty in particular_qty_dict.items():
        #     Orders.objects.filter(particular_id=particular_id, user=user, customer=customer).update(qty=total_qty)

        return Response({'message': 'Successfully processed orders.', 'status': 'SUCCESS'})

    except Exception as e:
        return Response({'message': str(e), 'status': 'ERROR'}, status=400)
