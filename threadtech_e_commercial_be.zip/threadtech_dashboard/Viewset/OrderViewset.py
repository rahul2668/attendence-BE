from django.shortcuts import render
from django.shortcuts import render, redirect
from django.http import HttpResponse, JsonResponse
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.exceptions import ValidationError
from rest_framework.response import Response
from ..models import Orders, BaseTable
from ..serializers import OrdersSerializer, BaseTableSerializer



@api_view(['GET'])
def order_list(request):
    # order_obj = Orders.objects.all()
    order_obj = BaseTable.objects.all()
    serializer = BaseTableSerializer(order_obj, many=True)
    return Response({"status": "SUCCESS", "body": serializer.data})