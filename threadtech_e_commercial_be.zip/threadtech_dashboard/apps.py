from django.apps import AppConfig


class ThreadtechDashboardConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'threadtech_dashboard'
