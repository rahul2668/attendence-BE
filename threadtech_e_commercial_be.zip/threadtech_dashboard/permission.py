from rest_framework.permissions import BasePermission

class IsAuthenticated(BasePermission):
    def has_permission(self, request, view):
        import pdb;pdb.set_trace()
        excluded_urls = (['/api/login/', '/api/registration/', '/api/register_auth/', '/api/user_view/']) #'/api/change_password/<str:user_name>/<str:email>/<str:password>/
        # import pdb;pdb.set_trace()
        if request.path in excluded_urls:
            return True  
        return request.user and request.user.is_authenticated