from rest_framework import serializers
from .models import RoleMaster,UserDetails, UserAuth, CustomerDetails, ParticularPriceMaster, Orders, BaseTable

class RoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = RoleMaster
        # fields = ['role','active']
        fields=['id','role']


class UserDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserDetails
        # fields = ['user_name', 'email', 'mobile_number', 'address']
        fields = ['username', 'email', 'password']  # Adjust fields as per your model




class UserAuthSerializer(serializers.ModelSerializer):
    class Meta:
        model=UserAuth
        fields=['user_id', 'username', 'email', 'password', 'login_type']
        extra_kwargs = {
            'password': {'write_only': True}
        }

    def create(self, validated_data):
        password = validated_data.pop('password', None)
        instance = self.Meta.model(**validated_data)
        if password is not None:
            instance.set_password(password)
        instance.save()
        return instance

class UserAuthForgetPasswordSerializer(serializers.ModelSerializer):
    class Meta:
        model=UserAuth
        fields=['username', 'email', 'password']
        extra_kwargs= { 'password': {'write_only': True}}

        def update(self, instance, validated_data):
            # import pdb;pdb.set_trace()
            password = validated_data.pop('password', None)
            for attr, value in validated_data.items():
                setattr(instance, attr, value)
            # instance = self.Meta.model(**validated_data)
            if password is not None:
                instance.set_password(password)
            instance.save()
            return instance
        
# class UserAuthResetPasswordSerializer(serializers.ModelSerializer):
#     class Meta:
#         model=UserAuth
#         fields=['username', 'email', 'password']
#         extra_kwargs= { 'password': {'write_only': True}}

#         def update(self, instance, validated_data):
#             import pdb;pdb.set_trace()
#             password = validated_data.pop('password', None)
#             for attr, value in validated_data.items():
#                 setattr(instance, attr, value)
#             # instance = self.Meta.model(**validated_data)
#             if password is not None:
#                 instance.set_password(password)
#             instance.save()
#             return instance
class UserAuthResetPasswordSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserAuth
        fields = ['username', 'email', 'password']
        extra_kwargs = {'password': {'write_only': True}}

    def update(self, instance, validated_data):
        password = validated_data.pop('password', None)
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        if password is not None:
            instance.set_password(password)
        instance.save()
        return instance

class UserAuthLoginSerializer(serializers.ModelSerializer):
    class Meta:
        model=UserAuth
        fields=['user_id', 'user_name', 'email', 'password']
        # extra_kwargs = {
        #     'password': {'write_only': True}
        # }

class CustomerDetailsSerializer(serializers.ModelSerializer):
    customer_id = serializers.CharField(source='id')
    class Meta:
        model = CustomerDetails
        # fields = ['role','active']
        fields=['customer_id','customername', 'role', 'user', 'address', 'email', 'mobile_number']

class CustomerNameSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomerDetails
        # fields = ['role','active']
        fields=['id','customername']

class ParticularPriceMasterSerializer(serializers.ModelSerializer):
    # particular_id = serializers.CharField(source='id')
    class Meta:
        model=ParticularPriceMaster
        fields=['id', 'particular_name', 'customer_price']

class OrdersSerializer(serializers.ModelSerializer):
    order_id = serializers.CharField(source='id')
    customer = serializers.CharField(source='customer.customername', read_only=True)
    order_date = serializers.DateTimeField(format="%Y-%m-%d", required=False)
    trail_date = serializers.DateTimeField(format="%Y-%m-%d", required=False)
    delivery_date = serializers.DateTimeField(format="%Y-%m-%d", required=False)
    class Meta:
        model = Orders
        fields=["order_id",
            "bill_no",
            "particular_name",
            "qty",
            "order_date",
            "trail_date",
            "trail_status",
            "delivery_date",
            "delivery_status",
            "order_status",
            "comments",
            "remark",
            "design_pattern",
            # "qty_total_amount": "500.00",
            # "user": 8,
            "customer",
            
            ]
        # fields = ['role','active']
    # fields=['order_id', 'bill_no', 'customer', 'particular_name', 'qty', 
    # 'order_date',
    # 'trail_date',
    # 'trail_status',
    # 'delivery_date',
    # 'delivery_status',
    # 'order_status',
    # 'comments',
    # 'remark',
    # 'design_pattern',
    # ]
    # qty_total_amount = models.DecimalField(max_digits=7, decimal_places=2, default=0.00)




# 67,68,70,78,71,79,72,80,73,74,75,76,

class BaseTableSerializer(serializers.ModelSerializer):
    # order_id = serializers.CharField(source='id')
    customer = serializers.CharField(source='cust_name', read_only=True)
    order_date = serializers.DateTimeField(format="%Y-%m-%d", required=False)
    trail_date = serializers.DateTimeField(format="%Y-%m-%d", required=False)
    delivery_date = serializers.DateTimeField(format="%Y-%m-%d", required=False)
    class Meta:
        model = BaseTable
        fields=[
            # "order_id",
            "bill_no",
            "particular_name",
            "qty",
            "order_date",
            "trail_date",
            "trail_status",
            "delivery_date",
            "delivery_status",
            "ord_status",
            "ord_comments",
            "ord_remark",
            "design_pattern",
            # "qty_total_amount": "500.00",
            # "user": 8,
            "customer",
            
            ]


