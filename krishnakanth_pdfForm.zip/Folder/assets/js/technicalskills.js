function addSkillRow() {
    const tableBody = document.querySelector('#skillsTable tbody');

    const newRow = document.createElement('tr');
    newRow.innerHTML = `
        <td><input type="text" class="form-control" name="left_column[]" required></td>
        <td><input type="text" class="form-control" name="right_column[]" required></td>
        <td><button type="button" class="btn btn-danger" onclick="removeSkillRow(this)">Remove</button></td>
    `;

    tableBody.appendChild(newRow);
}

function removeSkillRow(button) {
    const row = button.closest('tr');
    row.remove();
}