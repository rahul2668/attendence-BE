function addEducation() {
    const educationContainer = document.getElementById('educationContainer');
    const newEducationSection = document.createElement('div');
    newEducationSection.classList.add('education', 'border', 'rounded', 'p-3', 'mb-3');

    newEducationSection.innerHTML = `
        <label for="education">Education:</label>
        <div class="form-group">
            <label for="course">Course:</label>
            <input type="text" class="form-control" name="course[]" required>
        </div>
        <div class="form-group">
            <label for="branch">Branch/Specialization:</label>
            <input type="text" class="form-control" name="branch[]" required>
        </div>
        <div class="form-group">
            <label for="college">College/School:</label>
            <input type="text" class="form-control" name="college[]" required>
        </div>
        <div class="form-group">
            <label for="year_from">Year From:</label>
            <input type="number" class="form-control" name="year_from[]" min="1950" max="2030" placeholder="Enter year">
        </div>
        <div class="form-group">
            <label for="year_to">Year To:</label>
            <input type="text" class="form-control" name="year_to[]" max="2030" min="1950" placeholder="Enter year or 'Present'" >
        </div>
       
        <button type="button" class="btn btn-danger remove-btn" onclick="removeEducation(this)">Remove Education</button>
    `;

    educationContainer.appendChild(newEducationSection);
}

function removeEducation(button) {
    button.closest('.education').remove();
}