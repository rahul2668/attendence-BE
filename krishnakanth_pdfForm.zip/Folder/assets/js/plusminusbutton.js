document.addEventListener('DOMContentLoaded', function() {
    const container = document.getElementById('profile-container');
    container.addEventListener('click', function(event) {
        if (event.target.classList.contains('add-profile-field')) {
            addProfile(event);
        } else if (event.target.classList.contains('remove-profile-field')) {
            const profileBoxes = document.querySelectorAll('.profile-box');
            if (profileBoxes.length > 1) {
                const profileBox = event.target.parentNode;
                profileBox.parentNode.removeChild(profileBox);
                renumberProfiles();
            } else {
                profileBoxes[0].querySelector('textarea').value = '';
            }
        }
    });
});

function addProfile(event) {
    const clickedButton = event.target;
    const newProfileBox = clickedButton.parentNode.cloneNode(true);
    const profileNumber = document.querySelectorAll('.profile-box').length + 1;
    const label = newProfileBox.querySelector('label');
    label.innerText = `${profileNumber}:`;
    const textarea = newProfileBox.querySelector('textarea');
    textarea.setAttribute('id', `profile${profileNumber}`);
    textarea.setAttribute('name', `profile${profileNumber}`);
    textarea.value = '';
    clickedButton.parentNode.parentNode.insertBefore(newProfileBox, clickedButton.parentNode.nextSibling);
    renumberProfiles();
}

function renumberProfiles() {
    const profileBoxes = document.querySelectorAll('.profile-box');
    profileBoxes.forEach((box, index) => {
        const profileNumber = index + 1;
        const label = box.querySelector('label');
        label.innerText = `${profileNumber}:`;
        const textarea = box.querySelector('textarea');
        textarea.setAttribute('id', `profile${profileNumber}`);
        textarea.setAttribute('name', `profile${profileNumber}`);
    });
}