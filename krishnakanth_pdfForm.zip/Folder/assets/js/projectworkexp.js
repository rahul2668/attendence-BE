        let projectCount = 1;
        // let workExperienceCount = 1;

        function addProject() {
            projectCount++;
            const container = document.getElementById('projectsContainer');
            const projectDiv = document.createElement('div');
            projectDiv.classList.add('project', 'border', 'rounded', 'p-3', 'mb-3');
            projectDiv.innerHTML = `
                <h3>Project - ${projectCount}</h3>
                <div class="form-group">
                    <label for="project${projectCount}_name">Project Name:</label>
                    <input type="text" class="form-control" id="project${projectCount}_name" name="project${projectCount}_name" required>
                </div>
                <div class="form-group">
                    <label for="project${projectCount}_client">Client:</label>
                    <input type="text" class="form-control" id="project${projectCount}_client" name="project${projectCount}_client">
                </div>
                <div class="form-group">
                    <label for="project${projectCount}_role">Role:</label>
                    <input type="text" class="form-control" id="project${projectCount}_role" name="project${projectCount}_role">
                </div>
                <div class="form-group">
                    <label for="project${projectCount}_application">Application:</label>
                    <input type="text" class="form-control" id="project${projectCount}_application" name="project${projectCount}_application">
                </div>
                <div class="form-group">
                    <label for="project${projectCount}_environment">Environment:</label>
                    <input type="text" class="form-control" id="project${projectCount}_environment" name="project${projectCount}_environment">
                </div>
                <div class="form-group">
                    <label for="project${projectCount}_description">Description:</label>
                    <textarea class="form-control" id="project${projectCount}_description" name="project${projectCount}_description" rows="3"></textarea>
                </div>
                <div class="form-group">
                    <label for="project_responsibilities${projectCount}">Project Responsibilities:</label>
                    <div id="project-responsibilities-container${projectCount}">
                        <div class="responsibility-box">
                            <label for="project${projectCount}_responsibility1">1:</label>
                            <textarea class="form-control responsibility-input" id="project${projectCount}_responsibility1" name="project${projectCount}_responsibility1" rows="1"></textarea>
                            <button type="button" class="btn btn-success add-responsibility-field" title="Add Project Responsibility">+</button>
                            <button type="button" class="btn btn-danger remove-responsibility-field" title="Remove Project Responsibility">-</button>
                        </div>
                    </div>
                </div>
                <button type="button" class="btn btn-danger remove-btn" onclick="removeProject(this)">Remove Project</button>
            `;
            container.appendChild(projectDiv);
            updateProjectIDs(); // Call the updateProjectIDs function to ensure sequential IDs
        }

        function removeProject(button) {
            const container = document.getElementById('projectsContainer');
            container.removeChild(button.parentNode);
            updateProjectIDs();
        }

        function updateProjectIDs() {
            const projects = document.querySelectorAll('.project');
            projectCount = 1;
            projects.forEach((project) => {
                const inputs = project.querySelectorAll('input, textarea');
                inputs.forEach((input) => {
                    const id = input.getAttribute('id');
                    if (id) {
                        const newID = id.replace(/\d+/, projectCount);
                        input.setAttribute('id', newID);
                        input.setAttribute('name', newID);
                    }
                });
                project.querySelector('h3').innerText = `Project - ${projectCount}`;
                projectCount++;
            });
        }

        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('projectsContainer').addEventListener('click', function(event) {
                if (event.target.classList.contains('add-responsibility-field')) {
                    const containerId = event.target.closest('.project').querySelector('.form-group div').id;
                    const projectIndex = containerId.match(/\d+/)[0];
                    const responsibilityBox = event.target.parentNode;
                    const newResponsibilityBox = createResponsibilityBox(projectIndex);
                    responsibilityBox.parentNode.insertBefore(newResponsibilityBox, responsibilityBox.nextSibling);
                    renumberResponsibilities(projectIndex);
                } else if (event.target.classList.contains('remove-responsibility-field')) {
                    const containerId = event.target.closest('.project').querySelector('.form-group div').id;
                    const projectIndex = containerId.match(/\d+/)[0];
                    const responsibilityBoxes = document.querySelectorAll(`#project-responsibilities-container${projectIndex} .responsibility-box`);
                    if (responsibilityBoxes.length > 1) {
                        const responsibilityBox = event.target.parentNode;
                        responsibilityBox.parentNode.removeChild(responsibilityBox);
                        renumberResponsibilities(projectIndex);
                    } else {
                        responsibilityBoxes[0].querySelector('textarea').value = '';
                    }
                }
            });
        });

        function createResponsibilityBox(projectIndex) {
            const defaultBox = document.querySelector(`#project-responsibilities-container${projectIndex} .responsibility-box`);
            const newResponsibilityBox = defaultBox.cloneNode(true);
            
            const index = document.querySelectorAll(`#project-responsibilities-container${projectIndex} .responsibility-box`).length + 1;
            
            newResponsibilityBox.querySelector('label').innerText = `${index}:`;
            const textarea = newResponsibilityBox.querySelector('textarea');
            textarea.setAttribute('id', `project${projectIndex}_responsibility${index}`);
            textarea.setAttribute('name', `project${projectIndex}_responsibility${index}`);
            textarea.value = '';
            
            return newResponsibilityBox;
        }

        function renumberResponsibilities(projectIndex) {
            const responsibilityBoxes = document.querySelectorAll(`#project-responsibilities-container${projectIndex} .responsibility-box`);
            responsibilityBoxes.forEach((box, index) => {
                box.querySelector('label').innerText = `${index + 1}:`;
                const textarea = box.querySelector('textarea');
                textarea.setAttribute('id', `project${projectIndex}_responsibility${index + 1}`);
                textarea.setAttribute('name', `project${projectIndex}_responsibility${index + 1}`);
            });
        }

        let workExperienceCount = 1;

        function addWorkExperience() {
            workExperienceCount++;
            const container = document.getElementById('workExperienceContainer');
            const workExperienceDiv = document.createElement('div');
            workExperienceDiv.classList.add('workExperience', 'border', 'rounded', 'p-3', 'mb-3');
            workExperienceDiv.innerHTML = `
                <h3>Work Experience - ${workExperienceCount}</h3>
                <div class="form-group">
                    <label for="work${workExperienceCount}_title">Role:</label>
                    <input type="text" class="form-control" id="work${workExperienceCount}_title" name="work${workExperienceCount}_title" required>
                </div>
                <div class="form-group">
                    <label for="work${workExperienceCount}_company">Company:</label>
                    <input type="text" class="form-control" id="work${workExperienceCount}_company" name="work${workExperienceCount}_company" required>
                </div>
                <div class="form-group">
                    <label for="work${workExperienceCount}_from">From:</label>
                    <input type="text" class="form-control" id="work${workExperienceCount}_from" name="work${workExperienceCount}_from" placeholder="Select month and year" >
                </div>
                <div class="form-group">
                    <label for="work${workExperienceCount}_to">To:</label>
                    <input type="text" class="form-control" id="work${workExperienceCount}_to" name="work${workExperienceCount}_to" placeholder="Select month and year">
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="work${workExperienceCount}_marked" name="work${workExperienceCount}_marked">
                    <label class="form-check-label" for="work${workExperienceCount}_marked">currently working</label>
                </div>
                <button type="button" class="btn btn-danger remove-btn" onclick="removeWorkExperience(this)">Remove Work Experience</button>
            `;
            container.appendChild(workExperienceDiv);
            updateWorkExperienceIDs(); // Call the updateWorkExperienceIDs function to ensure sequential IDs

            // Initialize Flatpickr for the new input fields
            const options = {
                dateFormat: "M Y", // Format: Month Year
                enableTime: false, // Disable time selection
                minDate: new Date(1900, 0, 1) // Optional: Set minimum date to 1900
            };

            flatpickr(`#work${workExperienceCount}_from`, options);
            flatpickr(`#work${workExperienceCount}_to`, options);
        }

        function removeWorkExperience(button) {
            const container = document.getElementById('workExperienceContainer');
            container.removeChild(button.parentNode);
            updateWorkExperienceIDs();
        }

        function updateWorkExperienceIDs() {
            const workExperiences = document.querySelectorAll('.workExperience');
            workExperienceCount = 1;
            workExperiences.forEach((workExperience) => {
                const inputs = workExperience.querySelectorAll('input');
                inputs.forEach((input) => {
                    const id = input.getAttribute('id');
                    if (id) {
                        const newID = id.replace(/\d+/, workExperienceCount);
                        input.setAttribute('id', newID);
                        input.setAttribute('name', newID);
                    }
                });
                workExperience.querySelector('h3').innerText = `Work Experience - ${workExperienceCount}`;
                workExperienceCount++;
            });

            // Reinitialize Flatpickr for all the date fields
            document.querySelectorAll('.workExperience .form-control').forEach((input) => {
                if (input.id.includes('from') || input.id.includes('to')) {
                    flatpickr(`#${input.id}`, {
                        dateFormat: "M Y",
                        enableTime: false,
                        minDate: new Date(1900, 0, 1)
                    });
                }
            });
        }

        // Initial Flatpickr setup for the first work experience
        document.addEventListener('DOMContentLoaded', function() {
            const options = {
                dateFormat: "M Y", // Format: Month Year
                enableTime: false, // Disable time selection
                minDate: new Date(1900, 0, 1) // Optional: Set minimum date to today
            };

            flatpickr("#work1_from", options);
            flatpickr("#work1_to", options);
        });
        
