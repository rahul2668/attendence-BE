from django.urls import path
from . import views

urlpatterns = [
    
    path('home',views.home, name='home'),
    path('',views.signuppage, name='signup'),
    path('page/',views.page, name='page'),
    path('login/',views.loginpage, name='login'),
    path('logout/',views.logoutpage, name='logout'),

    # path('form/',views.form, name='form'),
   
]