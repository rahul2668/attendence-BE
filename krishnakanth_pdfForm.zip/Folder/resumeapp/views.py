from django.shortcuts import render, redirect
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponse
from datetime import datetime
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db import IntegrityError

@login_required(login_url='login')
def home(request):
    return render(request, 'home.html')


def signuppage(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password1 = request.POST['password1']
        password2 = request.POST['password2']

        if password1 == password2:
            try:
                if User.objects.filter(username=username).exists():
                    messages.error(request, 'Username already exists')
                elif User.objects.filter(email=email).exists():
                    messages.error(request, 'Email already exists')
                else:
                    user = User.objects.create_user(username=username, email=email, password=password1)
                    user.save()
                    # messages.success(request, 'User created successfully')
                    return redirect('login')
            except IntegrityError:
                messages.error(request, 'An error occurred while creating the user')
        else:
            messages.error(request, 'Passwords do not match')
    
    return render(request, 'signup.html')


def loginpage(request):
    if request.method=='POST':
        username=request.POST.get('username')
        pass1=request.POST.get('pass')
        user=authenticate(request,username=username,password=pass1)
        if user is not None:
            login(request,user)
            return redirect('home')
        else:
            # return HttpResponse("Username or Password is incorrect.")

            messages.error(request, 'Username or Password is incorrect.')
            # return redirect('login')
    return render (request,'login.html')


def logoutpage(request):
    logout(request)
    return redirect('login')
# def form(request):
#     return render(request, 'form.html') 

@csrf_exempt
def page(request):
    if request.method == 'POST':
        projects = []
        i = 1
        while True:
            project_name = request.POST.get(f'project{i}_name')
            if not project_name:
                break

            responsibilities = []
            j = 1
            while True:
                responsibility = request.POST.get(f'project{i}_responsibility{j}')
                if not responsibility:
                    break
                responsibilities.append(responsibility)
                j += 1

            # print(responsibilities)
            project = {
                'name': project_name,
                'client': request.POST.get(f'project{i}_client'),
                'role': request.POST.get(f'project{i}_role'),
                'application': request.POST.get(f'project{i}_application'),
                'environment': request.POST.get(f'project{i}_environment'),
                'description': request.POST.get(f'project{i}_description'),
                'responsibilities': responsibilities
            }
            projects.append(project)
            i += 1
            # print(final)

           

        # Fetch work experience data
        work_experiences = []
        j = 1
        while True:
            work_title = request.POST.get(f'work{j}_title')
            if not work_title:
                break
            work_experience = {
                'title': work_title,
                'company': request.POST.get(f'work{j}_company'),
                # 'duration': request.POST.get(f'work{j}_duration'),
                'from': request.POST.get(f'work{j}_from'),
                'to': request.POST.get(f'work{j}_to'),
                'marked': request.POST.get(f'work{j}_marked') == 'on'
                # 'duties': request.POST.get(f'work{j}_duties').split(',')
            }
            work_experiences.append(work_experience)
            j += 1
        print(work_experiences)

        profile_sections = []  # Initialize list for professional summary sections
        k = 1
        while True:
            profile_section = request.POST.get(f'profile{k}')
            if not profile_section:
                break
            profile_sections.append(profile_section)
            k += 1
        # print(profile_sections)

        educations = []
        for i in range(len(request.POST.getlist('course[]'))):
            education = {
                'course': request.POST.getlist('course[]')[i],
                'branch': request.POST.getlist('branch[]')[i],
                'college': request.POST.getlist('college[]')[i],
                'year_from': request.POST.getlist('year_from[]')[i],
                'year_to': int(request.POST.getlist('year_to[]')[i])
                # 'others': request.POST.getlist('others[]')[i]
            }
            educations.append(education)
            # print(type(request.POST.getlist('year_to[]')[i]))

        skills_left = request.POST.getlist('left_column[]')
        skills_right = request.POST.getlist('right_column[]')
        skills = [{'left': left, 'right': right} for left, right in zip(skills_left, skills_right)]
       
        current_year = datetime.now().year
        # print(type(current_year))

        context = {
            'name': request.POST.get('name'),
            # 'email': request.POST.get('email'),
            # 'phone': request.POST.get('phone'),
            # 'address': request.POST.get('address'),
            'profile': profile_sections,
            'work_experience': work_experiences,
            'educations': educations,
            'skills': skills,
            'projects': projects,
            'this_year': current_year
        }
        # print(context['educations'])
        return render(request, 'page.html', context)
    else:
        return render(request, 'form.html')
    