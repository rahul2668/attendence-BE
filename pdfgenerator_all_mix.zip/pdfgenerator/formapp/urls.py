from django.urls import path
from . import views

urlpatterns = [

    # path('', views.input_json_upload, name='input_json_upload'),
    # path('process_json/', views.process_json, name='process_json'),
    path('generate_pdf/', views.generate_pdf, name='generate_pdf'),   # final
    path('upload_and_review/', views.upload_and_review, name='upload_and_review'),  #final
    
    
    # path('api_process_json/', views.api_process_json, name='process_json'),
    # path('api_generate_pdf/', views.api_generate_pdf, name='generate_pdf'),
    # path('api_upload_and_review/', views.api_upload_and_review, name='upload_and_review'),
]
