from django.db import models

class FormData(models.Model):
    username = models.CharField(max_length=50)
    file_name = models.TextField()
    json_data = models.TextField()
    class Meta:
        db_table = 'formData'


    # def __str__(self):
    #     return f"Form Data ID: {self.id}"
    
    # @classmethod
    # def create(cls, username, file_name, json_data):
    #     form_data = cls(username=username, file_name=file_name, json_data=json_data)
    #     form_data.save()
    #     return form_data
