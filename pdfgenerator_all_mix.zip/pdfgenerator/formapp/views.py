from django.shortcuts import render
from django.http import HttpResponse, HttpResponseBadRequest
from xhtml2pdf import pisa
import json
from .models import FormData


# upload file without validation
# def upload_and_review(request):
#     if request.method == 'POST':
#         json_data_str = request.POST.get('json_data')
#         html_template_file = request.FILES.get('html_template')

#         if not json_data_str or not html_template_file:
#             return HttpResponseBadRequest('Please provide JSON data and upload an HTML template.')

#         try:
#             json_data = json.loads(json_data_str)
#         except json.JSONDecodeError as e:
#             return HttpResponseBadRequest(f'Invalid JSON data: {e}')

#         html_content = html_template_file.read().decode('utf-8')

#         # Replace placeholders in the HTML template with JSON data values
#         for key, value in json_data.items():
#             placeholder = f'{{{{ json_data.{key} }}}}'
#             html_content = html_content.replace(placeholder, str(value))

#         # Render the HTML content within a template to include the "Generate PDF" form
#         context = {
#             'html_content': html_content,
#             'json_data': json_data,
#         }
#         return render(request, 'jsonapp/review.html', context)

#     return render(request, 'jsonapp/upload.html')



# upload file with validation of JSON
def upload_and_review(request):
    if request.method == 'POST':
        json_data_str = request.POST.get('json_data')
        html_template_file = request.FILES.get('html_template')

        if not json_data_str:
            error_message = 'Please provide JSON data.'
            return render_error(request, error_message)

        try:
            json_data = json.loads(json_data_str)
        except json.JSONDecodeError as e:
            error_message = f'Invalid JSON data: {e}'
            return render_error(request, error_message)

        mandatory_fields = {
            'display_name': str,
            'name': str,
            'first_name': str,
            'last_name': str,
            'email': str,
            'password': str,
            'active': bool,
        }

        for field, expected_type in mandatory_fields.items():
            if field not in json_data:
                error_message = f'Missing mandatory field: {field}'
                return render_error(request, error_message)
            if not json_data[field]:
                error_message = f'Empty value for field: {field}'
                return render_error(request, error_message)
            if not isinstance(json_data[field], expected_type):
                error_message = f'Invalid type for field {field}. Expected {expected_type.__name__}'
                return render_error(request, error_message)

        html_content = html_template_file.read().decode('utf-8')

        for key, value in json_data.items():
            placeholder = f'{{{{ json_data.{key} }}}}'
            html_content = html_content.replace(placeholder, str(value))

        context = {
            'html_content': html_content,
            'json_data': json_data,
        }
        # print("*********", context)
        # return render(request, 'jsonapp/review.html', context)
        return render(request, 'jsonapp/review.html', context)

    return render(request, 'jsonapp/upload.html')

def render_error(request, error_message):
    context = {
        'error_message': error_message,
    }
    return render(request, 'jsonapp/error.html', context)


# def generate_pdf(request):
#     if request.method == 'POST':
#         html_content = request.POST.get('html_content')
#         if not html_content:
#             return HttpResponseBadRequest('No HTML content found in the request.')

#         response = HttpResponse(content_type='application/pdf')
#         response['Content-Disposition'] = 'attachment; filename="pdf_data.pdf"'

#         pisa_status = pisa.CreatePDF(html_content, dest=response)

#         if pisa_status.err:
#             return HttpResponse(f'We had some errors with code {pisa_status.err}')

#         return response

#     return HttpResponseBadRequest('Invalid request method.')



############################### API


def api_process_json(request):
    if request.method == 'POST':
        try:
            json_data = json.loads(request.POST.get('json_data'))
            return render(request, 'jsonapp/review_page.html', {'json_data': json_data})
        except json.JSONDecodeError as e:
            return render(request, 'jsonapp/error.html', {'error_message': str(e)})
    return render(request, 'jsonapp/input_json.html')

# def api_upload_and_review(request):
#     if request.method == 'POST':
#         json_data_str = request.POST.get('json_data')
#         html_template_file = request.FILES.get('html_template')

#         if not json_data_str or not html_template_file:
#             return HttpResponseBadRequest('Please provide JSON data and upload an HTML template.')

#         try:
#             json_data = json.loads(json_data_str)
#         except json.JSONDecodeError as e:
#             return HttpResponseBadRequest(f'Invalid JSON data: {e}')

#         html_content = html_template_file.read().decode('utf-8')

#         for key, value in json_data.items():
#             placeholder = f'{{{{ json_data.{key} }}}}'
#             html_content = html_content.replace(placeholder, str(value))

#         context = {
#             'html_content': html_content,
#             'json_data': json_data,
#         }
#         return render(request, 'jsonapp/reviewapi.html', context)

#     return render(request, 'jsonapp/uploadapi.html')

def api_upload_and_review(request):
    if request.method == 'POST':
        json_data_str = request.POST.get('json_data')
        html_template_file = request.FILES.get('html_template')

        if not json_data_str or not html_template_file:
            return HttpResponseBadRequest('Please provide JSON data and upload an HTML template.')

        try:
            json_data = json.loads(json_data_str)
        except json.JSONDecodeError as e:
            return HttpResponseBadRequest(f'Invalid JSON data: {e}')

        html_content = html_template_file.read().decode('utf-8')

        for key, value in json_data.items():
            placeholder = f'{{{{ json_data.{key} }}}}'
            html_content = html_content.replace(placeholder, str(value))

        context = {
            'html_content': html_content,
            'json_data': json_data,
        }
        return render(request, 'jsonapp/reviewapi.html', context)

    return render(request, 'jsonapp/uploadapi.html')

# def api_generate_pdf(request):
#     if request.method == 'POST':
#         html_content = request.POST.get('html_content')
#         if not html_content:
#             return HttpResponseBadRequest('No HTML content found in the request.')

#         response = HttpResponse(content_type='application/pdf')
#         response['Content-Disposition'] = 'attachment; filename="pdftype2data.pdf"'

#         pisa_status = pisa.CreatePDF(html_content, dest=response)

#         if pisa_status.err:
#             return HttpResponse(f'We had some errors with code {pisa_status.err}')

#         return response

#     return HttpResponseBadRequest('Invalid request method.')



from django.http import JsonResponse, HttpResponseBadRequest, HttpResponse
from django.shortcuts import redirect
from django.urls import reverse
from xhtml2pdf import pisa
import json

def generate_pdf(request):
    if request.method == 'POST':
        html_content = request.POST.get('html_content')
        json_data_str = request.POST.get('json_data')
    
        if not html_content:
            return HttpResponseBadRequest('No HTML content found in the request.')
        if not json_data_str:
            return HttpResponseBadRequest('No JSON data found in the request.')

        json_data_str_corrected = json_data_str.replace("'", '"')

        
        response = HttpResponse(content_type='application/pdf')
        response['Content-Disposition'] = 'attachment; filename="pdf_data.pdf"'

        pisa_status = pisa.CreatePDF(html_content, dest=response)

        if pisa_status.err:
            return HttpResponse(f'We had some errors with code {pisa_status.err}')

        try:
            json_data = json_data_str_corrected
            first_name='test'
            file_name='test2'
            form_data = FormData(username=first_name, file_name=file_name, json_data=json_data)
            form_data.save()
        except json.JSONDecodeError as e:
            return HttpResponseBadRequest(f'Error decoding JSON: {str(e)}')
        except Exception as e:
            return HttpResponseBadRequest(f'Error saving data: {str(e)}')


        return response

    return HttpResponseBadRequest('Invalid request method.')

