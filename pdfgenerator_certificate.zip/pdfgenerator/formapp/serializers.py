from rest_framework import serializers

class FileUploadSerializer(serializers.Serializer):
    json_data = serializers.CharField()
    html_template = serializers.FileField()