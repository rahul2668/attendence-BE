INSERT INTO public.utils_function (
        function_name,
        description,
        record_status,
        module_id,
        function_code,
        sort_order
    )
VALUES ('Users', NULL, true, 'USRCTRL', 'USERS', 1),
    ('Roles', NULL, true, 'USRCTRL', 'ROLES', 2),
    (
        'Furnace Material Maintenance',
        NULL,
        true,
        'MSTRDATA',
        'FUR_MNT',
        1
    ),
    (
        'Additive Maintenance',
        NULL,
        true,
        'MSTRDATA',
        'ADD_MNT',
        2
    ),
    (
        'By Products',
        NULL,
        true,
        'MSTRDATA',
        'BY_PROD',
        3
    ),
    (
        'WIP Maintenance',
        NULL,
        true,
        'MSTRDATA',
        'WIP_MNT',
        4
    ),
    (
        'Standard BOM',
        NULL,
        true,
        'MSTRDATA',
        'STD_BOM',
        5
    ),
    (
        'Active Furnace List',
        NULL,
        true,
        'MSTRDATA',
        'ACT_FUR',
        6
    ),
    (
        'Customer Specifications',
        NULL,
        true,
        'MSTRDATA',
        'CUSTSPEC',
        7
    ),
    (
        'Heat Maintenance',
        NULL,
        true,
        'COREPROC',
        'HEAT_MNT',
        1
    );
INSERT INTO public.utils_function (
        function_name,
        description,
        record_status,
        module_id,
        function_code,
        sort_order
    )
VALUES (
        'Bin Content',
        NULL,
        true,
        'COREPROC',
        'BIN_CNT',
        2
    ),
    (
        'Production Schedule',
        NULL,
        true,
        'COREPROC',
        'PROD_SCH',
        3
    ),
    (
        'Silicon Grade Material Maintenance',
        NULL,
        true,
        'COREPROC',
        'SIL_MAT',
        4
    ),
    (
        'Silicon Grade Heat Maintenance',
        NULL,
        true,
        'COREPROC',
        'SIL_HEAT',
        5
    ),
    (
        'Heat Analysis',
        NULL,
        true,
        'LABANLYS',
        'HEAT_ANA',
        1
    ),
    (
        'Ladle Additive Analysis',
        NULL,
        true,
        'LABANLYS',
        'LAD_ANA',
        2
    ),
    (
        'Ladle Product',
        NULL,
        true,
        'LABANLYS',
        'LAD_PROD',
        3
    ),
    (
        'Furnace Mix & Fume Analysis',
        NULL,
        true,
        'LABANLYS',
        'FUR_FUME',
        4
    ),
    (
        'Spout (Tap) Analysis',
        NULL,
        true,
        'LABANLYS',
        'SPT_ANA',
        5
    ),
    (
        'Furnace Mix Lab Analysis',
        NULL,
        true,
        'LABANLYS',
        'FUR_LAB',
        6
    );
INSERT INTO public.utils_function (
        function_name,
        description,
        record_status,
        module_id,
        function_code,
        sort_order
    )
VALUES (
        'Primary Heat Report',
        NULL,
        true,
        'REPORTS',
        'PRM_HEAT',
        4
    ),
    (
        'Prod Schedule Analysis',
        NULL,
        true,
        'REPORTS',
        'SCH_ANA',
        5
    ),
    (
        'Material Analysis Report',
        NULL,
        true,
        'REPORTS',
        'MAT_ANA',
        1
    ),
    (
        'Material Consumption Report',
        NULL,
        true,
        'REPORTS',
        'MAT_CON',
        3
    ),
    (
        'Material Analysis Size Report',
        NULL,
        true,
        'REPORTS',
        'MAT_SZE',
        2
    ),
    (
        'Plant Configuration',
        NULL,
        true,
        'SYSADMN',
        'PLT_CFG',
        1
    ),
    (
        'Furnace Configuration',
        NULL,
        true,
        'SYSADMN',
        'FUR_CFG',
        2
    ),
    (
        'Furnace Bed Log',
        NULL,
        true,
        'LOGBOOK',
        'FUR_BED',
        1
    ),
    (
        'Tap Hole Log',
        NULL,
        true,
        'LOGBOOK',
        'TAP_LOG',
        2
    ),
    (
        'Furnace Downtime Log',
        NULL,
        true,
        'LOGBOOK',
        'DWN_LOG',
        3
    ),
    (
        'Furnace Downtime Log - Event',
        NULL,
        true,
        'LOGBOOK',
        'DWN_EVT',
        4
    );
INSERT INTO public.utils_function (
        function_name,
        description,
        record_status,
        module_id,
        function_code,
        sort_order
    )
VALUES (
        'Furnace Downtime Log - Split',
        NULL,
        true,
        'LOGBOOK',
        'DWN_SPLT',
        5
    );