INSERT INTO public.log_book_category_master (category, log_name, category_code)
VALUES ('Auto Collapse', 'FurnaceBed', 'AUTO_COL'),
    (
        'Electrode - Auto Lining Wideness',
        'FurnaceBed',
        'ELEC_ALW'
    ),
    (
        'Noise when Collapsing',
        'FurnaceBed',
        'NOIS_COL'
    ),
    (
        'Electrode Blows Direction',
        'FurnaceBed',
        'ELEC_BD'
    ),
    (
        'Electrode Crust Formation',
        'FurnaceBed',
        'ELEC_CF'
    ),
    ('Bed Conditions', 'FurnaceBed', 'BED_COND'),
    ('Activity Homogeneity', 'FurnaceBed', 'ACT_HOM'),
    ('Flame', 'TapHole', 'FLAME'),
    ('Flame Colour', 'TapHole', 'FLM_COL'),
    ('Tap Hole Bottom', 'TapHole', 'TH_BOT');
INSERT INTO public.log_book_category_master (category, log_name, category_code)
VALUES ('Metal Output', 'TapHole', 'MET_OUT'),
    ('Furnace Tapping', 'TapHole', 'FUR_TAP'),
    ('Slag', 'TapHole', 'SLAG'),
    ('Flame Intensity', 'TapHole', 'FLM_INT');