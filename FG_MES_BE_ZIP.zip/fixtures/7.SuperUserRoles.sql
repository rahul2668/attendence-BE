INSERT INTO public.users_user_roles (user_id, role_id)
VALUES (1, 1);