INSERT INTO public.utils_module (
        module_name,
        description,
        module_code,
        sort_order
    )
VALUES ('User Access Control', null, 'USRCTRL', 2),
    ('Master Data', null, 'MSTRDATA', 3),
    ('Core Process', null, 'COREPROC', 4),
    ('Lab Analysis', null, 'LABANLYS', 5),
    ('Reports', null, 'REPORTS', 7),
    ('System Admin', null, 'SYSADMN', 1),
    ('Log Book', null, 'LOGBOOK', 6);