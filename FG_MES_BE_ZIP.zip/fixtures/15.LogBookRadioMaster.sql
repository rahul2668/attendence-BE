INSERT INTO public.log_book_radio_master (value, log_category_master_id, radio_code)
VALUES ('Yes', 'AUTO_COL', 'LBRD_001'),
     ('No', 'AUTO_COL', 'LBRD_002'),
     ('Wide', 'ELEC_ALW', 'LBRD_003'),
     ('Narrow', 'ELEC_ALW', 'LBRD_004'),
     ('Roaring', 'NOIS_COL', 'LBRD_005'),
     ('No Noise', 'NOIS_COL', 'LBRD_006'),
     ('Vertical', 'ELEC_BD', 'LBRD_007'),
     ('Angle', 'ELEC_BD', 'LBRD_008'),
     ('Yes', 'ELEC_CF', 'LBRD_009'),
     ('No', 'ELEC_CF', 'LBRD_010');
INSERT INTO public.log_book_radio_master (value, log_category_master_id, radio_code)
VALUES ('Soft', 'BED_COND', 'LBRD_011'),
     ('Gummy', 'BED_COND', 'LBRD_012'),
     ('Hard', 'BED_COND', 'LBRD_013'),
     ('Even', 'ACT_HOM', 'LBRD_014'),
     ('Centre', 'ACT_HOM', 'LBRD_015'),
     ('Electrode 1', 'ACT_HOM', 'LBRD_016'),
     ('Electrode 2', 'ACT_HOM', 'LBRD_017'),
     ('Electrode 3', 'ACT_HOM', 'LBRD_018'),
     ('Yes', 'FLAME', 'LBRD_019'),
     ('No', 'FLAME', 'LBRD_020');
INSERT INTO public.log_book_radio_master (value, log_category_master_id, radio_code)
VALUES ('White', 'FLM_COL', 'LBRD_021'),
     ('Red', 'FLM_COL', 'LBRD_022'),
     ('Hard', 'TH_BOT', 'LBRD_023'),
     ('Soft', 'TH_BOT', 'LBRD_024'),
     ('Bottom', 'MET_OUT', 'LBRD_025'),
     ('Top', 'MET_OUT', 'LBRD_026'),
     ('Easy', 'FUR_TAP', 'LBRD_027'),
     ('Intermediate', 'FUR_TAP', 'LBRD_028'),
     ('Difficult', 'FUR_TAP', 'LBRD_029'),
     ('Sticky', 'SLAG', 'LBRD_030');
INSERT INTO public.log_book_radio_master (value, log_category_master_id, radio_code)
VALUES ('Normal', 'SLAG', 'LBRD_031'),
     ('Lumpy', 'SLAG', 'LBRD_032'),
     ('None', 'FLM_INT', 'LBRD_033'),
     ('Light', 'FLM_INT', 'LBRD_034'),
     ('Medium', 'FLM_INT', 'LBRD_035'),
     ('Heavy', 'FLM_INT', 'LBRD_036');