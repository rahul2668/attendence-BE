INSERT INTO public.log_book_equipments (equipment_name, equipment_code)
VALUES ('Furnace', 'FURNACE'),
    ('Electrode', 'ELECTROD'),
    ('Casting Bay', 'CAST_BAY'),
    ('Dust Collector', 'DUST_COL'),
    ('Raw Material', 'RAW_MAT'),
    ('Electrical System', 'ELEC_SYS'),
    ('Hydraulic System', 'HYD_SYS'),
    ('Instrumentation', 'INSTRUM'),
    ('Cooling System', 'COOL_SYS');