INSERT INTO public.log_book_downtime_type_master ("name", down_time_type_code)
VALUES ('Planned Downtime', 'PLANNED'),
    ('Operational Downtime', 'OPER_DT'),
    ('Breakdown Downtime', 'BREAK_DT'),
    ('Efficiency /Production loss', 'EFF_PROD');