INSERT INTO public.users_role (
        created_at,
        modified_at,
        record_status,
        role_name,
        is_delete,
        is_superuser,
        created_by_id,
        modified_by_id
    )
VALUES (
        now(),
        now(),
        true,
        'SuperAdmin',
        false,
        false,
        NULL,
        1
    );