INSERT INTO public.users_rolepermission (
        created_at,
        modified_at,
        record_status,
        "create",
        "view",
        edit,
        "delete",
        created_by_id,
        function_master_id,
        modified_by_id,
        role_id
    )
VALUES (
        now(),
        now(),
        true,
        true,
        true,
        true,
        true,
        1,
        'PLT_CFG',
        1,
        1
    );