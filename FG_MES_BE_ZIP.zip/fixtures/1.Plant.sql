INSERT INTO public.plant_plant (
        created_at,
        modified_at,
        record_status,
        plant_name,
        plant_id,
        area_code,
        created_by_id,
        modified_by_id
    )
VALUES (
        now(),
        now(),
        true,
        'Anglefort',
        '6V',
        '00AN00',
        NULL,
        NULL
    );