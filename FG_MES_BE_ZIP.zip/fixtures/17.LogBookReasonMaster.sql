-- Updated insert statements with new reason codes
INSERT INTO public.log_book_reason_master (equipment_id, reason_id) VALUES
    (1, 'POWR_CON'),
    (1, 'MAINTEN'),
    (1, 'INV_CTRL'),
    (1, 'ORG_NAT'),
    (2, 'HARD_BRK'),
    (2, 'PASTE_LK'),
    (2, 'LONG_SL'),
    (2, 'HIGH_CAV'),
    (2, 'CASE_WLD'),
    (2, 'PASTE_AD');
INSERT INTO public.log_book_reason_master (equipment_id, reason_id) VALUES
    (2, 'SLP_THRU'),
    (2, 'OTHER'),
    (3, 'TH_WRK'),
    (3, 'CAST_DEL'),
    (3, 'LADL_OV'),
    (3, 'TH_BLOW'),
    (3, 'OTHER'),
    (4, 'MAT_BLK'),
    (4, 'MAT_LACK'),
    (4, 'OTHER');
INSERT INTO public.log_book_reason_master (equipment_id, reason_id) VALUES
    (5, 'HIGH_BP'),
    (5, 'HI_TEMP'),
    (5, 'OTHER'),
    (6, 'OVER_CUR'),
    (6, 'STR_FLAM'),
    (6, 'TIME_CHG'),
    (6, 'CHIM_CLN'),
    (6, 'OTHER'),
    (6, 'ORG_LOC'),
    (7, 'SHOE_LK');
INSERT INTO public.log_book_reason_master (equipment_id, reason_id) VALUES
    (7, 'RING_LK'),
    (7, 'INSUL'),
    (7, 'REG_SYS'),
    (7, 'SLIP_SYS'),
    (7, 'PASTE_FD'),
    (7, 'OTHER'),
    (8, 'OTHER'),
    (9, 'OTHER'),
    (10, 'OTHER'),
    (11, 'CALIB');
INSERT INTO public.log_book_reason_master (equipment_id, reason_id) VALUES
    (11, 'OTHER'),
    (12, 'ID_TRIP'),
    (12, 'CLEANSYS'),
    (12, 'BAG_REPL'),
    (12, 'OTHER'),
    (13, 'CRANE'),
    (13, 'MOB_EQ'),
    (13, 'CAROSEL'),
    (13, 'OTHER'),
    (14, 'HOOD_LK');
INSERT INTO public.log_book_reason_master (equipment_id, reason_id) VALUES
    (14, 'DOORS'),
    (14, 'SHEL_ROT'),
    (14, 'STOK_EQ'),
    (14, 'OTHER'),
    (15, 'OTHER'),
    (16, 'BAKING'),
    (17, 'LOAD_RED'),
    (17, 'CAMPAIGN'),
    (17, 'STR_FLAM'),
    (17, 'CHIM_CLN');
INSERT INTO public.log_book_reason_master (equipment_id, reason_id) VALUES
    (17, 'OVER_CUR'),
    (17, 'LOAD_IMB'),
    (17, 'ORG_LOC'),
    (18, 'TH_WRK'),
    (18, 'CAST_DEL'),
    (18, 'LADL_OV'),
    (18, 'TH_BLOW'),
    (19, 'MAT_BLK'),
    (19, 'MAT_LACK'),
    (20, 'HIGH_BP');
INSERT INTO public.log_book_reason_master (equipment_id, reason_id) VALUES
    (20, 'HI_TEMP'),
    (21, 'HI_TEMP'),
    (21, 'LOW_PR');
