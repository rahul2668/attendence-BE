INSERT INTO public.furnace_producttype (
        created_at,
        modified_at,
        record_status,
        "name",
        created_by_id,
        modified_by_id
    )
VALUES (
        now(),
        now(),
        true,
        'Molten',
        1,
        1
    ),
    (
        now(),
        now(),
        true,
        'WIP',
        1,
        1
    );