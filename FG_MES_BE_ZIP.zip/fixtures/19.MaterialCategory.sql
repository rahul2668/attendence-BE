INSERT INTO public.material_master_materialcategorymaster (
        created_at,
        modified_at,
        record_status,
        category_name,
        category_code,
        created_by_id,
        modified_by_id
    )
VALUES (
        now(),
        now(),
        true,
        'Raw Materials',
        'MP',
        1,
        1
    ),
    (
        now(),
        now(),
        true,
        'Additives',
        'AB',
        1,
        1
    ),
    (
        now(),
        now(),
        true,
        'By Products',
        'SR',
        1,
        1
    ),
    (
        now(),
        now(),
        true,
        'WIP',
        'CD',
        1,
        1
    ),
    (
        now(),
        now(),
        true,
        'Finished Products',
        'PT',
        1,
        1
    );
