INSERT INTO public.log_book_equipment_master (down_time_type_id, equipment_id)
VALUES ('PLANNED', 'FURNACE'),
    ('OPER_DT', 'ELECTROD'),
    ('OPER_DT', 'CAST_BAY'),
    ('OPER_DT', 'RAW_MAT'),
    ('OPER_DT', 'DUST_COL'),
    ('OPER_DT', 'FURNACE'),
    ('BREAK_DT', 'ELECTROD'),
    ('BREAK_DT', 'ELEC_SYS'),
    ('BREAK_DT', 'HYD_SYS'),
    ('BREAK_DT', 'INSTRUM');
INSERT INTO public.log_book_equipment_master (down_time_type_id, equipment_id)
VALUES ('BREAK_DT', 'RAW_MAT'),
    ('BREAK_DT', 'DUST_COL'),
    ('BREAK_DT', 'CAST_BAY'),
    ('BREAK_DT', 'FURNACE'),
    ('BREAK_DT', 'COOL_SYS'),
    ('EFF_PROD', 'ELECTROD'),
    ('EFF_PROD', 'FURNACE'),
    ('EFF_PROD', 'CAST_BAY'),
    ('EFF_PROD', 'RAW_MAT'),
    ('EFF_PROD', 'DUST_COL');
INSERT INTO public.log_book_equipment_master (down_time_type_id, equipment_id)
VALUES ('EFF_PROD', 'COOL_SYS');