INSERT INTO public.utils_globalunit (name, imperial, metric)
VALUES ('Temp', '°F', '°C'),
    ('Time', 'mins', 'mins'),
    ('O₂ Flow', 'Nft³/h', 'Nm³/h'),
    ('Air Flow', 'Nft³/h', 'Nm³/h'),
    ('N Flow', 'Nft³/h', 'Nm³/h'),
    ('O₂ Pressure', 'psi', 'Bar'),
    ('Air Pressure', 'psi', 'Bar'),
    ('N₂ Pressure', 'psi', 'Bar'),
    ('Quantity', 'lb/t', 'kg/t'),
    ('Core Mass/Length', 'lb/in', 'kg/cm');
INSERT INTO public.utils_globalunit (name, imperial, metric)
VALUES ('Paste Mass/Length', 'lb/in', 'kg/cm'),
    ('Casing Mass/Length', 'lb/in', 'kg/cm'),
    ('Energy Losses', '%', '%'),
    ('Joule Losses Coefficient', '%', '%'),
    ('Default EPI Index', 'in', 'cm'),
    (
        'Corrected Reactance Coefficient',
        'mOhm/cm',
        'mOhm/cm'
    ),
    ('Design MW', 'MW', 'MW'),
    ('Default Moisture', '%', '%'),
    ('Silicon FC', '%', '%'),
    ('K SIC', '%', '%');
INSERT INTO public.utils_globalunit (name, imperial, metric)
VALUES ('Shell Losses', '%', '%'),
    ('material', 'lbs/ton', 'kg/ton'),
    ('Unit Weight', 'lb', 't'),
    ('Density', 'lb/ft³', 'g/cm³'),
    ('kWh Melting', 'kWh/t', 'kWh/t'),
    ('Electrode diameter', 'cm', 'cm'),
    ('Target Energy Efficiency', 'MWh/t', 'MWh/t'),
    ('Target Availability', '%', '%'),
    ('Target Furnace Load', 'MW', 'MW'),
    ('Crucible Diameter', 'm', 'm');
INSERT INTO public.utils_globalunit (name, imperial, metric)
VALUES ('Crucible Depth', 'm', 'm'),
    ('PCD Theoretical', 'm', 'm'),
    ('PCD Actual', 'm', 'm');