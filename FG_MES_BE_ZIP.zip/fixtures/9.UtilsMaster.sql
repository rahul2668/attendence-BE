INSERT INTO public.utils_master (category, value, description, master_code)
VALUES ('UNITSYSTEM', 'Metric System', '', 'UNI_MET'),
    ('UNITSYSTEM', 'Imperial System', '', 'UNI_IMP'),
    (
        'CURRENCY',
        'United States Dollar ($)',
        '',
        'CUR_USD'
    ),
    ('CURRENCY', 'Pound Sterling (£)', '', 'CUR_GBP'),
    ('CURRENCY', 'Euro (€)', '', 'CUR_EUR'),
    (
        'CURRENCY',
        'Canadian Dollar (C$)',
        '',
        'CUR_CAD'
    ),
    (
        'CURRENCY',
        'South African Rand (ZAR)',
        '',
        'CUR_ZAR'
    ),
    (
        'CURRENCY',
        'Argentine Peso (Arg$)',
        '',
        'CUR_ARS'
    ),
    (
        'CURRENCY',
        'Norwegian Krone (NOK)',
        '',
        'CUR_NOK'
    ),
    (
        'CURRENCY',
        'Venezuelan bolivar (Bs)',
        '',
        'CUR_VEF'
    );
INSERT INTO public.utils_master (category, value, description, master_code)
VALUES ('CURRENCY', 'Chinese Yuan (¥)', '', 'CUR_CNY'),
    ('LANGUAGE', 'English', '', 'LAN_ENG'),
    ('LANGUAGE', 'Spanish', '', 'LAN_SPA'),
    ('LANGUAGE', 'French', '', 'LAN_FRE'),
    (
        'TIMEZONE',
        '(UTC - 05:00) Eastern Time (US & Canada)',
        '',
        'TZ_EST'
    ),
    (
        'TIMEZONE',
        '(UTC - 06:00) Central Time (US & Canada)',
        '',
        'TZ_CST'
    ),
    (
        'TIMEZONE',
        '(UTC - 07:00) Mountain Time (US & Canada)',
        '',
        'TZ_MST'
    ),
    (
        'TIMEZONE',
        '(UTC - 08:00) Pacific Time (US & Canada)',
        '',
        'TZ_PST'
    ),
    (
        'TIMEZONE',
        '(UTC + 01:00) Central European Time',
        'Europe/Paris',
        'TZ_CET'
    ),
    (
        'TIMEZONE',
        '(UTC - 03:00) Argentina Time',
        '',
        'TZ_ART'
    );
INSERT INTO public.utils_master (category, value, description, master_code)
VALUES (
        'TIMEZONE',
        '(UTC - 04:00) Venezuelan Standard Time',
        '',
        'TZ_VET'
    ),
    (
        'TIMEZONE',
        '(UTC + 08:00) China Standard Time',
        '',
        'TZ_CHST'
    ),
    ('PRODUCT', 'Silica Fume', '', 'PROD_SF'),
    ('PRODUCT', 'Metallurgical Si', '', 'PROD_MS'),
    ('PRODUCT', 'Si Fines/Hyperfines', '', 'PROD_SFH'),
    ('PRODUCT', 'Si Dross', '', 'PROD_SD'),
    ('PRODUCT', 'FeSi', '', 'PROD_FES'),
    ('POWERDELIVERY', 'AC Arc', '', 'PWR_ACA'),
    ('POWERDELIVERY', 'DC Arc', '', 'PWR_DCA'),
    ('POWERDELIVERY', 'Induction', '', 'PWR_IND');
INSERT INTO public.utils_master (category, value, description, master_code)
VALUES ('COSTCENTER', 'BF1', '', 'COST_BF1'),
    ('COSTCENTER', 'BF2', '', 'COST_BF2'),
    ('ELECTRODES', 'Composite', '', 'COMP_EL'),
    ('PRODUCTSTATE', 'Molten', '', 'STAT_MOL'),
    ('PRODUCTSTATE', 'WIP', '', 'STAT_WIP'),
    (
        'SILICAFUMEDEFAULTMATERIAL',
        'C910 Fume de Silice',
        '',
        'SFDM_C91'
    ),
    (
        'SILICAFUMEDEFAULTMATERIAL',
        'C950 Fumes de silice',
        '',
        'SFDM_C95'
    ),
    (
        'SLAGPRODUCTDEFAULTMATERIAL',
        '5501370 - SiMe Alloy Cast DOW Sinking Slag',
        '',
        'SPDM_137'
    ),
    (
        'SLAGPRODUCTDEFAULTMATERIAL',
        '5501370 - SiMe Alloy Cast DOW Sinking Slag1',
        '',
        'SPDM_138'
    ),
    (
        'SLAGPRODUCTDEFAULTMATERIAL',
        '5501370 - SiMe Alloy Cast DOW Sinking Slag2',
        '',
        'SPDM_139'
    );
INSERT INTO public.utils_master (category, value, description, master_code)
VALUES (
        'SLAGPRODUCTDEFAULTMATERIAL',
        '5501370 - SiMe Alloy Cast DOW Sinking Slag3',
        '',
        'SPDM_140'
    ),
    ('REMELT', 'D045 Silicium 0/7', '', 'REM_D045'),
    ('ADDITIVES', 'M196 SABLE S 26', '', 'ADD_M196'),
    (
        'ADDITIVES',
        'M193 SABLE 0.1-0.3 mm Vrac',
        '',
        'ADD_M193'
    ),
    (
        'ADDITIVES',
        'M270 SABLE SILICEUX',
        '',
        'ADD_M270'
    ),
    ('AI', 'MD59 Aluminium', '', 'AI_MD59'),
    ('LIME', 'MA02 Calcaire 8/12', '', 'LIME_MA2'),
    ('SLAG', 'D020 Scories', '', 'SLAG_D02'),
    ('SKULL', 'D035 Silicium Ferreux', '', 'SKUL_D35'),
    (
        'CORE',
        'ME17 Electrodes UCAR L2100 550',
        '',
        'CORE_M17'
    );
INSERT INTO public.utils_master (category, value, description, master_code)
VALUES (
        'PASTE',
        'ME53 Pate Rheinfelden Elpa 35 Si Eco',
        '',
        'PAST_M53'
    ),
    (
        'PASTE',
        'ME55 Pate Rheinfelden Elpa 45 Si Eco',
        '',
        'PAST_M55'
    ),
    (
        'PASTE',
        'ME72 Pate briquette SGL CA-LP',
        '',
        'PAST_M72'
    ),
    ('WORKSHOPNO', '1', '', 'WORK_01'),
    ('CONTROLPARAMETERS', 'Temp', '', 'CTRL_TMP'),
    ('CONTROLPARAMETERS', 'Time', '', 'CTRL_TIM'),
    ('CONTROLPARAMETERS', 'O₂ Flow', '', 'CTRL_O2F'),
    ('CONTROLPARAMETERS', 'Air Flow', '', 'CTRL_AIR'),
    ('CONTROLPARAMETERS', 'N Flow', '', 'CTRL_NFL'),
    (
        'CONTROLPARAMETERS',
        'O₂ Pressure',
        '',
        'CTRL_O2P'
    );
INSERT INTO public.utils_master (category, value, description, master_code)
VALUES (
        'CONTROLPARAMETERS',
        'Air Pressure',
        '',
        'CTRL_AIP'
    ),
    (
        'CONTROLPARAMETERS',
        'N₂ Pressure',
        '',
        'CTRL_N2P'
    ),
    ('ADDITIVES', 'D045 Silicium 0/7', '', 'ADD_D045'),
    ('ADDITIVES', 'MD59 Aluminium', '', 'ADD_MD59'),
    ('ADDITIVES', 'MA02 Calcaire 8/12', '', 'ADD_MA2'),
    ('STEPS', 'Wait', '', 'STEP_WT'),
    ('STEPS', 'Fill', '', 'STEP_FI'),
    ('STEPS', 'Refine', '', 'STEP_RF'),
    ('STEPS', 'Settle', '', 'STEP_ST'),
    ('STEPS', 'Cast', '', 'STEP_CA');
INSERT INTO public.utils_master (category, value, description, master_code)
VALUES ('STEPS', 'De-slag', '', 'STEP_DS'),
    ('STEPS', 'Purge', '', 'STEP_PU'),
    (
        'CASING',
        'MV14 VIROLE DIAM.1040 L.1810',
        '',
        'CASE_M14'
    ),
    (
        'CASING',
        'MV15 VIROLE DIAM.1140 L.2000',
        '',
        'CASE_M15'
    ),
    (
        'CASING',
        'MV16 VIROLE DIAM 1250 L.1250 EN 30/10',
        '',
        'CASE_M16'
    ),
    ('COSTCENTER', 'B1F1', '', 'COS_B1F1'),
    ('ELECTRODES', 'Pre-baked', '', 'BAKE_EL'),
    ('ELECTRODES', 'Soderberg', '', 'SODER_EL'),
    ('ELECTRODES', 'DC Furnace', '', 'DCFUR_EL');