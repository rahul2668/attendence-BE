from django.conf import settings
from rest_framework.routers import DefaultRouter, SimpleRouter


from mes.users.views import UserViewSet
from mes.utils.views import UnitViewSet
# from mes.reports.views.DataLoadtoDB import LoadDataToMaterialMaster, LoadDataToMaterialType, LoadDataToMaterialCategory, LoadDataToRawSpecification, LoadDataToAdditiveSpecification, LoadDataToByProductSpecification, LoadDataToWIPSpecification, LoadDataToBaseAnalysisTable, LoadDataToConsumptionTable , LoadDataToMaterialMasterConsumption, LoadDataToBaseConsumptionReport #, LoadDataToTechniqueBaseConsumptionReport #LoadDataToFinishedProductsSpecification, LoadDataToFurnanceMaster
# from mes.reports.views.DataLoadtoDB import LoadDataToDatabaseViewset
from mes.master_data.material_master import views  as material_master_views
from mes.master_data.furnace_material import views  as furnace_material_views
if settings.DEBUG:
    router = DefaultRouter()
else:
    router = SimpleRouter()


router.register('users',UserViewSet)
router.register('units',UnitViewSet)
# router.register('load/material_category', LoadDataToMaterialCategory, basename="LoadDataToMaterialCategory")
# router.register('load/material_type', LoadDataToMaterialType, basename="LoadDataToMaterialType")
# router.register('load/material_master', LoadDataToMaterialMaster, basename="LoadDataToMaterialMaster")
# router.register("load/rawmaterial_specification", LoadDataToRawSpecification, basename="LoadDataToRawMaterialSpecification")
# router.register("load/additive_specification", LoadDataToAdditiveSpecification, basename="LoadDataToAdditiveSpecification")
# router.register("load/by_product_specification", LoadDataToByProductSpecification, basename="LoadDataToByProductSpecification")
# router.register("load/wip_specification", LoadDataToWIPSpecification, basename="LoadDataToWIPSpecification")
# router.register("load/", LoadDataToFinishedProductsSpecification, basename="LoadDataToFinishedProductsSpecification")
# router.register("load/base_analysis_report", LoadDataToBaseAnalysisTable, basename="LoadDataToBaseAnalysisTable")
# router.register("load/consumption_report", LoadDataToConsumptionTable, basename="LoadDataToConsumptionTable")
# router.register("load/furnance_master", LoadDataToFurnanceMaster, basename="LoadDataToFurnanceMaster")
# router.register("load/material_master_consumption", LoadDataToMaterialMasterConsumption, basename="LoadDataToMaterialMasterConsumption")
# router.register("load/technique_consumption_report", LoadDataToBaseConsumptionReport, basename="LoadDataToBaseConsumptionReport")



# ============================ Master data Master materials============================
router.register(r'material-category', material_master_views.MaterialCategoryMasterViewSet)
router.register(r'material-type', material_master_views.MaterialTypeMasterViewSet)
router.register(r'materials', material_master_views.MaterialMasterViewSet)


# ========================== Master data furnace materials view====================
# router.register('get-furnace-material-specification/',furnace_material_views.get_furnace_material_specification,basename='get_furnace_material_specification')

# router.register(r'furnace-material-specification',furnace_material_views.ChemistryValuesViewSet)
# ====================================================


app_name = "api"
urlpatterns = router.urls