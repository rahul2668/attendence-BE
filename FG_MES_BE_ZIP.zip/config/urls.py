from django.contrib import admin
from django.urls import path,include,re_path
from rest_framework.authtoken import views
from mes.master_data.material_master.views import get_size_dropdown,get_element_specification_excel_data,CheckElementSpecificationView

API_MASTER='api/master/'
urlpatterns = [
    path('admin/', admin.site.urls),
    path("api/account/", include("mes.users.urls", namespace="users")),
    path(API_MASTER, include("mes.utils.urls", namespace="master")),
     path("api/plant/", include("mes.plant.urls", namespace="plant")),
     path("api/furnace-config/", include("mes.furnace.urls", namespace="furnace")),
     path('api/',include('config.api_router'),),
    path("health_check/", include('health_check.urls')),
    path("api/dashboard/", include("mes.reports.urls", namespace='reportdashboard')),
    # master data urls
     path("api/log/", include("mes.log_book.urls", namespace="log_book")),

     path("api/master/", include("mes.master_data.furnace_material.urls", namespace="furnace_material")),
     path("api/master/", include("mes.master_data.additive.urls", namespace="additive_material")),
     path("api/master/", include("mes.master_data.by_products.urls", namespace="buy_products")),
     path("api/master/", include("mes.master_data.wip.urls", namespace="wip")),
     # re_path('api/master/furnace-material-specification/<int:pk>/',fur_mat_views.FurnaceMaterialSpecificationStepView.as_view(),name='get_furnace_material_specification'),
     
    path('api/material/size-dropdown/',get_size_dropdown,name="get_size_dropdown"),
    path('api/material/specification-excel-download/<str:pk>/',get_element_specification_excel_data,name='get_element_specification_excel_data'),
    path('api/material/add-additional-elements/',CheckElementSpecificationView.as_view(),name='check_additional_elements')

   
]


urlpatterns+=[
    path("api/auth-token/", views.obtain_auth_token),
]
