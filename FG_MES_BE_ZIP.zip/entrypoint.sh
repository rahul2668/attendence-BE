#!/bin/bash

# Run database migrations
if python manage.py migrate; then
    echo "Database migrations completed."
else
    echo "Error: Database migrations failed."
    exit 1
fi
 
# Load data from data.yaml
# if python manage.py loaddata fixtures/data_v2.yaml; then
#     echo "Data loading completed."
# else
#     echo "Error: Data loading failed."
#     exit 1
# fi
 
# Start the application
if python manage.py runserver 0.0.0.0:8000; then
    echo "Application started successfully."
else
    echo "Error: Application startup failed."
    exit 1
fi
