from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from django.contrib.postgres.fields import ArrayField
from mes.furnace.models import FurnaceConfig
from mes.users.models import User
from mes.master_data.material_master.models import MaterialMaster, MaterialTypeMaster, Element
from mes.utils.models import BaseModel

class BaseConsumptionReport(models.Model):
    mes_mat_code = models.ForeignKey(MaterialMaster, on_delete=models.PROTECT, to_field='mes_mat_code', db_column='mes_mat_code')
    furnace_master = models.ForeignKey(FurnaceConfig, on_delete=models.PROTECT, to_field='furnace_no') #furnace_master_id
    source_id = models.CharField(max_length=100,null=True, blank=True) # ramp_id
    bin_id = models.BigIntegerField(null=True, blank=True)
    date = models.DateField(null=True, blank=True)
    time = models.TimeField(null=True, blank=True)
    date_timestamp = models.DateTimeField(null=True, blank=True)
    cons_type = models.IntegerField(null=True, blank=True) #ramp_type
    cons_poste = models.IntegerField(null=True, blank=True) #ramp_poste
    dry_quantity = models.DecimalField(max_digits=10, decimal_places=4, null=True, blank=True)
    humidity_quantity = models.DecimalField(max_digits=10, decimal_places=4, null=True, blank=True)
    material_type = models.ForeignKey(MaterialTypeMaster, on_delete=models.PROTECT, to_field='type_code')
 
    def __str__(self) -> str:
        return self.mes_mat_code
    
class BaseAnalysisReport(models.Model):
    mes_mat_code = models.ForeignKey(MaterialMaster, on_delete=models.PROTECT, to_field='mes_mat_code', db_column='mes_mat_code')
    year = models.CharField(max_length=100, null=True, blank=True)
    date = models.DateField(null=True, blank=True)
    time = models.TimeField(null=True, blank=True)
    date_timestamp = models.DateTimeField(null=True, blank=True)
    element = models.ForeignKey(Element, on_delete=models.PROTECT, to_field='element_code')
    element_value = models.DecimalField(max_digits=12,decimal_places=4, null=True, blank=True)
