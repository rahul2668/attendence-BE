CATEGORY_RAW_MATERIAL = 'Raw Materials'
CATEGORY_ADDITIVES = 'Additives'
CATEGORY_BY_PRODUCTS = 'By Products'
CATEGORY_WIP = 'WIP'
LAYOUT = ["1 column", "2 columns"]
GRANULARITY_DAY = 'day'
GRANULARITY_SHIFT = 'shift'
GRANULARITY_HOUR = 'hour'
GRANULARITY_WEEK = 'week'
GRANULARITY_MONTH = 'month'
GRANULARITY_QUARTER = 'quarter'
GRANULARITY_YEAR = 'year'
GRANULARITY_BATCH = 'batch'
ADMIN_LOGIN = ['Admin', 'ADMIN', 'admin', 'Admin']
RAW_MATERIAL_IN_CONSUMPTION = ['Quartz', 'Coal', 'Wood']
CONVERT_TIMEZONE = 'America/New_York'

CONS_TYPE_SHIFT = 2
CONS_TYPE_HOUR = 1
CONS_TYPE_DAY = 3
CONS_TYPE_BATCH = 5
CONS_POSTE_SHIFT = [1,2,3]
SHIFT_HOURS = [(4, 12),(12, 20),(20, 28),]

SIZE_ALL = 'All'
SIZE_WITHIN_RANGE = 'Within Range'
SIZE_ABOVE_ACCEPTED = 'Above Accepted'
SIZE_BELOW_ACCEPTED = 'Below Accepted'

SUPPLIER_LIST = ["supplier1", "supplier2", "supplier3", "all"]