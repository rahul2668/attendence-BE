from django.urls import path,re_path
from rest_framework.routers import DefaultRouter
from mes.reports import views
from mes.reports.views import ConsumptionReportViewset as consumption
from mes.reports.views import SizeLabAnalysisReportViewset as size

# router=DefaultRouter()


app_name = "reportdashboard"
urlpatterns = [

    path("lab_analysis/material_category_list/", view=views.material_category_list, name="material_list"),
    path("lab_analysis/material_type_list/", view=views.material_type_list, name="type_list"),
    path("lab_analysis/material_master_list/", view=views.material_master_list, name="master_list"),
    path("lab_analysis/report_option/", view=views.report_option, name="report_option"),
    path("lab_analysis/variant_save/", view=views.variant_save, name="variant_save_report"),
    path("lab_analysis/variant_list/", view=views.variant_list, name="variant_list"),
    path("lab_analysis/variant_delete/", view=views.variant_delete, name="variant_delete"),
    path("lab_analysis/variant_get/", view=views.variant_get, name="variant_get"),
    path("lab_analysis/report_generate/", view=views.report_generate, name="report_generate"),

    path("consumption/furnace_list/", view=consumption.furnace_list, name="furnace_list"),
    path("consumption/material_category_list/", view=consumption.material_category_list, name="material_list"),
    path("consumption/material_type_list/", view=consumption.material_type_list, name="type_list"),
    path("consumption/material_master_list/", view=consumption.material_master_list, name="master_list"),
    path("consumption/variant_save/", view=consumption.variant_save, name="variant_save_report"),
    path("consumption/variant_list/", view=consumption.variant_list, name="variant_list"),
    path("consumption/variant_delete/", view=consumption.variant_delete, name="variant_delete"),
    path("consumption/variant_get/", view=consumption.variant_get, name="variant_get"),
    path("consumption/report_generate/", view=consumption.report_generate, name="report_generate"),

    path("size_lab_analysis/material_category_list/", view=size.material_category_list, name="material_list"),
    path("size_lab_analysis/material_type_list/", view=size.material_type_list, name="type_list"),
    path("size_lab_analysis/material_master_list/", view=size.material_master_list, name="master_list"),
    path("size_lab_analysis/variant_save/", view=size.variant_save, name="variant_save_report"),
    path("size_lab_analysis/variant_list/", view=size.variant_list, name="variant_list"),
    path("size_lab_analysis/variant_delete/", view=size.variant_delete, name="variant_delete"),
    path("size_lab_analysis/variant_get/", view=size.variant_get, name="variant_get"),
    path("size_lab_analysis/report_generate/", view=size.report_generate, name="report_generate"),
    
]
# # router.register(r"lab-analysis/", LabAnalysisReportViewset, basename='labanalysis')
# # router.register(r"consumption/", ConsumptionReportViewset, basename='consumption')


