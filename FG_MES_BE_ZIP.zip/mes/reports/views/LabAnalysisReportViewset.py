from ..models import BaseAnalysisReport
from mes.utils.models import Variant
from mes.master_data.material_master.models import MaterialCategoryMaster, MaterialTypeMaster, MaterialMaster, MaterialElementMaster, ElementSpecification, Element, ElementGroup
from rest_framework.response import Response
from datetime import datetime, timedelta
from rest_framework.exceptions import ValidationError
from django.db.models import Avg, Max, Min, Case, Value, IntegerField, When
from django.db.models.functions import TruncWeek, TruncDay, TruncMonth, TruncQuarter, TruncYear, TruncHour, TruncDate
from decimal import Decimal
from django.db.models import Count, Q
from django.utils import timezone
from mes.reports.globalString import LAYOUT, GRANULARITY_DAY, GRANULARITY_HOUR, GRANULARITY_MONTH, GRANULARITY_QUARTER, GRANULARITY_SHIFT, GRANULARITY_WEEK, GRANULARITY_YEAR, SHIFT_HOURS, ADMIN_LOGIN, SUPPLIER_LIST
import pytz
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from mes.users.models import User
from mes.master_data.material_master.serializers import MaterialCategoryMasterSerializer, MaterialTypeMasterSerializer, MaterialMasterNumberSerializer, GroupedElementsSerializer
from mes.utils.serializers import VariantReportGetSerializer, VariantReportSerializer
from mes.users.models import User

def validate_report_option(option):
    required_keys = ["report_sqn", "element_id", "element_name", "chart_type"]
    for key in required_keys:
        if not option.get(key):
            return key
    return None


@api_view(["GET"])
@permission_classes((AllowAny,))
def material_category_list(request):
    material_category_obj = MaterialCategoryMaster.objects.filter(record_status=True).values('id', 'category_name', 'category_code').distinct().order_by('category_name')
    serializer = MaterialCategoryMasterSerializer(material_category_obj, many=True).data
    return Response(serializer)

@api_view(["POST"])
@permission_classes((AllowAny,))
def material_type_list(request):
    category_id= request.data['category_id']
    if category_id == '' or category_id == None:
        raise ValidationError("reports.selectValidMatCategoryNotify")     
    material_type_obj = MaterialTypeMaster.objects.filter(record_status=True, category = category_id).distinct().order_by('type_name')
    serializer = MaterialTypeMasterSerializer(material_type_obj, many=True).data
    return Response(serializer)

@api_view(["POST"])
@permission_classes((AllowAny,))
def material_master_list(request):
    material_type_id = request.data['type_id']
    if material_type_id == '' or material_type_id == None:
        raise ValidationError("reports.enterValidMaterialType")
    material_number_obj = MaterialMaster.objects.filter(record_status = True, material_type = material_type_id).order_by('mes_mat_code')
    serializer = MaterialMasterNumberSerializer(material_number_obj, many=True).data

    for entry in serializer:
        material_id = f"{entry['mes_mat_code']} - {entry['material_name']}"
        entry['material_code_name'] = material_id
        
    return Response(serializer)


@api_view(["POST"])
@permission_classes((AllowAny,))
def report_option(request):
    material_type_id = request.data["type_id"]
    material_category_id = request.data["category_id"]
    mes_mat_code = request.data["material_id"]
    if material_type_id == "" or material_type_id == None:
        raise ValidationError("reports.selectValidMaterialType")
    try:
        mes_mat_obj = MaterialMaster.objects.get(mes_mat_code=mes_mat_code, material_type_id=material_type_id)
    except:
        
        raise ValidationError("reports.noMaterialIdForSelectedOptions")
    if mes_mat_obj:
        mas = MaterialElementMaster.objects.filter(material_type_id=material_type_id, record_status=True).order_by('element_group_id', 'element')
        grouped_elements = {}
        for instance in mas:
            element_id = instance.element_id
            group_id = instance.element_group_id

            element_name = Element.objects.get(element_code=element_id).name
            group_name = ElementGroup.objects.get(element_group_code=group_id).element_group

            if group_id not in grouped_elements:
                grouped_elements[group_id] = {
                    'group_id': group_id,
                    'group_name': group_name,
                    'elements': []
                }

            grouped_elements[group_id]['elements'].append({
                'element_id': element_id,
                'element_name': element_name
            })

        # return Response(list(grouped_elements.values()))
        serializer = GroupedElementsSerializer(data=list(grouped_elements.values()), many=True)
        serializer.is_valid(raise_exception=True)
        return Response(serializer.validated_data)

@api_view(["POST"])
@permission_classes((AllowAny,))
def variant_list(request):
    username =request.data["user_name"] 
    if username == "" or username == None:
        raise ValidationError("reports.invalidUser")
                
    if username in ADMIN_LOGIN:
        variant_obj = Variant.objects.filter(furnace_flag=False, size_flag=False, record_status=True).order_by('-id')
    else:  
        try:  
            user_id_obj = User.objects.get(username=username).id
            user_records_private =  Variant.objects.filter(furnace_flag=False, size_flag=False, record_status=True).filter(user=user_id_obj)
            other_users_records_private_false = Variant.objects.filter(furnace_flag=False, size_flag=False, record_status=True).exclude(user=user_id_obj).filter(private=False)
            result = user_records_private | other_users_records_private_false
            variant_obj = result.all().order_by('-id')
        except:
            raise ValidationError("reports.invalidUsername")
    serializer = VariantReportGetSerializer(variant_obj, many=True).data
    return Response(serializer)

@api_view(["POST"])
@permission_classes((AllowAny,))
def variant_save(request):
    invalid_reports = []
    data = request.data["report_save"]
    variant_id = request.data.get("variant_id", "")
    variant_name = request.data["variant_name"].strip()
    material_category_id = data["category_id"]
    material_type_id = data["type_id"]
    material_master_id = data["material_id"]
    supplier = data.get("supplier", None).lower()
    layout = data.get("layout", None).lower()
    granularity = data["granularity"]
    date_range = data["date_range"]
    compare = data["compare"]
    report_options = data["report_options"]
    private = data.get("private", False)
    update_flag = data.get("update_flag", False)
    compare_time_flag = data.get("compare_time_flag", False)
    compare_time_period = data.get("compare_time_period", [])
    compare_material_flag = data.get("compare_material_flag", False)
    clone_flag = data.get("clone_flag", False)
    user_name = request.data['user_name']
    furnace_flag = request.data.get("furnace_flag", False)
    
    if variant_name == "" or variant_name == None:
        raise ValidationError("reports.selectValidVarientName")
    if material_category_id == "" or material_category_id == None:
        raise ValidationError("reports.selectValidMatCategoryNotify")
    if material_type_id == "" or material_type_id == None:
        raise ValidationError("reports.selectValidMaterialType")
    if material_master_id == "" or material_master_id == None:
        raise ValidationError("reports.selectValidMaterialId")
    if granularity == "" or granularity == None:
        raise ValidationError("reports.selectValidGranularityNotify")
    if user_name == "" or user_name == None:
        raise ValidationError("reports.invalidUsername")
    
    if len(date_range) == 2:
        if (date_range[0] == "" or date_range[0] == None) or (date_range[1] == "" or date_range[1] == None):
            raise ValidationError("reports.selectValidDateRangeNotify") 

    if compare == True:
        if compare_time_flag == True and compare_material_flag == False:
            if len(compare_time_period) == 2:
                if (compare_time_period[0] == "" or compare_time_period[0] == None) or (compare_time_period[1] == "" or compare_time_period[1] == None):
                    raise ValidationError("reports.selectValidCompareDateRange")
        if compare_time_flag == False and compare_material_flag == True:
            for compare_material_id in report_options:
                if compare_material_id == []:
                    raise ValidationError("reports.selectCompareMaterialId")
    if report_options == []:
        raise ValidationError("reports.selectAtleastOneReport")  
            
    if private == "" or private == None:
        raise ValidationError("reports.selectValidPrivate")
    
    if layout not in LAYOUT:
        raise ValidationError("reports.selectValidLayoutNotify")
    
    if supplier not in SUPPLIER_LIST:
        raise ValidationError("reports.enterValidSupplierName")
    
    # user_name, _ = User.objects.values_list('id', flat=True).get(username=user_name)
    try:
        user_obj = User.objects.get(username=user_name)
    except:
        raise ValidationError("reports.invalidUser")

    for i, option in enumerate(report_options):
        error_key = validate_report_option(option)
        if error_key:
            invalid_reports.append({"report_sqn": option["report_sqn"], "error_key": error_key})
            raise ValidationError(f"Report options has an Invalid '{error_key}' value.")
    if update_flag == False:
        variant_obj = Variant.objects.filter(record_status=True, variant_name__iexact = variant_name, furnace_flag = False)
    if update_flag == True:
        if variant_id == "" or variant_id == None:
            raise ValidationError("reports.selectValidVariantOrId")
        variant_obj = Variant.objects.filter(record_status=True, id= variant_id, furnace_flag=False)
    if variant_obj:
        if variant_obj and clone_flag == True:
            raise ValidationError("reports.variantNameAlreadyExistsEnterNewVariantNameNotify")

        if update_flag == True:
            if variant_id == "" or variant_id == None:
                raise ValidationError("reports.selectValidVariantOrId")
            try:
                data.pop('update_flag', None)
                data.pop('clone_flag', None)
                report_save = data
                Variant.objects.filter(record_status=True, id=variant_id, furnace_flag=False).update(variant_name = variant_name,
                report_json = report_save,
                modified_at = datetime.now().date(), 
                modified_by = user_obj, 
                private = private, 
                user = user_obj)
                return Response("Variant Successfully Updated")
                
            except:
                raise ValidationError("reports.errorUpdatingVariant")
        raise ValidationError("reports.variantAlreadyExists")
    

    if not variant_obj and clone_flag == True and update_flag == False:
        if variant_name == "" or variant_name == None:
            raise ValidationError("reports.selectValidVariantOrId")
        try:
            data.pop('update_flag', None)
            data.pop('clone_flag', None)
            report_save = data
            # variant_check = Variant.objects.filter(record_status=True, variant_name=variant_name, user_id=user_id)
            # if variant_check.exists():
            #     raise ValidationError("Variant with the name '{}' already exists.".format(variant_name))
            Variant.objects.create(
                variant_name = variant_name,
                created_by = user_obj,
                report_json = report_save,
                user = user_obj,
                private = private, 
                furnace_flag = furnace_flag
            )
            return Response("reports.variantClonedSuccess")
        except:
            raise ValidationError("reports.errorCreatingVariant")    
        
    if (not variant_obj) and (update_flag == False):
        try: 
            data.pop('update_flag', None)
            data.pop('clone_flag', None)
            report_save = data
            Variant.objects.create(
                variant_name = variant_name,
                created_by = user_obj,
                report_json = data,
                user = user_obj,
                private = private, 
                furnace_flag = furnace_flag
            )
            return Response("reports.variantCreationSuccess")
        except:

            raise ValidationError("reports.variantIsAlreadyExists")
    
    raise ValidationError("reports.selectValidOptions")

@api_view(["PUT"])
@permission_classes((AllowAny,))
def variant_delete(request):
    variant_id = request.data["variant_id"]
    variant_name = request.data['variant_name']
    username = request.data['user_name']
    if variant_id == "" or variant_id == None:
        raise ValidationError("reports.selectVariantId")
    if variant_name == "" or variant_name == None:
        raise ValidationError("reports.selectVariantId")
    if username == "" or username == None:
        raise ValidationError("reports.invalidUser")
    
    variant_obj = Variant.objects.filter(id=variant_id,  record_status=True, variant_name__iexact=variant_name, furnace_flag=False)

    if variant_obj:
        user_obj = User.objects.filter(username=username).first()
        variant_exist = variant_obj.filter(user = user_obj.id)
        if not variant_exist:
            raise ValidationError("reports.userNoAccessToDelete")
        variant_exist.update(record_status=False, modified_by=user_obj.id, modified_at=datetime.now().date())

        return Response(["reports.variantSuccessDelete"])
    else:
        raise ValidationError("reports.variantNotFound")


@api_view(["POST"])
@permission_classes((AllowAny,))
def variant_get(request):
    variant_id = request.data["variant_id"]
    variant_obj = Variant.objects.filter( record_status=True, id = variant_id, furnace_flag=False)
    if not variant_obj:
        raise ValidationError("reports.selectValidVariantName")
    serializer = VariantReportSerializer(variant_obj, many=True).data
    return Response(serializer)
    

def date_format(date_list, granularity):
    formatted_timestamps = []
    for timestamp in date_list:
        if granularity in [GRANULARITY_SHIFT, GRANULARITY_HOUR]:
            formatted_timestamp = timestamp.strftime("%Y-%m-%d %H:%M:%S")
        
        elif granularity in [GRANULARITY_MONTH, GRANULARITY_QUARTER]:
            formatted_timestamp = timestamp.strftime("%Y-%m")

        elif granularity == GRANULARITY_YEAR:
            formatted_timestamp = timestamp.strftime("%Y")

        else:
            formatted_timestamp = timestamp.strftime("%Y-%m-%d")
        formatted_timestamps.append(formatted_timestamp)
    return formatted_timestamps


def MaxMinValues(material_master_id, element_id, element_name):
    spec_obj = ElementSpecification.objects.filter(material_master_id=material_master_id, element=element_id).first()
    if not spec_obj:
        raise ValidationError(f"{material_master_id} for {element_name} values doesn't have Low & High Element Specification")
    return spec_obj

def generate_shifts(start_date, end_date):
    shifts_list = []
    current_date = start_date
 
    while current_date <= end_date:
        shifts_for_date = []
        for shift_index, (start_hour, end_hour) in enumerate(SHIFT_HOURS):
            start_shift_hour = current_date.replace(hour=start_hour, minute=0, second=0, microsecond=0)
            if end_hour >= 24:
                end_shift_hour = current_date + timedelta(days=1, hours=4)
            else:
                end_shift_hour = current_date.replace(hour=end_hour % 24, minute=0, second=0, microsecond=0)
           
            shifts_for_date.append({'start_time': start_shift_hour, 'end_time': end_shift_hour, 'shift': shift_index})
       
        shifts_list.append({'date': current_date, 'shifts': shifts_for_date})
        current_date += timedelta(days=1)
   
    return shifts_list

def aggregation_values(granularity, query_obj, start_date, end_date, element_id, element_name):
    element_name=element_name.replace(' ', '_')
    rounded_avg_values = []
    dates_duration = []
    avg_values = []
    avg_values_obj = []
    if start_date is not None:
            if granularity == GRANULARITY_SHIFT:
                shifts = generate_shifts(start_date, end_date)
                dates = []
                for shift_info in shifts:
                    for shift in shift_info['shifts']:
                        shift_sequence = {
                            'shift': shift['shift'],
                            'start_time': shift['start_time'],
                            'end_time': shift['end_time']
                        }
                        dates.append(shift_sequence)
                
                shift_days = [entry['start_time'] for entry in dates]
                shift_starting_days = {date: 0 for date in shift_days}
                
                for index, (start, end) in enumerate(SHIFT_HOURS):
                    if end < start:
                        SHIFT_HOURS[index] = (start, 24)
                        SHIFT_HOURS.append((0, end))
                conditions = [
                    When(date_timestamp__hour__gte=start, date_timestamp__hour__lt=end, then=Value(index)) 
                    for index, (start, end) in enumerate(SHIFT_HOURS)
                ]
                default_case = Value(2)
                avg_values_obj = query_obj.filter(element_id = element_id)
                avg_values_obj = avg_values_obj.annotate(shift=Case(*conditions,  default=default_case,output_field=IntegerField()))
                avg_values_obj = avg_values_obj.annotate(day=TruncDate('date_timestamp__date'))
                avg_values_obj = avg_values_obj.values('day', 'shift').annotate(
                    start_time=Min('date_timestamp'),
                    end_time=Max('date_timestamp'),
                    count=Count('*'),
                    **{'avg_{}'.format(element_name): Avg("element_value")}
                ).order_by('day', 'shift')

                for date_entry in dates:
                    shift = date_entry['shift']
                    start_time = date_entry['start_time']
                    end_time = date_entry['end_time']
                    date_entry['avg_{}'.format(element_name)] = []
                    for entry in avg_values_obj  :
                        if entry['shift'] == shift and start_time <= entry['start_time'] <= end_time:
                            shift_starting_days[date_entry['start_time']] = entry['avg_{}'.format(element_name)]
                dates_duration = list(shift_starting_days.keys())
                avg_values = list(shift_starting_days.values())
                rounded_avg_values = [round(value, 3) for value in avg_values]

            if granularity == GRANULARITY_HOUR:
                hours_per_day = [
                    datetime.combine(date, datetime.min.time()) + timedelta(hours=hour)
                    for date in (start_date + timedelta(days=i) for i in range((end_date - start_date).days + 1))
                    for hour in range(24)
                ]
                hour_values_dict = {hour: 0 for hour in hours_per_day}
                avg_values_obj = query_obj.filter(element_id = element_id)
                avg_values_obj = avg_values_obj.annotate(hour=TruncHour('date_timestamp')).values('hour').annotate(**{'avg_{}'.format(element_name):Avg("element_value")}).order_by('hour')  
                for entry in avg_values_obj:
                    hour_values_dict[entry['hour']] = entry['avg_{}'.format(element_name)]

                dates_duration = list(hour_values_dict.keys())
                avg_values = list(hour_values_dict.values())
                rounded_avg_values = [round(value, 3) for value in avg_values]
            
            if granularity == GRANULARITY_DAY:
                date_sequence = [start_date + timedelta(days=x) for x in range((end_date - start_date).days + 1)]
                avg_values_obj = query_obj.filter(element_id = element_id)
                avg_values_obj = avg_values_obj.annotate(date_of_day=TruncDay('date')).values('date_of_day').annotate(**{'avg_{}'.format(element_name):Avg("element_value")}).order_by('date_of_day')  
                date_values_dict = {date: 0 for date in date_sequence}

                for entry in avg_values_obj:
                    date_values_dict[datetime.combine(entry['date_of_day'],   datetime.min.time())] = entry['avg_{}'.format(element_name)]

                dates_duration = list(date_values_dict.keys())
                avg_values = list(date_values_dict.values())
                rounded_avg_values = [round(value, 3) for value in avg_values]
            
            if granularity == GRANULARITY_WEEK:
                week_starting_days = [
                (start_date + timedelta(days=i - (start_date.weekday() + 1) % 7)).date()
                for i in range((end_date - start_date).days + 1)
                    if (start_date + timedelta(days=i - (start_date.weekday() + 1) % 7)).weekday() == 0]
                week_starting_day_values_dict = {day: 0 for day in week_starting_days}
                avg_values_obj = query_obj.filter(element_id = element_id)
                avg_values_obj = avg_values_obj.annotate(date_of_week=TruncWeek('date')).values('date_of_week').annotate(**{'avg_{}'.format(element_name):Avg("element_value")}).order_by('date_of_week')  
                for entry in avg_values_obj:
                    week_starting_day_values_dict[entry['date_of_week']] = entry['avg_{}'.format(element_name)]
                dates_duration = list(week_starting_day_values_dict.keys())
                avg_values = list(week_starting_day_values_dict.values())
                rounded_avg_values = [round(value, 3) for value in avg_values]
            
            if granularity == GRANULARITY_MONTH:
                months = [
                    (start_date.replace(year=start_date.year + (start_date.month + i - 1) // 12,
                                        month=(start_date.month + i - 1) % 12 + 1,
                                        day=1)).date()
                    for i in range((end_date.year - start_date.year) * 12 + end_date.month - start_date.month + 1)
                    if end_date >= start_date.replace(year=start_date.year + (start_date.month + i - 1) // 12,
                                                    month=(start_date.month + i - 1) % 12 + 1,
                                                    day=1) >= start_date
                ]

                total_months_dict = {month: 0 for month in months}
                avg_values_obj = query_obj.filter(element_id = element_id)
                avg_values_obj = avg_values_obj.annotate(date_of_month=TruncMonth('date')).values('date_of_month').annotate(**{'avg_{}'.format(element_name):Avg("element_value")}).order_by('date_of_month')  
                for entry in avg_values_obj:
                    total_months_dict[entry['date_of_month']] = entry['avg_{}'.format(element_name)]
                dates_duration = list(total_months_dict.keys())
                avg_values = list(total_months_dict.values())
                rounded_avg_values = [round(value, 3) for value in avg_values]
            
            if granularity == GRANULARITY_QUARTER:
                quarters = [
                    start_date.replace(year=start_date.year + (start_date.month + (i - 1) * 3 - 1) // 12,
                                    month=((start_date.month + (i - 1) * 3 - 1) % 12) + 1,
                                    day=1).date()
                    for i in
                    range(1, ((end_date.year - start_date.year) * 12 + end_date.month - start_date.month + 1) // 3 + 1)
                ]
                total_quarters_dict = {quarter: 0 for quarter in quarters}
                avg_values_obj = query_obj.filter(element_id = element_id)
                avg_values_obj = avg_values_obj.annotate(date_of_quarter=TruncQuarter('date')).values('date_of_quarter').annotate(**{'avg_{}'.format(element_name):Avg("element_value")}).order_by('date_of_quarter')  
                for entry in avg_values_obj:
                    total_quarters_dict[entry['date_of_quarter']] = entry['avg_{}'.format(element_name)]

                dates_duration = list(total_quarters_dict.keys())
                avg_values = list(total_quarters_dict.values())
                rounded_avg_values = [round(value, 3) for value in avg_values]

            if granularity == GRANULARITY_YEAR:
                years = [
                    start_date.replace(year=start_date.year + i, month=1, day=1).date()
                    for i in range((end_date.year - start_date.year) + 1)
                ]

                total_years_dict = {year: 0 for year in years}
                avg_values_obj = query_obj.filter(element_id = element_id)
                avg_values_obj = avg_values_obj.annotate(date_of_year=TruncYear('date')).values('date_of_year').annotate(**{'avg_{}'.format(element_name):Avg("element_value")}).order_by('date_of_year')  
                for entry in avg_values_obj:
                    total_years_dict[entry['date_of_year']] = entry['avg_{}'.format(element_name)]

                dates_duration = list(total_years_dict.keys())
                avg_values = list(total_years_dict.values())
                rounded_avg_values = [round(value, 3) for value in avg_values]
    return rounded_avg_values, dates_duration

@api_view(["POST"])
@permission_classes((AllowAny,))
def report_generate(request):
        result = []
        invalid_reports = []
        data = request.data["generate_report"]
        material_category_id = data["category_id"]
        material_type_id = data["type_id"]
        material_master_id = data["material_id"]
        supplier = data.get("supplier", None).lower()
        layout = data.get("layout", None).lower()
        granularity = data["granularity"].lower()
        date_range = data["date_range"]
        compare = data.get("compare", False)
        compare_time_flag = data.get("compare_time_flag", False)
        compare_material_flag = data.get("compare_material_flag", False)
        compare_time_period = data.get("compare_time_period", None)
        report_options = data["report_options"]

        if material_category_id == "" or material_category_id == None:
            raise ValidationError("reports.selectValidMatCategoryNotify")
        if material_type_id == "" or material_type_id == None:
            raise ValidationError("reports.selectValidMaterialType")
        if material_master_id == "" or material_master_id == None:
            raise ValidationError("reports.selectValidMaterialId")
        if granularity == "" or granularity == None:
            raise ValidationError("reports.selectValidGranularityNotify")
        if not date_range:
                raise ValidationError("reports.selectValidDateRangeNotify") 
        
        if layout  not in LAYOUT:
            raise ValidationError("reports.selectValidLayoutNotify")
        if supplier not in SUPPLIER_LIST:
            raise ValidationError("reports.enterValidSupplierNameNotify")

        if len(date_range) == 2:
            if (date_range[0] == "" or date_range[0] == None) or (date_range[1] == "" or date_range[1] == None):
                raise ValidationError("reports.selectValidDateRangeNotify")
        start_date = datetime.strptime(date_range[0], '%Y-%m-%d')
        end_date = datetime.strptime(date_range[1], '%Y-%m-%d') + timedelta(hours=23, minutes=59,seconds=59)# + timedelta(days=1) #- timedelta(seconds=1)  

        for i, option in enumerate(report_options):
            error_key = validate_report_option(option)
            if error_key:
                invalid_reports.append({"report_sqn": option["report_sqn"], "error_key": error_key})
                raise ValidationError(f"Report options has an Invalid '{error_key}' value.")        
        
        sorted_report_options = sorted(report_options, key=lambda x: x["report_sqn"])

        for option in sorted_report_options:
            report_generate = {}
            fixed_values = {}
            compare_values = []
            
            report_sqn = option['report_sqn']
            element_name = option['element_name']
            element_id = option['element_id']
            chart_type = option['chart_type']
            
            query_obj = BaseAnalysisReport.objects.filter(date_timestamp__gte=start_date, date_timestamp__lte = end_date, mes_mat_code = material_master_id)

            if granularity:
                rounded_avg_values, dates_duration = aggregation_values(granularity, query_obj, start_date, end_date, element_id, element_name)
            
            if rounded_avg_values == []:
                raise ValidationError("No Data for given Date range : {}".format(date_range))
            if dates_duration == []:
                raise ValidationError("No Date for given Date range: {}".format(date_range))

            dates_duration = date_format(dates_duration, granularity)

            material_obj = MaterialMaster.objects.filter(mes_mat_code=material_master_id).first().mes_mat_code
            fixed_values[f"{material_obj}_{element_name}_values"] = rounded_avg_values 
        
            report_generate["x-axis_1"] = dates_duration
            report_generate["fixed_values"] = fixed_values       
            report_generate["report_sqn"] = report_sqn
            report_generate["element_name"] = element_name
            report_generate["chart_type"] = chart_type

            if (compare == False) or (compare ==True and compare_time_flag == True and compare_material_flag == False):
                spec_obj = MaxMinValues(material_master_id, element_id, element_name)
                spec_max = spec_obj.high
                spec_min = spec_obj.low
                mean = spec_obj.aim
                stddev_data = Decimal(0.01)
                m_plus_3s = mean + 3 * stddev_data
                m_minus_3s = mean - 3 * stddev_data

                report_generate['spec_max'] = spec_max
                report_generate['spec_min'] = spec_min
                report_generate['mean'] = mean
                report_generate['m_plus_3s'] = round(m_plus_3s,3)
                report_generate['m_minus_3s'] = round(m_minus_3s,3)
                report_generate["below_tolerance"] = ""
                report_generate["above_tolerance"] = ""
            
                if compare == False:
                    element_unit = Element.objects.get(element_code=element_id).unit
                    report_generate["title"] = "{} Graph for - {} ({})".format(material_obj, element_name, element_unit)
                    # report_generate["title"] = "{} Graph for - {}".format(material_obj, element_name)
                if compare == True and compare_time_flag == True and compare_material_flag == False:
                    element_unit = Element.objects.get(element_code=element_id).unit
                    report_generate["title"] = "{} {} ({}) Graph for - ({} to {}) vs ({} to {})".format(material_obj, element_name, element_unit,  date_range[0], date_range[1], compare_time_period[0], compare_time_period[1])
                    
            if compare == True and compare_time_flag == True and compare_material_flag == False:
                if len(compare_time_period) == 2:
                    if (compare_time_period[0] == "" or compare_time_period[0] == None) or (compare_time_period[1] == "" or compare_time_period[1] == None):
                        raise ValidationError("reports.selectValidCompareDateRange")
                compare_start_date = datetime.strptime(compare_time_period[0], '%Y-%m-%d')
                compare_end_date = datetime.strptime(compare_time_period[1], '%Y-%m-%d') + timedelta(hours=23, minutes=59,seconds=59) #+ timedelta(days=1) #- timedelta(seconds=1)
            
                query_obj = BaseAnalysisReport.objects.filter(date_timestamp__gte=compare_start_date, date_timestamp__lte=compare_end_date, mes_mat_code = material_master_id)
                if granularity:
                    rounded_avg_values, dates_duration = aggregation_values(granularity, query_obj, compare_start_date, compare_end_date, element_id, element_name)
                
                if rounded_avg_values == []:
                    raise ValidationError("No Data for given Date range : {}".format(compare_time_period))
                if dates_duration == []:
                    raise ValidationError("No Date for given Date range: {}".format(compare_time_period))

                dates_duration = date_format(dates_duration, granularity)
                compare_values.append({f"{element_name}_values": rounded_avg_values})
                # compare_values[f"{element_name}_values"] = rounded_avg_values 
                report_generate["x-axis_2"] = dates_duration
                report_generate["compare_material_values"] = compare_values
            
            if compare  == True and compare_time_flag == False and compare_material_flag == True:
                compare_material_number_values = []
                compare_material_id = option.get("compare_material_id")
                title_list = []
                element_unit = Element.objects.get(element_code=element_id).unit
                for m_id in compare_material_id:
                    compare_dict = {}
                    query_obj = BaseAnalysisReport.objects.filter(date_timestamp__gte=start_date, date_timestamp__lte=end_date, mes_mat_code = m_id)

                    if not query_obj:
                        raise ValidationError("reports.emptyRecordsForCompareMaterialID")

                    if granularity:
                        rounded_avg_values, dates_duration = aggregation_values(granularity, query_obj, start_date, end_date, element_id, element_name)

                    if rounded_avg_values == []:
                        raise ValidationError("No Data for given Date range : {}".format(date_range))
                    if dates_duration == []:
                        raise ValidationError("No Date for given Date range: {}".format(date_range))
                    

                    m_id_list = MaterialMaster.objects.filter(mes_mat_code=m_id).first().mes_mat_code
                    
                    if not m_id_list:
                        raise ValidationError("reports.noRecordForMatNumberNotify")
                    title_list.append(m_id_list)
                    compare_dict[f"{m_id_list}_{element_name}_values"] = rounded_avg_values     
                    compare_material_number_values.append(compare_dict)
                
                report_generate['compare_material_values'] = compare_material_number_values 
                report_generate["title"] = "{} ({}) Graph for - {} vs {}".format(element_name, element_unit, material_obj, " , ".join(title_list))
                # report_generate["title"] = "{} Graph for - {} vs {}".format(element_name, material_obj, " , ".join(title_list))  
            result.append(report_generate)
        return Response(result)