# from .ConsumptionReportViewset import *
from .LabAnalysisReportViewset import *