from django.db import models
from mes.plant.models import PlantConfigWorkshop
from mes.utils.models import Master,BaseModel
from mes.master_data.material_master.models import MaterialMaster


class FurnaceChangeLog(BaseModel):
    furnace=models.ForeignKey("FurnaceConfig",related_name="furnace_change_log",on_delete=models.PROTECT)
    change_log=models.JSONField()

class FurnaceConfig(BaseModel):
    plant_id = models.CharField(max_length=50)
    furnace_no = models.SmallIntegerField(unique=True)
    furnace_description = models.CharField(max_length=500)
    workshop = models.ForeignKey(PlantConfigWorkshop,related_name="plant_furnace_workshop",on_delete=models.PROTECT)
    power_delivery = models.ForeignKey(Master,related_name="furnace_master_power_delivery",on_delete=models.PROTECT, to_field='master_code')
    cost_center = models.ForeignKey(Master,related_name="furnace_master_cost_center",on_delete=models.PROTECT, to_field='master_code')
    silica_fume_default_material = models.ForeignKey(Master,related_name="furnace_master_smdm",on_delete=models.PROTECT,null=True, to_field='master_code')
    slag = models.ForeignKey(Master,related_name="furnace_master_slag",on_delete=models.PROTECT,null=True, to_field='master_code')
    skull = models.ForeignKey(Master,related_name="furnace_master_skull",on_delete=models.PROTECT,null=True, to_field='master_code')
    is_active=models.BooleanField(default=True)

    class Meta:
        ordering=['-created_at','-record_status']

    def __str__(self):
        return self.furnace_no
    
class FurnaceConfigParameters(BaseModel):
    furnace_config = models.ForeignKey(FurnaceConfig,related_name="furnace_config_parameters",on_delete=models.PROTECT, to_field='furnace_no')
    effective_date=models.DateField()
    energy_losses = models.DecimalField(max_digits=10, decimal_places=2)
    joule_losses_coefficient = models.DecimalField(max_digits=10, decimal_places=2)
    default_epi_index = models.DecimalField(max_digits=10, decimal_places=2)
    corrected_reactance_coefficient = models.DecimalField(max_digits=10, decimal_places=2)
    design_mv = models.DecimalField(max_digits=10, decimal_places=2)
    fixed_cost = models.DecimalField(max_digits=10, decimal_places=2)
    target_energy_efficiency = models.DecimalField(max_digits=10, decimal_places=2)
    target_cost_budget = models.DecimalField(max_digits=10, decimal_places=2)
    target_availability = models.DecimalField(max_digits=10, decimal_places=2)
    target_furnace_load = models.DecimalField(max_digits=10, decimal_places=2)
    crucible_diameter = models.DecimalField(max_digits=10, decimal_places=2)
    crucible_depth = models.DecimalField(max_digits=10, decimal_places=2)
    pcd_theoretical = models.DecimalField(max_digits=10, decimal_places=2)
    pcd_actual = models.DecimalField(max_digits=10, decimal_places=2)
    default_moisture = models.BooleanField(default=False)


    def __str__(self) -> str:
        return f'{self.effective_date}'
    
    class Meta:
        db_table="furnace_config_parameters"
        db_table_comment="It holds the furnace config  parameters"
        unique_together = ( 'furnace_config','effective_date')



    
   

class ProductType(BaseModel):
    name=models.CharField(max_length=50)
    def __str__(self) -> str:
        return self.name
    
class ProductCode(BaseModel):
    product_type=models.ForeignKey(ProductType,related_name="product_type_code",on_delete=models.PROTECT)
    name=models.CharField(max_length=50)
    def __str__(self) -> str:
        return self.name
    

class FurnaceProduct(BaseModel):
    furnace_config = models.ForeignKey(FurnaceConfig,related_name="furnace_config_products",on_delete=models.PROTECT, to_field='furnace_no')
    product_type = models.ForeignKey(ProductType,related_name="master_furnace_product_type",on_delete=models.PROTECT)
    material_master = models.ForeignKey(MaterialMaster,related_name="master_product_code",on_delete=models.PROTECT)

    def __str__(self) -> str:
        return f'{self.product_type.name}'


class FurnaceElectrode(BaseModel):
    furnace_config = models.ForeignKey(FurnaceConfig,related_name="furnace_config_electrodes",on_delete=models.PROTECT, to_field='furnace_no')
    electrode_type = models.ForeignKey(Master,related_name="electrode_type",on_delete=models.PROTECT, to_field='master_code')
    electrode_name = models.CharField(max_length=50)
    core = models.ForeignKey(Master,related_name="master_furnace_electrode",on_delete=models.PROTECT,null=True, to_field='master_code')
    core_mass_length = models.DecimalField(max_digits=10, decimal_places=2, null=True)
    paste = models.ForeignKey(Master,related_name="master_electrode_paste",on_delete=models.PROTECT,null=True, to_field='master_code')
    paste_mass_length = models.DecimalField(max_digits=10, decimal_places=2, null=True)
    casing = models.ForeignKey(Master,related_name="master_electrode_casing",on_delete=models.PROTECT,null=True, to_field='master_code')
    casing_mass_length = models.DecimalField(max_digits=10, decimal_places=2, null=True)
    diameter=models.DecimalField(max_digits=10,decimal_places=2,null=True,blank=True)
    effective_date=models.DateField()

    def __str__(self) -> str:
        return str(self.electrode_name)
    class Meta:
        unique_together = ( 'furnace_config', 'electrode_name','effective_date')


class FurnaceStepChangeLog(BaseModel):
    furnace=models.ForeignKey(FurnaceConfig,related_name="furnace_step_change_log",on_delete=models.PROTECT, to_field='furnace_no')
    change_log=models.JSONField()
    def __str__(self) -> str:
        return self.furnace.furnace_no
    
class FurnaceConfigStepManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(record_status=True)
class FurnaceConfigStep(BaseModel):
    furnace=models.ForeignKey(FurnaceConfig,related_name="furnace_config_step",on_delete=models.PROTECT, to_field='furnace_no')
    step=models.CharField(max_length=10)
    order=models.SmallIntegerField()
    objects = FurnaceConfigStepManager()

    class Meta:
        ordering=['order']

    def __str__(self) -> str:
        return self.step
    


class ControlParameterManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(record_status=True)
    

class ControlParameter(BaseModel):
    furnace_config_step=models.ForeignKey(FurnaceConfigStep,related_name="furnace_control_params",on_delete=models.PROTECT)
    param=models.CharField(max_length=50)
    value=models.FloatField()
    is_mandatory=models.BooleanField(default=True)

    objects = ControlParameterManager()


    def __str__(self) -> str:
        return self.param
    


class AdditiveManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(record_status=True)
    
class Additive(BaseModel):
    furnace_config_step=models.ForeignKey(FurnaceConfigStep,related_name="furnace_additives",on_delete=models.PROTECT)
    material=models.CharField(max_length=50)
    quantity=models.FloatField()

    objects = AdditiveManager()


    def __str__(self) -> str:
        return self.material
    
