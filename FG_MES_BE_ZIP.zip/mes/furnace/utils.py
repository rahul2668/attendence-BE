from . import models as furnace_model
from mes.utils.models import Master

NOT_MANDATORY='Not Mandatory'
MANDATORY='Mandatory'
def save_new_change_log(data=None,furnace_config=None):
    json_data=[]
    step_ids=[]
    for item in data:
        change_log={}
        pk_id = item.get('id', None)
        control_parameters=  item.get('controlParameters', [])
        additives=item.get('additives', [])
        change_log['control_parameters']=[]
        change_log['additives']=[]
        param_ids=[]
        additive_ids=[]
        change_log['process_name']=getattr(Master.objects.filter(pk=item.get('step',None)).first(),'value')
        if pk_id:
            step_ids.append(pk_id)
            furnace_config_step= furnace_model.FurnaceConfigStep.objects.filter(pk=pk_id).first()
            for control_param_data in control_parameters:
                if 'icon' in control_param_data:
                    control_param_data.pop('icon')
                pk=control_param_data.pop('id', None)
                record_status=control_param_data.pop('record_status', None)
                if pk and record_status:
                    param_ids.append(pk)
                    step_control_param= furnace_model.ControlParameter.objects.filter(pk=int(pk),furnace_config_step=furnace_config_step).first()
                    for key,val in control_param_data.items():
                        old_value=getattr(step_control_param,key)
                        try:
                            new_value=float(val)if  key !='is_mandatory' else val
                            old_value=float(old_value) if  key !='is_mandatory' else old_value
                        except Exception:
                            new_value= val
                        if hasattr(old_value, 'id'):
                            old_value = old_value.id
                        if (old_value is not None and new_value is not None) and old_value != new_value and  key !='is_mandatory':
                                change_log['control_parameters'].append({
                                     "edited":True,
                                    "name":Master.objects.get(pk=step_control_param.param).value,
                                    "old_value":getattr(step_control_param,'value'),
                                    "new_value":float(control_param_data.get('value',0.0)),
                                    'old_status':MANDATORY  if getattr(step_control_param,'is_mandatory') else NOT_MANDATORY,
                                    "new_status": MANDATORY if control_param_data.get('is_mandatory',None)else  NOT_MANDATORY
                                    }
                                )
                        elif old_value!=new_value and key=='is_mandatory' and getattr(step_control_param,'value')== float(control_param_data.get('value',0.0)):
                              change_log['control_parameters'].append({
                                     "edited":True,
                                    "name":Master.objects.get(pk=step_control_param.param).value,
                                    "old_value":getattr(step_control_param,'value'),
                                    "new_value":getattr(step_control_param,'value'),
                                    'old_status':MANDATORY  if getattr(step_control_param,'is_mandatory') else NOT_MANDATORY,
                                    "new_status": MANDATORY if control_param_data.get('is_mandatory',None)else  NOT_MANDATORY
                                    }
                                )
                elif record_status:
                    change_log['control_parameters'].append({
                        'newly_added':True,
                        "name":Master.objects.get(pk=int(control_param_data['param'])).value,
                        "new_value":float(control_param_data.get('value')),
                        "new_status":MANDATORY if control_param_data.get('is_mandatory',None) else NOT_MANDATORY
                    })
            for params in furnace_model.ControlParameter.objects.filter(furnace_config_step=furnace_config_step).exclude(id__in=param_ids):
                 change_log['control_parameters'].append({
                        'deleted':True,
                        "name":Master.objects.get(pk=int(params.param)).value,
                        "old_value":params.value,
                        "old_status":MANDATORY if params.is_mandatory else NOT_MANDATORY
                    })
                    
            for additive_data in additives:
                if 'icon' in additive_data:
                    additive_data.pop('icon')
                pk=additive_data.pop('id',None)
                record_status=additive_data.pop('record_status', None)
                if pk and record_status:
                    additive_ids.append(pk)
                    step_additive=furnace_model.Additive.objects.filter(furnace_config_step=furnace_config_step,pk=pk).first()
                    for key,val in additive_data.items():
                        old_value=getattr(step_additive,key)
                        new_value=float(val) if key=='value' else val
                        try:
                            old_value=old_value.id
                        except Exception: pass
                        try:
                             old_value=float(old_value)
                             new_value=float(new_value)
                        except Exception:pass
                        if (old_value and val) and old_value != new_value:
                                change_log['additives'].append({
                                     "edited":True,
                                    "field":Master.objects.get(pk=step_additive.material).value,
                                    "old_value":old_value,
                                    "new_value":new_value
                                })
                elif record_status:
                        change_log['additives'].append({
                            "newly_added":True,
                            "name":Master.objects.get(pk=int(additive_data['material'])).value,
                            "new_value":float(additive_data.get('quantity')),
                        })
            for additives in furnace_model.Additive.objects.filter(furnace_config_step=furnace_config_step).exclude(id__in=additive_ids):
                 change_log['additives'].append({
                            "is_deleted":True,
                            "name":Master.objects.get(pk=int(additives.material)).value,
                            "old_value":additives.quantity,
                        })
        else:
            change_log['newly_added_step']=True
            for control_param_data in control_parameters:
                        change_log['control_parameters'].append({
                             "newly_added":True,
                            "name":Master.objects.get(pk=control_param_data['param']).value,
                            "new_value":float(control_param_data.get('value',0)),
                            "new_status": MANDATORY if control_param_data.get('is_mandatory',None) else NOT_MANDATORY
                            }
                        )
            for additive_data in additives:
                    change_log['additives'].append({
                        "newly_added":True,
                        "name":Master.objects.get(pk=int(additive_data.get('material'))).value,
                        "new_value":float(additive_data.get('quantity',0)),
                    })
        if change_log['control_parameters'] or change_log['additives']:
            json_data.append(change_log)
    deleted=furnace_model.FurnaceConfigStep.objects.filter(furnace=furnace_config).exclude(id__in=step_ids)
    deleted_change_log={}
    deleted_change_log['control_parameters']=[]
    deleted_change_log['additives']=[]
    for item in deleted:
        deleted_change_log['process_name']=getattr(Master.objects.filter(pk=item.step).first(),'value')
        deleted_change_log['step_deleted']=True
        for params in item.furnace_control_params.all():
                deleted_change_log['control_parameters'].append({
                    "name":Master.objects.get(pk=int(params.param)).value,
                    "old_value":params.value,
                    "old_status":MANDATORY if params.is_mandatory else 'Not Mandatory'
                })
        for additives in item.furnace_additives.all():
                deleted_change_log['additives'].append({
                    "name":Master.objects.get(pk=int(additives.material)).value,
                    "old_value":additives.quantity,
                })
    if deleted_change_log['control_parameters'] or deleted_change_log['additives']:
        json_data.append(deleted_change_log)
    return json_data


unit_map={
     "core_mass_length":"Core Mass/Length",
     "paste_mass_length":"Paste Mass/Length",
     "casing_mass_length":"Casing Mass/Length",
     "energy_losses":"Energy Losses",
     "joule_losses_coeffient":"Joule Losses Coefficient",
     "default_epi_index":"Default EPI Index",
     "corrected_reactance_coefficient":"Corrected Reactance Coefficient",
     "design_mv":"Design MW",
     "default_moisture":"Default Moisture"
}