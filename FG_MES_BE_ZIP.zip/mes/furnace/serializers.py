from rest_framework import serializers
from . import models
from mes.utils.models import GlobalUnit
from mes.utils.models import Master
from mes.plant.models import PlantConfig
from mes.master_data.material_master.models import MaterialMaster
from mes.constants import EXCEL_UNIT_KEYS,CURRENCY_COLUMNS
from django.utils import timezone
now_date=timezone.now().date()
from mes.utils.services import get_full_name,separate_date_time,get_plant_currency 

class FurnaceConfigParametersSerializer(serializers.ModelSerializer):
    created_date = serializers.SerializerMethodField(read_only=True)
    modified_date = serializers.SerializerMethodField(read_only=True)
    created_name =  serializers.SerializerMethodField(read_only=True)
    modified_name =  serializers.SerializerMethodField(read_only=True)
    furnace_no=serializers.SerializerMethodField(read_only=True)
    class Meta:
        model=models.FurnaceConfigParameters
        fields="__all__"
    def get_created_date(self,obj):
        return separate_date_time(obj,'created_at')
    def get_modified_date(self,obj):
        return separate_date_time(obj,'modified_at')
    def get_created_name(self,obj):
        return get_full_name(obj,'created_by')
    def get_modified_name(self,obj):
        return get_full_name(obj,'modified_by')
    def get_furnace_no(self,obj):
        return getattr(obj.furnace_config,"furnace_no",None)
    def to_representation(self, instance):
        representation= super().to_representation(instance)
        for field_name in ['created_at', 'modified_at', 'modified_by','created_by','record_status']:
            representation.pop(field_name, None)
        request=self.context.get('request',None)
        if request:

            plant=PlantConfig.objects.first()
            if plant:
                master=Master.objects.filter(master_code=plant.unit_id).first()
                master_value=getattr(master,"value",'')
            unit_val=''
            for key,value in representation.items():
                lookup_key=EXCEL_UNIT_KEYS.get(key,'')
                if lookup_key:
                    if key in CURRENCY_COLUMNS:
                        representation[key] = f"{value} {get_plant_currency()}"
                    elif key not in CURRENCY_COLUMNS:
                        unit_val = GlobalUnit.objects.filter(name=lookup_key).first()
                        if master_value == 'Metric System':
                            unit = getattr(unit_val, 'imperial', '')
                        elif master_value == 'Imperial System':
                            unit = getattr(unit_val, 'metric', '')
                        else:
                            unit = ''
                        representation[key] = f"{value}{unit}" if value else value
                else:
                    representation[key] = value
        return representation


class ElectrodeSerializer(serializers.ModelSerializer):
    class Meta:
        model=models.FurnaceElectrode
        fields="__all__"

    def to_representation(self, instance):
        representation= super().to_representation(instance)
        for field_name in ['created_at', 'modified_at', 'modified_by','created_by','record_status']:
            representation.pop(field_name, None)
       
        return representation


unit_map = {
        "core_mass_length": "Core Mass/Length",
        "paste_mass_length": "Paste Mass/Length",
        "casing_mass_length": "Casing Mass/Length",
        "energy_losses": "Energy Losses",
        "joule_losses_coefficient": "Joule Losses Coefficient",
        "default_epi_index": "Default EPI Index",
        "corrected_reactance_coefficient": "Corrected Reactance Coefficient",
        "design_mv": "Design MW",
        "default_moisture": "Default Moisture"
    }

class FurnaceElectrodeCreateSerializer(serializers.ModelSerializer):
     class Meta:
        model = models.FurnaceElectrode
        fields="__all__"

class FurnaceElectrodeSerializer(serializers.ModelSerializer):
    core_value = serializers.SerializerMethodField(read_only=True)  
    paste_value = serializers.SerializerMethodField(read_only=True)
    casing_value = serializers.SerializerMethodField(read_only=True)   
    electrode_type_name = serializers.SerializerMethodField(read_only=True)
    created_date = serializers.SerializerMethodField(read_only=True)
    modified_date = serializers.SerializerMethodField(read_only=True)
    created_name =  serializers.SerializerMethodField(read_only=True)
    modified_name =  serializers.SerializerMethodField(read_only=True)
    furnace_no=serializers.SerializerMethodField(read_only=True)
   

    class Meta:
        model = models.FurnaceElectrode
        fields="__all__"
    def get_created_date(self,obj):
        return separate_date_time(obj,'created_at')
    def get_modified_date(self,obj):
        return separate_date_time(obj,'modified_at')
    def get_created_name(self,obj):
        return get_full_name(obj,'created_by')
    def get_modified_name(self,obj):
        return get_full_name(obj,'modified_by')
    def get_furnace_no(self,obj):
        return getattr(obj.furnace_config,"furnace_no",None)
    def get_electrode_type_name(self,obj):
        return Master.objects.get(master_code=obj.electrode_type_id).value
    def get_core_id(self,obj):
        return getattr(obj.core, 'id', None)
    def get_core_value(self,obj):
        return getattr(obj.core, 'value', None)
    def get_paste_id(self,obj):
        return getattr(obj.paste, 'id', None)
    def get_paste_value(self,obj):
        return getattr(obj.paste, 'value', None)
    
    def get_casing_id(self,obj):
        return getattr(obj.casing, 'id', None)
    def get_casing_value(self,obj):
        return getattr(obj.casing, 'value', None)

    def get_mapped_value(self, key):
        return unit_map.get(key, None)
    
    def get_unit_value(self,name):
        plant=PlantConfig.objects.first()
        master=Master.objects.filter(master_code=plant.unit_id).first()
        unit= GlobalUnit.objects.get(name=name)
        if master.value=='Metric System':
            return unit.metric
        else:
            return unit.imperial
        
    def to_representation(self, instance):
        request=self.context.get('request',None)
        representation= super().to_representation(instance)
        for field_name in ['modified_by','created_by','record_status','created_at','modified_at','furnace_config',]:
                representation.pop(field_name,None)

        if request:
            plant=PlantConfig.objects.first()
            if plant:
                master=Master.objects.filter(master_code=plant.unit_id).first()
                master_value=getattr(master,"value",'')
            for key,value in representation.items():
                lookup_key=EXCEL_UNIT_KEYS.get(key,'')
                if lookup_key:
                    unit_val=GlobalUnit.objects.filter(name=lookup_key).first()
                    if master_value=='Metric System':
                        representation[key]=str(value) + getattr(unit_val,'imperial','') if value else value
                    elif master_value=='Imperial System':
                        representation[key]=str(value) + getattr(unit_val,'metric','') if value else value
                else:
                    representation[key]=value
        return representation

class FurnaceProductCreateSerializer(serializers.ModelSerializer):
      class Meta:
        model = models.FurnaceProduct
        exclude = "__all__"


class FurnaceProductSerializer(serializers.ModelSerializer):
    product_type =serializers.SerializerMethodField(read_only=True) 
    product_type_value =serializers.SerializerMethodField(read_only=True) 
    product_code=serializers.SerializerMethodField(read_only=True)
    product_code_value=serializers.SerializerMethodField(read_only=True)
    class Meta:
        model = models.FurnaceProduct
        exclude = ['created_by','modified_by','created_at','modified_at']

    def get_product_type(self,obj):
        return getattr(obj.product_type, 'id', None)
    def get_product_type_value(self,obj):
        return getattr(obj.product_type, 'name', None)
    def get_product_code(self,obj):
        return getattr(obj.material_master, 'id', None)
    
    def get_product_code_value(self,obj):
        material_master = obj.material_master
        if material_master:
            mes_mat_code = material_master.mes_mat_code
            material_name = material_master.material_name
            return f'{mes_mat_code} {material_name}'
        return None


class ControlParameterSerializer(serializers.ModelSerializer):
    param_value=serializers.SerializerMethodField()
    class Meta:
        model = models.ControlParameter
        fields = '__all__'

    def get_param_value(self,obj):
        return Master.objects.get(pk=obj.param).value

class AdditivesSerializer(serializers.ModelSerializer):
    material_value=serializers.SerializerMethodField()
    class Meta:
        model = models.Additive
        fields = '__all__'

    def get_material_value(self,obj):
        return Master.objects.get(pk=obj.material).value

class FurnaceConfigStepSerializer(serializers.ModelSerializer):
    control_parameters = ControlParameterSerializer(many=True,read_only=True,source="furnace_control_params" )
    additives = AdditivesSerializer(many=True,read_only=True,source="furnace_additives")

    class Meta:
        model = models.FurnaceConfigStep
        fields = '__all__'


class FurnaceConfigSerializer(serializers.ModelSerializer):
    furnace_products = FurnaceProductSerializer(many=True, read_only=True,source="furnace_config_products")
    workshop_value=serializers.SerializerMethodField(read_only=True)
    
    class Meta:
        model = models.FurnaceConfig
        fields = '__all__'
    def get_workshop_value(self,obj):
        return getattr(obj.workshop,"workshop_name",None)
    

    def create(self, validated_data):
        furnace_config = models.FurnaceConfig.objects.create(**validated_data)
        return furnace_config
    
    def update(self, instance, validated_data):
        return super().update(instance, validated_data)
    
    def to_representation(self, instance):
        return super().to_representation(instance)


class FurnaceConfigListSerializer(serializers.ModelSerializer):
    workshop_value=serializers.SerializerMethodField(read_only=True)
    power_delivery_value = serializers.SerializerMethodField(read_only=True)
    electrode_type_value = serializers.SerializerMethodField(read_only=True)
    is_mandates_completed = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model=models.FurnaceConfig
        fields=['id','workshop_value','record_status','furnace_no', 'electrode_type_value', 'power_delivery_value','is_mandates_completed','is_active']
    def get_workshop_value(self,obj):
        return getattr(obj.workshop,"workshop_name",None)
    def get_electrode_type_value(self,obj):
        data=obj.furnace_config_electrodes.all()
        below_latest_date=data.filter(furnace_config=obj,effective_date__lte=now_date).order_by('-effective_date')
        above_latest_date=data.filter(furnace_config=obj,effective_date=now_date).order_by('-effective_date')
        selected_date=None
        if above_latest_date:
            selected_date = above_latest_date
        elif below_latest_date:
            selected_date = below_latest_date
        if  selected_date is None:
            above_latest_date=data.filter(furnace_config_id=obj,effective_date__gte=now_date).order_by('effective_date')
            selected_date=above_latest_date
        electrode_type_id=getattr(selected_date.first(),"electrode_type_id",None)
        try:
            electrode_type_value=Master.objects.get(master_code=electrode_type_id)
        except (Master.DoesNotExist,Exception):
            return None
        return getattr(electrode_type_value,'value',None)
    def get_power_delivery_value (self,obj):
        return getattr(obj.power_delivery,'value',None)
    
    def get_is_mandates_completed(self,obj):
        if obj.furnace_config_parameters.all().count() and obj.furnace_config_electrodes.all().count():
            return True
        else:
            return False
class ProductTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.ProductType
        fields = ['id', 'name']


class ProductCodeSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.ProductCode
        fields = ['id', 'product_type', 'name'] 



class FurnaceChangeLogSerializer(serializers.ModelSerializer):
    class Meta:
        model=models.FurnaceChangeLog
        fields="__all__"


class FurnaceStepChangeLogSerializer(serializers.ModelSerializer):
    steps=serializers.SerializerMethodField()
    username=serializers.SerializerMethodField()
    class Meta:
        model=models.FurnaceStepChangeLog
        exclude=['modified_at','record_status','change_log',]
    def get_steps(self,obj):
        return obj.change_log
    def get_username(self,obj):
        return getattr(obj.created_by,'username',None)

        



# ================================================== Furnace Get with unit =========================







class FurnaceElectrodeGetSerializer(serializers.ModelSerializer):
    core = serializers.SerializerMethodField(read_only=True)  
    core_value = serializers.SerializerMethodField(read_only=True)  
    paste = serializers.SerializerMethodField(read_only=True)  
    paste_value = serializers.SerializerMethodField(read_only=True)
    casing = serializers.SerializerMethodField(read_only=True)  
    casing_value = serializers.SerializerMethodField(read_only=True)    
    class Meta:
        model = models.FurnaceElectrode
        fields = '__all__'

 

    def get_core(self,obj):
        return getattr(obj.core, 'id', None)
    def get_core_value(self,obj):
        return getattr(obj.core, 'value', None)
    def get_paste(self,obj):
        return getattr(obj.paste, 'id', None)
    def get_paste_value(self,obj):
        return getattr(obj.paste, 'value', None)
    
    def get_casing(self,obj):
        return getattr(obj.casing, 'id', None)
    def get_casing_value(self,obj):
        return getattr(obj.casing, 'value', None)
    

    def get_mapped_value(self, key):
        return unit_map.get(key, None)
    
    def get_unit_value(self,name):
        plant=PlantConfig.objects.first()
        master=Master.objects.filter(master_code=plant.unit_id).first()
        unit= GlobalUnit.objects.get(name=name)
        if master.value=='Metric System':
            return unit.metric
        else:
            return unit.imperial
    # def to_representation(self, instance):
    #     data = super().to_representation(instance)

    #     for key, value in data.items():
    #         unit_value = self.get_mapped_value(key=key)
    #         if unit_value:
    #             try:
    #                 unit_val = self.get_unit_value(name=unit_value)
    #                 if unit_val is not None and value is not None:
    #                     data[key] = str(value) +" "+ str(unit_val)
    #                 else:
    #                     data[key] = value
    #             except Exception as e:
    #                 print(f"Error retrieving unit value for {unit_value}: {str(e)}")
    #         else:
    #             data[key] = value

    #     return data
    
    def to_representation(self, instance):
        data = super().to_representation(instance)

        for key,value in data.items():
            unit_value=self.get_mapped_value(key=key)
            unit_val=''
            if unit_value:
                unit_val=  self.get_unit_value(name=unit_value)
                if unit_val:
                    data[key]=value +' '+ unit_val
                else:
                    data[key]=value
            else:
                data[key]=value

        return data




class FurnaceConfigGetSerializer(serializers.ModelSerializer):
    # furnace_products = FurnaceProductSerializer(many=True, read_only=True,source="furnace_config_products")
    workshop_value=serializers.SerializerMethodField(read_only=True)
    furnace_products=serializers.SerializerMethodField()
    
    class Meta:
        model = models.FurnaceConfig
        fields = '__all__'
    def get_workshop_value(self,obj):
        return obj.workshop.workshop_name
    
    def get_furnace_products(self,obj):
        product_type_ids = list(models.ProductType.objects.values_list('id', flat=True))
        data = []
        for item in product_type_ids:
            products_data=[]
            for product in obj.furnace_config_products.values('id','furnace_config','material_master','record_status','product_type',):
               if product.get('product_type')==item:
                   obj=MaterialMaster.objects.filter(pk=product.get('material_master',None)).first()
                   product['material_master_value']=f'{obj.mes_mat_code} {obj.material_name}'
                   products_data.append(product)
            product= {
                "product_name":models.ProductType.objects.get(pk=item).name,
                    "product_type":item,
                    "products":products_data
                }
            if len(product['products']):
                    data.append(product)
        
        return data

    def to_representation(self, instance):
        representation= super().to_representation(instance)
        for field_name in ['created_at', 'modified_at', 'modified_by','created_by',]:
            representation.pop(field_name, None)
        return representation
    

    

class FurnaceMasterSerializer(serializers.ModelSerializer):
    furnace_id = serializers.IntegerField(source='id')
    class Meta:
        model = models.FurnaceConfig
        fields = ["furnace_id", "furnace_no", "furnace_description"]




class MaterialMasterSerializer(serializers.ModelSerializer):
    material_code=serializers.SerializerMethodField()
    class Meta:
        model = MaterialMaster
        fields=['id','material_code']

    def get_material_code(self,obj):
        return f'{obj.mes_mat_code} {obj.material_name}'

