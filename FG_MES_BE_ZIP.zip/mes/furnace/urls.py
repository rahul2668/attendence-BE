from django.urls import path,re_path,include
from . import views
from rest_framework.routers import DefaultRouter
router=DefaultRouter()
router.register('product-code',views.ProductCodeViewSet)

app_name="furnace"
urlpatterns = [
    path('',include(router.urls)),


    re_path(r'^basic-info/(?P<pk>\d*)?/?$',views.FurnaceConfigBasicInfoView.as_view(),name='furnace_config_basic_info'),
    re_path(r'^electrodes/(?P<pk>\d*)?/?$',views.FurnaceConfigElectrodeView.as_view(),name="furnace_config_electrode"),
    re_path(r'^parameters/(?P<pk>\d*)?/?$',views.FurnaceConfigParametersView.as_view(),name="furnace_config_parameters"),
    re_path(r'^refining-steps/(?P<furnace_id>\d*)?/?$', views.FurnaceConfigStepListAPIView.as_view(), name='furnace_config_refining_steps'),


    path('furnace-config-change-order/',views.FurnaceConfigChangeOrder.as_view(),name="furnace_config_change_order"),
    re_path(r'^product-type/(?P<pk>\d*)?/?$', views.ProductTypeView.as_view(), name='furnace_config_product_type'),
    re_path(r'^change-log/(?P<furnace_id>\d*)?/?$', views.FurnaceStepChangeLogView.as_view(), name='furnace_config_change_log'),


    path('furnace-no-list/',views.furnace_no_list,name="furnace_no_list"),

    


]
