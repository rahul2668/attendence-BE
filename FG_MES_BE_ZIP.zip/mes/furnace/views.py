from django.db import IntegrityError
from rest_framework.response import Response
from rest_framework.views import APIView
from mes.furnace.models import (FurnaceConfig,FurnaceElectrode,FurnaceProduct,FurnaceConfigStep,ControlParameter
                                ,Additive,ProductType,FurnaceStepChangeLog,FurnaceConfigParameters)
from rest_framework import status  ,viewsets
from django.http import Http404
from django.shortcuts import get_object_or_404  
from django.db.models import Q  
from .import serializers as se
from . import models as m
from . import utils
from mes.master_data.material_master.views import MaterialMasterPagination
from mes.utils.services import de_structure_errors,audit_columns_update
from django.utils import timezone
from rest_framework.decorators import api_view
from mes.utils.models import Master

    
def change_key_names(d, key_mappings):
    return {key_mappings.get(k, k): v for k, v in d.items()}


def get_furnace(**kwargs):
        try:
            return FurnaceConfig.objects.get(**kwargs)
        except FurnaceConfig.DoesNotExist:
            raise Http404

class FurnaceConfigBasicInfoView(APIView):
    serializer_class=se.FurnaceConfigSerializer
    def get_object(self, pk):
        try:
            return FurnaceConfig.objects.get(plant_id=pk)
        except FurnaceConfig.DoesNotExist:
            raise Http404
    def get(self, request, pk=None):
        plant_id=request.query_params.get('plant_id',None)
        view_type=request.query_params.get('type',None)
        if view_type=='edit':
            serializer_class=self.serializer_class
        else:
            serializer_class=se.FurnaceConfigGetSerializer
        if pk and plant_id:
            furnace_config = get_object_or_404(FurnaceConfig, plant_id=plant_id, pk=pk)
            serializer = serializer_class(furnace_config)
        elif pk:
            furnace_config = get_object_or_404(FurnaceConfig, pk=pk)
            serializer = serializer_class(furnace_config)
        elif plant_id:
            furnace_configs = FurnaceConfig.objects.filter(plant_id__istartswith=plant_id).order_by('-modified_at')
            serializer = se.FurnaceConfigListSerializer(furnace_configs, many=True)
        else:return Response({"message": "systemAdmin.furnaceConfiguration.providePlantIdNotify "}, status=status.HTTP_400_BAD_REQUEST)
        return Response(serializer.data)

    def post(self, request,plant_id=None, pk=None):
        data=request.data
        product_data_json=data.pop('furnace_products',[])
        user=request.user
        serializer=self.serializer_class(data=data)
        if not serializer.is_valid():
            return Response(de_structure_errors(serializer.errors),status=status.HTTP_400_BAD_REQUEST)
        try:
            workshop_id=data.pop('workshop',None)
            serializer.validated_data.pop('record_status',False)
            furnace_config=FurnaceConfig.objects.create(created_by=user,modified_by=user,workshop_id=workshop_id,**serializer.validated_data,record_status=False)
        except IntegrityError:
            return Response({'message': "systemAdmin.furnaceConfiguration.furnaceNoAlreadyExistsNotify","furnace_no":data.furnace_no}, status=status.HTTP_400_BAD_REQUEST)
        for furnace_product in product_data_json:
            for item in furnace_product.get('products',[]):
                item["furnace_config"]=furnace_config.furnace_no
                item["created_by"]=user.id
                item["modified_by"]=user.id
                item["modified_at"]=timezone.now()
                item['product_type']=furnace_product.get('product_type','')
                product_serializer=se.FurnaceProductSerializer(data=item)
                if product_serializer.is_valid():
                    product_serializer.save(created_by=user,modified_by=user,product_type_id=furnace_product.get('product_type',''),modified_at=timezone.now(),)
                else:
                    return Response(de_structure_errors(product_serializer.errors),status=status.HTTP_400_BAD_REQUEST)
        return Response({"message":"systemAdmin.furnaceConfiguration.furnaceAddedSuccessNotify","id":furnace_config.id}, status=status.HTTP_201_CREATED)

    def put(self, request, pk=None, *args, **kwargs):
        data=request.data
        furnace_id=data.pop('id',None)
        if not furnace_id:
            return Response({"message":"Unable to get the record"},status=status.HTTP_400_BAD_REQUEST)
        product_data_json=data.pop('furnace_products',[])
        try:
            furnace_config = FurnaceConfig.objects.get(pk=furnace_id)
        except FurnaceConfig.DoesNotExist:
            return Response({"message":f"Furnace with this {furnace_id} does not exists"})
        serializer = se.FurnaceConfigSerializer(furnace_config, data=request.data)
        user=request.user
        data.pop('workshop_value',None)
        if serializer.is_valid():
            serializer.save(modified_by=user,modified_at=timezone.now(),furnace_no=data.pop('furnace_no',furnace_config.furnace_no))
            # FurnaceConfig.objects.filter(pk=furnace_config.id,).update(modified_by=user,modified_at=timezone.now(),**data)
            for furnace_product in product_data_json:
                for item in furnace_product.get('products',[]):
                    pk=item.pop('id',None)
                    try:
                        instance = FurnaceProduct.objects.get(pk=pk)
                    except FurnaceProduct.DoesNotExist:
                        instance = None
                    product_serializer = se.FurnaceProductSerializer(instance=instance, data=item, partial=True)
                    if product_serializer.is_valid():
                        product_serializer.save(
                            product_type_id=furnace_product.get('product_type'),
                            furnace_config=furnace_config,
                            created_by=user,
                            modified_by=user,
                            modified_at=timezone.now()
                        )
                    else:
                        return Response(de_structure_errors(product_serializer.errors),status=status.HTTP_400_BAD_REQUEST)
        
            return Response({"message":"systemAdmin.furnaceConfiguration.furnaceDetailsUpdateNotify","id":furnace_config.id}, status=status.HTTP_200_OK)
        return Response(de_structure_errors(serializer.errors), status=status.HTTP_400_BAD_REQUEST)
    def patch(self,request,pk=None):
        furnace_config = get_object_or_404(FurnaceConfig, pk=pk)
        furnace_config.is_active = not furnace_config.is_active
        furnace_config.record_status=not furnace_config.record_status
        furnace_config.save()
        return Response({"message": f"{'systemAdmin.furnaceConfiguration.furnaceIsActivatedSuccessNotify' if furnace_config.is_active else 'systemAdmin.furnaceConfiguration.furnaceIsDeactivatedSuccessNotify'}"})


class FurnaceConfigElectrodeView(APIView):
    serializer_class=se.FurnaceElectrodeSerializer
    se_class=se.FurnaceElectrodeCreateSerializer
    model_class=FurnaceElectrode
    now_date=timezone.now().date()
    def get_furnace(self,**kwargs):
        try:
            return FurnaceConfig.objects.get(**kwargs)
        except FurnaceConfig.DoesNotExist:
            raise Http404
    def get_object(self, **kwargs):
        try:
            return FurnaceElectrode.objects.get(**kwargs)
        except FurnaceElectrode.DoesNotExist:
            raise Http404

    def get(self,request,pk=None):
        furnace=self.get_furnace(pk=pk)
        data= furnace.furnace_config_electrodes.all()
        excel_download=request.query_params.get('excel_download','')
        if excel_download:
            serializer=self.serializer_class(data,many=True,context={"request":request})
            return Response({"data":serializer.data})
        below_latest_date=data.filter(effective_date__lte=self.now_date).order_by('-effective_date')
        above_latest_date=data.filter(effective_date=self.now_date).order_by('-effective_date')
        selected_date=None
        if above_latest_date:
            selected_date = above_latest_date
        elif below_latest_date:
            selected_date = below_latest_date
        if  selected_date is None:
            above_latest_date=data.filter(furnace_config_id=pk,effective_date__gte=self.now_date).order_by('effective_date')
            selected_date=above_latest_date
        serializer = self.serializer_class(selected_date[:3] if selected_date else selected_date,many=True)
        data={}
        selected_first_electrode=selected_date.first()
        data['electrodes']=serializer.data
        data["effective_date"]=getattr(selected_first_electrode,"effective_date",None)
        data["furnace_config"]=int(pk)
        data['diameter']=getattr(selected_first_electrode,"diameter",None)
        data["electrode_type_id"]=getattr(selected_first_electrode,"electrode_type_id",None)
        data["electrode_type_code"]=getattr(Master.objects.filter(master_code=getattr(selected_first_electrode,'electrode_type_id',None)).first(),'master_code',None)
        data=data if selected_date else {}
        return Response(data)


    def post(self,request,pk=None):
        user=request.user
        furnace_electrode_data=request.data.get('electrodes',[])
        user_approval=request.data.get('is_user_approved',False)
        ids = [electrode.get('id',None) for electrode in furnace_electrode_data]
        furnace_config=FurnaceConfig.objects.get(pk=request.data.get("furnace_config",pk))
        audit_columns_update(obj=furnace_config,user=user)
        electrode_type=request.data.get('electrode_type_code', None)
        for furnace_electrode in furnace_electrode_data:
            electrode_id=furnace_electrode.pop('id',None)
            furnace_config_id=request.data.get("furnace_config",pk)
            effective_date=request.data.get('effective_date', furnace_electrode.get('effective_date'))
            filters = {
                    'furnace_config': furnace_config.furnace_no,
                    'effective_date': effective_date,
                }
            check_existing_electrodes=self.model_class.objects.filter(**filters).exclude(Q(pk__in=ids))
            if check_existing_electrodes.exists() and check_existing_electrodes.count()>2 and not user_approval:
                return Response({"message":"apiNotifications.userApprovalNeeded","user_approval_needed":True},status=status.HTTP_200_OK)
            furnace_electrode['diameter'] = request.data.get('diameter', None)
            furnace_electrode['effective_date'] = effective_date
            furnace_electrode['furnace_config_id']=furnace_config_id
            furnace_electrode['furnace_config']=furnace_config.furnace_no
            furnace_electrode['electrode_type'] = electrode_type
            serializer=self.se_class(data=furnace_electrode)
            def save_electrode():
                data={
                        "core_mass_length":furnace_electrode.get('core_mass_length'),
                        "paste_mass_length":furnace_electrode.get('paste_mass_length'),
                        "casing_mass_length":furnace_electrode.get('casing_mass_length'),
                        "core_id":furnace_electrode.get('core',None),
                        "casing_id":furnace_electrode.get('casing',None),
                        "paste_id":furnace_electrode.get('paste',None),
                        "electrode_type_id":electrode_type,
                        "diameter":furnace_electrode.get('diameter',None),
                        "modified_by":user,
                        "modified_at":self.now_date,
                        "electrode_name":furnace_electrode.get('electrode_name',None)
                    }
                data.update(filters)
                data.update({'furnace_config':furnace_config})
                electrode = self.model_class.objects.filter(**filters,electrode_name=furnace_electrode.get('electrode_name',None))
                if electrode.exists():
                    electrode.update(**data)
                else:
                    self.model_class.objects.create(**data,created_by=user)
                furnace_config_change_status(furnace_config=furnace_config)
            if not serializer.is_valid():
                errors=de_structure_errors(serializer.errors)
                if errors.get('non_field_errors',None)=="The fields furnace_config, electrode_name, effective_date must make a unique set.":
                    save_electrode()
                else:
                    return Response(errors,status=status.HTTP_400_BAD_REQUEST)
            else:
                save_electrode()
        return Response({"id":int(furnace_config_id),"message":"systemAdmin.furnaceConfiguration.furnaceElectrodeUpdatedSuccessNotify"})
        
class FurnaceConfigParametersView(APIView):
    serializer_class=se.FurnaceConfigParametersSerializer
    model_class=FurnaceConfigParameters
    now_date=timezone.now().date()
    def get_furnace(self,**kwargs):
        try:
            return FurnaceConfig.objects.get(**kwargs)
        except FurnaceConfig.DoesNotExist:
            raise Http404
    def get_object(self, **kwargs):
        try:
            return FurnaceConfigParameters.objects.get(**kwargs)
        except FurnaceConfigParameters.DoesNotExist:
            raise Http404
        
    def get(self,request,pk=None):
        furnace_config=self.get_furnace(pk=pk)
        data= furnace_config.furnace_config_parameters.all()
        excel_download=request.query_params.get('excel_download','')
        if excel_download:
            serializer=self.serializer_class(data,many=True,context={"request":request})
            return Response({"data":serializer.data})
        below_latest_date=data.filter(effective_date__lte=self.now_date).order_by('-effective_date').first()
        above_latest_date=data.filter(effective_date=self.now_date).order_by('-effective_date').first()
        selected_date=None
        if above_latest_date:
            selected_date = above_latest_date
        elif below_latest_date:
            selected_date = below_latest_date
        if  selected_date is None:
            above_latest_date=data.filter(effective_date__gte=self.now_date).order_by('effective_date').first()
            selected_date=above_latest_date
        serializer = self.serializer_class(selected_date)
        return Response({"data":serializer.data if selected_date else {}})
    def save(self,furnace_config=None,user=None,**kwargs):
            
            parameters=self.model_class.objects.filter(furnace_config=furnace_config,effective_date=kwargs.get('effective_date'))
            if parameters.exists():
                parameters.update(**kwargs,modified_by=user,modified_at=self.now_date)
            else:
                self.model_class.objects.create(**kwargs,modified_by=user,modified_at=self.now_date,created_at=self.now_date)
            furnace_config_change_status(furnace_config=furnace_config)


    def post(self,request,pk=None):
        data=request.data 
        user=request.user
        serializer=self.serializer_class(data=data)
        is_user_approved=data.get('is_user_approved',False)
        parameter_id=data.pop('id',None)
        furnace_config=self.get_furnace(furnace_no=data.get('furnace_config'))
        data['furnace_config']=furnace_config.furnace_no
        data_to_save={item if item !="furnace_config" else "furnace_config_id":data.get(item,None) for item in data if hasattr(self.model_class,item)}
        check_existing_parameters=self.model_class.objects.filter(furnace_config_id=data_to_save.get('furnace_config_id'),effective_date=data_to_save.get('effective_date')).exclude(Q(pk=parameter_id),)
        if check_existing_parameters.exists() and not is_user_approved:
            return Response({"message":"apiNotifications.userApprovalNeeded","user_approval_needed":True},status=status.HTTP_200_OK)
        if serializer.is_valid() or  de_structure_errors(serializer.errors).get('non_field_errors',None)=="The fields furnace_config, effective_date must make a unique set.":
            audit_columns_update(obj=furnace_config,user=user)
            self.save(furnace_config=furnace_config,user=user,**data_to_save)
            try:
                if furnace_config.furnace_config_parameters.all().count() and furnace_config.furnace_config_electrodes.all().count() and not furnace_config.record_status:
                    furnace_config.record_status=True
                    furnace_config.modified_at=timezone.now()
                    furnace_config.modified_by=user
                    furnace_config.save()

            except (FurnaceConfig.DoesNotExist,Exception):pass
            return Response({"id":furnace_config.id,"message":"systemAdmin.furnaceConfiguration.furnaceParametersUpdatedSuccessNotify"})
        else:
            return Response(de_structure_errors(serializer.errors),status=status.HTTP_404_NOT_FOUND)


class FurnaceConfigStepListAPIView(APIView):
    def get_object(self,**kwargs):
        try:
            return FurnaceConfig.objects.get(**kwargs)
        except FurnaceConfig.DoesNotExist:
            raise Http404
    def get(self,request,furnace_id):
        furnace_config=self.get_object(pk=furnace_id)
        data=FurnaceConfigStep.objects.filter(furnace=furnace_config)
        serializer=se.FurnaceConfigStepSerializer(data,many=True)
        return Response({"data":serializer.data})
    

    def post(self,request,furnace_id=None):
        data=request.data.get('step_data')
        user=request.user
        furnace_config=self.get_object(pk=furnace_id)
        for index,item in enumerate(data,start=1):
            control_parameters=  item.pop('controlParameters', [])
            additives_data=item.pop('additives', [])
            item.pop('order', None)
            if not control_parameters: return Response({"message":"systemAdmin.furnaceConfiguration.controlParametersCantEmptyNotify"},status=status.HTTP_400_BAD_REQUEST)
            furnace_config_step = FurnaceConfigStep.objects.create(created_by=user,furnace=furnace_config,order=index,**item)
            for control_param_data in control_parameters:
                if 'icon' in control_param_data:
                    control_param_data.pop('icon')
                # plant_model.ControlParameter.objects.create(furnace_config_step=furnace_config_step, **control_param_data)
                ControlParameter.objects.create(created_by=user,furnace_config_step=furnace_config_step, **control_param_data)
            for additive_data in additives_data:
                if 'icon' in additive_data:
                        additive_data.pop('icon')
                Additive.objects.create(created_by=user,furnace_config_step=furnace_config_step, **additive_data)
        audit_columns_update(obj=furnace_config,user=user)
        return Response({"message":"systemAdmin.furnaceConfiguration.furnaceDetailAddedSuccessNotify"}, status=201, )
    
    def put(self,request,furnace_id):
        import copy
        data = request.data.get('step_data')
        copied_data = copy.deepcopy(data) 
        furnace_config=self.get_object(pk=furnace_id)
        change_log_json_data = utils.save_new_change_log(data=copied_data,furnace_config=furnace_config)
        user=request.user
        ids=[]
        audit_columns_update(obj=furnace_config,user=user)

        for item in data:
            pk_id = item.get('id', None)
            cont_params=item.pop('control_parameters',[])
            control_parameters=  item.pop('controlParameters', cont_params)
            additives_data=item.pop('additives', [])
            if  len(control_parameters)==0: return Response({"message":"systemAdmin.furnaceConfiguration.controlParametersCantEmptyNotify"},status=status.HTTP_400_BAD_REQUEST)
            if pk_id:
                FurnaceConfigStep.objects.filter(Q(pk=pk_id), furnace=furnace_config).update(modified_by=user, **item)
                furnace_config_step= FurnaceConfigStep.objects.filter(pk=pk_id).first()
            elif control_parameters:
                furnace_config_step = FurnaceConfigStep.objects.create(created_by=user,furnace=furnace_config,**item)
            if furnace_config_step:ids.append(furnace_config_step.id)
            for control_param_data in control_parameters:
                if 'icon' in control_param_data:
                    control_param_data.pop('icon')
                pk=control_param_data.pop('id', None)
                if pk:
                    ControlParameter.objects.filter(furnace_config_step=furnace_config_step, pk=pk).update(modified_by=user,**control_param_data)
                else:
                    ControlParameter.objects.create(created_by=user,furnace_config_step=furnace_config_step, **control_param_data)
            for additive_data in additives_data:
                if 'icon' in additive_data:
                    additive_data.pop('icon')
                pk=additive_data.pop('id',None)
                if pk:
                    Additive.objects.filter(furnace_config_step=furnace_config_step,pk=pk).update(modified_by=user,**additive_data)
                else:
                    Additive.objects.create(created_by=user,furnace_config_step=furnace_config_step, **additive_data)
        FurnaceConfigStep.objects.filter(furnace=furnace_config).exclude(id__in=ids).update(record_status=False)
        if len(change_log_json_data)>0:
            FurnaceStepChangeLog(
                furnace=furnace_config,
                change_log=change_log_json_data,
                created_by=user
            ).save()
        return Response({"message":"systemAdmin.furnaceConfiguration.furnaceDetailsUpdateNotify"})

class FurnaceConfigChangeOrder(APIView):
    def post(self,request):
        data=request.data.get('data',[])
        for item in data:
            FurnaceConfigStep.objects.filter(pk=item.pop("id")).update(modified_by=request.user,**item)
        return Response({"message":"systemAdmin.furnaceConfiguration.furnaceConfigUpdateNotify"})


class ProductTypeView(APIView):
    def get_object(self, pk):
        try:
            return ProductType.objects.get(pk=pk)
        except ProductType.DoesNotExist:
            raise Http404

    def get(self, request, pk):
        if pk:
            product_type = self.get_object(pk)
            serializer = se.ProductTypeSerializer(product_type)
            return Response(serializer.data)
        else:
            product_types = ProductType.objects.all()
            serializer = se.ProductTypeSerializer(product_types, many=True)
            return Response(serializer.data)
    def post(self, request,pk=None):
        serializer = se.ProductTypeSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(de_structure_errors(serializer.errors), status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, pk):
        product_type = self.get_object(pk)
        serializer = se.ProductTypeSerializer(product_type, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({"message":""})
        return Response(de_structure_errors(serializer.errors), status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        product_type = self.get_object(pk)
        product_type.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
    


class FurnaceStepChangeLogView(APIView):
    def get(self,request,furnace_id):
        change_log=m.FurnaceStepChangeLog.objects.filter(furnace=get_furnace(pk=furnace_id)).order_by('-created_at')
        serializer=se.FurnaceStepChangeLogSerializer(change_log,many=True)
        return Response({"data":serializer.data})




class ProductCodeViewSet(viewsets.ModelViewSet):
    queryset = se.MaterialMaster.objects.all()
    serializer_class = se.MaterialMasterSerializer
    pagination_class = MaterialMasterPagination


    def get_queryset(self):
        queryset=super().get_queryset()
        search_key = self.request.query_params.get('search_key', None)
        product_type = self.request.query_params.get('product_type', None)

        if product_type=='WIP':
            queryset=queryset.filter(record_status=True,material_type__category__category_name='WIP')
        if product_type=='Molten':
            # queryset=queryset.filter(material_type__category__category_name='Raw Materials')
            return queryset.none()

        if search_key:
            queryset=queryset.filter(Q(mes_mat_code__icontains=search_key)|Q(material_name__icontains=search_key))
        return queryset



@api_view(['GET'])
def furnace_no_list(request):
    furnaces = FurnaceConfig.objects.all().values_list('furnace_no',flat=True)
    return Response(furnaces,status=status.HTTP_200_OK)



def furnace_config_change_status(furnace_config):
    try:
        if furnace_config.furnace_config_parameters.all().count() and furnace_config.furnace_config_electrodes.all().count() and not furnace_config.record_status:
            furnace_config.record_status=True
            furnace_config.modified_at=timezone.now()
            furnace_config.save()
    except (FurnaceConfig.DoesNotExist,Exception):pass 