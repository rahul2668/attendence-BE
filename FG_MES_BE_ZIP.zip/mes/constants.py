EXCLUDE_FUNCTIONS_LIST=["Furnace Downtime Log - Event", "Furnace Downtime Log - Split"]    
FURNACE_DOWN_TIME_LOG="Furnace Downtime Log"


FILTER_KEYS_LOG_BOOK={
    "observation_id":"id",
    "username":"modified_by__username",
    "furnace_no":"furnace__furnace_no",
    "observation_dt":"observation_dt",
    "observation_start_dt":"observation_start_dt",
    "observation_end_dt":"observation_end_dt",
    "equipment_value":"equipment__name",
    "reason_value":"reason__name",
    "event_status":"event_status",
    "event_id":'id',
    "duration":'duration'

}

SEARCH_QUERY_NON_FIELDS_CHOICES = {
        'Planned':'1', 
        'Operational':'2', 
        'BreakDown':'3', 
        'Other':'4',
        'Manual':"1",
        'Automate':"2"
}  

SEARCH_QUERY_NON_FIELDS=['source','down_time_type']

DB_SEARCH_QUERY_KEYS={
    "furnace_no":'furnace__furnace_no__icontains',
    "username":"modified_by__username__in",
    "observation_dt":"observation_dt__date__range",
    "record_status":'record_status',
    "source_value":"source",
    "down_time_type_value":"down_time_type",
    'reason_value':"reason__reason__reason_code__in",
    "equipment_value":"equipment__equipment__equipment_code__in",
    "observation_start_dt":"observation_start_dt__date__gte",
    "observation_end_dt":"observation_end_dt__date__lte",
    "down_time_type":"down_time_type__down_time_type_code__in"

}


CURRENCY_VALUES={
    'United States Dollar ($)':'$',
    'Pound Sterling (£)':"£",
    'Euro (€)':" €",
    'Canadian Dollar (C$)':"C$",
    'South African Rand (ZAR)':"ZAR",
    'Argentine Peso (Arg$)':"Arg$",
    'Norwegian Krone (NOK)':"kr",
    'Venezuelan bolívar (Bs)':"Bs",
    'Chinese Yuan (¥)':"¥"
            }


CURRENCY_COLUMNS=['fixed_cost','target_cost_budget','energy_price','actual_cost','standard_cost']
EXCEL_UNIT_KEYS={
    "casing_mass_length":"Casing Mass/Length",
    "core_mass_length":"Core Mass/Length",
    "paste_mass_length":"Paste Mass/Length",
    "energy_losses":"Energy Losses",
    "joule_losses_coefficient":"Joule Losses Coefficient",
    "default_epi_index":"Default EPI Index",
    "corrected_reactance_coefficient":"Corrected Reactance Coefficient",
    "design_mv":"Design MW",
    "target_energy_efficiency":"Target Energy Efficiency",
    "target_availability":"Target Availability",
    "target_furnace_load":"Target Furnace Load",
    "crucible_diameter":"Crucible Diameter",
    "crucible_depth":"Crucible Depth",
    "pcd_theoretical":"PCD Theoretical",
    "pcd_actual":"PCD Actual",
    "unit_weight":"Unit Weight",
    "density":"Density",
    "kwh_melting":"kWh Melting",
    'fixed_cost':'fixed_cost',
    'target_cost_budget':'target_cost_budget',
    'standard_cost':'standard_cost',
    "actual_cost":"actual_cost"
    


}