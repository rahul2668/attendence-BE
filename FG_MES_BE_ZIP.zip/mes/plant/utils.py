
from mes.users.models import User,RolePermission

def set_first_user_permissions(plant_config,):
    if RolePermission.objects.filter(role_id = 1).count() > 1:
        return 
    functions=plant_config.plant_config_function.all()
    for item in functions:

        user=User.objects.first()
        role=user.roles.filter(role_name="SuperAdmin").first()
        role_permission=RolePermission.objects.filter(function_master_id=item.function.id).first()
        if not role_permission:
            RolePermission.objects.create(
                function_master=item.function,
                role=role,
                view=True,
                create=True,
                edit=True,
                delete=True,
                created_by=user
                )
        else:
            RolePermission.objects.filter(
                function_master=item.function,
                role=role,
                ).update( view=True,
                create=True,
                edit=True,
                delete=True,
                modified_by=user)
            



    