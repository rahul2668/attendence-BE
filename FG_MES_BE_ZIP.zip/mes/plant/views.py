from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status 
from rest_framework.views import APIView
from .models import Function,PlantConfig,PlantConfigProduct,PlantConfigWorkshop,PlantConfigFunction,PlantConfigParameters
from . import serializers  as se
from django.http import Http404
from . import models as plant_model
from mes.utils.models  import Module
from mes.utils.serializers import ModuleSerializer
from .utils import set_first_user_permissions
from mes.constants import EXCLUDE_FUNCTIONS_LIST,FURNACE_DOWN_TIME_LOG
from mes.utils.services import de_structure_errors
from django.db.models import Q
from django.utils import timezone


class FunctionListView(APIView):
    def get(self,request,):
        data=Module.objects.all()
        serializer=ModuleSerializer(data,many=True)
        return Response(serializer.data)
    
    
class PlantConfigView(APIView):
    serializer_class=se.PlantConfigSerializer
    model_class=PlantConfig
    param_model_class=PlantConfigParameters
    now_date=timezone.now().date()

    def get_object(self,  **kwargs):
        try:
            return PlantConfig.objects.get(**kwargs)
        except PlantConfig.DoesNotExist:
            raise Http404
    def get(self, request, pk=None):
        if pk:
            try:
                plant_config =  PlantConfig.objects.get(plant_id=pk)
            except PlantConfig.DoesNotExist:
                return Response({},status=status.HTTP_200_OK)
            serializer = se.PlantConfigSerializer(plant_config)
            below_latest_date=self.param_model_class.objects.filter(plant_config__plant_id=pk,effective_date__lte=self.now_date).order_by('-effective_date').first()
            above_latest_date=self.param_model_class.objects.filter(plant_config__plant_id=pk,effective_date=self.now_date).order_by('-effective_date').first()
            selected_date=None
            if above_latest_date:
                selected_date = above_latest_date
            elif below_latest_date:
                selected_date = below_latest_date
            if  selected_date is None:
                above_latest_date=self.param_model_class.objects.filter(plant_config__plant_id=pk,effective_date__gte=self.now_date).order_by('effective_date').first()
                selected_date=above_latest_date
            param_serializer = se.ParameterSerializer(selected_date)
            data=serializer.data
            data['parameters']=param_serializer.data 
            return Response(data)
        else :
            return Response({"message":"systemAdmin.plantConfiguration.plantIdMissingNotify"},status=status.HTTP_404_NOT_FOUND)
        # else:
        #     plant_configs = PlantConfig.objects.all()
        #     serializer = se.PlantConfigSerializer(plant_configs, many=True)
    def post(self,request,):
        data= request.data
        user=request.user
        plant_config_products=data.pop('productName',[])
        plant_config_workshops=data.pop('workshops',[])
        function_json=data.pop('function',[])
        serializer = se.PlantConfigSerializer(data=data)
        if PlantConfig.objects.all().count():
            return Response({"message":"systemAdmin.plantConfiguration.plantAlreadyConfigured"},status=status.HTTP_400_BAD_REQUEST)
        if serializer.is_valid(raise_exception=True):
            plant_config=serializer.save()
            check_parameters=check_and_save_plant_config_parameters(request=request,plant_config=plant_config.id)
            if not check_parameters:
                return Response({"message":"apiNotifications.userApprovalNeeded","user_approval_needed":True},status=status.HTTP_200_OK)
            for plant_config_product in plant_config_products:
                PlantConfigProduct.objects.create(plant_config=plant_config,**plant_config_product,created_by=user)
            for plant_config_workshop in plant_config_workshops:
                PlantConfigWorkshop.objects.create(plant_config=plant_config,**plant_config_workshop,created_by=user)
            for function in function_json:
                plant_model.PlantConfigFunction.objects.create(plant_config=plant_config,**function,created_by=user)
            for func in EXCLUDE_FUNCTIONS_LIST:
                function_master=Function.objects.get(function_name__iexact=func)
                if not plant_model.PlantConfigFunction.objects.filter(function__function_name__iexact=func).first() and plant_model.PlantConfigFunction.objects.filter(function__function_name=FURNACE_DOWN_TIME_LOG).exists():
                    PlantConfigFunction.objects.create(plant_config=plant_config, module=function_master.module, function=function_master)
            set_first_user_permissions(plant_config)
            return Response({'message': 'systemAdmin.plantConfiguration.plantConfigProcessedNotify'}, status=status.HTTP_200_OK)
        return Response({"message":de_structure_errors(serializer.errors)}, status=status.HTTP_400_BAD_REQUEST)
   
    
    def put(self, request, pk=None):
        data=request.data
        user=request.user
        plant_config_products=data.pop('productName')
        plant_config_workshops=data.pop('workshops')
        plant_functions=data.pop('function')
        plant_config = self.get_object(plant_id=pk)
        serializer = se.PlantConfigSerializer(plant_config, data=request.data,partial=True)
        if serializer.is_valid():
            plant_config=serializer.save()
            check_parameters=check_and_save_plant_config_parameters(request=request,plant_config=plant_config.id)
            if not check_parameters:
                return Response({"message":"apiNotifications.userApprovalNeeded","user_approval_needed":True},status=status.HTTP_200_OK)
          
            plant_product_ids=[]
            plant_function_ids=[]
            for plant_product in plant_config_products:
                pk_plant_product_id = plant_product.pop('id',None)
                if pk_plant_product_id:
                    PlantConfigProduct.objects.filter(pk=pk_plant_product_id,plant_config=plant_config).update(modified_by=user,**plant_product)
                    product = PlantConfigProduct.objects.filter(pk=pk_plant_product_id,plant_config=plant_config).first()
                else:
                    product = PlantConfigProduct.objects.create(plant_config=plant_config,**plant_product,created_by=user)

                plant_product_ids.append(product.id)
            for plant_workshop in plant_config_workshops:
                plant_workshop.pop('is_deactivate',None)
                plant_workshop.pop('id',None)
                workshop=PlantConfigWorkshop.objects.filter(workshop_name__exact=plant_workshop.get('workshop_name',''),plant_config=plant_config)
                if workshop.exists():
                    workshop.update(modified_by=user,**plant_workshop)
                else:
                    PlantConfigWorkshop.objects.create(plant_config=plant_config,**plant_workshop,created_by=user)

            for plant_function in plant_functions:
                plant_func=PlantConfigFunction.objects.filter(plant_config=plant_config,**plant_function)
                if plant_func.exists():
                    plant_func.update(modified_by=user,**plant_function)
                    functions = plant_func.first()
                else:
                    functions = plant_model.PlantConfigFunction.objects.create(plant_config=plant_config,**plant_function,created_by=user)
                plant_function_ids.append(functions.id)
            for func in EXCLUDE_FUNCTIONS_LIST:
                function_master=Function.objects.get(function_name__iexact=func)
                if not plant_model.PlantConfigFunction.objects.filter(function__function_name__iexact=func).first() and plant_model.PlantConfigFunction.objects.filter(function__function_name=FURNACE_DOWN_TIME_LOG).exists() :
                    plant_function=PlantConfigFunction.objects.create(plant_config=plant_config, module=function_master.module, function=function_master)
                    plant_function_ids.append(plant_function.id)
                elif PlantConfigFunction.objects.filter(function__function_name=FURNACE_DOWN_TIME_LOG).exists():
                    plant_function=PlantConfigFunction.objects.filter(plant_config=plant_config, module=function_master.module, function=function_master).first()
                    plant_function_ids.append(plant_function.id)

            plant_model.PlantConfigFunction.objects.filter(plant_config=plant_config).exclude(id__in=plant_function_ids).delete()
            PlantConfigProduct.objects.filter(plant_config=plant_config).exclude(pk__in=plant_product_ids).delete()
            set_first_user_permissions(plant_config,)
            return Response({"message":"systemAdmin.plantConfiguration.plantConfigUpdatedNotify"})
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

def check_and_save_plant_config_parameters(request,plant_config):
    parameters=plant_model.PlantConfigParameters
    serializer_cls=se.ParameterSerializer
    data=request.data.get('parameters',{})
    user_approval=request.data.get('is_user_approved',False)

    pk=data.get('id',None)
    user=request.user
    effective_date=data.get('effective_date',None)
    if pk:
        check_existing_parameter=parameters.objects.filter(pk=pk,effective_date=effective_date,plant_config=plant_config)
        if check_existing_parameter:
            check_existing_parameter.update(energy_price=data.get('energy_price'),modified_by=user,modified_at=timezone.now(),effective_date=effective_date)
            return True
    check_existing_parameter=parameters.objects.filter(effective_date=effective_date,plant_config=plant_config)
    if not check_existing_parameter.exists():
        data['plant_config']=plant_config
        serializer=serializer_cls(data=data)
        if serializer.is_valid():
            serializer.save(created_by=user,modified_by=user)
        return True
    if check_existing_parameter.exists() and not user_approval:
        return user_approval
    parameter=check_existing_parameter.first()
    if parameter:
        parameter.effective_date=effective_date
        parameter.energy_price=data.get('energy_price')
        parameter.modified_by=user
        parameter.modified_at=timezone.now()
        parameter.save()
    return True




    
@api_view(['GET'])
def get_plant_config_parameters_for_excel_download(request):
    
    parameters=PlantConfigParameters.objects.all()
    serializer=se.ParameterSerializer(parameters,many=True,context={"request":request})
    return Response({"data":serializer.data},status=status.HTTP_200_OK)
