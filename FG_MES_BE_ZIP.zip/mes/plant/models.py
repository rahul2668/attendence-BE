from django.db import models

from django.utils.translation import gettext_lazy as _
from django.db import connection
from mes.utils.models import BaseModel, Module, Function, Master
# Create your models here.

class Plant(BaseModel):
    plant_name=models.CharField(max_length=100,default="")
    plant_id=models.CharField(max_length=20,default="")
    area_code=models.CharField(max_length=20,default="")

    def __str__(self) -> str:
        return self.plant_name

class PlantConfig(BaseModel):
    plant_id=models.CharField(max_length=50,unique=True)
    plant_name = models.CharField(_("plant_config_name"), max_length=100)
    area_code = models.CharField(_("plant_config_area_code"), max_length=100)
    plant_address = models.CharField(_("plant_config_address"), max_length=100)
    timezone = models.ForeignKey(Master,related_name="plant_timezone",on_delete=models.PROTECT, to_field='master_code')
    language = models.ForeignKey(Master,related_name="plant_language",on_delete=models.PROTECT, to_field='master_code')
    unit = models.ForeignKey(Master,related_name="plant_unit",on_delete=models.PROTECT, to_field='master_code')
    currency = models.ForeignKey(Master,related_name="plant_currency",on_delete=models.PROTECT, to_field='master_code')
    shift1_from = models.CharField(_("plant_config_shift1_from"), max_length=100)
    shift1_to = models.CharField(_("plant_config_shift1_to"), max_length=100)
    shift2_from = models.CharField(_("plant_config_shift2_from"), max_length=100)
    shift2_to = models.CharField(_("plant_config_shift2_to"), max_length=100)
    shift3_from = models.CharField(_("plant_config_shift3_from"), max_length=100)
    shift3_to = models.CharField(_("plant_config_shift3_to"), max_length=100)


    def __str__(self) -> str:
        return self.plant_id



class PlantConfigProduct(BaseModel):
    plant_config = models.ForeignKey(PlantConfig,related_name="plant_config_products", on_delete=models.CASCADE)
    product = models.ForeignKey(Master,related_name="plant_product",on_delete=models.PROTECT, to_field='master_code')
    
    class Meta:
        db_table = 'plant_config_product'

class PlantConfigWorkshop(BaseModel):
    plant_config = models.ForeignKey(PlantConfig,related_name="plant_config_workshops", on_delete=models.CASCADE)
    workshop_name = models.CharField(max_length=500, unique=True)
    

    class Meta:
        db_table = 'plant_config_workshop'

class PlantConfigFunction(BaseModel):
    plant_config = models.ForeignKey(PlantConfig,related_name="plant_config_function", on_delete=models.CASCADE)
    module = models.ForeignKey(Module,related_name="plant_config_modules",on_delete=models.PROTECT, to_field='module_code')
    function = models.ForeignKey(Function,related_name="plant_config_functions",on_delete=models.PROTECT, to_field='function_code')

    class Meta:
        unique_together = ( 'module', 'function')



class PlantConfigParameters(BaseModel):
    plant_config = models.ForeignKey(PlantConfig,related_name="plant_config_parameters", on_delete=models.CASCADE,)
    effective_date=models.DateField()
    energy_price = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self) -> str:
        return f"{self.plant_config.plant_name}"
    
    class Meta:
        db_table="plant_config_parameters"
        db_table_comment="It holds the Plant config  parameters"
        unique_together=('plant_config','effective_date')
