from django.urls import path
from . import views

from rest_framework.routers import DefaultRouter

router=DefaultRouter()


app_name = "plant"
urlpatterns = [
    path("function/", view=views.FunctionListView.as_view(), name="function"),
    path('plant-config/<str:pk>/',views.PlantConfigView.as_view(),name='plant_config'),
    path('plant-config-post/',views.PlantConfigView.as_view(),name='plant_config'),
    path('parameter-excel-download/6V/',views.get_plant_config_parameters_for_excel_download,name="get_plant_config_parameters_for_excel_download")
]
