from django.urls import re_path,path
from . import views



app_name="log_book"
urlpatterns=[
     re_path(r'^furnacebed/(?P<pk>\d*)?/?$',views.FurnaceBedLogAPIView.as_view(),name='furnace_bed_log'),
     re_path(r'^taphole/(?P<pk>\d*)?/?$',views.TapHoleLogAPIView.as_view(),name='tap_hole_log'),
     path('get-all-furnace/',views.get_all_furnace_list,name='get_all_furnace_list'),
     path('furnacebed-radios/',views.get_radios,name='get_all_furnacebed_radios'),
     path('taphole-radios/',views.get_radios,name='get_all_taphole_radios'),
     path('furnace-downtime-type-master/',views.get_downtime_type_master_list,name='get_downtime_type_master_list'),
     re_path(r'^furnace-downtime-equipment-master/(?P<pk>[\w-]+)?/?$',views.get_equipment_master_list,name='furnace_downtime_master'),
     re_path(r'furnace-downtime-reasons/(?P<pk>[\w-]+)?/?$',views.get_reason_list,name='furnace_downtime_reasons'),
     re_path(r'^furnace-downtime/(?P<pk>\d*)?/?$',views.FurnaceDownTimeEventAPIView.as_view(),name='furnace_downtime_event'),
     re_path(r'^furnace-downtime-split/(?P<pk>\d*)?/?$',views.FurnaceDownTimeSplitAPIView.as_view(),name='furnace_downtime_split'),

]