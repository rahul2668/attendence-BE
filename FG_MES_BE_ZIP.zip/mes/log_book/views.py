from rest_framework.response import Response
from rest_framework.views import APIView
from .  import serializers as se
from . import models
from rest_framework import status  
from django.http import Http404
from django.db.models import Q
from rest_framework.pagination import PageNumberPagination
from mes.utils.services import de_structure_errors,query_params ,separate_date_time
from django.utils import timezone
from mes.constants import FILTER_KEYS_LOG_BOOK
from .utils import csv_download_furnace_downtime_event_split
from django.views.generic import View

from django.db.models import F, ExpressionWrapper, Case, When,DateTimeField,Value

# Define a Case expression to handle NULL observation_end_dt
duration_expression = ExpressionWrapper(
    Case(
        When(observation_end_dt__isnull=False, then=F('observation_end_dt') - F('observation_start_dt')),
        default=None,
        output_field=DateTimeField()
    ),
    output_field=DateTimeField()
)


# Define a Case expression to handle null observation_end_dt
desc_duration_expression = ExpressionWrapper(
    Case(
        When(observation_end_dt__isnull=False, then=F('observation_end_dt') - F('observation_start_dt')),
        default=Value('0 days'),  # Assign a large value for null records
        output_field=DateTimeField()
    ),
    output_field=DateTimeField()
)

class CustomPagination(PageNumberPagination):
        page_size = 10 
        page_size_query_param = 'page_size'
        max_page_size = 100



class FurnaceBedLogAPIView(APIView):
    se_cls=se.FurnaceBedLogSerializer
    se_class=se.FurnaceBedLogGetSerializer
    model_cls=models.FurnaceBedLog
    def get_object(self, pk):
        try:
            return self.model_cls.objects.get(pk=pk)
        except self.model_cls.DoesNotExist:
            raise Http404
    def get(self, request,pk=None):
        furnace_id = int(request.query_params.get('furnace_id')) if request.query_params.get('furnace_id') else None
        if pk:
            log=self.get_object(pk=pk)
            serializer=self.se_class(log)
            return Response(serializer.data)
        
        sort_by_type=FILTER_KEYS_LOG_BOOK.get(request.query_params.get('sort_by_type',None),None)
        order_by=self.request.query_params.get('sort_by',None)
        order_by_field=None

        logs = self.model_cls.objects.filter(record_status=True)
        if furnace_id:
            logs = logs.filter(furnace__id=furnace_id)
        filter_queries=query_params(request.query_params)
        if filter_queries:
            logs = logs.filter(query_params(request.query_params))
        if sort_by_type:
            order_by_field = sort_by_type if sort_by_type and order_by == 'ASC' else f'-{sort_by_type}'
        logs = logs.order_by(order_by_field if order_by_field else  '-modified_at').values('id', 'observation_dt', 'furnace__furnace_no', 'modified_by__username', 'record_status')
        processed_logs = []
        excel_download = request.query_params.get('excel_download',None)
        for log in logs:
            observation_dt = log.get('observation_dt', None) 
            log['observation_dt'] = separate_date_time(observation_dt) if excel_download else observation_dt
            log['username'] = log.pop('modified_by__username',None)
            log['furnace_no'] = log.pop('furnace__furnace_no',None)
            log['observation_id']=f"FB_{log.get('id')}"
            processed_logs.append(log)
        if excel_download:
            return Response({"results":processed_logs})
        paginator = CustomPagination()
        paginator.paginate_queryset(processed_logs, request)
        return paginator.get_paginated_response(processed_logs)

    def post(self, request,pk=None):
        user=request.user
        serializer = self.se_cls(data=request.data)
        if serializer.is_valid():
            serializer.save(created_by=user,modified_by=user)
            return Response({"message":"logBook.furnaceBedLog.furnaceBedLogAddedNotify"}, status=status.HTTP_201_CREATED)
        return Response(de_structure_errors(serializer.errors), status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, pk=None):
        user=request.user
        log=self.get_object(pk=pk)
        data=request.data
        serializer = self.se_cls(log, data=data,partial=True)
        if serializer.is_valid():
            dt=serializer.save(modified_by=user,modified_at=timezone.now())
            return Response({"message": "logBook.furnaceBedLog.furnaceBedLogUpdateNotify"})
        return Response(de_structure_errors(serializer.errors), status=status.HTTP_400_BAD_REQUEST)
    
    def patch(self,request,pk=None):
        user=request.user
        obj=self.get_object(pk=pk)
        obj.modified_by=user
        obj.modified_at=timezone.now()
        obj.record_status= not obj.record_status
        obj.save()
        return Response({"message":"logBook.furnaceBedLog.furnaceBedLogDeleteNotify"})

class TapHoleLogAPIView(APIView):
    se_cls=se.TapHoleLogSerializer
    se_class=se.TapHoleLogGetSerializer
    model_cls=models.TapHoleLog
    def get_object(self, pk):
        try:
            return self.model_cls.objects.get(pk=pk)
        except self.model_cls.DoesNotExist:
            raise Http404
    def get(self, request,pk=None):
        furnace_id = int(request.query_params.get('furnace_id')) if request.query_params.get('furnace_id') else None
        if pk:
            log=self.get_object(pk=pk)
            serializer=self.se_class(log)
            return Response(serializer.data)
        sort_by_type=FILTER_KEYS_LOG_BOOK.get(request.query_params.get('sort_by_type',None),None)
        order_by=self.request.query_params.get('sort_by',None)
        order_by_field=None
        logs = self.model_cls.objects.filter(record_status=True)
        if (furnace_id):
            logs = logs.filter(furnace__id=furnace_id)
        filter_queries=query_params(request.query_params)
        if filter_queries:
            logs = logs.filter(filter_queries)
        if sort_by_type:
            order_by_field = sort_by_type if sort_by_type and order_by == 'ASC' else f'-{sort_by_type}'
        logs = logs.order_by(order_by_field if order_by_field else  '-modified_at').values('id','observation_dt','furnace__furnace_no', 'modified_by__username','record_status')


        processed_logs = []
        excel_download = request.query_params.get('excel_download',None)

        for log in logs:
            observation_dt = log.pop('observation_dt', None)                
            
            log['observation_dt'] = separate_date_time(observation_dt) if excel_download else observation_dt
            log['username'] = log.pop('modified_by__username',None)
            log['furnace_no'] = log.pop('furnace__furnace_no',None)
            log['observation_id']=f"TH_{log.get('id')}"
            processed_logs.append(log)
        if request.query_params.get('excel_download',None):
            return Response({"results":processed_logs})
        paginator = CustomPagination()
        paginator.paginate_queryset(processed_logs, request)
        return paginator.get_paginated_response(processed_logs)
    def post(self, request,pk=None):
        user=request.user
        serializer = self.se_cls(data=request.data)
        if serializer.is_valid():
            serializer.save(created_by=user,modified_by=user)
            return Response({"message":"logBook.tapHoleLog.tapHoleLogAddedNotify"}, status=status.HTTP_201_CREATED)
        return Response(de_structure_errors(serializer.errors), status=status.HTTP_400_BAD_REQUEST)
    def put(self, request, pk=None):
        user=request.user
        log = self.get_object(pk)
        data=request.data
        serializer = self.se_cls(log, data=data,partial=True)
        if serializer.is_valid():
            serializer.save(modified_by=user,modified_at=timezone.now())
            return Response({"message":"logBook.tapHoleLog.tapHoleLogUpdateNotify"})
        return Response(de_structure_errors(serializer.errors), status=status.HTTP_400_BAD_REQUEST)
    def patch(self,request,pk=None):
        user=request.user
        obj=self.get_object(pk=pk)
        obj.modified_by=user
        obj.modified_at=timezone.now()
        obj.record_status= not obj.record_status
        obj.save()
        return Response({"message":"logBook.tapHoleLog.tapHoleLogDeleteNotify"})


from mes.furnace.models import FurnaceConfig
from rest_framework.decorators import api_view
@api_view(['GET'])
def get_all_furnace_list(request):
    furnace_configs = list(FurnaceConfig.objects.all().order_by('id').values('id', 'furnace_no'))
    furnace_configs.insert(0, {"id": 0, "furnace_no": "All"})
    return Response({"data":furnace_configs})

@api_view(['GET'])
def get_downtime_type_master_list(request):
    down_times=list(models.DowntimeTypeMaster.objects.all().order_by('id').values('id','down_time_type_code'))
    return Response({"data":{"down_time_type":down_times}})

@api_view(['GET'])
def get_equipment_master_list(request,pk=None):
    if pk:
        equipments = list(models.EquipmentMaster.objects.filter(Q(down_time_type_id=pk)).order_by('id').values('id', 'equipment__equipment_code'))
    else:
        equipments = list(models.EquipmentMaster.objects.all().order_by('equipment__equipment_code',).values('id', 'equipment__equipment_code','equipment__equipment_name').distinct('equipment__equipment_code'))

    data=[]
    for item in equipments:
        data.append(
            {
                "id":item.get('id'),
                "equipment_master_code":item.get("equipment__equipment_code",''),
                "name":item.get("equipment__equipment_name",'')
            }
        )
    return Response({"data":data})

@api_view(['GET'])
def get_reason_list(request,pk=None):
    if pk:
        reasons = list(models.ReasonMaster.objects.filter(equipment_id=pk).order_by('id').values('id', 'reason__reason_code','reason__reason_name'))
    else :
        reasons=list(models.ReasonMaster.objects.all().order_by('reason__reason_code','id').values('id', 'reason__reason_code','reason__reason_name').distinct('reason__reason_code'))
    data=[]
    for item in reasons:
        data.append(
            {
                "id":item.get('id'),
                "reason_code":item.get("reason__reason_code",''),
                "name":item.get('reason__reason_name','')
            }
        )
    return Response({"data":data})




@api_view(["GET"])
def get_radios(request):
    log_name_filter = "FurnaceBed" if 'furnacebed-radios' in request.path else "TapHole"
    log_radios = models.LogCategoryMaster.objects.filter(log_name=log_name_filter).order_by('id')
    data=[]
    for item in log_radios:
        name=item.category
        category_code=item.category_code
        
        data.append(
        {
            "label":category_code,
            "options":[{"id": itm.id,"value":itm.radio_code,} for itm in models.LogRadioMaster.objects.filter(log_category_master=item).order_by('id')],
            "payload_key":name.lower().replace('-','').replace(' ', '_').replace("__",'_'),
            "required":True
        })
    return Response({"data":data})    

# =====================================  furance down time=====================


class FurnaceDownTimeEventAPIView(APIView):
    serializer_cls=se.FurnaceDownTimeEventSerializer
    get_se_class=se.FurnaceDownTimeEventGetSerializer
    model_cls=models.FurnaceDownTimeEvent

    def get_object(self, pk):
        try:
            return self.model_cls.objects.get(pk=pk)
        except self.model_cls.DoesNotExist:
            raise Http404
    def get(self, request,pk=None):
        furnace_id = int(request.query_params.get('furnace_id')) if request.query_params.get('furnace_id') else None
        if pk:
            event=self.get_object(pk=pk)
            serializer=self.get_se_class(event)
            return Response(serializer.data)
        # sort keys  
        sort_by_type=FILTER_KEYS_LOG_BOOK.get(request.query_params.get('sort_by_type',None),None)
        order_by=self.request.query_params.get('sort_by',None)
        order_by_field=None
        # filtering out only status true records and the furnace relation
        events = self.model_cls.objects.filter(record_status=True)
        if furnace_id:
            events = events.filter(furnace__id=furnace_id)
        filter_queries=query_params(request.query_params)
        if filter_queries:
            split_events = models.FurnaceDownTimeSplit.objects.filter(filter_queries)
            event_ids = list(split_events.values_list('furnace_down_time_event_id', flat=True))
            event_ids.extend(events.filter(filter_queries).values_list('id',flat=True))
            events = events.filter(id__in=event_ids)
        # sort logic=
        event_status=request.query_params.get('status','')
        if event_status:
            events=events.filter(event_status=True if event_status=="true" else False)
        if sort_by_type:
            order_by_field = sort_by_type if sort_by_type and order_by =='ASC' else f'-{sort_by_type}'
        if sort_by_type=='duration':
            if order_by=='DESC':
                events=events.annotate(duration=desc_duration_expression)
            else:
                events=events.annotate(duration=duration_expression)
        # sorting and ordering
        events = events.order_by(order_by_field if order_by_field else '-modified_at')

        if request.query_params.get('excel_download',None):
            return Response({"results":csv_download_furnace_downtime_event_split(data=self.serializer_cls(events, many=True,context={"request":request}).data) })

        paginator = CustomPagination()
        result_page = paginator.paginate_queryset(events, request)
        serializer = self.serializer_cls(result_page, many=True,context={"request":request})
        return paginator.get_paginated_response(serializer.data)

    def post(self, request,*args, **kwargs):
        user=request.user
        serializer = self.serializer_cls(data=request.data)
        if serializer.is_valid():
            serializer.save(created_by=user,modified_by=user,source="1",)
            return Response({"message":"logBook.furnaceDownTimeLog.eventCreatedSuccessNotify"}, status=status.HTTP_201_CREATED)
        return Response(de_structure_errors(serializer.errors), status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, pk=None):
        user=request.user
        event = self.get_object(pk=pk)
        serializer = self.serializer_cls(event, data=request.data,partial=True)
        if serializer.is_valid():
            serializer.save(modified_by=user,modified_at=timezone.now())
            return Response({"message":"logBook.furnaceDownTimeLog.eventUpdatedSuccessNotify"}, status=status.HTTP_201_CREATED)

        return Response(de_structure_errors(serializer.errors), status=status.HTTP_400_BAD_REQUEST)

    def patch(self, request, pk=None):
        user=request.user
        obj=self.get_object(pk=pk)
        obj.modified_by=user
        obj.modified_at=timezone.now()
        obj.record_status= not obj.record_status
        obj.save()
        return Response({"message":"logBook.furnaceDownTimeLog.eventDeletedSuccessNotify"})



class FurnaceDownTimeSplitAPIView(APIView):
    serializer_cls=se.FurnaceDownTimeSplitSerializer
    get_se_class=se.FurnaceDownTimeSplitGetSerializer
    model_cls=models.FurnaceDownTimeSplit

    def get_object(self, pk):
        try:
            return self.model_cls.objects.get(pk=pk)
        except self.model_cls.DoesNotExist:
            raise Http404
    def get(self, request,pk=None):
        furnace_id = int(request.query_params.get('furnace_id')) if request.query_params.get('furnace_id') else None
        if pk:
            split=self.get_object(pk=pk)
            serializer=self.get_se_class(split)
            return Response(serializer.data)
        splits = self.model_cls.objects.filter(record_status=True).order_by('-modified_at')
        if furnace_id:
            splits = splits.filter(furnace__id=furnace_id)
        paginator = CustomPagination()

        result_page = paginator.paginate_queryset(splits, request)
        
        serializer = self.serializer_cls(result_page, many=True)
        return paginator.get_paginated_response(serializer.data)

    def post(self, request,pk=None):
        user=request.user
        serializer = self.serializer_cls(data=request.data)
        if serializer.is_valid():
            obj=serializer.save(created_by=user,modified_by=user,modified_at=timezone.now())
            obj.furnace_down_time_event.modified_at=timezone.now()
            obj.furnace_down_time_event.save()
            return Response({"message":"logBook.furnaceDownTimeLog.splitCreatedSuccessNotify"}, status=status.HTTP_201_CREATED)
        return Response(de_structure_errors(serializer.errors), status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, pk=None):
        user=request.user
        split = self.get_object(pk=pk)
        serializer = self.serializer_cls(split, data=request.data,partial=True)
        if serializer.is_valid():
            serializer.save(modified_by=user,modified_at=timezone.now())
            split.furnace_down_time_event.modified_at=timezone.now()
            split.furnace_down_time_event.save()
            
            return Response({"message":"logBook.furnaceDownTimeLog.splitUpdatedSuccessNotify"}, status=status.HTTP_201_CREATED)

        return Response(de_structure_errors(serializer.errors), status=status.HTTP_400_BAD_REQUEST)

    def patch(self, request, pk=None):
        user=request.user
        obj=self.get_object(pk=pk)
        obj.modified_by=user
        obj.modified_at=timezone.now()
        obj.record_status= not obj.record_status
        obj.save()
        obj.furnace_down_time_event.modified_at=timezone.now()
        obj.furnace_down_time_event.save()
        return Response({"message":"logBook.furnaceDownTimeLog.splitDeletedSuccessNotify"})





