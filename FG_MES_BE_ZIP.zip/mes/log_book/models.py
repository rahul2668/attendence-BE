from django.db import models
from mes.utils.models import BaseModel
# Create your models here.


from django.utils.translation import gettext_lazy as _

DOWN_TIME_TYPE_CHOICES = [
        ('1', 'Planned'),
        ('2', 'Operational'),
        ('3', 'BreakDown'),
        ('4', 'Other')
    ]
furnace_config = 'furnace.FurnaceConfig'

class LogCategoryMaster(models.Model):
    LOG_BOOK_CHOICES = [
        (1, "FurnaceBed"),
        (2, "TapHole"),
    ]
    category = models.CharField(_("log_category"), max_length=100)
    log_name = models.CharField(_("log_name"), max_length=100, choices=LOG_BOOK_CHOICES)
    category_code=models.CharField(max_length=8, unique=True)

    def __str__(self) -> str:
        return self.category
    
    class Meta:
        db_table='log_book_category_master'


class LogRadioMaster(models.Model):
    log_category_master=models.ForeignKey(LogCategoryMaster,on_delete=models.PROTECT,to_field='category_code')
    value = models.CharField(_("value"), max_length=100)
    radio_code=models.CharField(max_length=8, unique=True)

    def __str__(self) -> str:
        return self.value

    class Meta:
        db_table="log_book_radio_master"

class FurnaceBedLog(BaseModel):
    furnace = models.ForeignKey(furnace_config,related_name='furnace_bed',on_delete=models.CASCADE, to_field='furnace_no')
    observation_dt = models.DateTimeField()
    auto_collapse = models.ForeignKey(LogRadioMaster,related_name="auto_collapse",on_delete=models.PROTECT,to_field='radio_code')
    electrode_auto_lining_wideness = models.ForeignKey(LogRadioMaster,related_name="electrode_auto_lining_wideness",on_delete=models.PROTECT, to_field='radio_code')
    noise_when_collapsing = models.ForeignKey(LogRadioMaster,related_name="noise_when_collapsing",on_delete=models.PROTECT, to_field='radio_code')
    electrode_blows_direction =models.ForeignKey(LogRadioMaster,related_name="electrode_blows_direction",on_delete=models.PROTECT, to_field='radio_code')
    electrode_crust_formation = models.ForeignKey(LogRadioMaster,related_name="electrode_crust_formation",on_delete=models.PROTECT, to_field='radio_code')
    bed_conditions = models.ForeignKey(LogRadioMaster,related_name="bed_conditions",on_delete=models.PROTECT, to_field='radio_code')
    activity_homogeneity = models.ForeignKey(LogRadioMaster,related_name="activity_homogeneity",on_delete=models.PROTECT, to_field='radio_code')
    comments = models.TextField(null=True,blank=True)

    def __str__(self):
        return self.furnace.furnace_no
    
    class Meta:
        db_table='log_book_furnace_bed_log'
    

class TapHoleLog(BaseModel):
    furnace = models.ForeignKey(furnace_config,related_name='furnace_tap_hole',on_delete=models.CASCADE, to_field='furnace_no')
    observation_dt = models.DateTimeField()
    flame = models.ForeignKey(LogRadioMaster,related_name="flame",on_delete=models.PROTECT, to_field='radio_code')
    flame_colour = models.ForeignKey(LogRadioMaster,related_name="flame_colour",on_delete=models.PROTECT, to_field='radio_code')
    tap_hole_bottom = models.ForeignKey(LogRadioMaster,related_name="tap_hole_bottom",on_delete=models.PROTECT, to_field='radio_code')
    metal_output = models.ForeignKey(LogRadioMaster,related_name="metal_output",on_delete=models.PROTECT, to_field='radio_code')
    furnace_tapping= models.ForeignKey(LogRadioMaster,related_name="furnace_tapping",on_delete=models.PROTECT, to_field='radio_code')
    slag = models.ForeignKey(LogRadioMaster,related_name="slag",on_delete=models.PROTECT, to_field='radio_code')
    flame_intensity =models.ForeignKey(LogRadioMaster,related_name="flame_intensity",on_delete=models.PROTECT, to_field='radio_code')
    comments = models.TextField(null=True,blank=True)
    
    def __str__(self):
        return self.furnace.furnace_no
    
    class Meta:
        db_table='log_book_tap_hole_log'


class DowntimeTypeMaster(models.Model):
    name=models.CharField(max_length=50)
    down_time_type_code=models.CharField(max_length=8,unique=True)

    def __str__(self) -> str:
        return self.name
    
    class Meta:
        db_table="log_book_downtime_type_master"


class Equipment(models.Model):
    equipment_name=models.CharField(max_length=50,unique=True)
    equipment_code=models.CharField(max_length=8, unique=True)

    def __str__(self) -> str:
        return self.equipment_name
    class Meta:
        unique_together=('equipment_name','equipment_code')
        db_table="log_book_equipments"
        db_table_comment="This table holds the equipment  data"

class Reason(models.Model):
    reason_name=models.CharField(max_length=50,unique=True)
    reason_code=models.CharField(max_length=8, unique=True)

    def __str__(self) -> str:
        return self.reason_name
    class Meta:
        unique_together=('reason_name','reason_code')
        db_table="log_book_reasons"
        db_table_comment="This table holds the  reason data"

class EquipmentMaster(models.Model):
    down_time_type = models.ForeignKey(DowntimeTypeMaster,on_delete=models.PROTECT,related_name="equipment_down_time_type", to_field='down_time_type_code')
    equipment = models.ForeignKey(Equipment,on_delete=models.PROTECT,related_name="equipment_equipment_master", to_field='equipment_code')
    def __str__(self) -> str:
        return self.equipment.equipment_name
    class Meta:
        db_table="log_book_equipment_master"
    
class ReasonMaster(models.Model):
    equipment=models.ForeignKey(EquipmentMaster,on_delete=models.PROTECT)
    reason = models.ForeignKey(Reason,on_delete=models.PROTECT,related_name="reason_reason_master", to_field='reason_code')

    def __str__(self) -> str:
        return self.reason.reason_name
    class Meta:
        db_table="log_book_reason_master"
        
class FurnaceDownTimeEvent(BaseModel):
    SOURCE_CHOICES=[
        ('1',"Manual"),
        ('2',"Automate")
    ]
    furnace = models.ForeignKey(furnace_config, related_name='furnace_down_time_event', on_delete=models.CASCADE, to_field='furnace_no')
    observation_start_dt = models.DateTimeField()
    observation_end_dt = models.DateTimeField(null=True,blank=True)
    source=models.CharField(max_length=20,choices=SOURCE_CHOICES,blank=True)
    external_source_id=models.CharField(null=True,blank=True,max_length=100)
    equipment = models.ForeignKey(EquipmentMaster, related_name='equipment_split', on_delete=models.PROTECT)
    reason = models.ForeignKey(ReasonMaster, related_name='reason_split', on_delete=models.PROTECT)
    down_time_type = models.ForeignKey(DowntimeTypeMaster,on_delete=models.PROTECT,related_name="furnace_down_time_event",to_field='down_time_type_code')
    event_status = models.BooleanField(default=False)
    comments = models.TextField(null=True, blank=True)

    def __str__(self) -> str:
        return self.down_time_type.name
    
    class Meta:
        db_table="log_book_furnace_down_time_event"


class FurnaceDownTimeSplitManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(record_status=True).order_by('-modified_at')
class FurnaceDownTimeSplit(BaseModel):
    furnace_down_time_event = models.ForeignKey(FurnaceDownTimeEvent, related_name='furnace_down_time_event_split', on_delete=models.CASCADE)
    observation_start_dt = models.DateTimeField()
    observation_end_dt = models.DateTimeField()
    equipment = models.ForeignKey(EquipmentMaster, related_name='equipment_event', on_delete=models.PROTECT)
    reason = models.ForeignKey(ReasonMaster, related_name='reason_event', on_delete=models.PROTECT)
    down_time_type = models.ForeignKey(DowntimeTypeMaster,related_name='split_down_time_type',on_delete=models.PROTECT,to_field='down_time_type_code')
    comments = models.TextField(null=True, blank=True)

    objects=FurnaceDownTimeSplitManager()

    def __str__(self) -> str:
        return self.down_time_type.name
    
    class Meta:
        db_table="log_book_furnace_down_time_split"


    