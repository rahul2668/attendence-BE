from datetime import datetime
from rest_framework import serializers
from django.db.models import Min, Max
from . import models


class FurnaceBedLogSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.FurnaceBedLog
        exclude=['modified_at','record_status','modified_by','created_at','created_by']



class TapHoleLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.TapHoleLog
        exclude = ['modified_at', 'record_status', 'modified_by', 'created_at', 'created_by']


class FurnaceBedLogGetSerializer(serializers.ModelSerializer):
    username=serializers.SerializerMethodField()
    furnace=serializers.SerializerMethodField()
    observation_date_time=serializers.SerializerMethodField()
    auto_collapse = serializers.SerializerMethodField()
    electrode_auto_lining_wideness = serializers.SerializerMethodField()
    noise_when_collapsing = serializers.SerializerMethodField()
    electrode_blows_direction = serializers.SerializerMethodField()
    electrode_crust_formation = serializers.SerializerMethodField()
    bed_conditions = serializers.SerializerMethodField()
    activity_homogeneity = serializers.SerializerMethodField()
    observation_id = serializers.SerializerMethodField()

    class Meta:
        model = models.FurnaceBedLog
        exclude=['modified_at','record_status','modified_by','created_at','created_by']
    def get_observation_id(self, obj):
        return f"FB_{obj.id}"

    def get_field_data(self, obj, field_name):
        field = getattr(obj, field_name)
        return {
            "id": field.radio_code if field else None,
            "value": field.value if field else None,
            "label": field.log_category_master.category if field else None
        }

    def get_username(self,obj):
        return obj.modified_by.first_name+ " "+obj.modified_by.last_name  if hasattr(obj.modified_by, 'username') else None # getattr(obj.created_by,"username",None)
    
    def get_furnace(self,obj):
       return {"id":obj.furnace.id,"value":obj.furnace.furnace_no if obj.furnace else None,"label":"Furnace No."}
    
    def get_observation_date_time(self,obj):
        return {"id":None,"value":obj.observation_dt if obj.observation_dt else None,"label":"Observation Date & Time"}

    def get_auto_collapse(self, obj):
        return self.get_field_data(obj, 'auto_collapse')

    def get_electrode_auto_lining_wideness(self, obj):
        return self.get_field_data(obj, 'electrode_auto_lining_wideness')

    def get_noise_when_collapsing(self, obj):
        return self.get_field_data(obj, 'noise_when_collapsing')

    def get_electrode_blows_direction(self, obj):
        return self.get_field_data(obj, 'electrode_blows_direction')

    def get_electrode_crust_formation(self, obj):
        return self.get_field_data(obj, 'electrode_crust_formation')

    def get_bed_conditions(self, obj):
        return self.get_field_data(obj, 'bed_conditions')

    def get_activity_homogeneity(self, obj):
        return self.get_field_data(obj, 'activity_homogeneity')
    

class TapHoleLogGetSerializer(serializers.ModelSerializer):
    username = serializers.SerializerMethodField()
    furnace = serializers.SerializerMethodField()
    observation_date_time=serializers.SerializerMethodField()
    flame = serializers.SerializerMethodField()
    flame_colour = serializers.SerializerMethodField()
    tap_hole_bottom = serializers.SerializerMethodField()
    metal_output = serializers.SerializerMethodField()
    furnace_tapping = serializers.SerializerMethodField()
    slag = serializers.SerializerMethodField()
    flame_intensity = serializers.SerializerMethodField()
    observation_id = serializers.SerializerMethodField()

    class Meta:
        model = models.TapHoleLog
        exclude = ['modified_at', 'record_status', 'modified_by', 'created_at', 'created_by']
    def get_observation_id(self, obj):
        return f"TH_{obj.id}"  
    
    def get_username(self,obj):
        return obj.modified_by.first_name+ " "+obj.modified_by.last_name  if hasattr(obj.modified_by, 'username') else None # getattr(obj.created_by,"username",None)
    
    def get_field_data(self, obj, field_name):
        field = getattr(obj, field_name)
        return {
            "id": field.radio_code if field else None,
            "value": field.value if field else None,
            "label": field.log_category_master.category if field else None
        }

    def get_furnace(self, obj):
        return {"id":obj.furnace.id,"value":obj.furnace.furnace_no if obj.furnace else None,"label":"Furnace No."}
    def get_observation_date_time(self,obj):
        return {"id":None,"value":obj.observation_dt if obj.observation_dt else None,"label":"Observation Date & Time"}

    def get_flame(self, obj):
        return self.get_field_data(obj, 'flame')

    def get_flame_colour(self, obj):
        return self.get_field_data(obj, 'flame_colour')

    def get_tap_hole_bottom(self, obj):
        return self.get_field_data(obj, 'tap_hole_bottom')

    def get_metal_output(self, obj):
        return self.get_field_data(obj, 'metal_output')

    def get_furnace_tapping(self, obj):
        return self.get_field_data(obj, 'furnace_tapping')

    def get_slag(self, obj):
        return self.get_field_data(obj, 'slag')

    def get_flame_intensity(self, obj):
        return self.get_field_data(obj, 'flame_intensity')



# ?====================================Furnace Down time ==============================
class FurnaceDownTimeSplitSerializer(serializers.ModelSerializer):
    reason_value = serializers.SerializerMethodField()
    equipment_value = serializers.SerializerMethodField()
    split_id = serializers.SerializerMethodField()
    duration = serializers.SerializerMethodField()

    class Meta:
        model = models.FurnaceDownTimeSplit
        fields = '__all__'

    def get_duration(self, obj):
        start_datetime = obj.observation_start_dt
        end_datetime = obj.observation_end_dt
        try:            
            time_difference = start_datetime - end_datetime
            total_seconds = abs(time_difference.total_seconds())
            hours = total_seconds // 3600
            minutes = (total_seconds % 3600) // 60
            return f"{int(hours)} hrs {int(minutes)} mins" if hours or minutes else "0 hrs 0 mins"
        except Exception:
            return ""
   
    def get_split_id(self,obj):
        return f"SP_{obj.id}"
    def get_reason_value(self, obj):
        return obj.reason.reason.reason_code
    def get_equipment_value(self, obj):
        return obj.equipment.equipment.equipment_code
    def to_representation(self, instance):
        representation = super().to_representation(instance)
        
        for field_name in ['created_at', 'modified_at', 'modified_by','created_by','reason','equipment','comments',]:
            representation.pop(field_name, None)
        return representation
    

class FurnaceDownTimeEventSerializer(serializers.ModelSerializer):
    source_value = serializers.CharField(source='get_source_display', read_only=True)
    down_time_type_value = serializers.SerializerMethodField()
    
    furnace_no = serializers.SerializerMethodField()
    reason_value = serializers.SerializerMethodField()
    equipment_value = serializers.SerializerMethodField()
    event_status_value = serializers.SerializerMethodField()
    furnace_down_time = serializers.SerializerMethodField()
    event_id=serializers.SerializerMethodField()
    duration=serializers.SerializerMethodField()


    class Meta:
        model = models.FurnaceDownTimeEvent
        fields="__all__"
    def get_down_time_type_value(self,obj):
        return  obj.down_time_type.name if  hasattr(obj.down_time_type,"name") else ""
    def get_furnace_down_time(self,obj):
        request=self.context.get('request',None)
         
        reason= request.query_params.get('reason_value',None)
        equipment_value= request.query_params.get('equipment_value',None)
        down_time_type= request.query_params.get('down_time_type',None)
        observation_start_dt=request.query_params.get('observation_start_dt','')
        observation_end_dt=request.query_params.get('observation_end_dt','')
        split_data=obj.furnace_down_time_event_split.filter()
        if observation_start_dt:
            split_data=split_data.filter(observation_start_dt__date__gte=observation_start_dt)
        if observation_end_dt:
            split_data=split_data.filter(observation_end_dt__date__lte=observation_end_dt)
        if reason:
            reason=reason.split(',')
            split_data=split_data.filter(reason__reason__reason_code__in=reason)
        if equipment_value:
            equipment_value=equipment_value.split(',')
            split_data=split_data.filter(equipment__equipment__equipment_code__in=equipment_value)
        if down_time_type:
            down_time_type=down_time_type.split(',')
            split_data=split_data.filter(down_time_type__down_time_type_code__in=down_time_type)
        return FurnaceDownTimeSplitSerializer(split_data,many=True).data
        

    def get_event_id(self,obj):
        return f"DT_{obj.id}"
    def get_furnace_no(self, obj):
        return getattr(obj.furnace,"furnace_no",None )
    def get_reason_value(self, obj):
        return getattr(obj.reason.reason,"reason_code",None)
    def get_equipment_value(self, obj):
        return getattr(obj.equipment.equipment,"equipment_code",None)
    def get_event_status_value(self, obj):
        return 'Completed' if  obj.event_status else 'Pending'
    def get_duration(self, obj):
        start_datetime = obj.observation_start_dt
        end_datetime = obj.observation_end_dt
        try:
            time_difference = start_datetime - end_datetime
            total_seconds = abs(time_difference.total_seconds())
            hours = total_seconds // 3600
            minutes = (total_seconds % 3600) // 60
            return f"{int(hours)} hrs {int(minutes)} mins" if hours or minutes else "0 hrs 0 mins"
        except Exception:
            return "" 
    def to_representation(self, instance):
        representation = super().to_representation(instance)    
        for field_name in ['created_at', 'modified_at', 'modified_by','created_by','reason','equipment','furnace','comments','source','external_source_id']:
            representation.pop(field_name, None)
        
        return representation
    

class FurnaceDownTimeEventGetSerializer(serializers.ModelSerializer):
    source = serializers.SerializerMethodField()
    down_time_type = serializers.SerializerMethodField()
    furnace = serializers.SerializerMethodField()
    reason = serializers.SerializerMethodField()
    equipment = serializers.SerializerMethodField()
    event_status = serializers.SerializerMethodField()
    duration = serializers.SerializerMethodField()
    updated_by=serializers.SerializerMethodField()
    oldest_split_start_dt = serializers.SerializerMethodField()
    latest_split_end_dt = serializers.SerializerMethodField()

    class Meta:
        model = models.FurnaceDownTimeEvent
        exclude=['created_at','modified_at','modified_by','created_by',]
    def get_updated_by(self,obj):
        return obj.modified_by.first_name+ " "+obj.modified_by.last_name if hasattr(obj.modified_by,'username')else ""

    def get_furnace(self, obj):
        return {"id":obj.furnace.id,"value":obj.furnace.furnace_no if obj.furnace else None}
    def get_reason(self, obj):
        return {"id":obj.reason.id,"value":obj.reason.reason.reason_code if obj.reason else None}
    def get_equipment(self, obj):
        return {"id":obj.equipment.id,"value":obj.equipment.equipment.equipment_code if obj.equipment else None}
    def get_event_status(self, obj):
        return 'Completed' if  obj.event_status else 'Pending'
    def get_source(self,obj):
        return {"id":obj.source,"value":obj.get_source_display() if obj.source else None}
    def get_down_time_type(self,obj):
        return {"id":obj.down_time_type.down_time_type_code,"value":obj.down_time_type.down_time_type_code if obj.down_time_type else None}
    def get_duration(self, obj):
        start_datetime = obj.observation_start_dt
        end_datetime = obj.observation_end_dt
        try:
            time_difference = start_datetime - end_datetime
            total_seconds = abs(time_difference.total_seconds())
            hours = total_seconds // 3600
            minutes = (total_seconds % 3600) // 60

            return f"{int(hours)} hrs {int(minutes)} mins" if hours or minutes else "0 hrs 0 mins"
        except Exception:
            return "" 
    def get_oldest_split_start_dt(self, obj):
        splits = obj.furnace_down_time_event_split.all()
        oldest_split_start_dt = splits.aggregate(Min('observation_start_dt'))['observation_start_dt__min']
        return oldest_split_start_dt

    def get_latest_split_end_dt(self, obj):
        splits = obj.furnace_down_time_event_split.all()
        latest_split_end_dt = splits.aggregate(Max('observation_end_dt'))['observation_end_dt__max']
        return latest_split_end_dt

class FurnaceDownTimeSplitGetSerializer(serializers.ModelSerializer):
    down_time_type = serializers.SerializerMethodField()
    reason = serializers.SerializerMethodField()
    equipment = serializers.SerializerMethodField()
    furnace_no=serializers.SerializerMethodField()
    source=serializers.SerializerMethodField()
    duration = serializers.SerializerMethodField()
    updated_by=serializers.SerializerMethodField()
    event_start_date = serializers.SerializerMethodField()
    event_end_date = serializers.SerializerMethodField()


    class Meta:
        model = models.FurnaceDownTimeSplit
        exclude=['created_at','modified_at','modified_by','created_by',]
    def get_updated_by(self,obj):
        return obj.modified_by.first_name+ " "+obj.modified_by.last_name if hasattr(obj.modified_by,'username')else ""

    def get_duration(self, obj):
        start_datetime = obj.observation_start_dt
        end_datetime = obj.observation_end_dt
        try:
            time_difference = start_datetime - end_datetime
            total_seconds = abs(time_difference.total_seconds())
            hours = total_seconds // 3600
            minutes = (total_seconds % 3600) // 60

            return f"{int(hours)} hrs {int(minutes)} mins" if hours or minutes else "0 hrs 0 mins"
        except Exception:
            return ""
    def get_furnace_no(self,obj):
       return {"id":obj.furnace_down_time_event.furnace.furnace_no,"value":obj.furnace_down_time_event.furnace.furnace_no if obj.furnace_down_time_event else None,}
    def get_source(self,obj):
        return obj.furnace_down_time_event.get_source_display()
   
    def get_reason(self, obj):
        return {"id":obj.reason.id,"value":obj.reason.reason.reason_code if obj.reason else None}
    def get_equipment(self, obj):
        return {"id":obj.equipment.id,"value":obj.equipment.equipment.equipment_code if obj.equipment else None}
    def get_down_time_type(self,obj):
        return {"id":obj.down_time_type.down_time_type_code,"value":obj.down_time_type.down_time_type_code if obj.down_time_type else None}
    def get_event_start_date(self,obj):
       return getattr(obj.furnace_down_time_event,"observation_start_dt",None)
    def get_event_end_date(self,obj):
       return getattr(obj.furnace_down_time_event,"observation_end_dt",None)