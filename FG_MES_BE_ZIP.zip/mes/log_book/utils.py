from .models import EquipmentMaster ,ReasonMaster
from datetime import datetime


# def get_master_value_code(model,code):
#    data= model.objects.filter(**code).first()
#    return data.name if data else ""


def event_split_data(event={},data=None):
    equi_value=data.get('equipment_value',None)
    reason_value=data.get('reason_value',None)
    observation_start_dt_str = data.get('observation_start_dt','')[:10] if data.get('observation_start_dt','') else ""
    observation_end_dt_str = data.get('observation_end_dt','')[:10] if data.get('observation_end_dt','') else ""
    return {
            "event_id":event.get('event_id',data.get('event_id','')),
            "split_id":data.get('split_id',''),
            "furnace_no":data.get('furnace_no',event.get('furnace_no','')),
            "observation_start_dt":observation_start_dt_str ,
            "observation_end_dt":observation_end_dt_str ,
            "duration":data.get('duration'),
            "equipment_value":equi_value,
            "reason_value":reason_value,
            "event_status_value":data.get('event_status_value')
            }


def csv_download_furnace_downtime_event_split(data=None):
    downtime_event_split_data=[]
    for event in data:
        event_splits=event.pop('furnace_down_time',[])
        downtime_event_split_data.append(event_split_data(data=event))
        for split in event_splits:
            downtime_event_split_data.append(event_split_data(event,split))
    return  downtime_event_split_data
