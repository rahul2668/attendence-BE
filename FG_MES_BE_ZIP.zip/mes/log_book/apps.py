from django.apps import AppConfig


class LogBookConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mes.log_book'
