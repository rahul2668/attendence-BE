from rest_framework.permissions import BasePermission

class IsAuthenticated(BasePermission):
    def has_permission(self, request, view):
        excluded_urls = ['/api/account/simple-login/','/api/units/','/api/account/sso-login/', '/api/account/sso-login-credentials/' ,'/api/account/get-plant-language/','/api/master/master/']
        if request.path in excluded_urls:
            return True  
        return request.user and request.user.is_authenticated
