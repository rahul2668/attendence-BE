from django.utils import timezone
import pytz
from mes.master_data.material_master.models import ElementSpecificationChangeHistory,MaterialMaster
from datetime import datetime
from mes.utils.models import GlobalUnit,Master
from mes.plant.models import PlantConfig
from mes.constants import CURRENCY_VALUES
def create_update_data(model=None,data=None,user=None,pop_item=None,method="create",extra_data=None,master_id=None):
    for item in data:
        if pop_item:
            item.pop(pop_item)
        if method=='edit':
            pk=item.pop('id')
            item.pop('element',None)
            if extra_data:
                model.objects.filter(pk=pk).update(**extra_data, modified_by=user)
            else:
                model.objects.filter(pk=pk).update(**item)
                element=model.objects.filter(pk=pk).first()
                change_history=ElementSpecificationChangeHistory.objects.filter(modified_at__date=timezone.now().date(),element=element.element,material_master_id=master_id)
                if change_history.exists():
                    change_history.update(**item)
                else:
                    ElementSpecificationChangeHistory.objects.create(**item,created_by=user,modified_by=user,modified_at=timezone.now(),material_master_id=master_id,element=element.element)
        else:
            model.objects.create(**item,created_by=user,**extra_data)




def save_material_master(mes_mat_code):
    material_master=MaterialMaster.objects.get(mes_mat_code=mes_mat_code)
    material_master.modified_at=timezone.now()
    material_master.save()


def de_structure_errors(errors):
    errors_dict = {}
    for field, errors in errors.items():
        errors_dict[field] = errors[0]
    return errors_dict

from django.db.models import Q
from functools import reduce
from mes.constants import DB_SEARCH_QUERY_KEYS,SEARCH_QUERY_NON_FIELDS,SEARCH_QUERY_NON_FIELDS_CHOICES
def query_params(params):
    q_objects = []
    for key,value in params.items():
        if ',' in value:
            value=value.split(',')
        if value:
            lookup_key =DB_SEARCH_QUERY_KEYS.get(key,None)
            if lookup_key in SEARCH_QUERY_NON_FIELDS:
                value=SEARCH_QUERY_NON_FIELDS_CHOICES.get(value,'1')
            if lookup_key:
                q_objects.append(Q(**{lookup_key: value}))
    try:  
        filter_query = reduce(lambda x, y: x & y, q_objects)
        return filter_query
    except TypeError:
        return None
        

def audit_columns_update(obj,user,record_type=None):
    if record_type=='create':
        obj.created_by=user
        obj.created_at=timezone.now()
    obj.modified_by=user
    obj.modified_at=timezone.now()
    obj.save()



def get_material_master_additional_info(data=None,material_master=None):
    now_date=timezone.now().date()
    below_latest_date=data.filter(effective_date__lte=now_date).order_by('-effective_date')
    today_date=data.filter(effective_date=now_date).order_by('-effective_date')
    selected_date=None
    if today_date:
        selected_date = today_date
    elif below_latest_date:
        selected_date = below_latest_date
    if  selected_date is None:
        above_latest_date=data.filter(effective_date__gte=now_date).order_by('effective_date')
        selected_date=above_latest_date
    selected_date=selected_date.first()
    data={
        "master_data":{
            "material_type":material_master.material_type.type_name,
            "mes_mat_code":material_master.mes_mat_code,
            "material_name":material_master.material_name,
            "material_description":material_master.material_description,
            "created":material_master.created_at,
            "status":material_master.record_status,
            "erp_commercial_mat_code":material_master.erp_commercial_mat_code,
            "erp_commercial_mat_name":material_master.erp_commercial_mat_name,
            "erp_acc_mat_code":material_master.erp_acc_mat_code,
            "erp_acc_mat_name":material_master.erp_acc_mat_name,
            "ops_tech_mat_code":material_master.ops_tech_mat_code,
            },
            "type_name":getattr(material_master.material_type,"type_name",None)
        }
    return selected_date,data

from datetime import datetime




def separate_date_time(obj, type=None):
    if type and hasattr(obj, type):
        date = getattr(obj, type, None)
    else:
        date = obj

    if isinstance(date, str):
        date = datetime.strptime(date, "%Y-%m-%d %H:%M:%S")
    
    if isinstance(date, datetime):
        # Convert to the specified timezone
        plant=PlantConfig.objects.first()
        master=Master.objects.filter(master_code=plant.timezone_id).first()       
        tz = pytz.timezone(getattr(master , "description" , "UTC"))
        date = date.astimezone(tz)
        return f"{date.date().isoformat()} | {date.strftime('%I:%M %p')}"
    
    return ''
    
def get_full_name(obj,type):
    data=getattr(obj,type,None)
    if data:
        return f"{data.first_name} {data.last_name}"
    return ""

def get_attr(obj,type):
    data=getattr(obj,type,None)
    if data:
        return data
    return ""


def get_plant_currency():
    try:
        plant=PlantConfig.objects.first()
        master=Master.objects.filter(master_code=plant.currency_id).first()
        unit=CURRENCY_VALUES.get(master.value)
    except Exception:
        unit=''
    return unit 
