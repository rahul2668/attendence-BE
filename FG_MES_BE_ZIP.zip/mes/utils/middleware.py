from rest_framework.response import Response
from rest_framework import status
from rest_framework_simplejwt.tokens import  AccessToken
from mes.users.models import User
from django.http import HttpResponseForbidden
from rest_framework_simplejwt.exceptions import TokenBackendError,TokenError


class UserMiddleWare:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        access_token = request.headers.get("Authorization",None)
        if access_token:
            access_token=access_token.split(" ")[1].strip('"')
            try:
                token = AccessToken(access_token)
            except (TokenError,TokenBackendError,Exception):
                return Response({"message":"authentication.login.tokenInvalidNotify"},status=status.HTTP_401_UNAUTHORIZED)
            user_id = token['user_id']
            try:
                user=User.objects.get(id=user_id)
                if user.is_delete or (hasattr(user,"user_token") and (user.user_token.token !=access_token or user.user_token.token is None )) :
                    return HttpResponseForbidden(
                        {"authentication.login.userDeactivatedContactAdminNotify"},
                        status=status.HTTP_401_UNAUTHORIZED,
                    )
            except (AttributeError,User.DoesNotExist):
                return HttpResponseForbidden(
                        {"authentication.login.userNotFoundNotify"},
                        status=status.HTTP_401_UNAUTHORIZED,
                    )
            except Exception: pass

        response = self.get_response(request)
        return response
