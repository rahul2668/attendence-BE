from django.urls import path
from . import views


app_name = "master"
urlpatterns = [
    path("master/", view=views.MasterListView.as_view(), name="master_list"),
    path("master-drop/", view=views.MasterDropDownApiView.as_view(), name="master_list_drop_down"),
]
