
from rest_framework import serializers
from . import models as master_model
from .models import GlobalUnit, Master
from mes.plant.models import PlantConfig
from mes.users.serializers import RolePermissionSerializer
from mes.master_data.material_master.models import MaterialTypeMaster, MaterialCategoryMaster, MaterialMaster
from mes.utils.models import Variant
from itertools import chain
from mes.constants import EXCLUDE_FUNCTIONS_LIST

class MasterSerializer(serializers.ModelSerializer):
    class Meta:
        model = master_model.Master
        fields = '__all__'


class FunctionSerializer(serializers.ModelSerializer):
    permissions=RolePermissionSerializer(many=True,read_only=True,source="function_permissions")

    class Meta:
        model = master_model.Function
        fields="__all__"
        read_only_fields = ['id',]


class ModuleSerializer(serializers.ModelSerializer):
    module_functions = FunctionSerializer(many=True, read_only=True)
   
    class Meta:
        model = master_model.Module
        fields = ['id', 'module_name','module_code', 'description', 'module_functions']
        read_only_fields = ['id', ]

    def to_representation(self, instance):
        representation= super().to_representation(instance)
        result_tuples = master_model.Function.objects.filter(function_name__in=EXCLUDE_FUNCTIONS_LIST).values_list('id')
        representation['module_functions'] = [
            item for item in representation.get('module_functions')
            if item.get('id') not in [id_tuple[0] for id_tuple in result_tuples]
        ]
        return representation

class VariantReportGetSerializer(serializers.ModelSerializer):
    variant_id = serializers.IntegerField(source='id')
    class Meta:
        model = Variant
        fields = ["variant_id", "variant_name"]
    

class VariantReportSerializer(serializers.ModelSerializer):
    category_name = serializers.SerializerMethodField('material_name_get')
    variant_id = serializers.IntegerField(source='id')
    
    class Meta:
        model = Variant
        fields = ["category_name", "variant_id", "variant_name", "private", "report_json", "user"]
    
    def to_representation(self, instance):
        data = super().to_representation(instance)
        data.pop('category_name', None)
        return data

    def material_name_get(self, obj):
        material_type_obj = MaterialTypeMaster.objects.get(type_code = obj.report_json["type_id"])
        material_type_name = material_type_obj.type_name
        material_category_name = MaterialCategoryMaster.objects.get(category_code = obj.report_json["category_id"]).category_name
        obj.report_json["category_name"] = material_category_name
        obj.report_json["type_name"] = material_type_name
        
        material_number_obj = MaterialMaster.objects.get(mes_mat_code=obj.report_json["material_id"])
        material_id = "{} - {}".format(material_number_obj.mes_mat_code, material_number_obj.material_name)
 
        obj.report_json["material_code_name"] = material_id

        compare_material_option = obj.report_json['report_options']
        for material_option in compare_material_option:
            material_ids = material_option.get('compare_material_id', [])
            if material_ids:
                material_objects = MaterialMaster.objects.filter(id__in=material_ids)
                material_names = ["{} - {}".format(material.mes_mat_code, material.material_name) for material in material_objects]
                material_option['compare_material_code_name'] = material_names
            else:
                material_option['compare_material_code_name'] = []
        obj.report_json['report_options'] = compare_material_option

        return None
    

class VariantReportConsumptionSerializer(serializers.ModelSerializer):
    category_name = serializers.SerializerMethodField('material_name_get')
    variant_id = serializers.IntegerField(source='id')
    
    class Meta:
        model = Variant
        fields = ["category_name", "variant_id", "variant_name", "private", "report_json", "furnace", "user"]
    
    def to_representation(self, instance):
        data = super().to_representation(instance)
        data.pop('category_name', None)
        return data

    def material_name_get(self, obj):
        report_options = obj.report_json['report_options']
        material_category_name = MaterialCategoryMaster.objects.get(category_code = obj.report_json["category_id"]).category_name
        obj.report_json['category_name'] = material_category_name
        for option in report_options:
            type_id = option.get("type_id")
            material_id = option.get('mes_mat_code')
            material_type_obj = MaterialTypeMaster.objects.get(type_code = type_id)
            material_type_name = material_type_obj.type_name
            comapre_material_id = option.get('compare_material_id')
            option['type_name'] = material_type_name
            if material_id:
                material_objects = MaterialMaster.objects.filter(mes_mat_code__in=comapre_material_id)
                material_names = ["{} - {}".format(material.mes_mat_code, material.material_name) for material in material_objects]
                material_code_name = MaterialMaster.objects.get(mes_mat_code = material_id)
                material_code_name = "{} - {}".format(material_code_name.mes_mat_code, material_code_name.material_name)
                option['compare_material_code_name'] = material_names
                option['material_code_name'] = material_code_name
        return None
    
    
class UnitSerializer(serializers.ModelSerializer):
    unit=serializers.SerializerMethodField()
    class Meta:
        model=GlobalUnit
        fields=['id','name','unit']
    def get_unit(self,obj):
        plant=PlantConfig.objects.first()
        if plant:
            master=Master.objects.filter(master_code=plant.unit_id).first()
            if master.value=='Metric System':
                return obj.metric
            else:
                return obj.imperial
        else: return ""
        
