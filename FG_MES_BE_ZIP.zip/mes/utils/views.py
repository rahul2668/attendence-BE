from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet
from .models import Master, GlobalUnit
from .serializers import MasterSerializer
from rest_framework.views import APIView
from django.db.models import Q
from . import serializers as se

  
class MasterListView(APIView):
    
    def get(self,request):
     categories = ['TIMEZONE','LANGUAGE','UNITSYSTEM','CURRENCY','PRODUCT','STEPS','ADDITIVES','CONTROLPARAMETERS','WORKSHOPNO','POWERDELIVERY','ELECTRODES','PRODUCTSTATE','PRODUCTTYPE','PRODUCTCODE','SILICAFUMEDEFAULTMATERIAL', 'SLAGPRODUCTDEFAULTMATERIAL','REMELT', 'SAND', 'AI', 'LIME', 'SLAG', 'SKULL','CORE','PASTE','CASING','COSTCENTER']
     array = []
     for category in categories:
         data= Master.objects.filter(category = category)
         serializer=MasterSerializer(data,many = True)
         array.extend(serializer.data)

     return Response(array)
    
class MasterDropDownApiView(APIView):
    serializer_class=MasterSerializer
    queryset =Master.objects.all()

    def get(self,request):
        search_key = request.query_params.get('search_key', None)
        queryset =Master.objects.all()
        if search_key:
                queryset=queryset.filter(Q(category__icontains=search_key)| Q(value__icontains=search_key))
        serializer=MasterSerializer(queryset,many=True)
        return Response({"data":serializer.data})


class UnitViewSet(ModelViewSet):
    serializer_class=se.UnitSerializer
    queryset=GlobalUnit.objects.all()

    def list(self, request, *args, **kwargs):
        response =super().list(request, *args, **kwargs)
        plant=se.PlantConfig.objects.first()
        if plant:
            data={
                'United States Dollar ($)':'$',
                'Pound Sterling (£)':"£",
                'Euro (€)':" €",
                'Canadian Dollar (C$)':"C$",
                'South African Rand (ZAR)':"ZAR",
                'Argentine Peso (Arg$)':"Arg$",
                'Norwegian Krone (NOK)':"kr",
                'Venezuelan bolívar (Bs)':"Bs",
                'Chinese Yuan (¥)':"¥"
            }
            master=se.Master.objects.filter(master_code=plant.currency_id).first()
            unit=se.Master.objects.filter(master_code=plant.unit_id).first()
            try:
                response.data.append({
                    "id":len(response.data)+1,
                    "name":"currency",
                    "unit":data.get(master.value)
                    })
                response.data.append({
                    "id":len(response.data)+1,
                    "name":"Target Cost Budget",
                    "unit":data.get(master.value) +'/t' if unit.value=="Metric System" else"/lb"
                    })
            except Exception:pass
        return response
    