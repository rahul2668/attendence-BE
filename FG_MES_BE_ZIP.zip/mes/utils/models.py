from django.db import models
from django.utils.translation import gettext_lazy as _
from django.db import connection


class BaseModel(models.Model):
    created_by = models.ForeignKey("users.User", null=True, blank=True, on_delete=models.SET_NULL,  related_name='%(app_label)s_%(class)s_created_by', default=None)
    modified_by = models.ForeignKey("users.User", null=True, blank=True, on_delete=models.SET_NULL,  related_name='%(app_label)s_%(class)s_modified_by', default=None)
    created_at = models.DateTimeField(auto_now_add=True)
    modified_at = models.DateTimeField(auto_now=True )
    record_status=models.BooleanField(default=True)
    class Meta:
        abstract = True


class Master(models.Model):
    category =  models.CharField(_("master_category"), max_length=100)
    value = models.CharField(_("value"), max_length=100)
    description = models.TextField()
    master_code=models.CharField(max_length=8, unique=True)


    def __str__(self) -> str:
        return self.category

class Module(models.Model):
    module_name=models.CharField(max_length=255)
    description = models.TextField(null=True)
    module_code=models.CharField(max_length=8,unique=True)
    sort_order=models.IntegerField(unique=True)

    def __str__(self):
        return self.module_name
    
class Function(models.Model):
    module = models.ForeignKey(Module,related_name="module_functions",max_length=255,on_delete=models.PROTECT, to_field='module_code')
    function_name = models.CharField(max_length=255)
    description = models.TextField(null=True)
    record_status = models.BooleanField(default=True)
    function_code=models.CharField(max_length=8, unique=True)
    sort_order=models.PositiveSmallIntegerField()


   


    def __str__(self) -> str:
        return self.function_name

class Variant(BaseModel):
    user = models.ForeignKey("users.User", on_delete=models.PROTECT, null=True, blank=True) #user_id
    furnace = models.ForeignKey("furnace.FurnaceConfig", on_delete=models.PROTECT, null=True, blank=True,to_field='furnace_no')
    furnace_flag = models.BooleanField(default=False)
    size_flag = models.BooleanField(default=False)
    variant_name = models.CharField(max_length=50, null=True)
    private = models.BooleanField(default=True)
    report_json = models.JSONField()

    def __str__(self) -> str:
        return self.variant_name
    
class GlobalUnit(models.Model):
    name=models.CharField(max_length=50)
    imperial=models.CharField(max_length=10)
    metric=models.CharField(max_length=10)

    def __str__(self) -> str:
        return self.name