import uuid

from django.db import models
from django.contrib.auth.models import AbstractBaseUser,BaseUserManager
from django.utils.translation import gettext_lazy as _

from mes.utils.models import Function,Module



from mes.utils.models import BaseModel 

# Create your models here.

class UserManager(BaseUserManager):
    def create_user(self, username: str, password: str = None, **extra_fields):
        roles=extra_fields.pop('roles',[])
        extra_fields.setdefault("is_superuser", False)
        user=self.model(username=username,**extra_fields)
        user.username = username
        if password:
            user.set_password(password)
        else:
            user.set_unusable_password()
        user.save(using=self._db)
        user.roles.set(roles)
        return user
    def create_superuser(self, username, password=None, **extra_fields):
        extra_fields.setdefault('is_superuser', True)
        return self.create_user( username, password, **extra_fields)



    
class Role(BaseModel):
    role_name = models.CharField(verbose_name=_("Name of Role"), max_length=255)
    is_delete = models.BooleanField(default=False)
    is_superuser=models.BooleanField(default=False)


    def __str__(self) -> str:
        return self.role_name

class User(AbstractBaseUser,BaseModel):
    LOGIN_TYPE_CHOICES = [
        ('sso', 'SSO'),
        ('simple', 'Simple'),
    ]

    first_name=models.CharField(max_length=100)
    last_name=models.CharField(max_length=100)
    phone=models.CharField(max_length=20,null=True,blank=True)
    email=models.EmailField(null=True,blank=True)
    department=models.CharField(max_length=50,null=True,blank=True)
    login_type = models.CharField(max_length=50, choices=LOGIN_TYPE_CHOICES)
    username=models.CharField(max_length=50,unique=True,verbose_name=_("UserName"))
    is_delete=models.BooleanField(default=False)
    is_superuser=models.BooleanField(default=False)
    roles=models.ManyToManyField(Role,related_name="user_roles")
    
    USERNAME_FIELD = "username"
    REQUIRED_FIELDS = ["first_name", "last_name"]   

    objects=UserManager()
    def has_perm(self, perm, obj=None):
        return self.is_superuser

    def has_module_perms(self, app_label):
        return self.is_superuser


class UserToken(models.Model):
    user=models.OneToOneField(User,related_name='user_token',on_delete=models.CASCADE)
    token=models.TextField(null=True)

    def __str__(self) -> str:
        return self.user.username



class RolePermission(BaseModel):
    role=models.ForeignKey(Role,related_name="role_permissions",on_delete=models.PROTECT)
    function_master=models.ForeignKey(Function,related_name="function_permissions",on_delete=models.PROTECT, to_field='function_code')
    create=models.BooleanField(default=False)
    view=models.BooleanField(default=False)
    edit=models.BooleanField(default=False)
    delete=models.BooleanField(default=False)
    

    def __str__(self) -> str:
        return self.role.role_name
