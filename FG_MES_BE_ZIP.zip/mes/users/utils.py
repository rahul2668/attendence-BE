from .models import Role,RolePermission
from .models import Function,Module
from mes.plant.models import PlantConfig


def get_permissions_list(role_id=None, is_clone=False):

    module_list = Module.objects.all().order_by('sort_order')
    module_dict = {}
    for module in module_list:
        function_dict = {}
        function_list = Function.objects.filter(module=module).order_by('sort_order')
        permission_dict = {}
        for function in function_list:
            if role_id:
                role = Role.objects.get(id=role_id)
                try:
                    role_permission = RolePermission.objects.get(function_master=function, role=role)
                    if is_clone:
                        permission_dict = {
                            "view": role_permission.view,
                            "create": role_permission.create,
                            "edit": role_permission.edit,
                            "delete": role_permission.delete,
                            "id": function.id,
                        }

                    else:
                        permission_dict = {
                            "view": role_permission.view,
                            "create": role_permission.create,
                            "edit": role_permission.edit,
                            "delete": role_permission.delete,
                            "id": role_permission.id,
                        }

                    function_dict.update({role_permission.function_master.function_name: permission_dict})
                except RolePermission.DoesNotExist:
                    # continue
                    permission_dict = {
                        "view": False,
                        "create": False,
                        "edit": False,
                        "delete": False,
                        "id": function.id,
                    }
                    function_dict.update({function.function_name: permission_dict})

            else:
                permission_dict = {"view": False, "create": False, "edit": False, "delete": False, "id": function.id}
                function_dict.update({function.function_name: permission_dict})
        module_dict.update({module.module_name: function_dict})
    return module_dict


def get_permissions_list(role_id=None, is_clone=False):
    plant_config=PlantConfig.objects.first()
    plant_config_function=plant_config.plant_config_function.all().order_by('function__module__sort_order')
    module_dict = {}

    for item in plant_config_function:
        module_name = item.module.module_code
        function_name = item.function.function_code
        module_dict.setdefault(module_name, {}).setdefault(function_name, {})
        # if 'System Admin'not in module_name: 

        if role_id:
            role = Role.objects.get(id=role_id)
            try:
                role_permissions = RolePermission.objects.filter(function_master=item.function, role=role)
                if role_permissions.exists():
                    role_permission = role_permissions.first()
                    permission_dict = {
                        "view": role_permission.view,
                        "create": role_permission.create,
                        "edit": role_permission.edit,
                        "delete": role_permission.delete,
                        "id": item.function.function_code if is_clone else role_permission.id,
                }
                module_dict[module_name][function_name]=permission_dict
            except RolePermission.DoesNotExist:
                permission_dict = {
                        "view": False,
                        "create": False,
                        "edit": False,
                        "delete": False,
                        "id": item.function.function_code,
                    }
                module_dict[module_name][function_name]=permission_dict
                
        else:
            permission_dict = {"view": False, "create": False, "edit": False, "delete": False, "id": item.function.function_code}
            module_dict[module_name][function_name]=permission_dict

    return module_dict

from mes.constants import EXCLUDE_FUNCTIONS_LIST
def get_user_permissions_list(role_list):
    module_list = Module.objects.all().order_by('sort_order')
    role_permission_list = []

    if role_list:
        for role_id in role_list:
            role_dict = {}
            role = Role.objects.get(id=role_id)
            module_dict = {}

            for module in module_list:
                function_dict = {}
                function_list = Function.objects.filter(module=module).order_by('sort_order')

                for function in function_list:
                    permission_dict = {}
                    role_permissions = RolePermission.objects.filter(role=role, function_master=function)
                    
                    if role_permissions.exists():
                        role_permission = role_permissions.first()
                        permission_dict = {
                            "view": role_permission.view,
                            "create": role_permission.create,
                            "edit": role_permission.edit,
                            "delete": role_permission.delete,
                            "isEligibleForMenu": not (
                                function.function_name in EXCLUDE_FUNCTIONS_LIST or role_permission.view == False
                            )
                        }
                        function_dict.update({role_permission.function_master.function_code: permission_dict})
                
                module_dict.update({module.module_code: function_dict})
            role_dict.update({role.role_name: module_dict})
            role_permission_list.append(role_dict)
    return role_permission_list
def merge_with_priority(dict1, dict2):
    result = {}
    all_keys = set(dict1.keys()) | set(dict2.keys())

    for key in all_keys:
        value1 = dict1.get(key, {})
        value2 = dict2.get(key, {})

        if isinstance(value1, dict) and isinstance(value2, dict):
            result[key] = merge_with_priority(value1, value2)
        else:
            # Prioritize True values, if present in either dictionary
            result[key] = value1 if value1 is True else value2

    return result


def merge_with_priority_multiple(*dicts):
    user_dict = {}
    for user_permissions in dicts:
        for user_permission in user_permissions:
            for user, permissions in user_permission.items():
                if len(user_dict) == 0:
                    user_dict = permissions
                    continue
                for module, functions in permissions.items():
                    for key, function in functions.items():
                        for op_key, op_value in function.items():
                            if op_value:
                                user_dict[module][key][op_key] = op_value
    return user_dict


def get_permission_union(role_list):
    if not role_list:
        return {}
    users_permissions = get_user_permissions_list(role_list)


    merged_permissions = merge_with_priority_multiple(users_permissions)

    return merged_permissions


