from django.urls import path,re_path,include
from rest_framework.routers import DefaultRouter
from . import views
router = DefaultRouter()
router.register(r'functions', views.FunctionViewSet, basename='function')
app_name="accounts"
urlpatterns = [
    path('', include(router.urls)),
    path('simple-login/',view=views.SimpleUserLoginView.as_view(),name="simple_login"),
    path('sso-login/',view=views.SSOLoginView.as_view(),name="sso_login"),
    path('sso-login-credentials/',view=views.get_sso_login_keys,name="get_sso_login_keys"),
    re_path(r'^roles/(?P<pk>\d+)?/?$',views.RolesView.as_view(),name="manage_roles"),
    re_path(r'users/(?P<pk>\d+)?/?$',views.UserView.as_view(),name="user_view"),
    path("clone_role/", view=views.clone_role, name="clone_role"),
    path("create_role/", view=views.create_role, name="create_role"),
    path("edit_role/", view=views.edit_role, name="edit_role"),
    path('get-roles/',views.get_roles,name='get_roles'),
    path("get_permission_data/", view=views.get_permission_data, name="get_permission_data"),
    path("get-plant-language/", view=views.get_plant_language, name="get_plant_language"),

    path('reset-password/<int:pk>/',views.reset_password,name="reset_password"),
    path('change-password/',views.change_password,name="change_password"),
    path('logout/', views.LogoutAPIView.as_view(), name='logout'),


    path('get-all-users/',views.get_all_users_list_for_filter,name="get_all_users_list_for_filter")

]