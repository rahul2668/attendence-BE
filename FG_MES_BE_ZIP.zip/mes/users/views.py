from datetime import  timedelta
from django.contrib.auth import authenticate,login
from django.db import IntegrityError
from django.utils import timezone
from rest_framework.views import APIView
from rest_framework.decorators import api_view, permission_classes, action
from rest_framework.permissions import AllowAny
from rest_framework.mixins import ListModelMixin, RetrieveModelMixin, UpdateModelMixin, CreateModelMixin
from rest_framework.viewsets import GenericViewSet
from rest_framework_simplejwt.tokens import  AccessToken

from rest_framework.response import Response
from rest_framework import status
from rest_framework import viewsets

from . import models as account_model
from mes.utils.models import Function
from . import serializers as se
from .utils import get_permissions_list
from .models import User,RolePermission,UserToken
from django.contrib.auth.hashers import make_password

from mes.plant.models import Plant
from config import settings
import base64
from mes.plant.models import PlantConfigFunction,PlantConfig
from django.db import IntegrityError
from mes.utils.services import de_structure_errors
from mes.utils.models import Master
MESSAGE="userAccessControl.roles.roleWithSameNameAlreadyExistsNotify"

PASSWORD_MESSAGE="authentication.changePassword.newPasswordMustBeDifferentNotify"
created_at=modified_at=timezone.now()


class LogoutAPIView(APIView):
    def post(self,request):
        try:
            user=request.user
            user_token=UserToken.objects.get(user=user)
            user_token.token=None
            user_token.save()
            return Response({'message': 'authentication.login.logoutSuccessNotify'}, status=status.HTTP_205_RESET_CONTENT)
        except Exception as e:
            return Response({'message': str(e)}, status=status.HTTP_400_BAD_REQUEST)

def get_access_token_for_user(user, request):
    if PlantConfig.objects.all().exists():
        function_ids = list(PlantConfigFunction.objects.values_list('function_id', flat=True))
        role_permissions = RolePermission.objects.exclude(function_master_id__in=function_ids)
        for item in role_permissions:
            item.view = False
            item.create = False
            item.edit = False
            item.delete = False
            item.save()
    response={}
    login(request,user)
    serializer = se.UserDetailSerializer(user, context={"request": request})
    
    token_data = serializer.data
    token_data['login_type'] = user.login_type
    plant=Plant.objects.first()
    plant_config=PlantConfig.objects.first()
    plant_data={
            "plant_name":plant.plant_name,
            "plant_id":plant.plant_id,
            "area_code":plant.area_code,
            "plant_time_zone_id": plant_config.timezone_id if plant_config else None

            }
    access_token = AccessToken.for_user(user)
    access_token['user_data'] = dict(token_data)
    access_token['plant_data']=plant_data
    access_token=str(access_token)
    if UserToken.objects.filter(user=user).exists():
        user.user_token.token=access_token
        user.user_token.save()
    else:
        UserToken.objects.create(user=user,token=access_token)
    response["message"] = "authentication.login.loginSuccessNotify"
    response['access_token']=access_token
    return response
   


def encode_value(value):
    encoded_bytes = base64.b64encode(value.encode('utf-8'))
    encoded_string = encoded_bytes.decode('utf-8')
    return encoded_string
@api_view(['GET'])
def get_sso_login_keys(request):
   data= {
        "clientId":encode_value(settings.env('SSO_CLIENT_ID')),
        "authority":encode_value(settings.env('SSO_TENANT_ID')),
        "redirectUri":settings.env('SSO_REDIRECT_URL'),
        "acceptedDomain":settings.env('SSO_ACCEPTED_DOMAIN')
    }
   return Response(data)


@api_view(['GET'])
def get_plant_language(request):
    lang = "en"
    # try:
    #     plant_config = PlantConfig.objects.first()
    #     language = Master.objects.get(master_code=plant_config.language_id).value
    #     if language == 'Spanish':
    #         lang = "es"
    #     elif language == 'French':
    #         lang = 'fr'
    # except (Master.DoesNotExist, AttributeError):
    #     pass

    return Response({"language":lang})

class SimpleUserLoginView(APIView):
    def post(self,request):
        data=request.data
        username= data.get("username",None)
        password= data.get("password",None)
        if not username or not password :
            return Response({"message": "authentication.login.userNameOrPasswordIsEmptyNotify"}, status=status.HTTP_400_BAD_REQUEST)
        check_user=account_model.User.objects.filter(username__iexact=username).first()
        user=authenticate(request=request,username=username,password=password)
        if user:
            if user.is_delete:
                return Response({"message":"authentication.login.userDeactivatedContactAdminNotify"}, status=status.HTTP_401_UNAUTHORIZED)
            response = get_access_token_for_user(user, request)
            return Response(response, status=status.HTTP_200_OK)
        elif  check_user is None:
            return Response({"message":"authentication.login.userNotFoundNotify"},status=status.HTTP_404_NOT_FOUND)
        else:
            return Response({"message": "authentication.login.passwordIsNotCorrectNotify"}, status=status.HTTP_404_NOT_FOUND)


class SSOLoginView(APIView):
    def post(self,request,):
        
        email=request.data.get('email')
        user=User.objects.filter(username__iexact=email).first()
        if user :
            if  user.is_delete:
                return Response({"message":"authentication.login.userDeactivatedContactAdminNotify"}, status=status.HTTP_401_UNAUTHORIZED)
            response = get_access_token_for_user(user, request)
            return Response(response, status=status.HTTP_200_OK)
        elif  user is None:
            return Response({"message":"authentication.login.userNotFoundNotify"},status=status.HTTP_404_NOT_FOUND)
        else:
            return Response({"message": "authentication.login.passwordIsNotCorrectNotify"}, status=status.HTTP_404_NOT_FOUND)


class RolesView(APIView):
    def get(self,request,pk=None):
        if pk:
            role=account_model.Role.objects.get(pk=pk)
            serializer=se.RoleSerializer(role)
            return Response({"result":serializer.data},status=status.HTTP_200_OK)
        roles=account_model.Role.objects.filter(record_status=True).order_by('-modified_at')
        if  request.user.is_superuser == False:
            roles=roles.exclude(role_name="SuperAdmin")
        serializer=se.RoleSerializer(roles,many=True)

        return Response({"results":serializer.data},status=status.HTTP_200_OK)
    def post(self,request):
        user=request.user
        try:
            role_name = request.data.get("role_name")
            existing_role = account_model.Role.objects.filter(role_name__iexact=role_name).first()
            if existing_role:
                return Response({"message":MESSAGE}, status=status.HTTP_400_BAD_REQUEST)
            serializer= se.RoleSerializer(data=request.data,context={"request":request})
            if serializer.is_valid(raise_exception=True):
                serializer.save(created_by=user,modified_by=user,modified_at=modified_at)
                return Response({"message":"userAccessControl.roles.roleAddedSuccessNotify"})
            else:
                return Response({"message":de_structure_errors(serializer.errors)},status=status.HTTP_400_BAD_REQUEST)
           
        
        except IntegrityError as e:
            return Response({"message": f"{MESSAGE}"}, status=status.HTTP_400_BAD_REQUEST)

   

    def patch(self,request,pk=None):
        user=request.user
        response = {}
        try:
            role = account_model.Role.objects.get(id=pk)
        except account_model.Role.DoesNotExist:
            return Response({"message": "userAccessControl.roles.roleNotFoundNotify"}, status=status.HTTP_404_NOT_FOUND)

        user_obj = account_model.User.objects.filter(roles__id=pk, is_delete=False)
        if user_obj and role.is_delete ==False:
            return Response({"message": "userAccessControl.roles.usersAssociatedWithThisRoleNotify"}, status=status.HTTP_400_BAD_REQUEST)
        role_permissions = account_model.RolePermission.objects.filter(role=role)
        for permission in role_permissions:
            permission.is_delete = not role.is_delete
            permission.modified_by=user
            permission.modified_at=modified_at
            permission.save()
        role.is_delete = not role.is_delete
        role.modified_by=user
        role.modified_at=modified_at
        role.save()
        response["message"] = "userAccessControl.roles.roleDeactivatedNotify" if role.is_delete else "userAccessControl.roles.roleActivatedNotify"
        response["role"] = se.RoleSerializer(role, context={"request": request}).data
        return Response(response, status=status.HTTP_200_OK)

class  UserView(APIView):
    def get(self,request,pk=None):
        type_view=request.query_params.get('type',)
        if pk:
            user=account_model.User.objects.get(pk=pk)
            ids=[]
            if type_view=='edit':
                serializer=se.UserSerializer(user)
                data=serializer.data
            else:
                serializer=se.UserDetailSerializer(user,context={'request': request})
                data=serializer.data
                data['department']=user.department
            # if type_view=='edit':
            roles=user.roles.values('id')
               
            for item in roles:
                ids.append(item.get('id',None))
            data['roles']=ids
            return Response(data,status=status.HTTP_200_OK)
        users=account_model.User.objects.exclude(is_superuser=True).order_by('-modified_at')
        serializer=se.UserSerializer(users,many=True)
        return Response({"results":serializer.data})
    def post(self,request,pk=None):
        data=request.data
        request_user=request.user
        try:
            user=User.objects.create_user(**data,created_by=request_user,modified_by=request_user)
            UserToken.objects.create(user=user)
        except Exception :
            return Response({'message': "userAccessControl.users.userNameAlreadyExistsNotify","username":data.get('username', None)}, status=status.HTTP_400_BAD_REQUEST)
        return Response({"message":"userAccessControl.users.userAddedSuccessNotify"})
        
    def put(self,request,pk=None):
        roles = request.data.get('roles',[])
        data=request.data
        keys_to_remove = ['username', 'is_superuser', 'login_type']
        for key in keys_to_remove:
            data.pop(key, None)

        user=account_model.User.objects.filter(pk=pk).first()
        serializer=se.UserSerializer(instance=user,data=data,partial=True)
        if serializer.is_valid(raise_exception=True):
            user=serializer.save(modified_by=request.user,modified_at=modified_at)
            user.roles.set(roles)
            return Response({"message":"userAccessControl.users.userUpdateNotify"})
        else :
            return Response({"message":de_structure_errors(serializer.errors)})
    def patch(self,request,pk=None):
        user=account_model.User.objects.get(pk=pk)
        try:
            user_token=UserToken.objects.get(user=user)
            user_token.token=None
            user_token.save()
        except Exception:
            pass
        user.modified_by=request.user
        user.is_delete= not user.is_delete
        user.modified_at=modified_at
        user.save()
        return Response({"message":f"{'userAccessControl.users.userDeactivatedSuccessNotify' if  user.is_delete else 'userAccessControl.users.userActivatedSuccessNotify'}"})

@api_view(["POST"])
@permission_classes((AllowAny,))
def clone_role(request):
    role_name = request.data.get("role_name")
    role_id = request.data.get("role_id")
    permission_list = request.data.get("permission_list")
    response = {}
    role = account_model.Role.objects.get(id=role_id)
    role.role_name = role_name
    role.modified_by=request.user
    role.modified_at=modified_at
    role.save()
    for module_name, functions_list in permission_list.items():
        for function, permissions in functions_list.items():
            role_permission = account_model.RolePermission.objects.get(id=permissions["id"])
            role_permission.read = permissions["view"]
            role_permission.create = permissions["create"]
            role_permission.edit = permissions["edit"]
            role_permission.delete = permissions["delete"]
            role_permission.modified_by=request.user
            role.modified_at=modified_at
            role_permission.save()
    response["role"] = se.RoleSerializer(role, context={"request": request}).data
    return Response(response, status=status.HTTP_200_OK)


class FunctionViewSet(viewsets.ModelViewSet):
    queryset = account_model.Function.objects.all()
    serializer_class = se.FunctionSerializer

    def list(self, request, *args, **kwargs):
        response= super().list(request, *args, **kwargs)
        return response
    
    def create(self, request, *args, **kwargs):
        default_values = {
            'created_by': request.user, 
        }
        data_with_defaults = {**request.data, **default_values}
        serializer = self.get_serializer(data=data_with_defaults)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)

        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=201, headers=headers)

@api_view(["POST"])
@permission_classes((AllowAny,))
def edit_role(request):
    try:
        role_name = request.data.get("role_name")
        role_id = request.data.get("role_id")
        permission_list = request.data.get("permission_list")
        is_superuser = request.data.get("is_superuser",False)
        response = {}
        existing_role = account_model.Role.objects.exclude(pk=role_id).filter(role_name__iexact=role_name).first()
        if existing_role:
            return Response({"message":MESSAGE }, status=status.HTTP_400_BAD_REQUEST)
        role = account_model.Role.objects.get(id=role_id)
        role.role_name = role_name
        role.is_superuser = is_superuser
        role.modified_by=request.user
        role.modified_at=modified_at
        role.save()

        for module_name, functions_list in permission_list.items():
            for function, permissions in functions_list.items():
                function_=Function.objects.filter(function_code=function).first()
                try:
                    role_permission = account_model.RolePermission.objects.filter(role=role,function_master=function_)
                    if role_permission.exists():
                       role_permission = role_permission.first()
                       role_permission.view = permissions.get("view",False)
                       role_permission.create = permissions.get("create",False)
                       role_permission.edit = permissions.get("edit",False)
                       role_permission.delete = permissions.get("delete",False)
                       role.modified_by=request.user
                       role.modified_at=modified_at
                       role_permission.save()
                except (account_model.RolePermission.DoesNotExist, KeyError):
                    permissions.pop('id',None)
                    account_model.RolePermission.objects.create(**permissions,modified_by=request.user,role=role,function_master=function_)
                   
        response["role"] = se.RoleSerializer(role, context={"request": request}).data
       
        return Response({"message":"userAccessControl.roles.roleUpdatedSuccessNotify"}, status=status.HTTP_200_OK)
    except IntegrityError :
        return Response({"message": MESSAGE}, status=status.HTTP_400_BAD_REQUEST)

from .models import Module
@api_view(['GET'])
def get_roles(request):
    data=[]
    module=Module.objects.all()
    for i, item in enumerate(module):
        functions=item.module_functions.all()
        module_data={}
        module_data['id']=item.id
        module_data['module']=item.module_name
        module_data['functions']=[]
        for function in functions:
            module_data.get('functions').append({"id":function.id,"function_name":function.function_name})
            permissions=function.function_permissions.all()
            module_data['permissions']=[]
            for permission in permissions:
                permission_data={
                    "view":permission.view or False,
                    "create":permission.create or False,
                    "edit":permission.edit or False,
                    "delete":permission.delete or False,
                }
                module_data['permissions'].append(permission_data)
        data.append(module_data)
    return Response(data)


@api_view(["POST"])
@permission_classes((AllowAny,))
def get_permission_data(request):
    response = {}
    role_id = request.data.get("role_id")
    is_clone = request.data.get("is_clone", None)
    if role_id:
        role = account_model.Role.objects.get(id=role_id)
        response["role"] = se.RoleSerializer(role, context={"request": request}).data
        users=account_model.User.objects.filter(roles=role)
        response['users']=se.UserSerializer(users,many=True).data
    else:
        response["role"] = None
    permission_list = get_permissions_list(role_id,is_clone)
    response["permission_list"] = permission_list
    return Response(response, status=status.HTTP_200_OK)


@api_view(["POST"])
@permission_classes((AllowAny,))
def create_role(request):
    try:
        role_name = request.data.get("role_name")
        is_superuser = request.data.get("is_superuser")
        permission_list = request.data.get("permission_list")
        response = {}

        existing_role = account_model.Role.objects.filter(role_name__iexact=role_name).first()
        if existing_role:
            return Response({"message": MESSAGE}, status=status.HTTP_400_BAD_REQUEST)
        role = account_model.Role.objects.create(role_name=role_name, is_superuser=is_superuser,created_by=request.user)
        for module_name, functions_list in permission_list.items():
            for function, permissions in functions_list.items():
                account_model.RolePermission.objects.create(
                    function_master_id=permissions["id"],
                    role=role,
                    view=permissions["view"],
                    create=permissions["create"],
                    edit=permissions["edit"],
                    delete=permissions["delete"],
                    created_by=request.user,
                    modified_by=request.user
                )

        response["permission_list"] = get_permissions_list(role.id)
        response["role"] = se.RoleSerializer(role, context={"request": request}).data
        return Response({"message":"userAccessControl.roles.roleAddedSuccessNotify"}, status=status.HTTP_200_OK)
    except IntegrityError:
        return Response({"message": f"{MESSAGE}"}, status=status.HTTP_400_BAD_REQUEST)


class UserViewSet(RetrieveModelMixin, ListModelMixin, UpdateModelMixin, GenericViewSet, CreateModelMixin):
    filterset_fields = ["username", "email"]
    search_fields = ["username"]
    ordering = ["pk"]
    
    queryset = User.objects.all().order_by("id")
    lookup_field = "pk"

    def get_serializer_class(self):
        if self.action == "list":
            return se.UserListSerializer
        if self.action == "retrieve":
            return se.UserDetailSerializer
        if self.action == "create":
            return se.UserCreateSerializer
        if self.action == "update":
            return se.UserUpdateSerializer
        if self.action == "partial_update":
            return se.UserUpdateSerializer
        if self.action == "destroy":
            return se.UserCreateSerializer
        return se.UserSerializer
    @action(
        methods=["POST"],
        detail=True,
        url_path="resetpassword",
        url_name="resetpassword",
        permission_classes=[AllowAny],
    )
    def resetpassword(self, request, pk=None):
        response = {}
        
        user_object = self.get_object()
        password = request.data.get("password")
        password_match = user_object.check_password(password)
        if password_match:
            response["message"] = PASSWORD_MESSAGE
            status_code = status.HTTP_400_BAD_REQUEST
            return Response(response, status=status_code)

        password = make_password(password)

        user_object.set_password(password)

        user_object.save()

        # Serialize the current object and return it in the response
        user_object_serializer = se.UserDetailSerializer(user_object, context={"request": request})

        return Response(user_object_serializer.data, status=status.HTTP_200_OK)


@api_view(['POST'])
def reset_password(request, pk=None):
    response = {}
    user=request.user
    
    user_object = User.objects.get(pk=pk)
    password = request.data.get("password",'')
    if not password:
        return Response({"message":"userAccessControl.users.passwordRequiredToResetNotify"})
    password_match = user_object.check_password(password)
    if password_match:
        response["message"] = PASSWORD_MESSAGE
        status_code = status.HTTP_400_BAD_REQUEST
        return Response(response, status=status_code)

    password = make_password(password)
    user_object.password=password
    user_object.modified_at=modified_at
    user_object.modified_by=user
    user_object.save()
    if hasattr(user_object,"user_token"):
        user_object.user_token.token=None
        user_object.user_token.save()

    user_object_serializer = se.UserDetailSerializer(user_object, context={"request": request})

    return Response(user_object_serializer.data, status=status.HTTP_200_OK)

@api_view(['POST'])
def change_password(request):
        response = {}
        current_password = request.data.get("current_password")
        new_password = request.data.get("new_password")
        username = request.data.get("username")
 
        try:
            user = authenticate(username=username, password=current_password)
            if user is not None:
                password_match = user.check_password(new_password)
                if password_match:
                    response["message"] = PASSWORD_MESSAGE
                    status_code = status.HTTP_400_BAD_REQUEST
                    return Response(response, status=status_code)
                password = make_password(new_password)
                user.password = password
                user.modified_at=modified_at
                user.modified_by=request.user
                user.save()
                response["message"] = "authentication.changePassword.passwordChangedSuccessNotify"
                status_code = status.HTTP_200_OK
            else:
                response["message"] = "authentication.changePassword.oldPasswordWrongNotify"
                status_code = status.HTTP_400_BAD_REQUEST
        except Exception as e:
            response["message"] = "authentication.changePassword.errorOccurredWhileChangePasswordNotify"
            status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
 
        return Response(response, status=status_code)


@api_view(["POST"])
@permission_classes((AllowAny,))
def clone_role(request):
    role_name = request.data.get("role_name")
    role_id = request.data.get("role_id")
    permission_list = request.data.get("permission_list")
    is_superuser=request.data.get('is_superuser')
    response = {}
    role = account_model.Role.objects.get(id=role_id)
    role.role_name = role_name
    role.is_superuser = is_superuser
    role.modified_by=request.user
    role.save()
    for module_name, functions_list in permission_list.items():
        for function, permissions in functions_list.items():
            role_permission = account_model.RolePermission.objects.get(id=permissions["id"])
            role_permission.view = permissions["view"]
            role_permission.create = permissions["create"]
            role_permission.edit = permissions["edit"]
            role_permission.delete = permissions["delete"]
            role_permission.modified_by=request.user
            role_permission.save()
    response["permission_list"] = get_permissions_list(role.id)
    response["role"] = se.RoleSerializer(role, context={"request": request}).data
    return Response(response, status=status.HTTP_200_OK)


@api_view(['GET'])
def get_all_users_list_for_filter(request):
    users=User.objects.filter(record_status=True).values('id','username')
    return Response({"data":users},status=200)