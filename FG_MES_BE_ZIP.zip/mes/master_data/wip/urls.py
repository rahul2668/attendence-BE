from django.urls import path
from . import views

app_name="wip"
urlpatterns = [
    path('wip-additional-information/<str:pk>/', views.WipAdditionalInformationView.as_view(), name='wip_additional_information'),
    path('wip-material-specification-step2/<str:pk>/',views.WipSpecificationStepView.as_view(),name='wip_material_specification'),

]

