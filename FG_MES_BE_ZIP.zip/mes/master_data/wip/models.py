from django.db import models
from mes.utils.models import BaseModel
from mes.master_data.material_master.models import MaterialMaster,MaterialTypeMaster,ElementSpecification

# Create your models here.
class AdditionalInformation(BaseModel):
    material_master=models.ForeignKey(MaterialMaster,related_name="wip_additional_info",on_delete=models.PROTECT, to_field='mes_mat_code')
    density=models.DecimalField(max_digits=6,decimal_places=2)
    spec_references=models.CharField(max_length=255)
    is_available=models.BooleanField()
    effective_date=models.DateField()
    def __str__(self) -> str:
        return f'{self.spec_references}'
    class Meta:
        unique_together=('material_master','effective_date')
