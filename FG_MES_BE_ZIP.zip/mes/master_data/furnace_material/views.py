from . import models as fur_mat_model 
from . import serializers  as se
from rest_framework.response import Response
from rest_framework import status,views
from rest_framework.views import APIView
from mes.utils import services 
from django.http import Http404
from mes.master_data.material_master.models import MaterialMaster,ElementSpecification,ElementSpecificationChangeLog,Size,SizeSpecificationChangeHistory
from django.db import transaction,IntegrityError
from mes.master_data.material_master.views import get_material_specification
from mes.utils.services import get_material_master_additional_info
from mes.master_data.material_master.serializers import SizeCreateSerializer,AddInfoSerializer
from django.utils import timezone
from django.db.models import Q



class FurnaceMaterialSpecificationStepView(views.APIView):

    def get(self,request,pk=None):
        data=get_material_specification(material_master=MaterialMaster.objects.get(mes_mat_code=pk))
        return Response({"data": data})
        
    def put(self, request, *args, **kwargs):
        data = request.data
        user=request.user
        chemistry_values=data.get('chemistry_values')
        other_chemistry_values=data.get('other_chemistry_values')
        physical_elements=data.get('physical_elements')
        size=data.get('sizes',{})
        auxillary=data.get('auxillary',)
        material_master_id=kwargs.get('pk')
        services.save_material_master(mes_mat_code=material_master_id)


        change_log=data.get('changeHistoryData',[])
        services.create_update_data(method="edit",model=ElementSpecification,data= chemistry_values,user=user,master_id=material_master_id)
        services.create_update_data(method="edit",model=ElementSpecification,data= other_chemistry_values,user=user,master_id=material_master_id)
        services.create_update_data(method="edit",model=ElementSpecification,data= physical_elements,user=user,master_id=material_master_id)
        services.create_update_data(method="edit",model=ElementSpecification,data= auxillary,user=user,master_id=material_master_id)
        if change_log:
            ElementSpecificationChangeLog.objects.create(material_master_id=material_master_id,change_log=change_log,created_by=user)
        size_pk=size.pop('id',None)
        low_size=size.get('low_size',None)
        high_size=size.get('high_size',None)
        change_history=SizeSpecificationChangeHistory.objects.filter(modified_at__date=timezone.now().date(),material_master_id=material_master_id,low_size_id=low_size,high_size_id=high_size)
        if size_pk:
            instance=Size.objects.filter(pk=size_pk,material_master_id=material_master_id).first()
            serializer=SizeCreateSerializer(instance,size,partial=True)
            if serializer.is_valid():
                serializer.save()
        else:
            serializer=SizeCreateSerializer(data=size)
            if serializer.is_valid():
                serializer.save(material_master_id=material_master_id)
            if change_history.exists():
                change_history.update(**serializer.validated_data,modified_by=user,modified_at=timezone.now())
            else:
                SizeSpecificationChangeHistory.objects.create(**serializer.validated_data,material_master_id=material_master_id,created_by=user,modified_by=user,modified_at=timezone.now())
           
        return Response({"message":"masterData.sharedMasterDataTexts.materialSpecificationUpdateNotify"})
    

class FurnaceAdditionalInformationView(APIView):
    serializer_class=se.AdditionalInformationSerializer
    model_class=fur_mat_model.AdditionalInformation
    now_date=timezone.now().date()
    valid_serializer=AddInfoSerializer

    def get_object(self, **kwargs):
        try:
            return self.model_class.objects.get(**kwargs)
        except self.model_class.DoesNotExist:
            raise Http404
    def get(self,request,pk=None):
        master=MaterialMaster.objects.get(mes_mat_code=pk)
      
        if pk:
            data=master.additionalinformation_set.all()
            excel_download=request.query_params.get('excel_download','')
            if excel_download:
                serializer=self.serializer_class(data,many=True,context={"request":request})
                return Response({"data":serializer.data,})
            selected_date,master_data=get_material_master_additional_info(data=data,material_master=master,)
            if selected_date:
                serializer=self.serializer_class(selected_date)
                data=serializer.data
                data.update(master_data)
                return Response({"data":data})
            else:
                return Response({"data":master_data})
        else:
            return Response({"message":"sharedTexts.noRecordsFound"})
    def post(self, request,pk=None):
        user=request.user
        data=request.data
        data['material_master']=pk
        material_master=MaterialMaster.objects.get(mes_mat_code=pk)
        user_approval=request.data.pop('is_user_approved',False)
        val_serializer = self.valid_serializer(data=request.data)
        val_serializer.is_valid(raise_exception=True)
        if not Size.objects.filter(material_master=material_master).exists():
            Size.objects.create(material_master=material_master,below_tolerance=0,above_tolerance=0,created_by=user )
        material_master.save_element_specification(user=user)
        services.save_material_master(mes_mat_code=pk)
        try:
            with transaction.atomic():
                add_info_id = data.get('additional_info_id', None)
                if add_info_id:
                    existing_add_info=material_master.additionalinformation_set.filter(pk=add_info_id,effective_date=data.get('effective_date',None))
                    if existing_add_info.exists():
                        existing_add_info.update(**val_serializer.validated_data,modified_by=user,modified_at=self.now_date)
                        return Response({"message":"masterData.sharedMasterDataTexts.materialInfoUpdateNotify"}, status=status.HTTP_201_CREATED)
                existing_add_info=material_master.additionalinformation_set.filter(effective_date=data.get('effective_date',None))
                if existing_add_info.exists() and not user_approval:
                        return Response({"message":"apiNotifications.userApprovalNeeded","user_approval_needed":True},status=status.HTTP_200_OK)
                elif not existing_add_info.exists():
                    self.model_class.objects.create(**val_serializer.validated_data,created_by=user,modified_by=user,material_master=material_master)
                add_info =existing_add_info.first()
                if add_info:
                    add_info.modified_by = user
                    add_info.modified_at = self.now_date
                    for key, value in val_serializer.validated_data.items():
                        if hasattr(add_info, key):
                            setattr(add_info, key, value)
                    add_info.save()
        except IntegrityError as e:
            return Response({'message': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        return Response({"message":"masterData.sharedMasterDataTexts.materialInfoUpdateNotify"}, status=status.HTTP_201_CREATED)
