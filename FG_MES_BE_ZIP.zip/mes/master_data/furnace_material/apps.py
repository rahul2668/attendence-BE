from django.apps import AppConfig


class FurnaceMaterialConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mes.master_data.furnace_material'
