from django.urls import path
from . import views

app_name="furnace_material"

urlpatterns = [
    path('furnace-additional-information/<str:pk>/', views.FurnaceAdditionalInformationView.as_view(), name='furnace_additional_information'),
    path('furnace-material-specification-step2/<str:pk>/',views.FurnaceMaterialSpecificationStepView.as_view(),name='furnace_material_specification'),

]

