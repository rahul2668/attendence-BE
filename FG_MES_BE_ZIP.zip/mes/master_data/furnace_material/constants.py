
chemistry_values = [
    {"element": "AL (%)",  'low': 0, 'aim': 0, 'high': 0},
    {"element": "B (ppm)",  'low': 0, 'aim': 0, 'high': 0},
    {"element": "Ca (%)",  'low': 0, 'aim': 0, 'high': 0},
    {"element": "Cr (ppm)",  'low': 0, 'aim': 0, 'high': 0},
    {"element": "Cu (ppm)",  'low': 0, 'aim': 0, 'high': 0},
    {"element": "Fe (%)",  'low': 0, 'aim': 0, 'high': 0},
    {"element": "Mg (ppm)",  'low': 0, 'aim': 0, 'high': 0},
    {"element": "Mn (ppm)",  'low': 0, 'aim': 0, 'high': 0},
    {"element": "Ni (ppm)",  'low': 0, 'aim': 0, 'high': 0},
    {"element": "P (ppm)",  'low': 0, 'aim': 0, 'high': 0},
    {"element": "S (ppm)",  'low': 0, 'aim': 0, 'high': 0},
    {"element": "Ti (ppm)",  'low': 0, 'aim': 0, 'high': 0},
    {"element": "V (ppm)",  'low': 0, 'aim': 0, 'high': 0},
    {"element": "Zn (ppm)",  'low': 0, 'aim': 0, 'high': 0},
]
other_chemical_values=[
    
]
physical_elements = [
    {"element": "Volatile (%)", 'low': 0, 'aim': 0, 'high': 0},
    {"element": "Fixed Carbon (%)", 'low': 0, 'aim': 0, 'high': 0},
    {"element": "Ash (%)", 'low': 0, 'aim': 0, 'high': 0},
    {"element": "Moisture (%)", 'low': 0, 'aim': 0, 'high': 0},
]

size = [
    {"element": "Coke (ISO mm)", 'low': 0, 'aim': 0, 'high': 0},
]

DATA = {
    'chemistry_values': chemistry_values,
    'other_chemical_values': other_chemical_values,
    'physical_elements': physical_elements,
    'size': size
}

