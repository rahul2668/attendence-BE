from mes.master_data.furnace_material import models as fur_mat_model
from mes.master_data.material_master.models import MaterialElementMaster

dict_data={}
def load_tab2_list_data_from_excel(section_type='Furnace',material_type=None,models=None,material_master=None):
    try:
        if section_type=='Furnace':
            dict_data['Chemistry']=[]
            dict_data['Other Chemistry']=[]
            dict_data['Physical']=[]
            dict_data['Auxiliary']=[]
            dict_data["size"]=[]
            key_order=['Chemistry','Other Chemistry','Physical','Auxiliary',"size",]
            if material_type=='Quartz':
                models.append(fur_mat_model.Auxillary)
            dict_data['size'].append({
            "unit":"",
            "low":0,
            "below_tolerance":0,
            "high":0,
            "above_tolerance":0,   
            })

            models.append(fur_mat_model.Size)
            df_iter_rows(section_type=section_type,material_type=material_type)
        elif section_type=='Additives':
            dict_data["Chemistry"]=[]
            dict_data["Physical"]=[]
            key_order=["Chemistry","Physical"]
            df_iter_rows(section_type=section_type,material_type=material_type)
        elif section_type=='By_Product':
            dict_data["Chemistry"]=[]
            dict_data["Other Chemistry"]=[]
            dict_data["Physical"]=[]
            dict_data["Auxiliary"]=[]
            dict_data["size"]=[]
            key_order=["Chemistry","Other Chemistry","Physical","Auxiliary","size",]
            dict_data['size'].append({
            "unit":"",
            "low":0,
            "below_tolerance":0,
            "high":0,
            "above_tolerance":0,   
            })
            df_iter_rows(section_type=section_type,material_type=material_type)
        elif section_type =='WIP':
            dict_data["Chemistry"]=[]
            dict_data["Physical"]=[]
            key_order=["Chemistry","Physical"]
            df_iter_rows(section_type=section_type,material_type=material_type)
        for index,key in enumerate(key_order):
                value = dict_data[key]
                for itm in value:
                    models[index].objects.create(material_master=material_master,**itm)
    except Exception :
         return False


def df_iter_rows(material_type=None,section_type=None):
    elements=MaterialElementMaster.objects.filter(material_type__type_name=material_type)
    for item in elements:
        unit_part = f"({item.element.unit})" if item.element.unit else "" 
        dict_data[item.element_group.element_group].append({
            "element":  f"{item.element.name}{unit_part}",
            "low":0,
            "aim":0,
            "high":0
        })
