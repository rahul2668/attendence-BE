from django.urls import path
from . import views

app_name="furnace_material"

urlpatterns = [
    path('additive-additional-information/<str:pk>/', views.AdditiveAdditionalInformationView.as_view(), name='additive_additional_information'),
    path('additive-material-specification-step2/<str:pk>/',views.AdditiveMaterialSpecificationStepView.as_view(),name='additive_material_specification'),

]

