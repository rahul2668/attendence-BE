from rest_framework import viewsets,response
from . import  serializers as se
from django.utils import timezone
from django.db.models import Q
from rest_framework.pagination import PageNumberPagination
from rest_framework.response import Response
from rest_framework.decorators  import api_view,APIView
from . import models  as master_models
from rest_framework import status

class MaterialMasterPagination(PageNumberPagination):
    page_size = 10
    page_size_query_param = 'page_size'
    max_page_size = 100
class MaterialCategoryMasterViewSet(viewsets.ModelViewSet):
    queryset = se.MaterialCategoryMaster.objects.all()
    serializer_class = se.MaterialCategoryMasterSerializer

class MaterialTypeMasterViewSet(viewsets.ModelViewSet):
    queryset = se.MaterialTypeMaster.objects.all()
    serializer_class = se.MaterialTypeMasterSerializer

    def get_queryset(self):
        queryset= super().get_queryset()
        category = self.request.query_params.get('category', None)
        if category is None:
            return queryset.none()
        queryset=queryset.filter(category__category_name=category)
        return queryset

class MaterialMasterViewSet(viewsets.ModelViewSet):
    queryset = se.MaterialMaster.objects.all()
    serializer_class = se.MaterialMasterSerializer
    pagination_class = MaterialMasterPagination
    lookup_field='mes_mat_code'

    def get_serializer_context(self):
        context = super().get_serializer_context()
        context['category'] = self.request.query_params.get('category', None)
        return context
    # def get_object(self):
    #     return super().get_object()

    def get_queryset(self):
        queryset=super().get_queryset()
        category = self.request.query_params.get('category', None)
        mes_mat_code = self.request.query_params.get('material_no', None)
        status = self.request.query_params.get('status', None)
        material_name = self.request.query_params.get('material_name', None)
        sort_by_type = self.request.query_params.get('sort_by_type', None)
        filter_by_type = self.request.query_params.get('filter_by_type', None)
        if filter_by_type:
            filter_by_type = [int(item) for item in filter_by_type.split(',')]
        order_by=self.request.query_params.get('sort_by',None)
        if category:
            queryset=queryset.filter(material_type__category__category_name=category)
        if category=='Raw Materials' :
            queryset=queryset.exclude(material_type__type_name__in=['Flux','Anthracite','Other Raw Materials','Chemical Si','Fonderie Others'])
        if filter_by_type:
            queryset=queryset.filter(material_type__id__in=filter_by_type)
        if mes_mat_code:
            queryset=queryset.filter(mes_mat_code__icontains=mes_mat_code)
        if status:
            queryset=queryset.filter(record_status=False if status== "false" else True)
        if material_name:
            queryset=queryset.filter(material_name__istartswith=material_name)
        if sort_by_type:
            order=f'-{sort_by_type}' if order_by == 'DESC' else sort_by_type
            queryset = queryset.order_by(order)
        return queryset
    def partial_update(self, request, *args, **kwargs):
        instance = self.get_object()
        instance.record_status=not instance.record_status
        instance.modified_at=timezone.now()
        instance.save()
        return response.Response({"message":f"Material {instance.material_name} Successfully {'Acitivated'if instance.record_status else 'Deactivated'}"})

class ElementGroupViewSet(viewsets.ModelViewSet):
    queryset = se.ElementGroup.objects.all()
    serializer_class = se.ElementGroupSerializer


# from .models import ElementSpecification,MaterialElementMaster
# def get_material_specification(section_type=None,material_master=None):
#     spec = ElementSpecification.objects.filter(material_master=material_master)
#     serializer=se.ElementSpecificationSerializer if section_type==None else se.ElementSpecificationWipSerializer

#     data = {
#         "chemistry_values": [],
#         "other_chemistry_values": [],
#         "physical_elements": [],
#         "auxillary_values": [],
#         'type_name':material_master.material_type.type_name,
#         'changeHistoryData':se.ElementSpecificationChangeLogSerializer(se.ElementSpecificationChangeLog.objects.filter(material_master=material_master).order_by('-created_at'),many=True).data
#     }
#     for item in spec:
#         element = MaterialElementMaster.objects.filter(element=item.element,material_type=material_master.material_type).first()
#         group = element.element_group.element_group.lower()+ "_values" if element else None
#         if group in data:
#             data[group].append(serializer(item).data)
#     data = {key: value for key, value in data.items() if value}
#     return data



from .models import ElementSpecification,MaterialElementMaster
def get_material_specification(section_type=None,material_master=None):
    spec =material_master.elementspecification_set.all()
    serializer= se.ElementSpecificationWipSerializer if section_type=="WIP" else se.ElementSpecificationSerializer
    data={}
    data["chemistry_values"]=[]
    data["other_chemistry_values"]=[]
    data["physical_elements"]=[]
    data["auxillary"]=[]
    data['sizes']={}



    for item in spec:
        element = MaterialElementMaster.objects.filter(element=item.element,material_type=material_master.material_type).first()
        group = element.element_group.element_group if element else None
        if group == 'Chemistry':
            data['chemistry_values'].append(serializer(item).data)
        elif group == 'Other Chemistry':
            data['other_chemistry_values'].append(serializer(item).data)
        elif group == 'Physical':
            data['physical_elements'].append(serializer(item).data)
        elif group == 'Auxiliary':#Auxiliary
            data['auxillary'].append(serializer(item).data)
    try:
        size_dt=se.Size.objects.filter(material_master=material_master).first()
        data['sizes']=se.SizeSerializer(size_dt).data
    except:pass
    data[ "type_name"]=material_master.material_type.type_name
    data['changeHistoryData']=se.ElementSpecificationChangeLogSerializer(se.ElementSpecificationChangeLog.objects.filter(material_master=material_master).order_by('-created_at'),many=True).data
    data = {key: value for key, value in data.items() if value}
    return data


@api_view(['GET'])
def get_size_dropdown(request):
    sizes_dd=MaterialElementMaster.objects.filter(element_group__element_group="Size")
    data=[{"id":item.element.element_code,"value":item.element.name, "unit":item.element.unit} for item in sizes_dd]
    return Response(data=data)
    


@api_view(['GET'])
def get_element_specification_excel_data(request,pk=None):
    material_master=master_models.MaterialMaster.objects.get(mes_mat_code=pk)
    size_serializer_cls=se.SizeSpecificationChangeHistorySerializer
    serializer_class=se.ElementSpecificationWipChangeHistorySerializer if material_master.material_type.type_name =='WIP' else se.ElementSpecificationChangeHistorySerializer
    specification_data=master_models.ElementSpecificationChangeHistory.objects.filter(material_master=material_master)
    size_specification=master_models.SizeSpecificationChangeHistory.objects.filter(material_master=material_master)
    size_serializer=size_serializer_cls(size_specification,many=True)
    serializer=serializer_class(specification_data,many=True)
    all_data=list(serializer.data)
    for item in size_serializer.data:
        all_data.append(item)

    return Response({"excel_data":all_data})

class CheckElementSpecificationView(APIView):
    material_masters=se.MaterialMaster.objects.all()
    def create_element_specifications(self, item, user,section_type=None):
        element_masters=MaterialElementMaster.objects.filter(material_type__type_name=item.material_type.type_name)
        for element_master in element_masters:
            if  ElementSpecification.objects.filter(element=element_master.element, material_master=item).count()<=0:
                specify=ElementSpecification.objects.create(
                    material_master=item,
                    element=element_master.element,
                    low=0,
                    aim=0,
                    high=0,
                    created_by=user,
                    modified_by=user
                )
                if section_type=='WIP':
                        master_models.WipMaterialSpecification.objects.create(element_specification=specify)
    def post(self,request):
        user=request.user
        for item in self.material_masters:
            if hasattr(item,'additive_add_info'):
                # if item.additive_add_info.all():
                    self.create_element_specifications(item,user)
            if hasattr(item,'by_product_add_info'):
                # if item.by_product_add_info.all():
                    self.create_element_specifications(item,user)
            if hasattr(item,'additionalinformation_set'):
                # if item.additionalinformation_set.all():
                   self.create_element_specifications(item,user)
            if hasattr(item,'wip_additional_info'):
                # if item.wip_additional_info.all():
                    self.create_element_specifications(item,user,section_type="WIP")
        return Response({"message":"New Elements are added for existing Material Specification Successfully"},status=status.HTTP_200_OK)
    


    