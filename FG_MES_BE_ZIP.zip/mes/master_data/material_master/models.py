from django.db import models
from mes.utils.models import BaseModel
from django.core.validators import MinValueValidator, MaxValueValidator
# Create your models here.
class MaterialCategoryMaster(BaseModel):
    category_name = models.CharField(max_length=100)
    category_code = models.CharField(max_length=8, unique=True)

    def __str__(self) -> str:
        return self.category_name
    
class MaterialTypeMaster(BaseModel):
    category = models.ForeignKey(MaterialCategoryMaster, on_delete=models.PROTECT, to_field='category_code') 
    type_name = models.CharField(max_length=100)
    type_code = models.CharField(max_length=8, unique=True)

    def __str__(self) -> str:
        return self.type_name
    

class MaterialMaster(BaseModel):
    mes_mat_code = models.CharField(max_length=8, unique=True)
    material_name = models.CharField(max_length=100)
    material_type = models.ForeignKey(MaterialTypeMaster, on_delete=models.PROTECT, to_field='type_code')
    erp_commercial_mat_code = models.CharField(max_length=100)
    erp_commercial_mat_name = models.CharField(max_length=100)
    erp_acc_mat_code = models.CharField(max_length=100)
    erp_acc_mat_name = models.CharField(max_length=100)
    ops_tech_mat_code = models.CharField(max_length=100)
    consumption_flag = models.BooleanField(default=False)
    material_description = models.CharField(max_length=100, null=True)
 
    class Meta:
        ordering=['-modified_at','-record_status']

    def __str__(self) -> str:
        return self.mes_mat_code
        

    def save_element_specification(self,section_type=None,user=None):
            elements=MaterialElementMaster.objects.filter(material_type__type_name=self.material_type.type_name)
            for item in elements:
                if  ElementSpecification.objects.filter(element=item.element, material_master=self).count()<=0:
                    specify=ElementSpecification.objects.create(
                        material_master=self,
                        element=item.element,
                        low=0,
                        aim=0,
                        high=0,
                        created_by=user,
                        modified_by=user                    
                        )
                    if section_type=='WIP':
                        WipMaterialSpecification.objects.create(element_specification=specify)

 
class ElementGroup(BaseModel):
    element_group = models.CharField(max_length=100)
    element_group_code = models.CharField(max_length=8, unique=True)

    def __str__(self):
        return self.element_group
    
class Element(BaseModel):
    name = models.CharField(max_length=50)
    unit = models.CharField(max_length=8)
    element_code=models.CharField(max_length=8,unique=True)

    class Meta:
        unique_together=('name','unit')

    def __str__(self):
        return self.name
    
class MaterialElementMaster(BaseModel):
    element_group = models.ForeignKey(ElementGroup, on_delete=models.PROTECT, to_field='element_group_code')
    material_type = models.ForeignKey(MaterialTypeMaster, on_delete=models.PROTECT, to_field='type_code')
    element = models.ForeignKey(Element, on_delete=models.PROTECT, to_field='element_code')

    def __str__(self):
        return f"MaterialElementMaster: {self.id}"
    
    class Meta:
        unique_together = ('element_group', 'material_type', 'element')
    
class ElementSpecification(BaseModel):
    material_master = models.ForeignKey(MaterialMaster, on_delete=models.PROTECT, to_field='mes_mat_code')
    element = models.ForeignKey(Element, on_delete=models.PROTECT, to_field='element_code')
    low = models.DecimalField(max_digits=5,decimal_places=2)
    aim = models.DecimalField(max_digits=5,decimal_places=2)
    high = models.DecimalField(max_digits=5,decimal_places=2)

    def __str__(self):
        return f"ElementSpecification: {self.id}"
    class Meta:
        ordering=['element']

class ElementSpecificationChangeHistory(BaseModel):

    material_master = models.ForeignKey(MaterialMaster, on_delete=models.PROTECT, to_field='mes_mat_code')
    element = models.ForeignKey(Element, on_delete=models.PROTECT,related_name="element_spec_change_hist", to_field='element_code')
    low = models.DecimalField(max_digits=5,decimal_places=2)
    aim = models.DecimalField(max_digits=5,decimal_places=2)
    high = models.DecimalField(max_digits=5,decimal_places=2,)

    def __str__(self):
        return f"ElementSpecification: {self.id}"
    class Meta:
        db_table_comment="It holds the history of material master element specification modifications"


class WipMaterialSpecificationChangeHistory(BaseModel):
    element_specification=models.OneToOneField(ElementSpecificationChangeHistory,related_name="specification_change_hist",on_delete=models.PROTECT)
    warning_tolerance=models.DecimalField(max_digits=5,decimal_places=2,default=0.0)
    control=models.BooleanField(default=False)

    def __str__(self) -> str:
        return f'{self.warning_tolerance}'
    class Meta:
        db_table_comment="It holds the history of material master element Wip specification modifications"



class WipMaterialSpecification(BaseModel):
    element_specification=models.OneToOneField(ElementSpecification,related_name="specification",on_delete=models.PROTECT)
    warning_tolerance=models.DecimalField(max_digits=5,decimal_places=2,default=0.0)
    control=models.BooleanField(default=False)

    def __str__(self) -> str:
        return f'{self.warning_tolerance}'
    

class ElementSpecificationChangeLog(BaseModel):
    material_master=models.ForeignKey(MaterialMaster,on_delete=models.PROTECT,null=True, to_field='mes_mat_code')
    change_log=models.JSONField()

    def __str__(self) -> str:
        return self.material_master.material_name
    

class Size(BaseModel):
    material_master=models.ForeignKey(MaterialMaster,on_delete=models.PROTECT,null=True,related_name='material_size', to_field='mes_mat_code')
    low_size = models.ForeignKey(Element,related_name="low_size", on_delete=models.PROTECT,null=True,blank=True, to_field='element_code')
    below_tolerance = models.DecimalField(validators=[MinValueValidator(0), MaxValueValidator(100)], decimal_places=2, max_digits=5)
    high_size = models.ForeignKey(Element,related_name="high_size", on_delete=models.PROTECT,null=True,blank=True, to_field='element_code')
    above_tolerance = models.DecimalField(validators=[MinValueValidator(0), MaxValueValidator(100)], decimal_places=2, max_digits=5)

    def __str__(self) -> str:
        return f"{self.below_tolerance}"
    

class SizeSpecificationChangeHistory(BaseModel):
    material_master=models.ForeignKey(MaterialMaster,on_delete=models.PROTECT,null=True,related_name='material_size_change_history', to_field='mes_mat_code')
    low_size = models.ForeignKey(Element,related_name="low_size_change_history", on_delete=models.PROTECT,null=True,blank=True, to_field='element_code')
    below_tolerance = models.DecimalField(validators=[MinValueValidator(0), MaxValueValidator(100)], decimal_places=2, max_digits=5)
    high_size = models.ForeignKey(Element,related_name="high_size_change_history", on_delete=models.PROTECT,null=True,blank=True, to_field='element_code')
    above_tolerance = models.DecimalField(validators=[MinValueValidator(0), MaxValueValidator(100)], decimal_places=2, max_digits=5)

    def __str__(self) -> str:
        return f"{self.above_tolerance}"
    class Meta:
        db_table_comment="It holds the history of material master element size specification modifications"

