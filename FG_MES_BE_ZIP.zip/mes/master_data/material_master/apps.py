from django.apps import AppConfig


class MaterialMasterConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mes.master_data.material_master'
