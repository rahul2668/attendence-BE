from rest_framework import serializers
from mes.utils.models import Variant
from mes.master_data.material_master.models import MaterialTypeMaster, MaterialCategoryMaster, MaterialMaster,ElementGroup,ElementSpecification,ElementSpecificationChangeLog,Size
from mes.master_data.furnace_material import models as fur_models
from mes.master_data.wip import models as wip_models
from mes.master_data.by_products import models as by_models
from mes.master_data.additive import models as add_models
from . import models as master_models

class MaterialCategoryMasterSerializer(serializers.ModelSerializer):
    category_id = serializers.IntegerField(source='id')
    class Meta:
        model = MaterialCategoryMaster
        exclude=['created_by','modified_by','modified_at','created_at']
        
class MaterialTypeMasterSerializer(serializers.ModelSerializer):
    class Meta:
        model = MaterialTypeMaster
        exclude=['created_by','modified_by','modified_at','created_at','record_status']


class MaterialMasterNumberSerializer(serializers.ModelSerializer):
    material_id = serializers.CharField(source='mes_mat_code')
    class Meta:
        model = MaterialMaster
        fields = ["material_id", "mes_mat_code", "material_name"]

from rest_framework import serializers
from .models import MaterialMaster,MaterialCategoryMaster, MaterialTypeMaster,ElementSpecification

class MaterialMasterSerializer(serializers.ModelSerializer):
    is_created=serializers.SerializerMethodField()
    class Meta:
        model = MaterialMaster
        fields="__all__"
    def get_is_created(self,obj):
        category = self.context.get('category')
        if category == 'Raw Materials':
            if fur_models.AdditionalInformation.objects.filter(material_master=obj).exists() and  ElementSpecification.objects.filter(material_master=obj).exists():
                return True
            else :return False
        elif category=='Additives':
            if add_models.AdditionalInformation.objects.filter(material_master=obj).exists() and  ElementSpecification.objects.filter(material_master=obj).exists():
                return True
            else :return False
        elif category=='By Products':
            if by_models.AdditionalInformation.objects.filter(material_master=obj).exists() and  ElementSpecification.objects.filter(material_master=obj).exists():
                return True
            else :return False
        elif category=='WIP':
            if wip_models.AdditionalInformation.objects.filter(material_master=obj).exists() and ElementSpecification.objects.filter(material_master=obj).exists():
                return True
            else: return False
        else:
            return False
    def to_representation(self, instance):
        representation= super().to_representation(instance)
        representation['id']=representation.get('mes_mat_code',representation.get('id'))
        return representation

# =================================================================
        

class ElementGroupSerializer(serializers.ModelSerializer):
    class Meta:
        model = ElementGroup
        fields = ['id', 'element_group', 'element_group_code']


class ElementSpecificationSerializer(serializers.ModelSerializer):
    element=serializers.SerializerMethodField()
    class Meta:
        model=ElementSpecification
        exclude=['created_at','modified_at','record_status','created_by','modified_by','material_master']

    def get_element(self,obj):
        unit_part = f"({obj.element.unit})" if obj.element.unit else "" 
        return f"{obj.element.name} {unit_part}"
    

class ElementSpecificationWipSerializer(serializers.ModelSerializer):
    element=serializers.SerializerMethodField()
    warning_tolerance=serializers.SerializerMethodField()
    control=serializers.SerializerMethodField()
    class Meta:
        model=ElementSpecification
        exclude=['created_at','modified_at','record_status','created_by','modified_by','material_master']

    def get_element(self,obj):
        unit_part = f"({obj.element.unit})" if obj.element.unit else "" 
        return f"{obj.element.name} {unit_part}"
    def get_warning_tolerance(self,obj):
        tolerance=obj.specification.warning_tolerance
        return  0.00 if tolerance==0 else tolerance
    
    def get_control(self,obj):
        return obj.specification.control

class GroupedElementsSerializer(serializers.Serializer):
    group_id = serializers.CharField()
    group_name = serializers.CharField()
    elements = serializers.ListField()

    def get_element(self,obj):
        unit_part = f"({obj.element.unit})" if obj.element.unit else "" 
        return f"{obj.element.name}{unit_part}"
    def get_warning_tolerance(self,obj):
        return obj.specification.warning_tolerance
    def get_control(self,obj):
        return obj.specification.control

class ElementSpecificationChangeLogSerializer(serializers.ModelSerializer):
    username=serializers.SerializerMethodField()
    class Meta:
        model = ElementSpecificationChangeLog
        exclude=['modified_at','record_status','modified_by',]

    def get_username(self,obj):
        if hasattr(obj.created_by,'username'):
            return getattr(obj.created_by,'username',None)
        else: return None


class SizeSerializer(serializers.ModelSerializer):
    class Meta:
        model=Size
        exclude=['created_by','modified_by','created_at','modified_at','record_status','material_master']


class SizeCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model=Size
        fields="__all__"


class ElementSpecificationChangeHistorySerializer(serializers.ModelSerializer):
    element=serializers.SerializerMethodField()
    element_group=serializers.SerializerMethodField()

    class Meta:
        model=master_models.ElementSpecificationChangeHistory
        fields='__all__'

    def get_element(self,obj):
        unit_part = f"({obj.element.unit})" if obj.element.unit else "" 
        return f"{obj.element.name} {unit_part}"
    def get_element_group(self,obj):
        element=master_models.MaterialElementMaster.objects.filter(element=obj.element).first()
        return element.element_group.element_group


class ElementSpecificationWipChangeHistorySerializer(serializers.ModelSerializer):
    element=serializers.SerializerMethodField()
    warning_tolerance=serializers.SerializerMethodField()
    control=serializers.SerializerMethodField()
    element_group=serializers.SerializerMethodField()
    class Meta:
        model=master_models.ElementSpecificationChangeHistory
        fields='__all__'
  
    def get_element(self,obj):
        unit_part = f"({obj.element.unit})" if obj.element.unit else "" 
        return f"{obj.element.name} {unit_part}"
    def get_element_group(self,obj):
        element=master_models.MaterialElementMaster.objects.filter(element=obj.element).first()
        return element.element_group.element_group

    def get_warning_tolerance(self,obj):
        tolerance=obj.specification_change_hist.warning_tolerance
        return  0.00 if tolerance==0 else tolerance
    
    def get_control(self,obj):
        return getattr(obj.specification_change_hist,'control',None)


class SizeSpecificationChangeHistorySerializer(serializers.ModelSerializer):
    element_group=serializers.SerializerMethodField()
    low=serializers.SerializerMethodField()
    aim=serializers.SerializerMethodField()
    high=serializers.SerializerMethodField()

    class Meta:
        model=master_models.SizeSpecificationChangeHistory
        fields="__all__"
    def get_element_group(self,obj):
        return "Size"
    
   
    def get_element(self,obj):
        return ''
    def get_low(self,obj):
            return getattr(obj.low_size,'name',None)
    def get_aim(self,obj):
            return ''
    def get_high(self,obj):
            return getattr(obj.high_size,'name',None)



class AddInfoSerializer(serializers.Serializer):
    unit_weight = serializers.DecimalField(max_digits=6, decimal_places=2,required=False)
    actual_cost = serializers.DecimalField(max_digits=6, decimal_places=2,required=False)
    addition_group = serializers.DecimalField(max_digits=6, decimal_places=2,required=False)
    density = serializers.DecimalField(max_digits=6, decimal_places=2,required=False)
    standard_cost = serializers.DecimalField(max_digits=6, decimal_places=2,required=False)
    co_contributor = serializers.DecimalField(max_digits=6, decimal_places=2,required=False)
    kwh_melting = serializers.DecimalField(max_digits=6, decimal_places=2,required=False)
    spec_references=serializers.CharField(required=False)
    is_available=serializers.BooleanField(required=False)
    effective_date = serializers.DateField()

    def validate(self, data):
        cleaned_data = super().validate(data)
        cleaned_data = {key: value for key, value in cleaned_data.items() if value is not None}
        return cleaned_data
    

