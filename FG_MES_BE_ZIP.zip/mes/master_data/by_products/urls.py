from django.urls import path
from . import views

app_name="by_product"

urlpatterns = [
    path('by-product-additional-information/<str:pk>/', views.ByProductAdditionalInformationView.as_view(), name='by_product_additional_information'),
    path('by-product-material-specification-step2/<str:pk>/',views.ByProductMaterialSpecificationStepView.as_view(),name='by_product_material_specification'),

]