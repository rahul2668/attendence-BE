from django.apps import AppConfig


class ByProductsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mes.master_data.by_products'
