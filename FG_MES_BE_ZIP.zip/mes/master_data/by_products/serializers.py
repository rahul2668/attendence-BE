from rest_framework import serializers
from . import  models as by_pro_model
from mes.master_data.material_master import models as material_model

from mes.utils.services import get_full_name,separate_date_time,get_plant_currency
from mes.utils.models import Master, GlobalUnit
from mes.plant.models import PlantConfig
from mes.constants import EXCEL_UNIT_KEYS,CURRENCY_COLUMNS


class AdditionalInformationSerializer(serializers.ModelSerializer):
    created_date = serializers.SerializerMethodField(read_only=True)
    modified_date = serializers.SerializerMethodField(read_only=True)
    created_name =  serializers.SerializerMethodField(read_only=True)
    modified_name =  serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = by_pro_model.AdditionalInformation
        fields = '__all__'
    def get_created_date(self,obj):
        return separate_date_time(obj,'created_at')
    def get_modified_date(self,obj):
        return separate_date_time(obj,'modified_at')
    def get_created_name(self,obj):
        return get_full_name(obj,'created_by')
    def get_modified_name(self,obj):
        return get_full_name(obj,'modified_by')

    def to_representation(self, instance):
        request=self.context.get('request',None)
        representation= super().to_representation(instance)
        if request:
            plant=PlantConfig.objects.first()
            if plant:
                master=Master.objects.filter(master_code=plant.unit_id).first()
                master_value=getattr(master,"value",'')
            for key,value in representation.items():
                lookup_key=EXCEL_UNIT_KEYS.get(key,'')
                if lookup_key:
                    if key in CURRENCY_COLUMNS:
                        representation[key] = f"{value} {get_plant_currency()}"
                    elif key not in CURRENCY_COLUMNS:
                        unit_val=GlobalUnit.objects.filter(name=lookup_key).first()
                        if master_value=='Metric System':
                            unit = getattr(unit_val, 'metric', '')
                        elif master_value=='Imperial System':
                            unit = getattr(unit_val, 'imperial', '')
                        else:
                            unit = ''
                        representation[key] = f"{value}{unit}" if value else value
                else:
                    representation[key]=value
            representation['mes_mat_code'] = instance.material_master.mes_mat_code
            representation['material_name'] = instance.material_master.material_name
            representation['material_type'] = instance.material_master.material_type.type_name
            representation['status'] = instance.material_master.record_status
        return representation
        
