from django.db import models
from mes.master_data.material_master.models import MaterialMaster,MaterialTypeMaster
from mes.utils.models import BaseModel

# Create your models here.

class AdditionalInformation(BaseModel):
    material_master=models.ForeignKey(MaterialMaster,related_name="by_product_add_info",on_delete=models.PROTECT, to_field='mes_mat_code')
    unit_weight=models.DecimalField(max_digits=6,decimal_places=2)
    density=models.DecimalField(max_digits=6,decimal_places=2)
    effective_date=models.DateField()

    def __str__(self) -> str:
        return f'{self.unit_weight}'
    
    class Meta:
        unique_together=('material_master','effective_date')

