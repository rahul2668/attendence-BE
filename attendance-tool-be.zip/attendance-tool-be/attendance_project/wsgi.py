# import os
# from django.core.wsgi import get_wsgi_application

# os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'attendance_project.settings')

# application = get_wsgi_application()

import os
import logging
from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'attendance_project.settings')

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

try:
    application = get_wsgi_application()
except Exception as e:
    logger.exception("WSGI application failed to initialize")
    raise
