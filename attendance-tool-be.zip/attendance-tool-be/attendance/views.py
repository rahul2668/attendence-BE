from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.utils import timezone
from .models import Employee, Course, Meeting, Attendance, Location
from .serializers import MeetingSerializer, AttendanceSerializer, CourseSerializer, EmployeeSerializer, MeetingListSerializer,AttendanceListSerializer, UpdateMeetingSerializer, MeetingDetailsSerializer, CreateMeetingSerializer, TestAttendanceListSerializer, TestEmployeeSerializer, TestMeetingDetailsSerializer, LocationSerializer
from rest_framework.parsers import JSONParser
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from datetime import date
from rest_framework.decorators import api_view
from rest_framework.parsers import JSONParser
from django.http import JsonResponse
from .models import Meeting, Course  # Adjust the import based on your project structure
from datetime import datetime
from django.db.models import Q

import json, random
from django.core.cache import cache
from django.http import HttpResponse

def hello_world(request):
    return HttpResponse("Hello, World!")

# @api_view(['POST'])
# @csrf_exempt
# def create_meeting(request):
#     data = JSONParser().parse(request)
#     serializer = CreateMeetingSerializer(data=data)
    
#     if serializer.is_valid():
#         meeting = serializer.save()
#         required_employees = data.get('required_employees', [])
#         try:
#             employees = Employee.objects.filter(id__in=required_employees)
#             meeting.required_employees.set(employees)
#         except Employee.DoesNotExist:
#             return JsonResponse({'error': 'One or more employees not found'}, status=400)
        
#         return JsonResponse(serializer.data, status=201)
    
#     return JsonResponse(serializer.errors, status=400)


@api_view(['POST'])
@csrf_exempt
def create_meeting(request):
    data = JSONParser().parse(request)
    meeting_name = data.get('meeting_name')
    course_value = data.get('course')
    start_date = data.get('start_date')
    end_date = data.get('end_date')
    start_time = data.get('start_time')
    end_time = data.get('end_time')
    required_employees = data.get('required_employees')
    trainer_name = data.get('trainer_name')
    meeting_type = data.get('type')
    location_value = data.get('location') 
    online_url = data.get('online_url')

    if not meeting_name:
        return JsonResponse({"error": "Meeting name is required."}, status=400)

    if not course_value:
        return JsonResponse({"error": "Course must be provided."}, status=400)

    if meeting_type == "Offline" and location_value is None:
        return JsonResponse({"error": "Location must be provided for offline meetings."}, status=400)

    if meeting_type == "Online" and not online_url:
        return JsonResponse({"error": "Online URL must be provided for online meetings."}, status=400)

    try:
        start_date_dt = datetime.strptime(start_date, '%Y-%m-%d').date()
        end_date_dt = datetime.strptime(end_date, '%Y-%m-%d').date()
    except ValueError:
        return JsonResponse({"error": "Invalid date format. Use YYYY-MM-DD format."}, status=400)

    # Validate that start date is not greater than end date
    if start_date_dt > end_date_dt:
        return JsonResponse({"error": "Start date must not be greater than end date."}, status=400)


    try:
        start_time_dt = datetime.strptime(start_time, '%H:%M').time()
        end_time_dt = datetime.strptime(end_time, '%H:%M').time()
    except ValueError:
        return JsonResponse({"error": "Invalid time format. Use HH:MM format."}, status=400)
    
    if start_date_dt > end_date_dt:
        return JsonResponse({"error": "Start date must not be greater than end date."}, status=400)

    if start_time_dt >= end_time_dt:
        return JsonResponse({"error": "Start time must be earlier than end time."}, status=400)


    if location_value and meeting_type == "Offline":
        if isinstance(location_value, int):
            overlapping_location = Meeting.objects.filter(
                start_date__lt=start_date_dt,
                end_date__gt = end_date_dt,
                location__id=location_value,
                
                start_time__lt=end_time_dt, 
                end_time__gt=start_time_dt   
            ).exists()
        else:
            overlapping_location = Meeting.objects.filter(
                start_date__lt=start_date_dt,
                end_date__gt = end_date_dt,
                location__location_name=location_value,
                start_time__lt=end_time_dt,  
                end_time__gt=start_time_dt   
            ).exists()

        if overlapping_location:
            return JsonResponse({"error": f"Location is already blocked for another meeting during the requested time range."}, status=400)

    if required_employees:
        conflicting_meetings = Meeting.objects.filter(
            start_date__lt=end_date_dt,  
            end_date__gt=start_date_dt,  
            start_time__lt=end_time_dt,  
            end_time__gt=start_time_dt   
        ).distinct()

        conflicting_employee_ids = []
        for meeting in conflicting_meetings:
            existing_ids = set(meeting.required_employees.values_list('id', flat=True))
            common_ids = existing_ids.intersection(set(required_employees))
            conflicting_employee_ids.extend(common_ids)

        if conflicting_employee_ids:
            conflicting_employees = Employee.objects.filter(id__in=conflicting_employee_ids).distinct()
            employee_names = list(conflicting_employees.values_list('name', flat=True))
            
            return JsonResponse({
                "error": "The following employees are already scheduled for another meeting at the same time:",
                "conflicting_employees": employee_names
            }, status=400)

    if isinstance(course_value, int):
        try:
            course = Course.objects.get(id=course_value)
        except Course.DoesNotExist:
            return JsonResponse({"error": "Course not found."}, status=400)
    else:  
        course, created = Course.objects.get_or_create(course_name=course_value)
    
    location = None
    if location_value:
        if isinstance(location_value, int):
            try:
                location = Location.objects.get(id=location_value)
            except Location.DoesNotExist:
                return JsonResponse({"error": "Location not found."}, status=400)
        else:
            location, created = Location.objects.get_or_create(name=location_value)

    meeting = Meeting.objects.create(
        meeting_name=meeting_name,
        course=course,  
        start_date=start_date,
        end_date=end_date,
        start_time=start_time,
        end_time=end_time,
        type=meeting_type,
        location=location,
        online_url=online_url
    )

    if required_employees:
        meeting.required_employees.set(required_employees)

    if trainer_name:
        meeting.trainer_name.set(trainer_name)

    return JsonResponse({"id": meeting.id}, status=201)
    # return JsonResponse({"id": "created succesfull"}, status=201)



@api_view(['GET'])
@csrf_exempt
def get_locations(request):
    location = Location.objects.all()
    serializer = LocationSerializer(location, many=True)
    return JsonResponse(serializer.data, safe=False)





# # @api_view(['POST'])
# @csrf_exempt
# def log_attendance(request):
#     data = JSONParser().parse(request)
#     meeting_id = data.get('meeting')
#     employee_ids = data.get('employees') 
#     try:
#         meeting = Meeting.objects.get(id=meeting_id)
#     except Meeting.DoesNotExist:
#         return JsonResponse({'error': 'Invalid meeting ID'}, status=400)
#     employee_names = []
#     existing_records = []
#     for emp_id in employee_ids:
#         try:
#             employee = Employee.objects.get(id=emp_id)
#             employee_names.append(employee.name)
#             if Attendance.objects.filter(meeting=meeting, employee=employee).exists():
#                 existing_records.append(employee.name)
#         except Employee.DoesNotExist:
#             return JsonResponse({'error': f'Invalid employee ID: {emp_id}'}, status=400)
    
#     if existing_records:
#         existing_records_str = ', '.join(existing_records)
#         error_message = (f'Attendance record already exists for meeting '
#                          f'<b>{meeting.meeting_name}</b> for employee(s): '
#                          f'<b>{existing_records_str}</b>')
#         return JsonResponse({'error': error_message}, status=400)
#     for emp_id in employee_ids:
#         employee = Employee.objects.get(id=emp_id)
#         try:
#             Attendance.objects.create(meeting=meeting, employee=employee)
#         except Exception as e:
#             return JsonResponse({'error': str(e)}, status=400)
    
#     return JsonResponse({'message': 'Attendance records created successfully'}, status=201)


@api_view(['POST'])
@csrf_exempt
def log_attendance(request):
    data = JSONParser().parse(request)
    meeting_id = data.get('meeting')
    employee_ids = data.get('employees')
    attendance_date = date.today()  # Use the current date from the server

    try:
        meeting = Meeting.objects.get(id=meeting_id)
    except Meeting.DoesNotExist:
        return JsonResponse({'error': 'Invalid meeting ID'}, status=400)

    employee_names = []
    existing_records = []

    for emp_id in employee_ids:
        try:
            employee = Employee.objects.get(id=emp_id)
            employee_names.append(employee.name)
            
            # Check for existing attendance for the same meeting, employee, and current date
            if Attendance.objects.filter(meeting=meeting, employee=employee, date=attendance_date).exists():
                existing_records.append(employee.name)
        except Employee.DoesNotExist:
            return JsonResponse({'error': f'Invalid employee ID: {emp_id}'}, status=400)

    if existing_records:
        existing_records_str = ', '.join(existing_records)
        error_message = (f'Attendance record already exists for meeting '
                         f'<b>{meeting.meeting_name}</b> for employee(s): '
                         f'<b>{existing_records_str}</b> on <b>{attendance_date}</b>')
        return JsonResponse({'error': error_message}, status=400)

    # Create attendance records for the employees on the current date
    for emp_id in employee_ids:
        employee = Employee.objects.get(id=emp_id)
        try:
            Attendance.objects.create(meeting=meeting, employee=employee, date=attendance_date)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=400)

    return JsonResponse({'message': 'Attendance records created successfully'}, status=201)

@api_view(['GET'])
def get_meetings(request):
    meetings = Meeting.objects.filter(status='in_progress')
    serializer = MeetingSerializer(meetings, many=True)
    return JsonResponse(serializer.data, safe=False)

@api_view(['GET'])
def get_courses(request):
    courses = Course.objects.all()
    serializer = CourseSerializer(courses, many=True)
    return JsonResponse(serializer.data, safe=False)

@api_view(['GET'])
def get_employees(request):
    meetings = Employee.objects.all()
    serializer = EmployeeSerializer(meetings, many=True)
    return JsonResponse(serializer.data, safe=False)

@api_view(['GET'])
def meetings_list(request):
    status = request.query_params.get('status')

    if status == 'in_progress':
        meetings = Meeting.objects.filter(status='in_progress')
    elif status == 'completed':
        # meetings = Meeting.objects.filter(status='completed')
        meetings = Meeting.objects.filter(
    Q(status='completed') | Q(is_active=False)
)
    else:
        return Response({"error": "Invalid status"}, status=400)

    serializer = MeetingListSerializer(meetings, many=True)
    return Response(serializer.data)

@api_view(['GET'])
def meetings_list_inprogress(request):
    meetings = Meeting.objects.filter(status='in_progress')
    serializer = MeetingListSerializer(meetings, many=True)
    return Response(serializer.data)

@api_view(['GET'])
def update_inprogress_status_to_completed(request, pk):
    try:
        meeting = Meeting.objects.get(pk=pk)
    except Meeting.DoesNotExist:
        return Response({'error': 'Meeting not found'}, status=status.HTTP_404_NOT_FOUND)
    
    # Hardcoded status update logic
    meeting.status = 'completed'  
    meeting.save()

    # Serialize and return the updated meeting data
    serializer = MeetingSerializer(meeting)
    # return Response(serializer.data, status=status.HTTP_200_OK)
    return Response({
        'message': 'Status updated to completed',
        'data': serializer.data
    }, status=status.HTTP_200_OK)

@api_view(['GET'])
def update_completed_status_to_inprogress(request, pk):
    try:
        meeting = Meeting.objects.get(pk=pk)
    except Meeting.DoesNotExist:
        return Response({'error': 'Meeting not found'}, status=status.HTTP_404_NOT_FOUND)
    
    # Hardcoded status update logic
    meeting.status = 'in_progress'  
    meeting.save()

    # Serialize and return the updated meeting data
    serializer = MeetingSerializer(meeting)
    # return Response(serializer.data, status=status.HTTP_200_OK)
    return Response({
        'message': 'Status updated to in_progress',
        'data': serializer.data
    }, status=status.HTTP_200_OK)

@api_view(['GET'])
def meetings_inprogress_list(request, pk):
    try:
        meeting = Meeting.objects.get(pk=pk)
    except Meeting.DoesNotExist:
        return Response({'error': 'Meeting not found'}, status=status.HTTP_404_NOT_FOUND)
    
    serializer = MeetingSerializer(meeting)
    return Response(serializer.data, status=status.HTTP_200_OK)


# @api_view(['GET'])
# def attendance_list(request):
#     meeting_id = request.query_params.get('meeting')
    
#     if not meeting_id:
#         return Response({"error": "Meeting ID is required"}, status=400)

#     try:
#         attendance = Attendance.objects.filter(meeting_id=meeting_id)
#         serializer = AttendanceListSerializer(attendance, many=True)
#         return Response(serializer.data)
#     except Attendance.DoesNotExist:
#         return Response({"error": "Attendance data not found"}, status=404)


# @api_view(['GET'])
# def attendance_list(request):
#     meeting_id = request.query_params.get('meeting')
    
#     if not meeting_id:
#         return Response({"error": "Meeting ID is required"}, status=400)

#     try:
#         # Fetch the meeting details
#         meeting = Meeting.objects.get(id=meeting_id)
#         meeting_serializer = MeetingDetailsSerializer(meeting)
        
#         # Fetch the attendance data
#         attendance = Attendance.objects.filter(meeting_id=meeting_id)
#         attendance_serializer = AttendanceListSerializer(attendance, many=True)
        
#         # Combine meeting details and attendance data
#         response_data = {
#             "meeting_details": meeting_serializer.data,
#             "attendance": attendance_serializer.data
#         }
        
#         return Response(response_data)
#     except Meeting.DoesNotExist:
#         return Response({"error": "Meeting not found"}, status=404)
#     except Attendance.DoesNotExist:
#         return Response({"error": "Attendance data not found"}, status=404)
    

# @api_view(['GET'])
# def attendance_list(request):
#     meeting_id = request.query_params.get('meeting')
    
#     if not meeting_id:
#         return Response({"error": "Meeting ID is required"}, status=400)

#     try:
#         # Fetch the meeting details
#         meeting = Meeting.objects.get(id=meeting_id)
#         meeting_serializer = MeetingDetailsSerializer(meeting)
        
#         # Fetch the required employees for the meeting
#         required_employees = meeting.required_employees.values_list('id', flat=True)
        
#         # Fetch the attendance data
#         attendance = Attendance.objects.filter(meeting_id=meeting_id, employee_id__in=required_employees)
#         attendance_serializer = AttendanceListSerializer(attendance, many=True)
        
#         # Combine meeting details and attendance data
#         response_data = {
#             "meeting_details": meeting_serializer.data,
#             "attendance": attendance_serializer.data
#         }
        
#         return Response(response_data)
#     except Meeting.DoesNotExist:
#         return Response({"error": "Meeting not found"}, status=404)
#     except Attendance.DoesNotExist:
#         return Response({"error": "Attendance data not found"}, status=404)




@api_view(['GET'])
def attendance_list(request):
    meeting_id = request.query_params.get('meeting')
    
    if not meeting_id:
        return Response({"error": "Meeting ID is required"}, status=400)

    try:
        # Fetch the meeting details
        meeting = Meeting.objects.get(id=meeting_id)
        meeting_serializer = TestMeetingDetailsSerializer(meeting)
        
        # Fetch the attendance data for the required employees
        required_employees = meeting.required_employees.values_list('id', flat=True)
        attendance = Attendance.objects.filter(meeting_id=meeting_id, employee_id__in=required_employees)
        attendance_serializer = TestAttendanceListSerializer(attendance, many=True)
        
        # Combine meeting details and attendance data
        response_data = {
            "meeting_details": meeting_serializer.data,
            "attendance": attendance_serializer.data
        }
        
        return Response(response_data)
    except Meeting.DoesNotExist:
        return Response({"error": "Meeting not found"}, status=404)



@api_view(['GET'])
def get_required_employees(request, meeting_id):
    try:
        meeting = Meeting.objects.get(id=meeting_id)
        employees = meeting.required_employees.all()
        employee_data = [
            {'id': employee.id, 'name': employee.name, 'employee_id': employee.employee_id}
            for employee in employees
        ]
        return Response(employee_data, status=200)
    except Meeting.DoesNotExist:
        return Response({'error': 'Meeting not found'}, status=404)
    

# @api_view(['POST'])
# def update_meeting(request, meeting_id):
#     """
#     Update a meeting with multiple fields
#     """
#     try:
#         print("111111", request.data)
#         meeting = Meeting.objects.get(id=meeting_id)
#     except Meeting.DoesNotExist:
#         return Response({'error': 'Meeting not found'}, status=status.HTTP_404_NOT_FOUND)

#     serializer = UpdateMeetingSerializer(meeting, data=request.data, partial=True)
    
#     if serializer.is_valid():
#         serializer.save()
#         return Response({'message': 'Meeting updated successfully'}, status=status.HTTP_200_OK)
    
#     return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# @api_view(['POST']) #original
# def update_meeting(request, meeting_id):
#     """
#     Update a meeting with multiple fields
#     """
#     try:
#         print("111111", request.data)
#         meeting = Meeting.objects.get(id=meeting_id)
#     except Meeting.DoesNotExist:
#         return Response({'error': 'Meeting not found'}, status=status.HTTP_404_NOT_FOUND)
#     data = request.data.copy()
#     meeting_type = data.get('type')
    
#     if meeting_type == 'Online':
#         data.pop('location', None)  # Remove location field if it's an online meeting
#     elif meeting_type == 'Offline':
#         data.pop('online_url', None)

#     serializer = UpdateMeetingSerializer(meeting, data=request.data, partial=True)
    
#     if serializer.is_valid():
#         serializer.save()
#         return Response({'message': 'Meeting updated successfully'}, status=status.HTTP_200_OK)
    
#     return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['POST'])
@csrf_exempt
def update_meeting(request, meeting_id):
    """
    Update a meeting with multiple fields
    """
    try:
        meeting = Meeting.objects.get(id=meeting_id)
    except Meeting.DoesNotExist:
        return JsonResponse({'error': 'Meeting not found'}, status=404)

    data = JSONParser().parse(request)
    meeting_name = data.get('meeting_name', meeting.meeting_name)  # Default to existing name if not provided
    course_value = data.get('course', meeting.course.id if meeting.course else None)
    start_date = data.get('start_date', meeting.start_date.strftime('%Y-%m-%d'))
    end_date = data.get('end_date', meeting.end_date.strftime('%Y-%m-%d'))
    start_time = data.get('start_time', meeting.start_time.strftime('%H:%M'))
    end_time = data.get('end_time', meeting.end_time.strftime('%H:%M'))
    required_employees = data.get('required_employees', list(meeting.required_employees.values_list('id', flat=True)))
    trainer_name = data.get('trainer_name', meeting.trainer_name)
    meeting_type = data.get('type', meeting.type)
    location_value = data.get('location', meeting.location.id if meeting.location else None)
    online_url = data.get('online_url', meeting.online_url)

    if not meeting_name:
        return JsonResponse({"error": "Meeting name is required."}, status=400)

    if not course_value:
        return JsonResponse({"error": "Course must be provided."}, status=400)

    if meeting_type == "Offline" and location_value is None:
        return JsonResponse({"error": "Location must be provided for offline meetings."}, status=400)

    if meeting_type == "Online" and not online_url:
        return JsonResponse({"error": "Online URL must be provided for online meetings."}, status=400)

    try:
        start_date_dt = datetime.strptime(start_date, '%Y-%m-%d').date()
        end_date_dt = datetime.strptime(end_date, '%Y-%m-%d').date()
    except ValueError:
        return JsonResponse({"error": "Invalid date format. Use YYYY-MM-DD format."}, status=400)

    if start_date_dt > end_date_dt:
        return JsonResponse({"error": "Start date must not be greater than end date."}, status=400)

    try:
        start_time_dt = datetime.strptime(start_time, '%H:%M').time()
        end_time_dt = datetime.strptime(end_time, '%H:%M').time()
    except ValueError:
        return JsonResponse({"error": "Invalid time format. Use HH:MM format."}, status=400)
    if start_time_dt >= end_time_dt:
        return JsonResponse({"error": "Start time must be earlier than end time."}, status=400)
    
    # Validate location overlap for offline meetings
    if meeting_type == "Offline" and location_value:
        if isinstance(location_value, int):
            overlapping_location = Meeting.objects.filter(
                start_date__lt=end_date_dt,
                end_date__gt=start_date_dt,
                location__id=location_value,
                start_time__lt=end_time_dt,
                end_time__gt=start_time_dt   
            ).exclude(id=meeting.id).exists()  # Exclude the current meeting
        else:
            overlapping_location = Meeting.objects.filter(
                start_date__lt=end_date_dt,
                end_date__gt=start_date_dt,
                location__location_name=location_value,
                start_time__lt=end_time_dt,
                end_time__gt=start_time_dt   
            ).exclude(id=meeting.id).exists()  # Exclude the current meeting

        if overlapping_location:
            return JsonResponse({"error": f"Location is already blocked for another meeting during the requested time range."}, status=400)

    # Validate employee conflicts
    if required_employees:
        conflicting_meetings = Meeting.objects.filter(
            start_date__lt=end_date_dt,  
            end_date__gt=start_date_dt,  
            start_time__lt=end_time_dt,  
            end_time__gt=start_time_dt   
        ).exclude(id=meeting.id).distinct()  # Exclude the current meeting

        conflicting_employee_ids = []
        for meeting in conflicting_meetings:
            existing_ids = set(meeting.required_employees.values_list('id', flat=True))
            common_ids = existing_ids.intersection(set(required_employees))
            conflicting_employee_ids.extend(common_ids)

        if conflicting_employee_ids:
            conflicting_employees = Employee.objects.filter(id__in=conflicting_employee_ids).distinct()
            employee_names = list(conflicting_employees.values_list('name', flat=True))
            
            return JsonResponse({
                "error": "The following employees are already scheduled for another meeting at the same time:",
                "conflicting_employees": employee_names
            }, status=400)

    # Retrieve or create the course
    if isinstance(course_value, int):
        try:
            course = Course.objects.get(id=course_value)
        except Course.DoesNotExist:
            return JsonResponse({"error": "Course not found."}, status=400)
    else:
        course, created = Course.objects.get_or_create(course_name=course_value)
    
    # Retrieve or create the location
    location = None
    if location_value:
        if isinstance(location_value, int):
            try:
                location = Location.objects.get(id=location_value)
            except Location.DoesNotExist:
                return JsonResponse({"error": "Location not found."}, status=400)
        else:
            location, created = Location.objects.get_or_create(name=location_value)

    # # Update the meeting instance
    # meeting.meeting_name = meeting_name
    # meeting.course = course
    # meeting.start_date = start_date
    # meeting.end_date = end_date
    # meeting.start_time = start_time
    # meeting.end_time = end_time
    # meeting.type = meeting_type
    # meeting.location = location
    # meeting.online_url = online_url
    
    # # Save the meeting instance
    # meeting.save()

    # if required_employees:
    #     meeting.required_employees.set(required_employees)

    # if trainer_name:
    #     meeting.trainer_name.set(trainer_name)

    # return JsonResponse({"id": meeting.id}, status=200)
    # Update the meeting instance using the update() method on the queryset
    Meeting.objects.filter(id=meeting.id).update(
    meeting_name=meeting_name,
    course=course,
    start_date=start_date_dt,  # Ensure to convert to appropriate format
    end_date=end_date_dt,      # Ensure to convert to appropriate format
    start_time=start_time_dt,  # Ensure to convert to time object
    end_time=end_time_dt,      # Ensure to convert to time object
    type=meeting_type,
    location=location,
    online_url=online_url
)

    # Update the required employees
    if required_employees:
        meeting.required_employees.set(required_employees)  # Assuming this is a ManyToManyField

    # Update the trainer name if it's a foreign key or ManyToManyField
    if trainer_name:
        # If trainer_name is a field that can have multiple values, use set()
        meeting.trainer_name.set(trainer_name)  # Use .set() for ManyToManyField or direct assignment for ForeignKey
        # If trainer_name is just a single ForeignKey, you might need:
        # meeting.trainer_name = trainer_name
        # meeting.save()  # Save only if you're modifying a single field.

    return JsonResponse({"id": meeting.id}, status=200)

@api_view(['POST'])
def delete_meeting(request, meeting_id):
    try:
        # Fetch the meeting by ID
        meeting = Meeting.objects.filter(id=meeting_id)
        if meeting:
            meeting.update(is_active=False, status='completed')
        return Response({'message': 'Meeting deleted successfully.'}, status=status.HTTP_204_NO_CONTENT)
    except Meeting.DoesNotExist:
        return Response({'error': 'Meeting not found.'}, status=status.HTTP_404_NOT_FOUND)



# @api_view(['POST'])
# def generate_otp(request):
#     data = json.loads(request.body)
#     meeting_id = data.get('meeting_id')

#     # Assuming you have a Meeting model to fetch the meeting name
#     meeting = Meeting.objects.get(id=meeting_id)
#     meeting_name = meeting.meeting_name  # Get the meeting name

#     # Generate a random 6-digit OTP
#     otp = random.randint(100000, 999999)

#     # Store the OTP in cache with a 2-minute expiration
#     cache_key = f"otp_{meeting_id}"  # Create a unique key for the meeting
#     cache.set(cache_key, otp, timeout=120)  # Timeout in seconds (2 minutes)

#     # Return OTP and meeting name to the frontend
#     return JsonResponse({'otp': otp, 'meeting_name': meeting_name})

# @api_view(['POST'])
# def generate_otp(request):
#     data = json.loads(request.body)
#     meeting_id = data.get('meeting_id')

#     # Fetch the meeting name from the Meeting model
#     meeting = Meeting.objects.get(id=meeting_id)
#     meeting_name = meeting.meeting_name  # Get the meeting name

#     # Generate a random 6-digit OTP
#     otp = random.randint(100000, 999999)

#     # Store the OTP in cache with a 2-minute expiration
#     cache_key = f"otp_{meeting_id}"  # Create a unique key for the meeting
#     cache.set(cache_key, otp, timeout=120)  # Timeout in seconds (2 minutes)

#     # Construct the URL with the meeting name
#     url = f"http://localhost:3000/form-fillup?meeting={meeting_name}"

#     # Return OTP, meeting name, and URL to the frontend
#     return JsonResponse({'otp': otp, 'meeting_name': meeting_name, 'url': url})
# @api_view(['POST'])
# def verify_otp(request):
#     if request.method == "POST":
#         data = json.loads(request.body)
#         meeting_id = data.get('meeting_id')
#         user_otp = data.get('otp')

#         # Construct cache key for the specific meeting
#         cache_key = f"otp_{meeting_id}"

#         # Retrieve the stored OTP from the cache
#         stored_otp = cache.get(cache_key)

#         if stored_otp is None:
#             return JsonResponse({'message': 'OTP has expired or does not exist'}, status=400)

#         if str(stored_otp) == str(user_otp):
#             # If OTP is valid, you can perform additional actions here
#             # For example, you might want to mark attendance, etc.
#             return JsonResponse({'message': 'OTP verified successfully'})
#         else:
#             return JsonResponse({'message': 'Invalid OTP'}, status=400)

#     return JsonResponse({'message': 'Invalid request method'}, status=405)


@api_view(['POST'])
def generate_otp(request):
    data = json.loads(request.body)
    meeting_id = data.get('meeting_id')

    # Fetch the meeting name from the Meeting model
    meeting = Meeting.objects.get(id=meeting_id)
    meeting_name = meeting.meeting_name

    # Generate a random 6-digit OTP
    otp = random.randint(100000, 999999)

    # Store the OTP in cache with a 2-minute expiration
    cache_key = f"otp_{meeting_id}"
    cache.set(cache_key, otp, timeout=120)
    url = f"http://localhost:3000/form-fillup?id={meeting_id}&meeting_name={meeting_name}"

    # Log the OTP for debugging
    print(f"Generated OTP for meeting {meeting_id}: {otp}")

    # Return OTP and meeting name to the frontend
    return JsonResponse({'otp': otp, 'meeting_name': meeting_name, 'meeting_id': meeting_id, 'url': url})

@api_view(['POST'])
def verify_otp(request):
    data = json.loads(request.body)
    meeting_id = data.get('meeting_id')
    user_otp = data.get('otp')

    # Construct cache key for the specific meeting
    cache_key = f"otp_{meeting_id}"

    # Retrieve the stored OTP from the cache
    stored_otp = cache.get(cache_key)

    # Log for debugging
    print(f"Verifying OTP for meeting {meeting_id}: User OTP: {user_otp}, Stored OTP: {stored_otp}")

    if stored_otp is None:
        return JsonResponse({'message': 'OTP has expired or does not exist'}, status=400)

    if str(stored_otp) == str(user_otp):
        return JsonResponse({'message': 'OTP verified successfully'})
    else:
        return JsonResponse({'message': 'Invalid OTP'}, status=400)
    


@api_view(['POST'])
@csrf_exempt
def attendanceSubmitByEmployee(request):
    data = JSONParser().parse(request)
    meeting_id = data.get('meeting_id')  # Meeting ID from the request
    employee_id = data.get('employee_id')  # Employee ID from the request
    attendance_date = date.today()  # Use the current date from the server

    # Validate the meeting ID
    try:
        meeting = Meeting.objects.get(id=meeting_id)
    except Meeting.DoesNotExist:
        return JsonResponse({'error': 'Invalid meeting ID'}, status=400)

    # Validate the employee ID
    try:
        employee = Employee.objects.get(employee_id=employee_id)  # Use employee_id to get Employee instance
    except Employee.DoesNotExist:
        return JsonResponse({'error': f'Invalid employee ID: {employee_id}'}, status=400)

    # Check if the employee is a participant in the meeting
    if not meeting.required_employees.filter(id=employee.id).exists():
        return JsonResponse({'error': f'Employee {employee.name} is not a participant in this meeting.'}, status=400)

    # Check for existing attendance record
    if Attendance.objects.filter(meeting=meeting, employee=employee, date=attendance_date).exists():
        error_message = (f'Attendance record already exists for {employee.name} on {attendance_date}')
        return JsonResponse({'error': error_message}, status=400)

    # Create the attendance record
    try:
        Attendance.objects.create(meeting=meeting, employee=employee, date=attendance_date)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=400)

    return JsonResponse({'message': 'Attendance record created successfully'}, status=200)