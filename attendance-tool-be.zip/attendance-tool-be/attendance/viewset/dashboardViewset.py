from django.shortcuts import render, redirect
from django.views.decorators.csrf import csrf_exempt
from ..models import Meeting, Attendance
from ..serializers import MeetingSerializer, MeetingListSerializer, TestAttendanceListSerializer, TestMeetingDetailsSerializer
from django.db.models import Q
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from ..decorator import azure_ad_required

@api_view(['GET'])
# @azure_ad_required
def update_inprogress_status_to_completed(request, pk):
    try:
        meeting = Meeting.objects.get(pk=pk)
    except Meeting.DoesNotExist:
        return Response({'error': 'Meeting not found'}, status=status.HTTP_404_NOT_FOUND)
    
    meeting.status = 'completed'  
    meeting.save()

    serializer = MeetingSerializer(meeting)
    return Response({
        'message': 'Status updated to completed',
        'data': serializer.data
    }, status=status.HTTP_200_OK)

@api_view(['GET'])
# @azure_ad_required
def update_completed_status_to_inprogress(request, pk):
    try:
        meeting = Meeting.objects.get(pk=pk)
    except Meeting.DoesNotExist:
        return Response({'error': 'Meeting not found'}, status=status.HTTP_404_NOT_FOUND)
    
    meeting.status = 'in_progress'  
    meeting.save()

    serializer = MeetingSerializer(meeting)
    return Response({
        'message': 'Status updated to in_progress',
        'data': serializer.data
    }, status=status.HTTP_200_OK)



@api_view(['GET'])
# @azure_ad_required
def meetings_list(request):
    status = request.query_params.get('status')

    if status == 'in_progress':
        meetings = Meeting.objects.filter(status='in_progress').order_by('meeting_name')
    elif status == 'completed':
        meetings = Meeting.objects.filter(
    Q(status='completed') #| Q(is_active=False)
).order_by('meeting_name')
    else:
        return Response({"error": "Invalid status"}, status=400)

    serializer = MeetingListSerializer(meetings, many=True)
    return Response(serializer.data)



@api_view(['GET'])
# @azure_ad_required
def attendance_list(request):
    meeting_id = request.query_params.get('meeting')
    
    if not meeting_id:
        return Response({"error": "Meeting ID is required"}, status=400)

    try:
        meeting = Meeting.objects.get(id=meeting_id)
        meeting_serializer = TestMeetingDetailsSerializer(meeting)
        required_employees = meeting.required_employees.values_list('id', flat=True)
        attendance = Attendance.objects.filter(meeting_id=meeting_id, employee_id__in=required_employees)
        attendance_serializer = TestAttendanceListSerializer(attendance, many=True)
        
        response_data = {
            "meeting_details": meeting_serializer.data,
            "attendance": attendance_serializer.data
        }
        
        return Response(response_data)
    except Meeting.DoesNotExist:
        return Response({"error": "Meeting not found"}, status=404)
