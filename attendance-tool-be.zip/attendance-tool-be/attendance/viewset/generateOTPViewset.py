from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from ..models import Employee,  Meeting, Attendance, Question, AssessmentAnswers
from rest_framework.parsers import JSONParser
from rest_framework.decorators import api_view
from datetime import date
import json
import json, random
from django.core.cache import cache
# from ...attendance_project.settings import UI_URL
from attendance_project.settings import UI_URL
from ..decorator import azure_ad_required


@api_view(['POST'])
# @azure_ad_required
def generate_otp(request):
    data = json.loads(request.body)
    meeting_id = data.get('meeting_id')
    timeout = data.get('minutes_in_sec')
    meeting = Meeting.objects.get(id=meeting_id)
    meeting_name = meeting.meeting_name
    otp = random.randint(100000, 999999)

    cache_key = f"otp_{meeting_id}"
    cache.set(cache_key, otp, timeout=timeout)
    url = f"{UI_URL}/form-fillup?id={meeting_id}&meeting_name={meeting_name}"

    print(f"Generated OTP for meeting {meeting_id}: {otp}")

    return JsonResponse({'otp': otp, 'meeting_name': meeting_name, 'meeting_id': meeting_id, 'url': url})

@api_view(['POST'])
# @azure_ad_required
def verify_otp(request):
    data = json.loads(request.body)
    meeting_id = data.get('meeting_id')
    user_otp = data.get('otp')

    cache_key = f"otp_{meeting_id}"

    stored_otp = cache.get(cache_key)

    print(f"Verifying OTP for meeting {meeting_id}: User OTP: {user_otp}, Stored OTP: {stored_otp}")

    if stored_otp is None:
        return JsonResponse({'message': 'OTP has expired or does not exist'}, status=400)

    if str(stored_otp) == str(user_otp):
        return JsonResponse({'message': 'OTP verified successfully'})
    else:
        return JsonResponse({'message': 'Invalid OTP'}, status=400)
    


@api_view(['POST'])
# @azure_ad_required
# @csrf_exempt
def attendanceSubmitByEmployee(request):
    data = JSONParser().parse(request)
    meeting_id = data.get('meeting_id') 
    employee_id = data.get('employee_id')  
    attendance_date = date.today()  
    try:
        meeting = Meeting.objects.get(id=meeting_id)
    except Meeting.DoesNotExist:
        return JsonResponse({'error': 'Invalid meeting ID'}, status=400)

    try:
        employee = Employee.objects.get(employee_id=employee_id)  
    except Employee.DoesNotExist:
        return JsonResponse({'error': f'Invalid employee ID: {employee_id}'}, status=400)

    if not meeting.required_employees.filter(id=employee.id).exists():
        return JsonResponse({'error': f'Employee {employee.name} is not a participant in this meeting.'}, status=400)

    if Attendance.objects.filter(meeting=meeting, employee=employee, date=attendance_date).exists():
        error_message = (f'Attendance record already exists for {employee.name} on {attendance_date}')
        return JsonResponse({'error': error_message}, status=400)

    try:
        Attendance.objects.create(meeting=meeting, employee=employee, date=attendance_date)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=400)

    return JsonResponse({'message': 'Attendance record created successfully'}, status=200)
