from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

from ..models import Employee, Meeting, Attendance, Meeting
from ..serializers import MeetingSerializer
from rest_framework.parsers import JSONParser
from rest_framework.decorators import api_view
from rest_framework.response import Response
from datetime import date
from ..decorator import azure_ad_required


@api_view(['GET'])
# # @azure_ad_required
def get_meetings(request):
    meetings = Meeting.objects.filter(status='in_progress').order_by('meeting_name')
    serializer = MeetingSerializer(meetings, many=True)
    return JsonResponse(serializer.data, safe=False)

@api_view(['GET'])
# @azure_ad_required
def get_required_employees(request, meeting_id):
    try:
        meeting = Meeting.objects.get(id=meeting_id)
        employees = meeting.required_employees.all()
        employee_data = [
            {'id': employee.id, 'name': employee.name, 'employee_id': employee.employee_id}
            for employee in employees
        ]
        return Response(employee_data, status=200)
    except Meeting.DoesNotExist:
        return Response({'error': 'Meeting not found'}, status=404)
    
@api_view(['POST'])
# @csrf_exempt
# @azure_ad_required
def log_attendance(request):
    data = JSONParser().parse(request)
    meeting_id = data.get('meeting')
    employee_ids = data.get('employees')
    attendance_date = date.today() 

    try:
        meeting = Meeting.objects.get(id=meeting_id)
    except Meeting.DoesNotExist:
        return JsonResponse({'error': 'Invalid meeting ID'}, status=400)

    employee_names = []
    existing_records = []

    for emp_id in employee_ids:
        try:
            employee = Employee.objects.get(id=emp_id)
            employee_names.append(employee.name)
            
            if Attendance.objects.filter(meeting=meeting, employee=employee, date=attendance_date).exists():
                existing_records.append(employee.name)
        except Employee.DoesNotExist:
            return JsonResponse({'error': f'Invalid employee ID: {emp_id}'}, status=400)

    if existing_records:
        existing_records_str = ', '.join(existing_records)
        error_message = (f'Attendance record already exists for meeting '
                         f'<b>{meeting.meeting_name}</b> for employee(s): '
                         f'<b>{existing_records_str}</b> on <b>{attendance_date}</b>')
        return JsonResponse({'error': error_message}, status=400)

    for emp_id in employee_ids:
        employee = Employee.objects.get(id=emp_id)
        try:
            Attendance.objects.create(meeting=meeting, employee=employee, date=attendance_date)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=400)

    return JsonResponse({'message': 'Attendance records created successfully'}, status=201)
