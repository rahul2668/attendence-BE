from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from ..models import Employee, Course, Meeting, Location
from ..serializers import MeetingSerializer, CourseSerializer, EmployeeSerializer, MeetingListSerializer, LocationSerializer
from rest_framework.parsers import JSONParser
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from django.http import JsonResponse
from ..models import Meeting, Course  
from datetime import datetime
from ..decorator import azure_ad_required


@api_view(['POST'])
# @csrf_exempt
# @azure_ad_required
def create_meeting(request):
    data = JSONParser().parse(request)
    meeting_name = data.get('meeting_name')
    course_value = data.get('course')
    start_date = data.get('start_date')
    end_date = data.get('end_date')
    start_time = data.get('start_time')
    end_time = data.get('end_time')
    required_employees = data.get('required_employees')
    trainer_name = data.get('trainer_name')
    meeting_type = data.get('type')
    location_value = data.get('location') 
    online_url = data.get('online_url')

    if not meeting_name:
        return JsonResponse({"error": "Meeting name is required."}, status=400)

    if not course_value:
        return JsonResponse({"error": "Course must be provided."}, status=400)

    if meeting_type == "Offline" and location_value is None:
        return JsonResponse({"error": "Location must be provided for offline meetings."}, status=400)

    if meeting_type == "Online" and not online_url:
        return JsonResponse({"error": "Online URL must be provided for online meetings."}, status=400)

    try:
        start_date_dt = datetime.strptime(start_date, '%Y-%m-%d').date()
        end_date_dt = datetime.strptime(end_date, '%Y-%m-%d').date()
    except ValueError:
        return JsonResponse({"error": "Invalid date format. Use YYYY-MM-DD format."}, status=400)

    if start_date_dt > end_date_dt:
        return JsonResponse({"error": "Start date must not be greater than end date."}, status=400)


    try:
        start_time_dt = datetime.strptime(start_time, '%H:%M').time()
        end_time_dt = datetime.strptime(end_time, '%H:%M').time()
    except ValueError:
        return JsonResponse({"error": "Invalid time format. Use HH:MM format."}, status=400)
    
    if start_date_dt > end_date_dt:
        return JsonResponse({"error": "Start date must not be greater than end date."}, status=400)

    if start_time_dt >= end_time_dt:
        return JsonResponse({"error": "Start time must be earlier than end time."}, status=400)


    if location_value and meeting_type == "Offline":
        if isinstance(location_value, int):
            overlapping_location = Meeting.objects.filter(
                start_date__lt=start_date_dt,
                end_date__gt = end_date_dt,
                location__id=location_value,
                
                start_time__lt=end_time_dt, 
                end_time__gt=start_time_dt   
            ).exists()
        else:
            overlapping_location = Meeting.objects.filter(
                start_date__lt=start_date_dt,
                end_date__gt = end_date_dt,
                location__location_name=location_value,
                start_time__lt=end_time_dt,  
                end_time__gt=start_time_dt   
            ).exists()

        if overlapping_location:
            return JsonResponse({"error": f"Location is already blocked for another meeting during the requested time range."}, status=400)

    if isinstance(course_value, int):
        try:
            course = Course.objects.get(id=course_value)
        except Course.DoesNotExist:
            return JsonResponse({"error": "Course not found."}, status=400)
    else:  
        course, created = Course.objects.get_or_create(course_name=course_value)
    
    location = None
    if location_value:
        if isinstance(location_value, int):
            try:
                location = Location.objects.get(id=location_value)
            except Location.DoesNotExist:
                return JsonResponse({"error": "Location not found."}, status=400)
        else:
            location, created = Location.objects.get_or_create(name=location_value)

    meeting = Meeting.objects.create(
        meeting_name=meeting_name,
        course=course,  
        start_date=start_date,
        end_date=end_date,
        start_time=start_time,
        end_time=end_time,
        type=meeting_type,
        location=location,
        online_url=online_url
    )

    if required_employees:
        meeting.required_employees.set(required_employees)

    if trainer_name:
        meeting.trainer_name.set(trainer_name)

    return JsonResponse({"id": meeting.id}, status=201)

@api_view(['GET'])
# @azure_ad_required
def meetings_list_inprogress(request):
    meetings = Meeting.objects.filter(status='in_progress').order_by('meeting_name')
    serializer = MeetingListSerializer(meetings, many=True)
    return Response(serializer.data)


@api_view(['GET'])
# @azure_ad_required
def get_courses(request):
    courses = Course.objects.all().order_by('course_name')
    serializer = CourseSerializer(courses, many=True)
    return JsonResponse(serializer.data, safe=False)



@api_view(['GET'])
# # @azure_ad_required
def get_employees(request):
    meetings = Employee.objects.filter(is_trainer=True).order_by('name')
    serializer = EmployeeSerializer(meetings, many=True)
    return JsonResponse(serializer.data, safe=False)


@api_view(['GET'])
# @azure_ad_required
def meetings_inprogress_list(request, pk):
    try:
        meeting = Meeting.objects.get(pk=pk)
    except Meeting.DoesNotExist:
        return Response({'error': 'Meeting not found'}, status=status.HTTP_404_NOT_FOUND)
    
    serializer = MeetingSerializer(meeting)
    return Response(serializer.data, status=status.HTTP_200_OK)


@api_view(['POST'])
# @csrf_exempt
# @azure_ad_required
def update_meeting(request, meeting_id):
    """
    Update a meeting with multiple fields
    """
    try:
        meeting = Meeting.objects.get(id=meeting_id)
    except Meeting.DoesNotExist:
        return JsonResponse({'error': 'Meeting not found'}, status=404)

    data = JSONParser().parse(request)
    meeting_name = data.get('meeting_name', meeting.meeting_name)  
    course_value = data.get('course', meeting.course.id if meeting.course else None)
    start_date = data.get('start_date', meeting.start_date.strftime('%Y-%m-%d'))
    end_date = data.get('end_date', meeting.end_date.strftime('%Y-%m-%d'))
    start_time = data.get('start_time', meeting.start_time.strftime('%H:%M'))
    end_time = data.get('end_time', meeting.end_time.strftime('%H:%M'))
    required_employees = data.get('required_employees', list(meeting.required_employees.values_list('id', flat=True)))
    trainer_name = data.get('trainer_name', meeting.trainer_name)
    meeting_type = data.get('type', meeting.type)
    location_value = data.get('location', meeting.location.id if meeting.location else None)
    online_url = data.get('online_url', meeting.online_url)
    status = data.get('status', meeting.status)

    if not meeting_name:
        return JsonResponse({"error": "Meeting name is required."}, status=400)

    if not course_value:
        return JsonResponse({"error": "Course must be provided."}, status=400)

    if meeting_type == "Offline" and location_value is None:
        return JsonResponse({"error": "Location must be provided for offline meetings."}, status=400)

    if meeting_type == "Online" and not online_url:
        return JsonResponse({"error": "Online URL must be provided for online meetings."}, status=400)

    if not  status:
        return JsonResponse({"error": "Status must be provided"}, status=400)
    try:
        start_date_dt = datetime.strptime(start_date, '%Y-%m-%d').date()
        end_date_dt = datetime.strptime(end_date, '%Y-%m-%d').date()
    except ValueError:
        return JsonResponse({"error": "Invalid date format. Use YYYY-MM-DD format."}, status=400)

    if start_date_dt > end_date_dt:
        return JsonResponse({"error": "Start date must not be greater than end date."}, status=400)

    try:
        start_time_dt = datetime.strptime(start_time, '%H:%M').time()
        end_time_dt = datetime.strptime(end_time, '%H:%M').time()
    except ValueError:
        return JsonResponse({"error": "Invalid time format. Use HH:MM format."}, status=400)
    if start_time_dt >= end_time_dt:
        return JsonResponse({"error": "Start time must be earlier than end time."}, status=400)
    
    if meeting_type == "Offline" and location_value:
        if isinstance(location_value, int):
            overlapping_location = Meeting.objects.filter(
                start_date__lt=end_date_dt,
                end_date__gt=start_date_dt,
                location__id=location_value,
                start_time__lt=end_time_dt,
                end_time__gt=start_time_dt   
            ).exclude(id=meeting.id).exists()  
        else:
            overlapping_location = Meeting.objects.filter(
                start_date__lt=end_date_dt,
                end_date__gt=start_date_dt,
                location__location_name=location_value,
                start_time__lt=end_time_dt,
                end_time__gt=start_time_dt   
            ).exclude(id=meeting.id).exists() 
        if overlapping_location:
            return JsonResponse({"error": f"Location is already blocked for another meeting during the requested time range."}, status=400)

    if isinstance(course_value, int):
        try:
            course = Course.objects.get(id=course_value)
        except Course.DoesNotExist:
            return JsonResponse({"error": "Course not found."}, status=400)
    else:
        course, created = Course.objects.get_or_create(course_name=course_value)
    
    location = None
    if location_value:
        if isinstance(location_value, int):
            try:
                location = Location.objects.get(id=location_value)
            except Location.DoesNotExist:
                return JsonResponse({"error": "Location not found."}, status=400)
        else:
            location, created = Location.objects.get_or_create(name=location_value)

    Meeting.objects.filter(id=meeting.id).update(
    meeting_name=meeting_name,
    course=course,
    start_date=start_date_dt,  
    end_date=end_date_dt,      
    start_time=start_time_dt,  
    end_time=end_time_dt,      
    type=meeting_type,
    location=location,
    online_url=online_url,
    status=status
)
    if required_employees:
        meeting.required_employees.set(required_employees) 

    if trainer_name:
        meeting.trainer_name.set(trainer_name)  
    return JsonResponse({"id": meeting.id}, status=200)


@api_view(['POST'])
# @azure_ad_required
def delete_meeting(request, meeting_id):
    
    try:
        meeting = Meeting.objects.filter(id=meeting_id)
        if meeting:
            meeting.update(is_active=False) #, status='completed')
        return Response({'message': 'Meeting deleted successfully.'}, status=status.HTTP_204_NO_CONTENT)
    except Meeting.DoesNotExist:
        return Response({'error': 'Meeting not found.'}, status=status.HTTP_404_NOT_FOUND)

@api_view(['GET'])
# @csrf_exempt
# @azure_ad_required
def get_locations(request):
    location = Location.objects.all().order_by('location_name')
    serializer = LocationSerializer(location, many=True)
    return JsonResponse(serializer.data, safe=False)

