from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from ..models import Employee,  Meeting, Question, AssessmentAnswers, AssessmentUrl

from rest_framework.decorators import api_view
from datetime import date
import json
from django.core.cache import cache
from django.db.models import Sum, F, Value, FloatField
from django.db.models import Q
from rest_framework import status

from rest_framework.response import Response
from ..serializers import MeetingWithQuestionsSerializer, QuestionSerializer, QuestionMeetingSerializer

from django.db.models.functions import Coalesce
from attendance_project.settings import UI_URL
from ..decorator import azure_ad_required

@api_view(['POST'])
@csrf_exempt
# @azure_ad_required
def QuestionCreation(request):
    data = request.data
    meeting_id = data.get("meetingId")

    if meeting_id:
        try:
            meeting = Meeting.objects.get(id=meeting_id)
        except Meeting.DoesNotExist:
            return Response({"error": "Meeting not found."}, status=status.HTTP_404_NOT_FOUND)

        questions_data = data.get("questions", [])

        for question_data in questions_data:
            question_id = question_data.get("id")
            if question_id:
                try:
                    question = Question.objects.get(question_id=question_id)
                    serializer = QuestionMeetingSerializer(question, data=question_data)
                except Question.DoesNotExist:
                    return Response({"error": f"Question with ID {question_id} not found."}, status=status.HTTP_404_NOT_FOUND)
            else:
                serializer = QuestionMeetingSerializer(data=question_data)

            if serializer.is_valid():
                serializer.save(meeting=meeting)
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        return Response({"message": "Preview created successfully!"}, status=status.HTTP_201_CREATED)
    else:
        return Response({"error": "Meeting ID is required."}, status=status.HTTP_400_BAD_REQUEST)
    

# @api_view(['POST'])
# def save_questions(request):
#     try:
#         data = json.loads(request.body)
#         meeting_id = data.get("meeting_id")
#         creationDate = data.get("creationDate")
#         questions = data.get("questions", [])
#         meeting = Meeting.objects.get(id=meeting_id)
#         existing_question = Question.objects.filter(
#                 meeting=meeting,
#                 creationDate=creationDate,
#                 question_text='Employee ID'
#             ).first()

#         for question in questions:
#             question_sqn_id = question.get("id")
#             question_type = question.get("type")
#             question_text = question.get("question")
#             options = question.get("options", [])
#             required = question.get("required", False)
#             acceptedAnswer= question.get("acceptedAnswer", [])
            
#             if existing_question:
#                 return JsonResponse({
#                     "error": f"Question already exists for this meeting."
#                 }, status=400)
            
#             if isinstance(question_sqn_id, str):
#                 question_sqn_id = int(question_sqn_id)  
#             save_question = Question.objects.create(
#                 meeting=meeting,
#                 question_sqn_id=question_sqn_id,
#                 question_type=question_type,
#                 question_text=question_text,
#                 options=options,
#                 required=required,
#                 acceptedAnswer=acceptedAnswer,
#                 creationDate=creationDate
#                 )
#             if save_question:
#                 # url = f"{UI_URL}/form-fill/{meeting_id}/{creationDate}"
#                 # AssessmentUrl.objects.create(meeting=meeting, creationDate=creationDate, url=url)
#         return JsonResponse({"message": "Questions saved successfully."}, status=201)

#     except Meeting.DoesNotExist:
#         return JsonResponse({"error": "Meeting not found."}, status=404)
#     except (ValueError, TypeError) as e:
#         return JsonResponse({"error": str(e)}, status=400)
#     except Exception as e:
#         return JsonResponse({"error": "An unexpected error occurred."}, status=500)
    
@api_view(['POST'])
# @azure_ad_required
def save_questions(request):
    try:
        data = json.loads(request.body)
        meeting_id = data.get("meeting_id")
        creationDate = data.get("creationDate")
        questions = data.get("questions", [])
        meeting = Meeting.objects.get(id=meeting_id)
        
        # Check if a question with 'Employee ID' already exists for this meeting and creationDate
        existing_question = Question.objects.filter(
            meeting=meeting,
            creationDate=creationDate,
            question_text__iexact='Employee ID'
        ).first()

        if existing_question:
            return JsonResponse({
                "error": "Question with 'Employee ID' already exists for this meeting."
            }, status=400)

        # Loop through questions and save them
        for question in questions:
            question_sqn_id = question.get("id")
            question_type = question.get("type")
            question_text = question.get("question")
            options = question.get("options", [])
            required = question.get("required", False)
            acceptedAnswer = question.get("acceptedAnswer", [])

            if isinstance(question_sqn_id, str):
                question_sqn_id = int(question_sqn_id)

            # Create and save the question
            Question.objects.create(
                meeting=meeting,
                question_sqn_id=question_sqn_id,
                question_type=question_type,
                question_text=question_text,
                options=options,
                required=required,
                acceptedAnswer=acceptedAnswer,
                creationDate=creationDate
            )

        # Check if the AssessmentUrl already exists based on meeting and creationDate
        if not AssessmentUrl.objects.filter(meeting=meeting, creationDate=creationDate).exists():
            url = f"{UI_URL}/form-fill/{meeting_id}/{creationDate}"
            AssessmentUrl.objects.create(meeting=meeting, creationDate=creationDate, url=url)

        return JsonResponse({"message": "Questions saved successfully."}, status=201)

    except Meeting.DoesNotExist:
        return JsonResponse({"error": "Meeting not found."}, status=404)
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)

@api_view(['GET'])
# @azure_ad_required
def meeting_question_detail(request, meeting_id, date):
    try:
        meeting = Meeting.objects.get(id=meeting_id)

        questions = Question.objects.filter(meeting=meeting, creationDate=date)

        if not questions.exists():
            return Response({'error': 'No questions found for this meeting and date'}, status=404)

        serializer = MeetingWithQuestionsSerializer(meeting)
        response_data = {
            'meeting': serializer.data,
            'questions': QuestionSerializer(questions, many=True).data  
        }

        return Response(response_data)

    except Meeting.DoesNotExist:
        return Response({'error': 'Meeting not found'}, status=404)
    except Exception as exc:
        return Response({'error': str(exc)}, status=500)
    


@api_view(['POST'])
# @azure_ad_required
def submit_answers(request):
    data = request.data
    meeting_id = data.get('meeting_id')
    
    try:
        meeting = Meeting.objects.get(id=meeting_id)
    except Meeting.DoesNotExist:
        return JsonResponse({'status': 'error', 'message': 'Meeting not found.'}, status=404)

    creation_date = data.get('creationDate')

    for q_data in data.get('questions', []):
        questions = Question.objects.filter(question_sqn_id=q_data['question_sqn_id'], meeting=meeting, creationDate=creation_date)
        
        if questions.exists():
            question = questions.first() 
        else:
            return JsonResponse({'status': 'error', 'message': f"Question with sqn_id {q_data['question_sqn_id']} not found."}, status=404)

        participant_answers = q_data['answer']

        if question.question_type == 'choice':
            participant_answers = participant_answers if isinstance(participant_answers, str) else participant_answers[0]
        elif question.question_type == 'multichoice':
            participant_answers = participant_answers if isinstance(participant_answers, list) else [participant_answers]

        marks = 0.0
        if question.question_text.lower() == 'employee id':
            if not meeting.required_employees.filter(employee_id=participant_answers).exists():
                return JsonResponse({'status': 'error', 'message': 'Employee ID is not in the required employees for this meeting.'}, status=400)
            if AssessmentAnswers.objects.filter(meeting=meeting, submited_date=creation_date, participant_answers=participant_answers).exists():
                return JsonResponse({'status': 'error', 'message': 'This Employee ID has already been submitted for this meeting on this date.'}, status=400)
            rr = Employee.objects.get(employee_id=participant_answers)


        if question.acceptedAnswer:
            if question.question_type == 'text':
                if participant_answers == question.acceptedAnswer:
                    marks = 1.0
                else:
                    marks = 0.0

            elif question.question_type == 'choice':
                if participant_answers == question.acceptedAnswer:
                    marks = 1.0
                else:
                    marks = 0.0

            elif question.question_type == 'multichoice':
                correct_answer_string = question.acceptedAnswer.strip().strip('[]')
                correct_answer_list = [answer.strip().strip("'") for answer in correct_answer_string.split(',') if answer.strip()]

                correct_answer_set = set(correct_answer_list) 
                submitted_answer_set = set(participant_answers)

                correct_submissions = correct_answer_set.intersection(submitted_answer_set)

                if len(correct_submissions) == len(correct_answer_set):
                    marks = 1.0  
                elif len(correct_submissions) > 0:
                    marks = 0.5 
                else:
                    marks = 0.0 

        answer = AssessmentAnswers(
            question=question,
            meeting=meeting,
            participant_answers=participant_answers,
            creationDate=creation_date,
            submited_date=date.today(),
            marks=marks,
            employee=rr
        )
        answer.save()  

    return JsonResponse({'status': 'success', 'message': 'Answers submitted successfully!'})

@api_view(['GET'])
# @azure_ad_required
def assessment_results(request, meeting_id, creationDate):
    meeting = Meeting.objects.get(id=meeting_id)
    trainer_names = ', '.join([trainer.name for trainer in meeting.trainer_name.all()])
    question_obj = Question.objects.filter(
        meeting_id=meeting_id,
        creationDate=creationDate
    )
    
    if question_obj.exists():
        creation_date = question_obj.first().creationDate
        total_marks = question_obj.count() 
    else:
        creation_date = None
        total_marks = 0
    results = Employee.objects.filter(
        assessmentanswers__meeting_id=meeting_id,
        assessmentanswers__creationDate=creationDate
    ).values(
        'employee_id',     
        'name',            
        'email',           
        'designation',     
        'vertical',        
    ).annotate(
        total_marks=Coalesce(Sum('assessmentanswers__marks'), Value(0.0), output_field=FloatField()) 
    )

    employee_details = [
        {
            'employee_id': result['employee_id'],
            'name': result['name'],
            'email': result['email'],
            'designation': result['designation'],
            'marks': result['total_marks'], 
            'vertical': result['vertical'],
        }
        for result in results
    ]

    meeting_name = meeting.meeting_name
    start_time = meeting.start_time.strftime("%H:%M")
    end_time = meeting.end_time.strftime("%H:%M")
    assessment = AssessmentUrl.objects.filter(meeting=meeting_id, creationDate=creation_date).first()
    if not assessment:
        assessment= ""
    else:
        assessment = assessment.url
    response_data = {
        "trainer_name": trainer_names,
        "meeting_name": meeting_name,
        "creationDate": creation_date,
        "total_marks": total_marks-1,  
        "employee_detail": employee_details,
        "start_time": start_time,
        "end_time": end_time,
        "url": assessment
    }

    return Response(response_data)


