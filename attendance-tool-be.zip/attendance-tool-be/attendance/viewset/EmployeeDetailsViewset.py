# views.py
import pandas as pd
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from ..models import Employee
from django.db import IntegrityError
from rest_framework.decorators import api_view
from ..decorator import azure_ad_required

# @api_view(['POST'])
# def UploadEmployeeData(request):
    
#     file = request.FILES.get('file')
#     if not file:
#         return Response({"error": "No file uploaded."}, status=status.HTTP_400_BAD_REQUEST)

#     try:
#         df = pd.read_excel(file)
#         required_columns = ['Employee Number', 'Employee Name', 'Work Email', 'Job Title', 'Vertical', 'Reporting To', 'Is Trainer']
#         missing_columns = [col for col in required_columns if col not in df.columns]

#         if missing_columns:
#             return Response({"error": f"Missing columns: {', '.join(missing_columns)}"}, status=status.HTTP_400_BAD_REQUEST)

#         response_data = {
#             "updated_records": [],
#             "created_records": []
#         }

#         for index, row in df.iterrows():
#             employee_id = str(row['Employee Number']).strip()
#             name = str(row['Employee Name']).strip()
#             email = str(row['Work Email']).strip()
#             designation = str(row['Job Title']).strip()
#             vertical = str(row['Vertical']).strip()
#             reporting_to = str(row['Reporting To']).strip()
#             is_trainer = str(row['Is Trainer']).strip().lower() == 'yes'

#             if not all([employee_id, name, email, designation, vertical]):
#                 continue

#             employee, created = Employee.objects.update_or_create(
#                 employee_id=employee_id,
#                 defaults={
#                     'name': name,
#                     'email': email,
#                     'designation': designation,
#                     'vertical': vertical,
#                     'reporting_to': reporting_to if reporting_to else None,
#                     'is_trainer': is_trainer
#                 }
#             )

#             if created:
#                 response_data["created_records"].append(employee_id)
#             else:
#                 response_data["updated_records"].append(employee_id)

#         response_message = []
#         if response_data["created_records"]:
#             response_message.append(f"{len(response_data['created_records'])} Records Created") #: {', '.join(response_data['created_records'])}
#         if response_data["updated_records"]:
#             response_message.append(f"{len(response_data['updated_records'])} Records Updated") #{', '.join(response_data['updated_records'])}

#         return Response({"message": " ".join(response_message)}, status=status.HTTP_200_OK)

#     except Exception as e:
#         return Response({"error": f"An error occurred: {str(e)}"}, status=status.HTTP_400_BAD_REQUEST)
@api_view(['POST'])
# @azure_ad_required
def UploadEmployeeData(request):
    
    file = request.FILES.get('file')
    if not file:
        return Response({"error": "No file uploaded."}, status=status.HTTP_400_BAD_REQUEST)

    try:
        df = pd.read_excel(file)
        required_columns = ['Employee Number', 'Employee Name', 'Work Email', 'Job Title', 'Vertical', 'Reporting To', 'Is Trainer']
        missing_columns = [col for col in required_columns if col not in df.columns]

        if missing_columns:
            return Response({"error": f"Missing columns: {', '.join(missing_columns)}"}, status=status.HTTP_400_BAD_REQUEST)

        response_data = {
            "updated_records": [],
            "created_records": [],
            "skipped_records": []  # To track skipped records due to duplicates
        }

        for index, row in df.iterrows():
            employee_id = str(row['Employee Number']).strip()
            name = str(row['Employee Name']).strip()
            email = str(row['Work Email']).strip()
            designation = str(row['Job Title']).strip()
            vertical = str(row['Vertical']).strip()
            reporting_to = str(row['Reporting To']).strip()
            is_trainer = str(row['Is Trainer']).strip().lower() == 'yes'

            if not all([employee_id, name, email, designation, vertical]):
                continue

            # Check if an employee with the same email already exists
            existing_employee = Employee.objects.filter(email=email).first()

            if existing_employee:
                # If the existing employee has the same employee ID, update their data
                if existing_employee.employee_id == employee_id:
                    # Update the existing employee's data
                    existing_employee.name = name
                    existing_employee.designation = designation
                    existing_employee.vertical = vertical
                    existing_employee.reporting_to = reporting_to if reporting_to else None
                    existing_employee.is_trainer = is_trainer
                    existing_employee.save()
                    response_data["updated_records"].append(employee_id)
                else:
                    # Skip the record if the email exists with a different employee ID
                    response_data["skipped_records"].append(email)
            else:
                # Create a new employee record
                employee = Employee.objects.create(
                    employee_id=employee_id,
                    name=name,
                    email=email,
                    designation=designation,
                    vertical=vertical,
                    reporting_to=reporting_to if reporting_to else None,
                    is_trainer=is_trainer
                )
                response_data["created_records"].append(employee_id)

        response_message = []
        if response_data["created_records"]:
            response_message.append(f"{len(response_data['created_records'])} Records Created")
        if response_data["updated_records"]:
            response_message.append(f"{len(response_data['updated_records'])} Records Updated")
        if response_data["skipped_records"]:
            response_message.append(f"{len(response_data['skipped_records'])} Records Skipped due to duplicate emails")

        return Response({"message": " ".join(response_message)}, status=status.HTTP_200_OK)

    except Exception as e:
        return Response({"error": f"An error occurred: {str(e)}"}, status=status.HTTP_400_BAD_REQUEST)
