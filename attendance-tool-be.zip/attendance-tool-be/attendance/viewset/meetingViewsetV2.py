from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from ..models import Employee, Course, Meeting, Location
from ..serializers import MeetingSerializer, CourseSerializer, EmployeeSerializer, MeetingListSerializer, LocationSerializer
from rest_framework.parsers import JSONParser
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from django.http import JsonResponse
from ..models import Meeting, Course  
from datetime import datetime
from ..decorator import azure_ad_required


@api_view(['GET'])
# @csrf_exempt
# @azure_ad_required
def meetingListV2(request):
    meetings = Meeting.objects.filter(is_active=True)
    # meetings = Meeting.objects.all()
    serializer = MeetingSerializer(meetings, many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)