from django.urls import path
# from . import views
from .viewset import generateOTPViewset as genearteOTPViewset
from .viewset import dashboardViewset as dashboardViewset
from .viewset import meetingViewset as meetingViewset
from .viewset import attendanceLogViewset as attendanceLogViewset
from .viewset import assessmentViewset as assessmentViewset
from .viewset import EmployeeDetailsViewset as EmployeeDetailsViewset
from .viewset import meetingViewsetV2 as meetingViewsetV2

urlpatterns = [
    #  Creating Meeting API's
    path('create_meeting/', meetingViewset.create_meeting, name='create_meeting'),
    
    # Attendance Dashboard API's
    path('inprogress_to_complete_meeting_status/<int:pk>/', dashboardViewset.update_inprogress_status_to_completed, name='update_inprogress_status_to_completed'),
    path('complete_to_inprogress_meeting_status/<int:pk>/', dashboardViewset.update_completed_status_to_inprogress, name='update_completed_status_to_inprogress'),
    path('meetings_list/', dashboardViewset.meetings_list, name='meetings_list'),
    path('attendance_list/', dashboardViewset.attendance_list, name='attendance_list'),

    # Attendance Log API's
    path('get_meetings/', attendanceLogViewset.get_meetings, name='get_meetings'),
    path('get_required_employees/<int:meeting_id>/', attendanceLogViewset.get_required_employees, name='get_required_employees'),
    path('log_attendance/', attendanceLogViewset.log_attendance, name='log_attendance'),

    # Meeting Update API's
    path('get_meetings_inprogress/', meetingViewset.meetings_list_inprogress, name='meetings_list_inprogress'),
    path('get_courses/', meetingViewset.get_courses, name='get_courses'),
    path('get_employees/', meetingViewset.get_employees, name='get_employees'),
    path('meetings_inprogress_list/<int:pk>/', meetingViewset.meetings_inprogress_list, name='meetings_inprogress_list'),
    path('update_meeting/<int:meeting_id>/', meetingViewset.update_meeting, name='update_meeting'),    
    path('delete_meeting/<int:meeting_id>/', meetingViewset.delete_meeting, name='delete_meeting'),
    path('get_locations/', meetingViewset.get_locations, name='get_locations'),

    # generate OTP API's
    path('generate_otp/', genearteOTPViewset.generate_otp, name='generate_otp'),
    path('verify_otp/', genearteOTPViewset.verify_otp, name='generate_otp'),
    path('attendance-submit-by-employee_id/', genearteOTPViewset.attendanceSubmitByEmployee, name='attendance-submit-by-employee_id'),

    # Assessment API's
    path('create-questions/', assessmentViewset.QuestionCreation, name='create_questions'),
    path('save_questions/', assessmentViewset.save_questions, name='save_questions'),
    # path('preview_form/', genearteOTPViewset.preview_form, name='preview_form'),
    # path('meeting_question_detail/<int:pk>', genearteOTPViewset.meeting_question_detail, name='meeting_question_detail')
    
    path('meeting_question_detail/<int:meeting_id>/<str:date>/', assessmentViewset.meeting_question_detail, 
     name='meeting_question_detail'),
     path('submit-answers/', assessmentViewset.submit_answers, name='submit-answers'),
     path('assessment-results/<int:meeting_id>/<str:creationDate>', assessmentViewset.assessment_results, name='assessment-results'),

    #  upload employee Details API
    path('upload-employees/', EmployeeDetailsViewset.UploadEmployeeData, name='upload-employees'),

    path('meetingListV2/', meetingViewsetV2.meetingListV2, name='meetingListV2'),
]


