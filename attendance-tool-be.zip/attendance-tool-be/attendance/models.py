from django.db import models
from django.utils import timezone

class Employee(models.Model):
    name = models.CharField(max_length=100)
    employee_id = models.CharField(max_length=20, unique=True)
    email = models.EmailField(unique=True)
    vertical = models.CharField(max_length=100)
    designation = models.CharField(max_length=100, null=True)
    reporting_to = models.CharField(max_length=255, null=True, blank=True)
    is_trainer = models.BooleanField(default=True)

    def __str__(self):
        return self.name


class Course(models.Model):
    course_name = models.CharField(max_length=100)

    def __str__(self):
        return self.course_name
    
class Location(models.Model):
    location_name=models.CharField(max_length=100, null=True, blank=True)

    def __str__(self):
        return self.location_name

class Meeting(models.Model):
    STATUS_IN_PROGRESS = 'in_progress'
    STATUS_COMPLETED = 'completed'
    STATUS_CHOICES = [
        (STATUS_IN_PROGRESS, 'In Progress'),
        (STATUS_COMPLETED, 'Completed'),
    ]
    meeting_name = models.CharField(max_length=100)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    trainer_name = models.ManyToManyField(Employee, related_name='meeting_trainer_names')
    start_date = models.DateField()
    end_date = models.DateField()
    start_time = models.TimeField(null=True) 
    end_time = models.TimeField(null=True)   
    required_employees = models.ManyToManyField(Employee, related_name='required_meetings')
    type = models.CharField(max_length=100, null=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_IN_PROGRESS)
    online_url = models.CharField(max_length=200, null=True, blank=True)
    location = models.ForeignKey(Location, on_delete=models.CASCADE, null=True, blank=True)
    is_active = models.BooleanField(default=True)
    def __str__(self):
        return f'{self.meeting_name} - {self.course.course_name}'


class Attendance(models.Model):
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    meeting = models.ForeignKey(Meeting, on_delete=models.CASCADE, null=True, blank=True)
    date = models.DateField(default=timezone.now)
    
    def __str__(self):
        return f'{self.employee.name} attended {self.meeting.meeting_name} on {self.date}'

class Question(models.Model):
    meeting = models.ForeignKey(Meeting, related_name='questions', on_delete=models.CASCADE)
    question_sqn_id = models.IntegerField(null=True, blank=True)
    question_type = models.CharField(max_length=50)
    question_text = models.TextField()
    options = models.JSONField(default=list)  # Store options as a list
    required = models.BooleanField(default=False)
    acceptedAnswer = models.CharField(max_length=500, null=True, blank=True)
    creationDate = models.DateField(null=True, blank=True)

class AssessmentAnswers(models.Model):
    meeting = models.ForeignKey(Meeting, on_delete=models.CASCADE)
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, null=True)
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    participant_answers = models.CharField(max_length=200, null=True, blank=True)
    submited_date = models.DateField(null=True, blank=True)
    creationDate=models.DateField(null=True, blank=True)
    marks = models.FloatField(default=0.0)

class AssessmentUrl(models.Model):
    meeting = models.ForeignKey(Meeting, on_delete=models.CASCADE)
    creationDate = models.DateField(null=True, blank=True)
    url = models.CharField(max_length=500, null=True, blank=True)