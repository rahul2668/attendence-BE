from rest_framework import serializers
from .models import Employee, Course, Meeting, Attendance, Location, AssessmentAnswers, Question, AssessmentUrl

class EmployeeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Employee
        fields = '__all__'

class CourseSerializer(serializers.ModelSerializer):
    class Meta:
        model = Course
        fields = '__all__'

class LocationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Location
        fields = ['id', 'location_name']

# class AsssessmentURLSerializer(serializers.ModelSerializer):
#     class Meta:
#         model=AssessmentUrl
#         fields = ['url', 'creationDate']
class MeetingSerializer(serializers.ModelSerializer):
    required_employees = EmployeeSerializer(many=True)
    trainer_name = EmployeeSerializer(many=True)
    course = CourseSerializer()
    location = LocationSerializer()
    # assessment = serializers.SerializerMethodField()

    class Meta:
        model = Meeting
        fields = [
            'id', 'meeting_name', 'course', 'start_date', 'end_date', 
            'start_time', 'end_time', 'required_employees', 'trainer_name', 
            'type', 'status', 'location', 'online_url', 'location', #'assessment'
        ]
    # def get_assessment(self, obj):
    #     assessments = AssessmentUrl.objects.filter(meeting=obj)
    #     return AsssessmentURLSerializer(assessments, many=True).data
    
    def create(self, validated_data):
        employees_data = validated_data.pop('required_employees')
        meeting = Meeting.objects.create(**validated_data)
        meeting.required_employees.set(employees_data)
        return meeting

    def update(self, instance, validated_data):
        employees_data = validated_data.pop('required_employees')
        instance.meeting_name = validated_data.get('meeting_name', instance.meeting_name)
        instance.course = validated_data.get('course', instance.course)
        instance.start_date = validated_data.get('start_date', instance.start_date)
        instance.end_date = validated_data.get('end_date', instance.end_date)
        instance.start_time = validated_data.get('start_time', instance.start_time)
        instance.end_time = validated_data.get('end_time', instance.end_time)
        instance.trainer_name = validated_data.get('trainer_name', instance.trainer_name)
        instance.type = validated_data.get('type', instance.type)
        instance.status = validated_data.get('status', instance.status)
        instance.save()

        instance.required_employees.set(employees_data)
        return instance


class CreateMeetingSerializer(serializers.ModelSerializer):
    required_employees = serializers.PrimaryKeyRelatedField(many=True, queryset=Employee.objects.all())
    trainer_name = serializers.PrimaryKeyRelatedField(many=True, queryset=Employee.objects.all())
    course = serializers.CharField(required=False)  # Accept course as string for validation

    class Meta:
        model = Meeting
        fields = [
            'id', 'meeting_name', 'course', 'start_date', 'end_date', 
            'start_time', 'end_time', 'required_employees', 'trainer_name', 
            'type', 'status', 'online_url', 'location'
        ]


    def create(self, validated_data):
        course_value = validated_data.pop('course')

        # Determine the course based on the value of `course`
        if isinstance(course_value, int):  # If course is an integer (ID)
            try:
                course = Course.objects.get(id=course_value)
            except Course.DoesNotExist:
                raise serializers.ValidationError({"course": "Course not found."})

        elif isinstance(course_value, str):  # If course is a string (name)
            course, _ = Course.objects.get_or_create(course_name=course_value)
            
        else:
            raise serializers.ValidationError({"course": "Invalid course value."})


        validated_data['course'] = course
        return super().create(validated_data)

class AttendanceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Attendance
        fields = '__all__'

class MeetingListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Meeting
        fields = ['id', 'meeting_name']


class MeetingDetailsSerializer(serializers.ModelSerializer):
    trainer_name = serializers.CharField(source='trainer_name.name')
    required_employees = serializers.PrimaryKeyRelatedField(queryset=Employee.objects.all(), many=True)
    
    class Meta:
        model = Meeting
        fields = ['trainer_name', 'start_date', 'end_date', 'start_time', 'end_time', 'type', 'required_employees']


class AttendanceListSerializer(serializers.ModelSerializer):
    employee_id = serializers.CharField(source='employee.employee_id')
    employee_name = serializers.CharField(source='employee.name')
    vertical = serializers.CharField(source='employee.vertical')
    email = serializers.CharField(source="employee.email")
    designation = serializers.CharField(source="employee.designation")

    class Meta:
        model = Attendance
        fields = [
            'employee_id', 
            'employee_name', 
            'date', 
            'vertical', 
            'email', 
            'designation'
        ]


class UpdateMeetingSerializer(serializers.ModelSerializer):
    required_employees = serializers.PrimaryKeyRelatedField(
        many=True, queryset=Employee.objects.all()
    )
    
    class Meta:
        model = Meeting
        fields = ['meeting_name', 'course', 'trainer_name', 'start_date', 'end_date', 'start_time', 'end_time', 'required_employees', 'type', 'status', 'location', 'online_url']

class TestEmployeeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Employee
        fields = ['id', 'employee_name', 'email', 'designation', 'vertical']

class TestAttendanceListSerializer(serializers.ModelSerializer):
    employee = EmployeeSerializer()

    class Meta:
        model = Attendance
        fields = ['employee', 'date',]  

class TestMeetingDetailsSerializer(serializers.ModelSerializer):
    # trainer_name = serializers.CharField(source='trainer_name.name')
    trainer_name = serializers.StringRelatedField(many=True) 
    required_employees = EmployeeSerializer(many=True) 
    location = serializers.CharField(source='location.location_name')

    class Meta:
        model = Meeting
        fields = ['trainer_name', 'start_date', 'end_date', 'start_time', 'end_time', 'type', 'required_employees', 'location', 'meeting_name']

class QuestionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Question
        fields = ['question_sqn_id', 'question_type', 'question_text', 'options', 'required', 'acceptedAnswer', 'creationDate']

class QuestionMeetingSerializer(serializers.ModelSerializer):
    questions = QuestionSerializer(many=True, read_only=True) 

    class Meta:
        model = Meeting
        fields = ['id', 'meeting_name', 'questions'] 
    
class QuestionListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Question
        fields = ['question_sqn_id', 'question_type', 'question_text', 'options', 'required', 'creationDate']

class MeetingWithQuestionsSerializer(serializers.ModelSerializer):
    questions = QuestionListSerializer(many=True, read_only=True)

    class Meta:
        model = Meeting
        fields = ['meeting_name', 'questions'] 

class AssessmentAnswersSerializer(serializers.ModelSerializer):
    employees = EmployeeSerializer(many=True, source='meeting.required_employees')

    class Meta:
        model = AssessmentAnswers
        fields = ['employees', 'marks']  

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        flattened_employees = []
        for emp in representation['employees']:
            flattened_employees.append({
                'employee_id': emp['employee_id'],
                'email': emp['email'],
                'name': emp['name'],
                'designation': emp['designation'],
                'marks': representation['marks']
            })
        return flattened_employees
    

class MeetingSerializerV2(serializers.ModelSerializer):
    course_name = serializers.CharField(source='course.course_name')
    location_name = serializers.CharField(source='location.location_name', allow_null=True)
    trainer_name = serializers.SerializerMethodField()

    class Meta:
        model = Meeting
        fields = [
            'id', 'meeting_name', 'course_name', 'trainer_name',
            'start_date', 'end_date', 'start_time', 'end_time',
            'type', 'status', 'online_url', 'location_name', 'is_active'
        ]
    def get_trainer_name(self, obj):
        # Return a list of trainer names
        return [trainer.name for trainer in obj.trainer_name.all()]