# your_app/decorators.py

from functools import wraps
from django.http import JsonResponse
from azure_ad_verify_token import verify  # Replace with the correct function name

def verify_azure_ad_token(request):
    token = request.META.get('HTTP_AUTHORIZATION')
    print("****Token Valid")
    # cliend_id='858b70ef-0bfe-4812-ab5e-a07d68cd43a6'
    cliend_id='ce82faf1-2a43-4bc8-beda-e1347f79c066'

    if not token or not token.startswith('Bearer '):
        return None

    token = token.split(' ')[1]

    try:
        payload = verify(token, audience=cliend_id)
        return payload
    except Exception:
        return Exception

def azure_ad_required(view_func):
    @wraps(view_func)
    def _wrapped_view(request, *args, **kwargs):
        payload = verify_azure_ad_token(request)

        if payload is None:
            return JsonResponse({'error': 'Unauthorized'}, status=401)

        request.user = payload
        return view_func(request, *args, **kwargs)

    return _wrapped_view
