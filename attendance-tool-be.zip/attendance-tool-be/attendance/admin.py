from django.contrib import admin
from .models import Employee, Course, Attendance
# MeetingAttendance

admin.site.register(Employee)
admin.site.register(Course)
admin.site.register(Attendance)
# admin.site.register(MeetingAttendance)