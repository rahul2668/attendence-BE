from django.db import models

class FormData(models.Model):
    username = models.CharField(max_length=50)
    file_name = models.TextField()
    json_data = models.TextField()
    template_name = models.TextField(null=True, blank=True)
    class Meta:
        db_table = 'formData'


