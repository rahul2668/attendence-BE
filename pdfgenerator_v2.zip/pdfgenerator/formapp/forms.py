from django import forms

class JSONForm(forms.Form):
    json_input = forms.CharField(label='JSON Input', widget=forms.Textarea)
