# ************************************ HTML to PDF ************************************
from django.shortcuts import render
from django.http import HttpResponse, HttpResponseBadRequest, JsonResponse
from xhtml2pdf import pisa
import json
from .models import FormData
from .global_strings import MANDATORY_FIELDS
import os
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
from docx import Document
from docx2pdf import convert

import os
import json
from django.conf import settings
from django.http import HttpResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx2pdf import convert
from .models import FormData

def html_upload_and_review(request):
    if request.method == 'POST':
        json_data_str = request.POST.get('json_data')
        html_template_file = request.FILES.get('html_template')
 
        if not json_data_str:
            error_message = 'Please provide JSON data.'
            return render_error(request, error_message)
 
        try:
            json_data = json.loads(json_data_str)
        except json.JSONDecodeError as e:
            error_message = f'Invalid JSON data: {e}'
            return render_error(request, error_message)
 
        for field, expected_type in MANDATORY_FIELDS.items():
            if field not in json_data:
                error_message = f'Missing mandatory field: {field}'
                return render_error(request, error_message)
            if not json_data[field]:
                error_message = f'Empty value for field: {field}'
                return render_error(request, error_message)
            if not isinstance(json_data[field], expected_type):
                error_message = f'Invalid type for field {field}. Expected {expected_type.__name__}'
                return render_error(request, error_message)
 
        html_content = html_template_file.read().decode('utf-8')
        uploaded_filename = html_template_file.name
        for key, value in json_data.items():
            placeholder = f'{{{{ json_data.{key} }}}}'
            html_content = html_content.replace(placeholder, str(value))
 
        context = {
            'html_content': html_content,
            'json_data': json_data,
            'uploaded_filename':uploaded_filename,
        }
        return render(request, 'jsonapp/review.html', context)
 
    return render(request, 'jsonapp/upload.html')
 
def render_error(request, error_message):
    context = {
        'error_message': error_message,
    }
    return render(request, 'jsonapp/error.html', context)
 
@csrf_exempt
def html_generate_pdf(request):
    if request.method == 'POST':
        html_content = request.POST.get('html_content')
        json_data_str = request.POST.get('json_data')
        uploaded_filename = request.POST.get('uploaded_filename')
 
        if not html_content:
            return HttpResponseBadRequest('No HTML content found in the request.')
        if not json_data_str:
            return HttpResponseBadRequest('No JSON data found in the request.')
 
        try:
            json_data_str = json_data_str.replace("'", '"')
            json_data = json.loads(json_data_str)
        except json.JSONDecodeError as e:
            return HttpResponseBadRequest(f'Error decoding JSON: {str(e)}')
 
        user_name = json_data.get('first_name', 'Unknown')
        combined_filename = f"{user_name}_{uploaded_filename.split('.')[0]}.pdf"
 
        try:
            form_data = FormData(
                username=user_name,
                file_name=combined_filename,
                json_data=json_data_str,
                template_name=uploaded_filename
            )
            form_data.save()
        except Exception as e:
            return HttpResponseBadRequest(f'Error saving to database: {str(e)}')
 
        return JsonResponse({'message': 'Data saved successfully'})
 
    return HttpResponseBadRequest('Invalid request method.')
 
 

# ************************************ DOC to PDF ************************************

def render_error(request, error_message):
    context = {'error_message': error_message}
    return render(request, 'jsonapp/error.html', context)
 
def replace_placeholders_in_runs(runs, json_data):
    for run in runs:
        for key, value in json_data.items():
            placeholder = f'{{{key}}}'
            if placeholder in run.text:
                run.text = run.text.replace(placeholder, str(value))
                run.font.size = Pt(12)
                run.font.bold = True
                run.font.italic = True
 
def replace_placeholders_in_paragraphs(paragraphs, json_data):
    for para in paragraphs:
        replace_placeholders_in_runs(para.runs, json_data)
        for key, value in json_data.items():
            placeholder = f'{{{key}}}'
            if placeholder in para.text:
                para.text = para.text.replace(placeholder, str(value))
                para.alignment = WD_ALIGN_PARAGRAPH.CENTER
 
def replace_placeholders_in_tables(tables, json_data):
    for table in tables:
        for row in table.rows:
            for cell in row.cells:
                replace_placeholders_in_paragraphs(cell.paragraphs, json_data)
 
def replace_placeholders_in_headers_footers(sections, json_data):
    for section in sections:
        for header in section.header.paragraphs:
            replace_placeholders_in_runs(header.runs, json_data)
        for footer in section.footer.paragraphs:
            replace_placeholders_in_runs(footer.runs, json_data)
 
def replace_placeholders_in_document(doc, json_data):
    replace_placeholders_in_paragraphs(doc.paragraphs, json_data)
    replace_placeholders_in_tables(doc.tables, json_data)
    replace_placeholders_in_headers_footers(doc.sections, json_data)
 
@csrf_exempt
def doc_upload_and_review(request):
    if request.method == 'POST':
        json_data_str = request.POST.get('json_data')
        doc_template_file = request.FILES.get('doc_template')
 
        if not json_data_str:
            return render_error(request, 'Please provide JSON data.')
 
        try:
            json_data = json.loads(json_data_str)
        except json.JSONDecodeError as e:
            return render_error(request, f'Invalid JSON data: {e}')
 
        user_name = json_data.get('first_name', 'Unknown')
 
        uploaded_filename = doc_template_file.name
        combined_filename = f"{user_name}_{uploaded_filename.split('.')[0]}.pdf"
 
        try:
            doc = Document(doc_template_file)
            replace_placeholders_in_document(doc, json_data)
            modified_doc_path = os.path.join(settings.MEDIA_ROOT, 'modified_doc.docx')
            doc.save(modified_doc_path)
            pdf_path = os.path.join(settings.MEDIA_ROOT, combined_filename)
            convert(modified_doc_path, pdf_path)
            form_data = FormData.objects.create(
                username=user_name,
                file_name=combined_filename,
                json_data=json_data_str,
                template_name=doc_template_file.name
            )
            form_data.save()
            with open(pdf_path, 'rb') as pdf_file:
                response = HttpResponse(pdf_file.read(), content_type='application/pdf')
                response['Content-Disposition'] = f'attachment; filename={combined_filename}'
                return response
 
        except Exception as e:
            return render_error(request, f'Error processing DOC file: {e}')
 
    return render(request, 'jsonapp/upload_docx.html')
 
 
 