from django.urls import path
from . import views
 
urlpatterns = [
    path('htmltopdf', views.html_upload_and_review, name='html_upload_and_review'),
    path('html_generate_pdf', views.html_generate_pdf, name='html_generate_pdf'),
 
   
    path('doctopdf', views.doc_upload_and_review, name='doc_upload_and_review'),  
]
 
 