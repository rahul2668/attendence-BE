MANDATORY_FIELDS={
    "display_name": str,
    "name": str,
    "first_name": str,
    "last_name": str,
    "email": str,
    "date":str,
    "event_name":str,
    }

# {
# 'display_name': str,
# 'name': str,
# 'first_name': str,
# 'last_name': str,
# 'email': str,
# 'password': str,
# 'active': bool,
# }


