import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import englishTranslation from './locales/english/en.json';
import frenchTranslation from './locales/french/fr.json';
import spanishTranslation from './locales/spanish/es.json';

i18n.use(initReactI18next).init({
  lng: 'en',
  fallbackLng: 'en',
  interpolation: {
    escapeValue: false,
  },
  resources: {
    en: {
      translation: englishTranslation,
    },
    fr: {
      translation: frenchTranslation,
    },
    es: {
      translation: spanishTranslation,
    },
  },
});

export default i18n;
