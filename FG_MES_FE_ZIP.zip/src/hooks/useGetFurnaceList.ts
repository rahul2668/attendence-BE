import { useEffect } from 'react';
import { useAppDispatch, useAppSelector } from 'store';
import { getFurnaceList } from 'store/slices/furnaceListSlice';

const useGetFurnaceList = () => {
  const dispatch = useAppDispatch();

  useEffect(() => {
    // Dispatch the getPlant action and handle the Promise
    dispatch(getFurnaceList())
      .then((response: any) => {
        // Handle successful response here
        console.log('Response', response);
      })
      .catch((error: any) => {
        // Handle error here
        console.error('Error', error);
      });
  }, []);

  const getFurnaceListData = useAppSelector((state) => state.furnace_config);

  return getFurnaceListData;
};

export { useGetFurnaceList };
