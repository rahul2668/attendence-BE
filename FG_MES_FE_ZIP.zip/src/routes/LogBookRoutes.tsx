import { lazy } from 'react';
import { Navigate } from 'react-router-dom';
import { hasPermission } from 'utils/utils';
import { getRouteElement } from './RouteUtils';
import { paths } from './paths';
import { FURNACE_BED_LOG, FURNACE_DOWNTIME_LOG, TAP_HOLE_LOG } from './Routes';

const furnaceBedLog = lazy(() => import('pages/LogBook/FurnaceBed/FurnaceBedLogList'));
const tapHoleLog = lazy(() => import('pages/LogBook/TapHole/TapHoleLogList'));
const furnaceDowntimeLog = lazy(() => import('pages/LogBook/FurnaceDowntime/FurnaceDowntimeList'));
const renderDashboard = <Navigate to={paths.dashboard} />;

export const LogBookRoutes = [
  {
    path: FURNACE_BED_LOG,
    element: hasPermission(FURNACE_BED_LOG)
      ? getRouteElement(furnaceBedLog, true)
      : renderDashboard,
  },
  {
    path: TAP_HOLE_LOG,
    element: hasPermission(TAP_HOLE_LOG) ? getRouteElement(tapHoleLog, true) : renderDashboard,
  },
  {
    path: FURNACE_DOWNTIME_LOG,
    element: hasPermission(FURNACE_DOWNTIME_LOG)
      ? getRouteElement(furnaceDowntimeLog, true)
      : renderDashboard,
  },
];
