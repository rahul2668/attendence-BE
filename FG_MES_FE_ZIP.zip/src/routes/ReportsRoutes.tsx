//import { crudType, permissionsMapper } from 'utils/constants';
//import { validatePermissions } from 'utils/utils';
import { getRouteElement } from './RouteUtils';
import { lazy } from 'react';
import { paths } from './paths';

/*const hasEditPermission = (path: string) => {
  const module = path?.split('/')[1];
  const subModule = path?.split('/')[2];
  if (module && subModule)
    return validatePermissions(
      permissionsMapper[module],
      permissionsMapper[subModule],
      crudType.edit
    );
};

const hasCreatePermission = (path: string) => {
  const module = path?.split('/')[1];
  const subModule = path?.split('/')[2];
  if (module && subModule)
    return validatePermissions(
      permissionsMapper[module],
      permissionsMapper[subModule],
      crudType.create
    );
};

const hasPermission = (path: string) => {
  const module = path?.split('/')[1];
  const subModule = path?.split('/')[2];
  if (module && subModule)
    return validatePermissions(
      permissionsMapper[module],
      permissionsMapper[subModule],
      crudType.view
    );
};*/
const ConsumptionReportScreen = lazy(() => import('pages/Dashboard/MaterialConsumptionBox'));

const AnalysisReportScreen = lazy(() => import('pages/Dashboard/MaterialAnalysisReport'));

const SizeAnalysisReportScreen = lazy(() => import('pages/Dashboard/MaterialAnalysisSizeReport'));

export const ReportsRoutes = [
  {
    path: paths.consumptionReport,
    element: getRouteElement(ConsumptionReportScreen, true),
  },
  {
    path: paths.analysisReport,
    element: getRouteElement(AnalysisReportScreen, true),
  },
  {
    path: paths.sizeAnalysisReport,
    element: getRouteElement(SizeAnalysisReportScreen, true),
  },
];
