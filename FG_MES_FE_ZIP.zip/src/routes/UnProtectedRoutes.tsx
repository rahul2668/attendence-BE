import { getSessionStorage } from 'utils/utils';
import { paths } from './paths';
import { Navigate } from 'react-router-dom';

const UnProtectedRoutes = ({ children }: any) => {
  const authToken = getSessionStorage('accessToken');
  return !authToken ? children : <Navigate to={`${paths.dashboard}`} />;
};

export default UnProtectedRoutes;
