import { paths } from './paths';
import { lazy } from 'react';
import { Navigate } from 'react-router-dom';
import { getRouteElement } from './RouteUtils';
import { validatePermissions } from 'utils/utils';
import { crudType, permissionsMapper } from 'utils/constants';

const hasEditPermission = (path: string) => {
  const module = path?.split('/')[1];
  const subModule = path?.split('/')[2];
  if (module && subModule)
    return validatePermissions(
      permissionsMapper[module],
      permissionsMapper[subModule],
      crudType.edit
    );
};

const hasCreatePermission = (path: string) => {
  const module = path?.split('/')[1];
  const subModule = path?.split('/')[2];
  if (module && subModule)
    return validatePermissions(
      permissionsMapper[module],
      permissionsMapper[subModule],
      crudType.create
    );
};

const hasViewPermission = (path: string) => {
  const module = path?.split('/')[1];
  const subModule = path?.split('/')[2];
  if (module && subModule)
    return validatePermissions(
      permissionsMapper[module],
      permissionsMapper[subModule],
      crudType.view
    );
};

const renderDashboard = <Navigate to={paths.dashboard} />;

//additive maintenance
const AdditiveMaintenanceList = lazy(
  () => import('pages/MasterData/Additive/AdditiveMaintenceList')
);
const AdditiveMaintenanceView = lazy(() => import('pages/MasterData/Additive/TabHeader'));

//furnace material maintenance
const FurnaceMaterialMaintenanceList = lazy(
  () => import('pages/MasterData/FurnaceMaterialMaintenace/FurnaceMaterialMaintenaceList')
);
const FurnaceMaterialMaintenanceView = lazy(
  () => import('pages/MasterData/FurnaceMaterialMaintenace/TabHeader')
);

// By Products

const ByProductsList = lazy(() => import('pages/MasterData/ByProducts/byProductListing'));
const ByProductsView = lazy(() => import('pages/MasterData/ByProducts/TabHeader'));

// By WIP

const WIPList = lazy(() => import('pages/MasterData/WIP/wipList'));
const WIPView = lazy(() => import('pages/MasterData/WIP/TabHeader'));

export const MasterDataRoutes = [
  // additive maintenance
  {
    path: paths.additiveMaintenance.list,
    element: hasViewPermission(paths.additiveMaintenance.view)
      ? getRouteElement(AdditiveMaintenanceList, true)
      : renderDashboard,
  },
  {
    path: `${paths.additiveMaintenance.view}/:id`,
    element: hasViewPermission(paths.additiveMaintenance.view)
      ? getRouteElement(AdditiveMaintenanceView, true)
      : renderDashboard,
  },
  {
    path: `${paths.additiveMaintenance.create}/:id`,
    element: hasCreatePermission(paths.additiveMaintenance.create)
      ? getRouteElement(AdditiveMaintenanceView, true)
      : renderDashboard,
  },
  {
    path: `${paths.additiveMaintenance.edit}/:id`,
    element: hasEditPermission(paths.additiveMaintenance.edit)
      ? getRouteElement(AdditiveMaintenanceView, true)
      : renderDashboard,
  },
  {
    path: paths.additiveMaintenance.analysisValue,
    element: getRouteElement(AdditiveMaintenanceView, true),
  },

  //furnace material maintenance
  {
    path: paths.furnaceMaterialMaintenance.list,
    element: hasViewPermission(paths.furnaceMaterialMaintenance.view)
      ? getRouteElement(FurnaceMaterialMaintenanceList, true)
      : renderDashboard,
  },
  {
    path: `${paths.furnaceMaterialMaintenance.view}/:id`,
    element: hasViewPermission(paths.furnaceMaterialMaintenance.view)
      ? getRouteElement(FurnaceMaterialMaintenanceView, true)
      : renderDashboard,
  },
  {
    path: `${paths.furnaceMaterialMaintenance.create}/:id`,
    element: hasCreatePermission(paths.furnaceMaterialMaintenance.create)
      ? getRouteElement(FurnaceMaterialMaintenanceView, true)
      : renderDashboard,
  },
  {
    path: `${paths.furnaceMaterialMaintenance.edit}/:id`,
    element: hasEditPermission(paths.furnaceMaterialMaintenance.edit)
      ? getRouteElement(FurnaceMaterialMaintenanceView, true)
      : renderDashboard,
  },

  // By Products

  {
    path: paths.byProducts.list,
    element: hasViewPermission(paths.byProducts.view)
      ? getRouteElement(ByProductsList, true)
      : renderDashboard,
  },
  {
    path: `${paths.byProducts.view}/:id`,
    element: hasViewPermission(paths.byProducts.view)
      ? getRouteElement(ByProductsView, true)
      : renderDashboard,
  },
  {
    path: `${paths.byProducts.create}/:id`,
    element: hasCreatePermission(paths.byProducts.create)
      ? getRouteElement(ByProductsView, true)
      : renderDashboard,
  },
  {
    path: `${paths.byProducts.edit}/:id`,
    element: hasEditPermission(paths.additiveMaintenance.edit)
      ? getRouteElement(ByProductsView, true)
      : renderDashboard,
  },

  // WIP

  {
    path: paths.wip.list,
    element: hasViewPermission(paths.wip.view) ? getRouteElement(WIPList, true) : renderDashboard,
  },
  {
    path: `${paths.wip.view}/:id`,
    element: hasViewPermission(paths.wip.view) ? getRouteElement(WIPView, true) : renderDashboard,
  },
  {
    path: `${paths.wip.create}/:id`,
    element: hasCreatePermission(paths.wip.create)
      ? getRouteElement(WIPView, true)
      : renderDashboard,
  },
  {
    path: `${paths.wip.edit}/:id`,
    element: hasEditPermission(paths.wip.edit) ? getRouteElement(WIPView, true) : renderDashboard,
  },

  //redirection routes
  { path: '', element: <Navigate to={paths.dashboard} /> },
  { path: '*', element: <Navigate to={paths.dashboard} /> },
];
