import { paths } from 'routes/paths';
import { getRouteElement } from './RouteUtils';
import { MasterDataRoutes } from './MasterDataRoutes';
import { createBrowserRouter, Navigate, Outlet } from 'react-router-dom';
import { UserAccessControlRoutes } from './UserAccessControlRoutes';
import { SystemAdminRoutes } from './SystemAdmin';
import { ReportsRoutes } from './ReportsRoutes';
import Layout from '../Layout';
import Login from '../components/auth/Login';
import Dashboard from '../pages/Dashboard/Dashboard';
import ErrorBoundary from 'components/common/ErrorBoundary/ErrorBoundary';
import TimeOut from 'components/common/SessionInactive';
import { LogBookRoutes } from './LogBookRoutes';

const ErrorBoundaryLayout = () => (
  <ErrorBoundary>
    <Outlet />
    <TimeOut />
  </ErrorBoundary>
);

const routes = [
  {
    path: '/',
    element: getRouteElement(Layout, true),
    children: [
      {
        path: '',
        element: <Navigate to='/dashboard' />,
      },
      {
        path: paths.dashboard,
        element: getRouteElement(Dashboard, true),
      },
      { path: '*', element: <Navigate to='/dashboard' /> },
      { path: '', element: <Navigate to={paths.dashboard} /> },
      { path: paths.dashboard, element: getRouteElement(Dashboard, true) },
    ],
  },
  {
    path: paths.masterData,
    element: getRouteElement(Layout, true),
    children: MasterDataRoutes,
  },
  {
    path: paths.userAccessControl,
    element: getRouteElement(Layout, true),
    children: UserAccessControlRoutes,
  },
  {
    path: paths.plant,
    element: getRouteElement(Layout, true),
    children: SystemAdminRoutes,
  },

  {
    path: paths.logBook,
    element: getRouteElement(Layout, true),
    children: LogBookRoutes,
  },
  { path: paths.reports, element: getRouteElement(Layout, true), children: ReportsRoutes },
  { path: paths.login, element: getRouteElement(Login, false) },
  { path: '', element: <Navigate to={paths.dashboard} /> },
];
export const AppRouter = createBrowserRouter([
  {
    element: <ErrorBoundaryLayout />,
    children: routes,
  },
]);
