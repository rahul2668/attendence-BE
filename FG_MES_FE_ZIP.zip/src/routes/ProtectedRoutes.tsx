import { Navigate } from 'react-router-dom';
import { paths } from './paths';
import { getSessionStorage } from 'utils/utils';

const ProtectedRoutes = ({ children }: any) => {
  const authenticated = getSessionStorage('accessToken');
  return authenticated ? children : <Navigate to={`${paths.login}`} />;
};

export default ProtectedRoutes;
