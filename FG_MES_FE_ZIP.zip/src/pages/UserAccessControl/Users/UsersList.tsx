import { useEffect, useState } from 'react';
import copy from '../../../assets/icons/copy.svg';
import 'assets/styles/scss/pages/dashboard.scss';
import 'assets/styles/scss/components/table-general.scss';
import { useLocation, useNavigate } from 'react-router-dom';
import Header from 'components/common/MainHeader3';
import { paths } from 'routes/paths';
import Pagination from 'components/common/Pagination';
import httpClient from 'http/httpClient';
import { clearSessionStorage, notify, validatePermissions } from 'utils/utils';
import { crudType, permissionsMapper } from 'utils/constants';
import AlertModal from 'components/Modal/AlertModal';
import Loading from 'components/common/Loading';
import { useTranslation } from 'react-i18next';
import _ from 'lodash';
import ReusableTable from 'components/common/ReusableTable/ReusableTable';
import { formatUsers, generatePassword, toolTipsForUsers, userTableHeaders } from './helper';
import { useAppSelector } from 'store';
import GeneratePasswordModal from 'components/Modal/GeneratePasswordModel';
import MUIToolTip from 'components/common/ToolTip/MUIToolTip';
import { userLogout } from 'store/slices/authSlice';
import { useDispatch } from 'react-redux';

interface Role {
  id: number;
  role_name: string;
  // Other role properties
}

interface User {
  id: number;
  roles: number[]; // Assuming role IDs are stored in an array
  // Other user properties
}

const UsersList = () => {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const loggedInUserData = useAppSelector((state) => state.userData.userData);

  const [users, setUsers] = useState<any>([]);
  const itemsPerPage = 10;
  const [count, setCount] = useState(null);
  const [previous, setPrevious] = useState(null);
  const [next, setNext] = useState(null);
  const [callApi, setCallApi] = useState(false);
  const [loading, setLoading] = useState(true);
  const [allRoles, setAllRoles] = useState<any>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [usersDataToSearch, setUsersDataToSearch] = useState([]);
  const [usersList, setUsersList] = useState([]);

  // data state passed to the reusable table
  const [renderedUserData, setRenderedUserData] = useState<any>([]);
  // deactivate/activate/reset modal control state
  const [showDeactivateOrActivateModal, setShowDeactivateOrActivateModal] =
    useState<boolean>(false); // reset dialogue uses same modal
  // Same modal is used for activate, deactivate and reset. so the texts passes are stored in these states
  const [modalConfirmButtonText, setModalConfirmButtonText] = useState<string>(''); // stores if the current flow is deactivate or activate
  const [modalTitle, setModalTitle] = useState('');
  const [modalContent, setModalContent] = useState('');
  // since the activate and deactivate has confirm modals, the userData is temporarily stored in a state
  const [selectedUserData, setSelectedUserData] = useState<any>();
  const [currentAction, setCurrentAction] = useState<string>(''); // one modal is used for all things. need to know if its reset

  // need to store the newly generated password
  const [generatedPassword, setGeneratedPassword] = useState<string>(''); // one modal is used for all things. need to know if its reset
  const [showPasswordCopyModal, setShowPasswordCopyModal] = useState(false); // controls modal shown after reset of password

  // MAIN API
  const getUsers = (pageNumber: any) => {
    setLoading(true);
    setCurrentPage(1);
    let url = '';
    if (pageNumber === 1) {
      url = `/api/account/users/`;
    } else {
      url = `/api/users/?page=${pageNumber}&page_size=${itemsPerPage}`;
    }
    httpClient
      .get(url)
      .then((response: any) => {
        if (response.data) {
          const userData: any = [...response.data.results]?.map((user: any) => ({
            ...user,
            showModal: false,
            // is_delete: false
          }));
          setUsersList(userData);
          setUsersDataToSearch(userData);
          setCount(response.data.results.length);
          setPrevious(response.data.results); //???
          setNext(response.data.results); // ???
          setCallApi(false);
          setLoading(false);
        }
      })
      .catch((err) => {
        setLoading(false);
        console.log('errored -->', err);
      });
  };

  // ROLES GETTING API, MAYBE MOVE THIS TO BACKEND LOGIC?
  useEffect(() => {
    const getRolesAPI = async () => {
      httpClient
        // .get('/api/roles/?is_delete=false')
        .get('/api/account/roles/?is_delete=false')
        .then((response: any) => {
          if (response.data) {
            setAllRoles(response.data.results);
          }
        })
        .catch((err) => {
          console.log('errored -->', err);
        });
    };
    getRolesAPI();
  }, []);

  // ADD BUTTON IN HEADER'S FUNCTION
  const handleAddNewUser = () => {
    navigate(`${paths.addNewUser}`);
  };

  // FIRING MAIN API ON COMPONENT CALL
  useEffect(() => {
    getUsers(1);
  }, []);

  // this... no idea
  useEffect(() => {
    if (callApi) {
      getUsers(1);
    }
  }, [callApi]);

  // The data is Formatted to be used in reusable Table. The formatting is needed everywhere the reusable table is used
  useEffect(() => {
    setRenderedUserData(users.map(formatUsers));
  }, [users]);

  // front end pagination
  const onPageChange = (newPage: any) => {
    setCurrentPage(newPage);
    if (newPage !== 0) {
      const filterData = usersList.filter((val: any, index: any) => {
        if (index >= newPage * itemsPerPage - itemsPerPage && index < newPage * itemsPerPage) {
          return val;
        }
      });
      setUsers(filterData);
    }
  };

  // front end search  function
  const handleSearch = (searchValue: any) => {
    if (searchValue) {
      const filteredUser: any = usersDataToSearch.filter((item: any) => {
        // Convert searchValue to string for consistent comparison
        const searchString = searchValue.toString().toLowerCase();

        // Check if any field matches the search value
        return (
          item.id.toString().toLowerCase().includes(searchString) ||
          item.first_name.toLowerCase().includes(searchString) ||
          item.username.toLowerCase().includes(searchString) ||
          item.last_name.toLowerCase().includes(searchString)
        );
      });

      setUsers(filteredUser);
      setUsersList(filteredUser);
      setCount(filteredUser.length);
      setPrevious(filteredUser);
      setNext(filteredUser);
    } else {
      getUsers(1);
    }
  };

  // front end handling of filters
  const handleFilter = (filteredData: any) => {
    if (filteredData) {
      const filteredUser: any = usersDataToSearch.filter((item: any) => {
        // Convert searchValue to string for consistent comparison
        const searchString = filteredData?.search?.toString().toLowerCase();
        const filterSelect = filteredData?.is_active;

        // Check if any field matches the search value
        if (searchString && (filterSelect || filterSelect === false)) {
          return (
            item.roles
              ?.map((roleId: any) => {
                const role = allRoles.find((r: any) => r.id === roleId);

                return role ? role.role_name : null;
              })
              .some((element: any) => element?.toLowerCase().includes(searchString)) &&
            item?.is_delete !== filterSelect
          );
        } else if (searchString) {
          return item.roles
            ?.map((roleId: any) => {
              const role = allRoles.find((r: any) => r.id === roleId);

              return role ? role.role_name : null;
            })
            .some((element: any) => element?.toLowerCase().includes(searchString));
        } else if (filterSelect || filterSelect === false) {
          return item?.is_delete !== filterSelect;
        }
      });
      setUsers(filteredUser);
      setUsersList(filteredUser);
      setCount(filteredUser.length);
      setPrevious(filteredUser);
      setNext(filteredUser);
    } else {
      getUsers(1);
    }
  };

  // front end pagination related
  useEffect(() => {
    const filterData = usersList.filter((val: any, index: any) => {
      if (index >= 1 * itemsPerPage - itemsPerPage && index < 1 * itemsPerPage) {
        return val;
      }
    });
    setUsers(filterData);
  }, [usersList]);

  if (loading) return <Loading />;

  // if we change roles to backend, this can be removed
  const getUserRoles = (usersData: User[], rolesData: Role[]): string[] => {
    const userRoles: string[] = usersData.flatMap((user) => {
      const roleNames = user.roles.map((roleId: any) => {
        const role = rolesData.find((role) => role.id === roleId);
        return role ? role.role_name : null;
      });
      return roleNames.filter((roleName: any) => roleName !== null) as string[];
    });
    return userRoles;
  };

  // front end sort logic
  const sortHandler = (columnName: string, sortOrder: 'ASC' | 'DESC') => {
    let sortOrderToPass: 'asc' | 'desc' = sortOrder === 'ASC' ? 'asc' : 'desc';
    const sortedUserData = _.orderBy(usersList, [columnName], [sortOrderToPass]);
    setUsersList(sortedUserData);
  };

  // PERMISSIONS RELATED CODE ------

  const { pathname } = useLocation();
  const module = pathname?.split('/')[1];
  const subModule = pathname?.split('/')[2];
  // usersPermissions -> PASSED TO REUSABLE TABLE
  const usersPermissions = {
    hasEdit: validatePermissions(
      permissionsMapper[module],
      permissionsMapper[subModule],
      crudType.edit
    ),
    // edit permission decides the deactivation
    hasDeactivate: validatePermissions(
      permissionsMapper[module],
      permissionsMapper[subModule],
      crudType.edit
    ),
    // edit permission decides the reset
    hasReset: validatePermissions(
      permissionsMapper[module],
      permissionsMapper[subModule],
      crudType.edit
    ),
  };
  // PERMISSIONS RELATED CODE ------

  // ICONS ICON CALLBACKS PASSED TO THE CHILD (these fire on respective icon click) -----------------
  // gets called on view icon click
  const handleViewClickAction = (rowData: any) => {
    const { userId } = rowData;
    navigate(`${paths.userListView}/${userId}`);
  };

  // gets called on edit icon click
  const handleEditClickAction = (rowData: any) => {
    const { userId } = rowData;
    navigate(`${paths.editUser}/${userId}`);
  };

  // called on deactivate icon onclick
  const handleDeactivateAction = (rowData: any) => {
    //sets up the modal and stores the user data in a state temporarily
    setSelectedUserData(rowData);
    setShowDeactivateOrActivateModal(true);
    setModalTitle(t('sharedTexts.alert'));
    setModalConfirmButtonText(t('sharedTexts.deactivate'));
    setModalContent(t('userAccessControl.users.doYouWantToDeactivateThisUser'));
  };

  // CHANGE MODAL TEXTS $$$$$!!!!!!!!!!!!!!

  // called on activate icon onclick
  const handleActivateIconClick = (rowData: any) => {
    //sets up the modal and stores the user data in a state temporarily
    setSelectedUserData(rowData);
    setShowDeactivateOrActivateModal(true);
    setModalTitle(t('sharedTexts.alert'));
    setModalConfirmButtonText(t('sharedTexts.proceed'));
    setModalContent(t('userAccessControl.users.doYouWantToActivateTheUser'));
  };

  // called on Reset icon onclick
  const handleResetIconClick = (rowData: any) => {
    //sets up the modal and stores the user data in a state temporarily
    setSelectedUserData(rowData);
    setCurrentAction('reset');
    setShowDeactivateOrActivateModal(true);
    setModalTitle(t('sharedTexts.alert'));
    setModalConfirmButtonText(t('userAccessControl.users.yesResetPassword'));
    setModalContent(
      `${t('userAccessControl.users.areYouSureYouWantToResetPassword')}: ${rowData?.name}?`
    );
  };
  // ICONS ICON CALLBACKS PASSED TO THE CHILD - END ------------------------------

  // MAIN ACTIVATE / deactivate FUNC - gets called after modal confirmation
  // same function, same api call, same param. api logic toggles the active status of a USER
  const handleDeactivateOrActivateConfirmClick = () => {
    if (currentAction === 'reset') {
      handleResettingPassword();
      return;
    }
    changeStatusOfUser(selectedUserData?.userId);
  };

  //API call -  the same api has activate and deactivate logic
  const changeStatusOfUser = async (userId: any) => {
    setLoading(true);
    httpClient
      .patch(`/api/account/users/${userId}/`)
      .then((response: any) => {
        if (response.status === 200) {
          if (response.data) {
            getUsers(1);
            setLoading(false);
            notify('success', t(response.data.message));
            setShowDeactivateOrActivateModal(false);
            setCurrentAction('');
          }
        } else if (response.data?.error) {
          getUsers(1);
          setLoading(false);
          setShowDeactivateOrActivateModal(false);
          setCurrentAction('');
        }
      })
      .catch(() => {
        getUsers(1);
        notify('error', t('userAccessControl.roles.failedToChangeRoleStatus'));
        setShowDeactivateOrActivateModal(false);
        setCurrentAction('');
      });
  };

  // reset password functions.. -> generates a random password with a helper function and sends the new password to backend to update it
  const handleResettingPassword = async () => {
    setShowDeactivateOrActivateModal(false);
    setCurrentAction('');
    const password = generatePassword();
    setLoading(true);
    if (password) {
      const data = { password: password };
      const response = await httpClient.post(
        `/api/account/reset-password/${selectedUserData.userId}/`,
        {
          data: data,
        }
      );
      if (response.status == 200) {
        setLoading(false);
        notify('success', t('userAccessControl.users.passwordResetSuccessfully'));
        setGeneratedPassword(password);
        setShowPasswordCopyModal(true);
      }
    }
  };

  // closing function of the 'generated password copying modal'
  const closeGeneratedModal = () => {
    setShowPasswordCopyModal(false);
    // IF THE LOGGED IN USER RESETS HIS PASSWORD FROM LIST, WE ARE FORCING A LOGOUT
    if (loggedInUserData && loggedInUserData?.id == selectedUserData.userId) {
      onLogout();
    }
  };

  // if the logged in user resets his pass, need to force a logout
  const onLogout = async () => {
    setLoading(true);
    dispatch(userLogout());
    clearSessionStorage(['accessToken']);
    setLoading(false);
    navigate(`${paths.login}`);
  };

  return (
    <main className='dashboard'>
      <section className='dashboard__main'>
        <Header
          title={t('plantModulesAndFunctions.USERS')}
          buttonText={t('userAccessControl.users.addNewUser')}
          onButtonClick={handleAddNewUser}
          placeholder={t('sharedTexts.search')}
          onSearchChange={(value) => {
            handleSearch(value);
          }}
          sort_filter_click={(filterValue: any) => handleFilter(filterValue)}
          rolesDataList={Array.from(new Set(getUserRoles(usersDataToSearch, allRoles)))}
        />
        <div
          className='dashboard__main__body pt-6'
          style={{ padding: '16px 12px', overflow: 'auto' }}
        >
          <ReusableTable
            mainHeaders={userTableHeaders}
            renderData={renderedUserData}
            showActionIconsInRow
            sortHandler={sortHandler}
            callBackOnViewClick={handleViewClickAction}
            callBackOnEditClick={handleEditClickAction}
            callBackOnDeactivationClick={handleDeactivateAction}
            callBackOnActivationClick={handleActivateIconClick}
            callBackOnResetClick={handleResetIconClick}
            rowActionsPermission={usersPermissions}
            toolTips={toolTipsForUsers}
            columnsToDisplayAsPills={['ssoStatus']}
            activeButtonDependencyKey={'showActivateButton'}
            resetButtonDependencyKey={'showResetButton'}
            columnsToIgnoreInRendering={['showActivateButton', 'showResetButton']}
          />

          <Pagination
            totalItems={count}
            itemsPerPage={itemsPerPage}
            onPageChange={onPageChange}
            currentPage={currentPage}
            previous={previous}
            next={next}
          />

          {/* DEACTIVATE / activate/ reset CONFIRMATION MODAL  */}
          {showDeactivateOrActivateModal && (
            <AlertModal
              showModal={showDeactivateOrActivateModal}
              closeModal={() => {
                setShowDeactivateOrActivateModal(false);
                setCurrentAction('');
              }}
              onConfirmClick={handleDeactivateOrActivateConfirmClick}
              title={modalTitle}
              content={modalContent}
              confirmButtonText={modalConfirmButtonText}
            />
          )}

          {/* ============================================= */}
          {/* THE MODAL WHICH POPS UP AFTER PASSWORD RESET - NOT ABLE TO MOVE IT. EVENTS ARE NOT GETTING TRIGGERED PROPERLY */}
          {/* ==================== START ================== */}

          <GeneratePasswordModal
            showModal={showPasswordCopyModal}
            closeModal={closeGeneratedModal}
            title={t('sharedTexts.alert')}
          >
            <div
              className='col-4 px-2 mb-6 flex'
              style={{ width: 'fit-content', position: 'relative' }}
            >
              <div className='col-wrapper'>
                <label className='input-field-label font-semibold' htmlFor='password_generated'>
                  {t('userAccessControl.users.passwordGenerated')}
                </label>
                <input
                  type='password'
                  disabled
                  placeholder=''
                  name='password'
                  value={generatedPassword}
                  className='input-field input-field md input-field h40 w-full'
                  style={{ minWidth: '222px' }}
                />
              </div>
              <MUIToolTip text={t('userAccessControl.users.copyPassword')}>
                <button
                  onClick={() => {
                    // copying to clipboard
                    navigator.clipboard.writeText(generatedPassword);
                  }}
                  style={{ border: '0px solid', backgroundColor: '#f0ffff00' }}
                  type='button'
                >
                  <img
                    src={copy}
                    alt='copy-icon'
                    style={{
                      cursor: 'pointer',
                      width: '30px',
                      marginLeft: '10px',
                      marginTop: '22px',
                    }}
                    data-toggle='tooltip'
                    data-placement='bottom'
                  />
                </button>
              </MUIToolTip>
            </div>
          </GeneratePasswordModal>
          {/* =================== END ===================== */}
          {/* ============================================= */}
        </div>
      </section>
    </main>
  );
};

export default UsersList;
