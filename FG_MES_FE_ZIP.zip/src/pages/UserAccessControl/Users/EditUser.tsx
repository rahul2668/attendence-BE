import { useEffect, useState } from 'react';
import 'assets/styles/scss/pages/dashboard.scss';
import 'assets/styles/scss/components/table-general.scss';
import arrowLeft from 'assets/icons/arrow-left.svg';
import closeIcon from 'assets/icons/pills-close-btn.svg';
import { useNavigate, useParams } from 'react-router-dom';
import { paths } from 'routes/paths';
import httpClient from 'http/httpClient';
import { notify, isEmpty, clearSessionStorage } from 'utils/utils';
import Loading from 'components/common/Loading';
import CustomSelect from 'components/common/SelectField';
import OutsideClickHandler from 'react-outside-click-handler';
import copy from 'assets/icons/copy.svg';
import { useAppDispatch, useAppSelector } from 'store';
import { ssoLoginCredentials } from 'store/slices/authSlice';
import AlertModal from 'components/Modal/AlertModal';
import { useTranslation } from 'react-i18next';
const EditUser = () => {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { userId } = useParams();
  const [showTooltip, setShowTooltip] = useState(false);
  const [userDetails, setUserDetails] = useState<any>({});
  const [existingRoles, setExistingRoles] = useState<any>([]);
  const [existingRolesList, setExistingRolesList] = useState<any>([]);
  const [allRoles, setAllRoles] = useState<any>([]);
  const [selectedLoginType, setSelectedLoginType] = useState<number>(0);
  const [isPasswordVisible, setIsPasswordVisible] = useState<boolean>(false);
  const [newPassword, setNewPassword] = useState<any>('');
  const [loading, setLoading] = useState(true);
  const [selectedValue, setSelectedValue] = useState('Select');
  const [openAlertModal, setOpenAlertModal] = useState<boolean>(false);

  const userDataString = useAppSelector((state) => state.userData.userData);
  const userData: any = userDataString ? userDataString : null;

  const dispatch = useAppDispatch();

  const ssoKeys = useAppSelector((state) => state.login.ssoLoginKeys);

  useEffect(() => {
    if (!ssoKeys) {
      dispatch(ssoLoginCredentials());
    }
  }, [dispatch, ssoKeys]);

  useEffect(() => {
    const getRolesAPI = async () => {
      httpClient
        // .get('/api/roles/?is_delete=false')
        .get('/api/account/roles/?is_delete=false')
        .then((response: any) => {
          if (response.data) {
            setExistingRolesList(response.data.results);
            setAllRoles(response.data.results);
          }
        })
        .catch((err) => {
          console.log('errored -->', err);
        });
    };
    getRolesAPI();
  }, []);

  useEffect(() => {
    if (userId) {
      httpClient
        // .get(`/api/users/${userId}`)
        .get(`/api/account/users/${userId}/?type=edit`)
        .then((response) => {
          if (response.data) {
            setLoading(false);
            const user: any = response.data;
            setUserDetails(user);
            setFormData({
              firstname: user?.first_name,
              lastname: user?.last_name,
              username: user?.username,
              phone: user?.phone,
              email: user?.email,
              department: user?.department,
              roles: user?.roles.length ? [...user.roles.map((roles: any) => roles)] : [],
            });

            const selectedLoginType = user.login_type == '' || user.login_type == 'simple' ? 1 : 0;
            setSelectedLoginType(selectedLoginType);
          }
        })
        .catch((err) => {
          console.log('errored -->', err);
        });
    }
  }, [userId]);

  // filter user roles from existing roles
  useEffect(() => {
    if (!isEmpty(userDetails) && !isEmpty(existingRolesList)) {
      const remainingRoles = [...existingRolesList].filter(
        (obj1) => ![...(userDetails?.roles ?? [])].some((obj2) => obj1.id === obj2)
      );
      setExistingRoles(remainingRoles);
    }
  }, [userDetails, existingRolesList]);

  const [formData, setFormData] = useState<any>({
    firstname: '',
    lastname: '',
    username: '',
    phone: '',
    email: '',
    roles: [],
    department: '',
  });

  const [errors, setErrors] = useState<any>({});

  const handleFirstnameChange = (value: any) => {
    setFormData({ ...formData, firstname: value });
    setErrors({ ...errors, firstname: validateFirstname(value) });
  };

  const handleLastnameChange = (value: any) => {
    setFormData({ ...formData, lastname: value });
    setErrors({ ...errors, lastname: validateLastname(value) });
  };

  const handleUsernameChange = (value: any) => {
    setFormData({ ...formData, username: value });
    setErrors({ ...errors, username: validateUsername(value) });
  };

  const handlePhoneChange = (value: any) => {
    setFormData({ ...formData, phone: value });
    setErrors({ ...errors, phone: validatePhone(value) });
  };

  const handleEmailChange = (value: any) => {
    setFormData({ ...formData, email: value.trim() });
    setErrors({ ...errors, email: validateEmail(value.trim()) });
  };

  const handleDepartmentChange = (value: any) => {
    setFormData({ ...formData, department: value.trim() });
  };

  const handleRoleClick = (roleId: any) => {
    if (formData.roles.includes(roleId)) {
      // Deselect the roles if it's already selected
      setFormData({
        ...formData,
        roles: formData.roles.filter((selectedRoleId: any) => selectedRoleId !== roleId),
      });
      // Add the roles back to existingRoles
      setExistingRoles([...existingRoles, getRoleById(roleId)]);
    } else {
      // Select the roles if it's not selected
      setFormData({
        ...formData,
        roles: [...formData.roles, roleId],
      });
      setExistingRoles(existingRoles.filter((roles: any) => roles.id !== roleId));
    }
  };

  const validateForm = () => {
    const validationErrors = {
      firstname: validateFirstname(formData?.firstname),
      lastname: validateLastname(formData?.lastname),
      username: validateUsername(formData?.username),
      phone: validatePhone(formData?.phone),
      email: validateEmail(formData?.email?.trim()),
    };
    setErrors(validationErrors);
    return Object.values(validationErrors).every((error) => !error);
  };

  const getRoleById = (roleId: any) => {
    return allRoles.find((roles: any) => roles.id === roleId);
  };

  const deleteRole = (roleId: any) => {
    if (formData.roles?.map((roles: any) => roles === roleId)) {
      setFormData({
        ...formData,
        roles: formData.roles.filter((selectedRoleId: any) => selectedRoleId !== roleId),
      });
      // Add the roles back to existingRoles
      setExistingRoles(Array.from(new Set([...existingRoles, getRoleById(roleId)])));
    }
  };

  const getRoleNameById = (roleId: any) => {
    const roles = allRoles.find((roles: any) => roles.id === roleId);
    return roles ? roles.role_name : 'Role Not Found';
  };

  const validateFirstname = (value: any) => {
    if (!value) {
      return t('userAccessControl.users.firstNameIsRequired');
    }

    const pattern = /^[a-zA-Z][a-zA-Z ]{1,18}[a-zA-Z]$/;

    if (!pattern.test(value)) {
      return t('sharedTexts.invalidNameFormat');
    }

    return '';
  };

  const validateLastname = (value: any) => {
    if (!value) {
      return t('userAccessControl.users.lastNameIsRequired');
    }
    const pattern = /^[a-zA-Z][a-zA-Z ]{1,18}[a-zA-Z]$/;

    if (!pattern.test(value)) {
      return t('sharedTexts.invalidNameFormat');
    }

    return '';
  };

  const validateUsername = (value: any) => {
    if (!value) {
      return t('userAccessControl.users.userIdIsRequired');
    }

    let errorMessage = '';
    if (
      (value?.length < 4 ||
        value?.length > 20 ||
        /^\d/.test(value) ||
        !/^[a-zA-Z0-9]+$/.test(value)) &&
      selectedLoginType == 1
    ) {
      errorMessage = t('userAccessControl.users.invalidUsername');
    }
    return errorMessage.trim();
  };
  function onValueChange(event: any) {
    setSelectedLoginType(event.target.value);
  }
  const validatePhone = (value: any) => {
    if (!value) {
      return '';
    } else if (!/^\d{10}$/g.test(value)) {
      return t('userAccessControl.users.invalidPhoneFormat');
    }
    return '';
  };

  function validateEmailDomain(email: string, domain: string) {
    // Split email by @ symbol
    const parts = email.split('@');
    // Check if the domain part matches the provided domain
    return parts[1] !== domain;
  }

  useEffect(() => {
    setErrors({ ...errors, email: validateEmail(formData.email) });
  }, [selectedLoginType]);

  const validateEmail = (value: any) => {
    const domain: string = ssoKeys?.acceptedDomain ?? '';

    if (!value) {
      return '';
    } else if (validateEmailDomain(value, domain) && selectedLoginType == 0) {
      return `${t('userAccessControl.users.acceptedDomain')} - ${domain}`;
    } else if (!/^\S+@\S+\.\S+$/.test(value)) {
      return t('userAccessControl.users.invalidEmailFormat');
    }
    return '';
  };

  const arraysHaveSameValues = (arr1: Array<number>, arr2: Array<number>) => {
    // Check if arrays have the same length
    if (arr1.length !== arr2.length) {
      return true;
    }

    // Sort the arrays
    const sortedArr1 = arr1.slice()?.sort((a, b) => a - b);
    const sortedArr2 = arr2.slice()?.sort((a, b) => a - b);

    // Compare sorted arrays
    for (let i = 0; i < sortedArr1.length; i++) {
      if (sortedArr1[i] !== sortedArr2[i]) {
        return true;
      }
    }

    return false;
  };

  const editUserAPI = async (request: any) => {
    setLoading(true);
    httpClient
      // .put(`/api/users/${userId}/`, { data: request })
      .put(`/api/account/users/${userId}/`, { data: request })
      .then((response: any) => {
        if (response.status === 200 || response.status === 201) {
          setLoading(false);
          if (response.data) {
            notify('success', t(response.data.message));

            if (
              arraysHaveSameValues(userDetails.roles, request.roles) &&
              request.id == userData.id
            ) {
              setOpenAlertModal(true);
            } else {
              navigate(`${paths.usersList}`);
            }
          }
        } else if (response.data) {
          const errorField = Object.keys(response?.data)[0];
          notify('error', response.data[errorField][0]);
        } else {
          notify('error', t('userAccessControl.users.failedToEditUserDetails'));
        }
      })
      .catch((err) => {
        notify('error', t('userAccessControl.users.failedToEditUserDetails'));
        console.log('errored -->', err);
      });
  };

  const handleSubmit = (e: any) => {
    e.preventDefault();

    if (validateForm()) {
      const request = {
        id: userId,
        first_name: formData.firstname,
        last_name: formData.lastname,
        // username: formData.username,
        phone: formData.phone,
        email: formData.email?.trim(),
        roles: [...formData.roles],
        department: formData.department,
      };

      editUserAPI(request);
    }
  };

  const onLogout = async () => {
    setLoading(true);
    clearSessionStorage(['accessToken', 'selectedLanguage']);
    setLoading(false);
    navigate(`${paths.login}`);
  };

  const generatePassword = async (): Promise<void> => {
    const symbols = '!@#$%^&*';
    const uppercaseLetters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const lowercaseLetters = 'abcdefghijklmnopqrstuvwxyz';
    const numbers = '0123456789';

    let generatedPassword = '';
    const charset = lowercaseLetters + uppercaseLetters + numbers + symbols;

    for (let i = 0; i < 8; i++) {
      generatedPassword += charset.charAt(Math.floor(Math.random() * charset.length));
    }

    // Ensure the password contains at least one uppercase letter, one number, and one symbol
    const hasUppercase = /[A-Z]/.test(generatedPassword);
    const hasNumber = /\d/.test(generatedPassword);
    const hasSymbol = /[!@#$%^&*]/.test(generatedPassword);

    if (!hasUppercase || !hasNumber || !hasSymbol) {
      // If any requirement is not met, recursively call generatePassword function again
      return generatePassword();
    }
    if (generatedPassword) {
      const data = { password: generatedPassword };
      setLoading(true);
      const response = await httpClient.post(`/api/account/reset-password/${userId}/`, {
        data: data,
      });
      if (response.status == 200) {
        setLoading(false);
        notify('success', t('userAccessControl.users.passwordResetSuccessfullyCopyThePassword'));
        setNewPassword(generatedPassword);
        setIsPasswordVisible(true);
      }
    }
  };
  function copyTextToClipboard(text: string) {
    const textArea = document.createElement('textarea');

    // Set the text content to be copied to the clipboard
    textArea.value = text;

    // Make the textarea hidden
    textArea.style.position = 'fixed';
    textArea.style.top = '0';
    textArea.style.left = '0';
    textArea.style.width = '2em';
    textArea.style.height = '2em';
    textArea.style.padding = '0';
    textArea.style.border = 'none';
    textArea.style.outline = 'none';
    textArea.style.boxShadow = 'none';
    textArea.style.background = 'transparent';

    // Append the textarea to the document
    document.body.appendChild(textArea);

    // Select and copy the text to the clipboard
    textArea.select();
    document.execCommand('copy');

    // Remove the textarea from the document
    document.body.removeChild(textArea);
  }
  const isUserFormFilled = (formData: any) => {
    for (const key in formData) {
      if (Object.hasOwn(formData, key)) {
        if (key !== 'email' && key !== 'department' && key !== 'phone') {
          if (Array.isArray(formData[key]) && formData[key]?.length === 0) {
            return false;
          }
          if (formData[key] === '' || formData[key] === undefined || formData[key] === null) {
            return false;
          }
        }
      }
    }
    return true;
  };

  const isUserFormValid = (formData: any) => {
    for (const key in formData) {
      if (Object.hasOwn(formData, key) && key !== 'confirmPassword') {
        if (Array.isArray(formData[key]) && formData[key]?.length === 0) {
          return false;
        }
        if (formData[key] === '' && key !== 'phone' && key !== 'email' && key !== 'department') {
          return false;
        }
      }
    }

    if (formData.phone && errors.phone) {
      return false;
    }

    if (formData.email && errors.email) {
      return false;
    }
    return true;
  };

  if (loading) return <Loading />;

  return (
    <main className='dashboard'>
      <section className='dashboard__main'>
        <div className='dashboard__main__header'>
          <div className='flex items-center justify-between h-full py-2'>
            <div className='flex items-center'>
              <button
                type='button'
                style={{ border: '0px solid', backgroundColor: '#f0ffff00' }}
                onClick={() => navigate(`${paths.usersList}`)}
              >
                <img className='cursor-pointer' src={arrowLeft} alt='back-arrow' />
              </button>
              <h2 className='text-xl font-bold ml-4'>{`${t('sharedTexts.edit')} - ${userDetails?.first_name} ${userDetails?.last_name}
              `}</h2>
            </div>
          </div>
        </div>

        <div className='dashboard__main__body px-8 py-6 scroll-0'>
          <div className='card-box pt-4 px-6 pb-8'>
            <div className='tab-section-content flex mt-4'>
              <div className='' style={{ paddingRight: 100 }}>
                <div className='flex flex-wrap -mx-2'>
                  <div className='col-4 px-2 mb-6'>
                    <div className='col-wrapper'>
                      <label
                        className='input-field-label font-semibold'
                        htmlFor='first_name'
                      >{`${t('userAccessControl.users.firstName')}*`}</label>
                      <input
                        type='text'
                        placeholder={t('userAccessControl.users.enterFirstName')}
                        name='firstname'
                        value={formData.firstname}
                        onChange={(e) => handleFirstnameChange(e.target.value)}
                        className='input-field input-field--md input-field--h40 w-full'
                        spellCheck={false}
                      />
                      {errors.firstname && <div className='error-message'>{errors.firstname}</div>}
                    </div>
                  </div>
                  <div className='col-4 px-2 mb-6'>
                    <div className='col-wrapper'>
                      <label
                        className='input-field-label font-semibold'
                        htmlFor='last_name'
                      >{`${t('userAccessControl.users.lastName')}*`}</label>
                      <input
                        type='text'
                        placeholder={t('userAccessControl.users.enterLastName')}
                        name='lastname'
                        value={formData.lastname}
                        onChange={(e) => handleLastnameChange(e.target.value)}
                        className='input-field input-field--md input-field--h40 w-full'
                        spellCheck={false}
                      />
                      {errors.lastname && <div className='error-message'>{errors.lastname}</div>}
                    </div>
                  </div>
                  <div className='col-4 px-2 mb-6'>
                    <div className='col-wrapper'>
                      <label
                        className='input-field-label font-semibold'
                        htmlFor='phone_number'
                      >{`${t('userAccessControl.users.phone')}`}</label>
                      <input
                        type='number'
                        placeholder={t('userAccessControl.users.enterPhoneNumber')}
                        name='phone'
                        value={formData.phone}
                        pattern='[0-9]{3}-[0-9]{2}-[0-9]{3}'
                        onChange={(e) => handlePhoneChange(e.target.value)}
                        className='input-field input-field--md input-field--h40 w-full'
                      />
                      {errors.phone && <div className='error-message'>{errors.phone}</div>}
                    </div>
                  </div>
                  <div className='col-4 px-2 mb-6'>
                    <div className='col-wrapper'>
                      <label className='input-field-label font-semibold' htmlFor='email'>
                        {t('userAccessControl.users.email')}
                      </label>
                      <input
                        type='text'
                        placeholder={t('userAccessControl.users.enterEmail')}
                        name='email'
                        value={formData.email}
                        onChange={(e) => handleEmailChange(e.target.value)}
                        className='input-field input-field--md input-field--h40 w-full'
                      />
                      {errors.email && <div className='error-message'>{errors.email}</div>}
                    </div>
                  </div>

                  <div className='col-4 px-2 mb-6'>
                    <div className='col-wrapper'>
                      <label className='input-field-label font-semibold' htmlFor='department'>
                        {t('userAccessControl.users.department')}
                      </label>
                      <input
                        type='text'
                        placeholder={t('userAccessControl.users.enterDepartment')}
                        name='department'
                        value={formData.department}
                        onChange={(e) => handleDepartmentChange(e.target.value.trim())}
                        className='input-field input-field--md input-field--h40 w-full'
                        spellCheck={false}
                      />
                    </div>
                  </div>
                  <div className='col-12 px-2 mb-6 arrow'>
                    <OutsideClickHandler onOutsideClick={() => {}}>
                      <div className='col-wrapper'>
                        <label
                          className='input-field-label font-semibold'
                          htmlFor='roles'
                        >{`${t('userAccessControl.roles.roles')}*`}</label>

                        <div className='custom-select-wrapper'>
                          <CustomSelect
                            options={existingRoles
                              .filter(
                                (roles: any) => roles.role_name !== 'SuperAdmin' && !roles.is_delete
                              )
                              .map((roles: any) => ({
                                value: roles.id,
                                option: roles.role_name,
                              }))}
                            index={0}
                            value={selectedValue === 'Select' ? 'Select' + ' ' : 'Select'}
                            // onChange={handleDropdown}
                            onChange={(id: any) => {
                              setSelectedValue(
                                selectedValue === 'Select' ? 'Select' + ' ' : 'Select'
                              );
                              handleRoleClick(id);
                              // handleDropdown()
                            }}
                            styles={{ paddingRight: '4px' }}
                          ></CustomSelect>
                        </div>
                      </div>
                    </OutsideClickHandler>

                    <div className='pills-box-wrapper mt-3'>
                      {formData.roles?.map((roles: any) => (
                        <div key={roles} className='pills-box'>
                          {getRoleNameById(roles)}
                          <button
                            style={{ border: '0px solid', backgroundColor: '#f0ffff00' }}
                            type='button'
                            onClick={() => deleteRole(roles)}
                          >
                            <img
                              src={closeIcon}
                              alt='close-icon'
                              className='pills-box__close-btn'
                            />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                <div className='col-12 px-2 mb-6'>
                  <label
                    className='input-field-label font-semibold'
                    htmlFor='login_type'
                  >{`${t('userAccessControl.users.loginType')}*`}</label>
                  <div className='modal__radio flex' style={{ padding: '15px 0' }}>
                    <label className='p-1 radio-container'>
                      <input
                        className='p-1'
                        type='radio'
                        name='current-mix-system'
                        value={0}
                        disabled={true}
                        checked={selectedLoginType == 0}
                        onChange={onValueChange}
                      />
                      <span className='radio-text radio-style'>
                        SSO {`(${t('userAccessControl.users.loginWithSso')})`}
                      </span>
                    </label>
                    <div className='col-12 flex mt-4'>
                      <label className='p-1 mt-2 col-2' style={{ width: 'auto' }}>
                        <input
                          className='p-1'
                          type='radio'
                          name='current-mix-system'
                          value={1}
                          disabled={true}
                          checked={selectedLoginType == 1}
                          onChange={onValueChange}
                        />
                        <span className='radio-text radio-style'>
                          {t('userAccessControl.users.userId')}
                        </span>
                      </label>
                      {
                        <div className='p-1 col-10'>
                          <div className='flex' style={{ marginTop: '-12px' }}>
                            <div className='col-4 px-2 mb-6'>
                              <div className='col-wrapper'>
                                <label
                                  className='input-field-label font-semibold'
                                  htmlFor='user_id'
                                >
                                  {t('userAccessControl.users.userId')}
                                </label>
                                <input
                                  type='text'
                                  placeholder='Enter User Id'
                                  name='username'
                                  disabled={true}
                                  value={formData.username}
                                  onChange={(e) => handleUsernameChange(e.target.value.trim())}
                                  className='input-field input-field--md input-field--h40 w-full'
                                  spellCheck={false}
                                  style={{ color: '#696969', fontWeight: 600 }}
                                />
                                {errors.username && (
                                  <div className='error-message'>{errors.username}</div>
                                )}
                              </div>
                            </div>
                            {selectedLoginType == 1 && isPasswordVisible && (
                              <div
                                className='col-4 px-2 mb-6 flex'
                                style={{ position: 'relative' }}
                              >
                                <div className='col-wrapper'>
                                  <label
                                    className='input-field-label font-semibold'
                                    htmlFor='password_generated'
                                  >
                                    {t('userAccessControl.users.passwordGenerated')}
                                  </label>
                                  <input
                                    type='password'
                                    disabled
                                    placeholder=''
                                    name='password'
                                    value={newPassword}
                                    // onChange={(e) => handlePasswordChange(e.target.value)}
                                    className='input-field input-field--md input-field--h40 w-full'
                                    style={{ minWidth: '222px' }}
                                  />
                                </div>
                                <img
                                  src={copy}
                                  alt='copy-icon'
                                  style={{
                                    cursor: 'pointer',
                                    width: '30px',
                                    marginLeft: '10px',
                                    marginTop: '22px',
                                  }}
                                  onClick={() => {
                                    copyTextToClipboard(newPassword);
                                    const plantDataString = useAppSelector(
                                      (state) => state.userData.userData
                                    );
                                    const userData: any = plantDataString ? plantDataString : null;
                                    if (userData.id == userId) {
                                      onLogout();
                                    }
                                  }}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') {
                                      copyTextToClipboard(newPassword);
                                      const plantDataString = useAppSelector(
                                        (state) => state.userData.userData
                                      );
                                      const userData: any = plantDataString
                                        ? plantDataString
                                        : null;
                                      if (userData.id == userId) {
                                        onLogout();
                                      }
                                    }
                                  }}
                                  data-toggle='tooltip'
                                  data-placement='bottom'
                                  onMouseOver={() => setShowTooltip(true)}
                                  onFocus={() => setShowTooltip(true)}
                                  onMouseOut={() => setShowTooltip(false)}
                                  onBlur={() => setShowTooltip(false)}
                                />{' '}
                                {showTooltip ? (
                                  <span
                                    className='user__tooltip'
                                    style={{ right: '35px', width: '120px' }}
                                  >
                                    {t('userAccessControl.users.copyPassword')}
                                  </span>
                                ) : (
                                  ''
                                )}
                              </div>
                            )}

                            {selectedLoginType == 1 && !isPasswordVisible && (
                              <div className='pt-28'>
                                <button
                                  type='button'
                                  className={`btn btn--primary btn--h36 px-8 py-2 ml-4`}
                                  onClick={generatePassword}
                                >
                                  {t('userAccessControl.users.resetPassword')}
                                </button>
                              </div>
                            )}
                          </div>
                        </div>
                      }
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className='dashboard__main__footer'>
          <div className='dashboard__main__footer__container'>
            <button
              className='btn btn--h36 px-4 py-2'
              type='button'
              onClick={() => navigate(`${paths.usersList}`)}
            >
              {t('sharedTexts.cancel')}
            </button>
            <button
              type='submit'
              className={`btn btn--primary btn--h36 px-8 py-2 ml-4 ${
                isUserFormFilled(formData) && isUserFormValid(formData) ? '' : 'disabled'
              }`}
              onClick={handleSubmit}
            >
              {t('sharedTexts.saveChanges')}
            </button>
          </div>
        </div>

        {openAlertModal && (
          <AlertModal
            showModal={openAlertModal}
            title={'Logout'}
            content={'User Roles Updated. You Need to Login again'}
            confirmButtonText='Proceed'
            isShowCloseIcon={false}
            onConfirmClick={async () => {
              setLoading(true);
              clearSessionStorage(['accessToken']);
              setLoading(false);
              navigate(`${paths.login}`);
            }}
            closeModal={() => {
              setOpenAlertModal(true);
            }}
          />
        )}
      </section>
    </main>
  );
};

export default EditUser;
