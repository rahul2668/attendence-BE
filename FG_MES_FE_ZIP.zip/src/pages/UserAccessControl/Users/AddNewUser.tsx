import React, { useState, useEffect } from 'react';
import 'assets/styles/scss/pages/dashboard.scss';
import arrowLeft from 'assets/icons/arrow-left.svg';
import copy from 'assets/icons/copy.svg';
import closeIcon from 'assets/icons/pills-close-btn.svg';
import { useNavigate } from 'react-router-dom';
import httpClient from 'http/httpClient';
import { paths } from 'routes/paths';
import CustomSelect from 'components/common/SelectField';
import ModalCloneUser from 'components/Modal/ModalCloneUser';
import { notify } from 'utils/utils';
import OutsideClickHandler from 'react-outside-click-handler';
import Loading from 'components/common/Loading';
import { useAppDispatch, useAppSelector } from 'store';
import { ssoLoginCredentials } from 'store/slices/authSlice';
import { useTranslation } from 'react-i18next';

interface AddNewRoleProps {
  setAddNewRole: (value: boolean) => void;
}

const AddNewUser: React.FC<AddNewRoleProps> = () => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const { t } = useTranslation();

  const ssoKeys = useAppSelector((state) => state.login.ssoLoginKeys);

  useEffect(() => {
    if (!ssoKeys) {
      dispatch(ssoLoginCredentials());
    }
  }, [dispatch, ssoKeys]);

  const [showTooltip, setShowTooltip] = useState(false);

  const [openCloneModal, setOpenCloneModal] = useState<boolean>(false);
  const [selectedLoginType, setSelectedLoginType] = useState<number>(1);
  const [selectedValue, setSelectedValue] = useState('Select');
  const [formData, setFormData] = useState<any>({
    firstname: '',
    lastname: '',
    username: '',
    phone: '',
    email: '',
    password: '',
    // confirmPassword: '',
    roles: [],
    department: '',
  });

  const [existingRoles, setExistingRoles] = useState<any>([]);
  const [allRoles, setAllRoles] = useState<any>([]);
  const [isPasswordVisible, setIsPasswordVisible] = useState<boolean>(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const getRolesAPI = async () => {
      httpClient
        // .get('/api/roles/?is_delete=false')
        .get('/api/account/roles/?is_delete=false')
        .then((response: any) => {
          if (response.data) {
            setLoading(false);
            setExistingRoles(response.data.results);
            setAllRoles(response.data.results);
          }
        })
        .catch((err) => {
          console.log('errored -->', err);
        });
    };
    getRolesAPI();
  }, []);

  const [errors, setErrors] = useState<any>({});

  const handleFirstnameChange = (value: any) => {
    setFormData({ ...formData, firstname: value });
    setErrors({ ...errors, firstname: validateFirstname(value) });
  };

  const handleLastnameChange = (value: any) => {
    setFormData({ ...formData, lastname: value });
    setErrors({ ...errors, lastname: validateLastname(value) });
  };

  const handleUsernameChange = (value: any) => {
    setFormData({ ...formData, username: value });
    setErrors({ ...errors, username: validateUsername(value) });
  };

  const handlePhoneChange = (value: any) => {
    setFormData({ ...formData, phone: value });
    setErrors({ ...errors, phone: validatePhone(value) });
  };

  const handleEmailChange = (value: any) => {
    setFormData({ ...formData, email: value.trim() });
    setErrors({ ...errors, email: validateEmail(value.trim()) });
  };

  async function onValueChange(event: any) {
    try {
      setSelectedLoginType(event.target.value);
      if (event.target.value === 0) {
        setFormData({ ...formData, username: '', password: '' });
        setIsPasswordVisible(false);
      }
    } catch (error) {
      console.error('Error in onValueChange:', error);
    }
  }

  const generatePassword = (): void => {
    const symbols = '!@#$%^&*';
    const uppercaseLetters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const lowercaseLetters = 'abcdefghijklmnopqrstuvwxyz';
    const numbers = '0123456789';

    let generatedPassword = '';
    const charset: any = lowercaseLetters + uppercaseLetters + numbers + symbols;

    for (let i = 0; i < 8; i++) {
      generatedPassword += charset.charAt(Math.floor(Math.random() * charset.length));
    }

    // Ensure the password contains at least one uppercase letter, one number, and one symbol
    const hasUppercase = /[A-Z]/.test(generatedPassword);
    const hasNumber = /\d/.test(generatedPassword);
    const hasSymbol = /[!@#$%^&*]/.test(generatedPassword);

    if (!hasUppercase || !hasNumber || !hasSymbol) {
      // If any requirement is not met, recursively call generatePassword function again
      return generatePassword();
    }
    setFormData({ ...formData, password: generatedPassword });
    setIsPasswordVisible(true);
  };

  function copyTextToClipboard(text: string) {
    const textArea = document.createElement('textarea');

    // Set the text content to be copied to the clipboard
    textArea.value = text;

    // Make the textarea hidden
    textArea.style.position = 'fixed';
    textArea.style.top = '0';
    textArea.style.left = '0';
    textArea.style.width = '2em';
    textArea.style.height = '2em';
    textArea.style.padding = '0';
    textArea.style.border = 'none';
    textArea.style.outline = 'none';
    textArea.style.boxShadow = 'none';
    textArea.style.background = 'transparent';

    // Append the textarea to the document
    document.body.appendChild(textArea);

    // Select and copy the text to the clipboard
    textArea.select();
    document.execCommand('copy');

    // Remove the textarea from the document
    document.body.removeChild(textArea);
  }
  const handleDepartmentChange = (value: any) => {
    setFormData({ ...formData, department: value });
  };

  const getRoleById = (roleId: any) => {
    return allRoles.find((roles: any) => roles.id === roleId);
  };

  const handleRoleClick = (roleId: any) => {
    if (formData.roles.includes(roleId)) {
      // Deselect the roles if it's already selected
      setFormData({
        ...formData,
        roles: formData.roles.filter((selectedRoleId: any) => selectedRoleId !== roleId),
      });
      // Add the roles back to existingRoles
      setExistingRoles([...existingRoles, getRoleById(roleId)]);
    } else {
      // Select the roles if it's not selected
      setFormData({
        ...formData,
        roles: [...formData.roles, roleId],
      });
      setExistingRoles(existingRoles.filter((roles: any) => roles.id !== roleId));
    }
  };

  const validateForm = () => {
    const validationErrors = {
      firstname: validateFirstname(formData.firstname),
      lastname: validateLastname(formData.lastname),
      username: validateUsername(formData.username),
      phone: validatePhone(formData.phone),
      email: validateEmail(formData.email.trim()),
      password: validatePassword(),
      // confirmPassword: validateConfirmPassword(
      //   formData.confirmPassword.trim(),
      //   formData.password.trim()
      // ),
    };
    setErrors(validationErrors);
    console.log('validationErrors', validationErrors);

    return Object.values(validationErrors).every((error) => !error);
  };

  const deleteRole = (roleId: any) => {
    if (formData.roles.includes(roleId)) {
      // Deselect the roles if it's already selected
      setFormData({
        ...formData,
        roles: formData.roles.filter((selectedRoleId: any) => selectedRoleId !== roleId),
      });
      // Add the roles back to existingRoles
      setExistingRoles([...existingRoles, getRoleById(roleId)]);
    }
  };

  const getRoleNameById = (roleId: any) => {
    const roles = allRoles.find((roles: any) => roles.id === roleId);
    return roles ? roles.role_name : 'Role Not Found';
  };

  const validateFirstname = (value: any) => {
    if (!value) {
      return t('userAccessControl.users.firstNameIsRequired');
    }
    const pattern = /^[a-zA-Z][a-zA-Z ]{1,18}[a-zA-Z]$/;

    if (!pattern.test(value)) {
      return t('sharedTexts.invalidNameFormat');
    }

    return '';
  };

  const validateLastname = (value: any) => {
    if (!value) {
      return t('userAccessControl.users.lastNameIsRequired');
    }
    const pattern = /^[a-zA-Z][a-zA-Z ]{1,18}[a-zA-Z]$/;

    if (!pattern.test(value)) {
      return t('sharedTexts.invalidNameFormat');
    }

    return '';
  };

  const validateUsername = (value: any) => {
    console.log('validateUsername', selectedLoginType);
    let errorMessage = '';
    if (!value) {
      if (selectedLoginType == 1) {
        return t('userAccessControl.users.userIdIsRequired');
      }
    }
    if (selectedLoginType == 1) {
      if (
        value.length < 4 ||
        value.length > 20 ||
        /^\d/.test(value) ||
        !/^[a-zA-Z0-9]+$/.test(value)
      ) {
        errorMessage = t('userAccessControl.users.invalidUsername');
      }
    }
    return errorMessage.trim();
  };

  const validatePhone = (value: any) => {
    if (!value) {
      return '';
    } else if (!/^\d{10}$/g.test(value)) {
      return t('userAccessControl.users.invalidPhoneFormat');
    }
    return '';
  };

  function validateEmailDomain(email: string, domain: string) {
    // Split email by @ symbol
    const parts = email.split('@');
    // Check if the domain part matches the provided domain
    return parts[1] !== domain;
  }

  useEffect(() => {
    setErrors({ ...errors, email: validateEmail(formData.email) });
  }, [selectedLoginType]);

  const validateEmail = (value: any) => {
    const domain: string = ssoKeys?.acceptedDomain ?? '';

    if (!value) {
      if (selectedLoginType == 0) {
        return t('userAccessControl.users.emailIsRequired');
      }
      return '';
    } else if (validateEmailDomain(value, domain) && selectedLoginType == 0) {
      return `${t('userAccessControl.users.acceptedDomain')} - ${domain}`;
    } else if (!/^\S+@\S+\.\S+$/.test(value)) {
      return t('userAccessControl.users.invalidEmailFormat');
    }
    return '';
  };

  const validatePassword = () => {
    const errorMessage = '';
    return errorMessage.trim();
  };

  const addUserAPI = async (request: any) => {
    setLoading(true);
    httpClient
      // .post('/api/users/', { data: request })
      .post('/api/account/users/', { data: request })
      .then((response: any) => {
        if (response.status === 200 || response.status === 201) {
          if (response.data) {
            setLoading(false);
            notify('success', t(response.data.message));
            navigate(`${paths.usersList}`);
          }
        } else if (response.data) {
          setLoading(false);
        } else {
          notify('error', t('userAccessControl.users.failedToCreateUser'));
        }
      })
      .catch(() => {
        notify('error', t('userAccessControl.users.failedToCreateUser'));
      });
  };

  const handleSubmit = (e: any) => {
    e.preventDefault();

    if (validateForm()) {
      const request = {
        first_name: formData.firstname,
        last_name: formData.lastname,
        username: formData.username,
        phone: formData.phone,
        email: formData.email.trim(),
        password: formData.password.trim(),
        roles: formData.roles,
        login_type: selectedLoginType == 1 ? 'simple' : 'sso',
        department: formData.department,
      };
      if (selectedLoginType != 1) {
        console.log('selectedLoginType', selectedLoginType);
        request['username'] = formData.email;
        delete request['password'];
      }
      addUserAPI(request);
    }
  };

  const closeCloneModal = () => {
    setOpenCloneModal(false);
  };

  const handleCloneUser = (selectedUser: any) => {
    closeCloneModal();
    setFormData({ ...formData, roles: [...selectedUser.roles.map((roles: any) => roles.id)] });

    // change existing roles according to added roles from clone
    const remainingRoles: any = (allRoles || []).filter(
      (item1: any) => !(selectedUser?.roles || []).some((item2: any) => item2.id === item1.id)
    );

    setExistingRoles(remainingRoles);
  };

  const isUserFormFilled = (formData: any) => {
    for (const key in formData) {
      if (Object.hasOwn(formData, key)) {
        console.log('isUserFormFilled', selectedLoginType);
        if (selectedLoginType == 1) {
          if (key !== 'email' && key !== 'department' && key !== 'phone') {
            if (Array.isArray(formData[key]) && formData[key].length === 0) {
              return false;
            }
            if (formData[key] === '') {
              return false;
            }
          }
        } else if (
          key !== 'username' &&
          key !== 'department' &&
          key !== 'password' &&
          key !== 'phone'
        ) {
          if (Array.isArray(formData[key]) && formData[key].length === 0) {
            return false;
          }
          if (formData[key] === '') {
            return false;
          }
        }
        if (formData.phone && errors.phone) {
          return false;
        }
      }
    }
    return true;
  };

  const isUserFormValid = (formData: any) => {
    for (const key in formData) {
      if (Object.hasOwn(formData, key) && key !== 'confirmPassword') {
        if (Array.isArray(formData[key]) && formData[key].length === 0) {
          return false;
        }
        if (formData[key] === '' && key !== 'phone' && key !== 'email' && key !== 'department') {
          return false;
        }
      }
    }

    if (formData.phone && errors.phone) {
      return false;
    }

    if (formData.email && errors.email) {
      return false;
    }
    return true;
  };

  if (loading) return <Loading />;
  return (
    <main className='dashboard'>
      <section className='dashboard__main'>
        <div className='dashboard__main__header'>
          <div className='flex items-center justify-between h-full'>
            <div className='flex items-center'>
              <button
                style={{ border: '0px solid', backgroundColor: '#f0ffff00' }}
                onClick={() => navigate(`${paths.usersList}`)}
                type='button'
              >
                <img className='cursor-pointer' src={arrowLeft} alt='back-arrow' />
              </button>
              <h2 className='text-xl font-bold ml-4'>{t('userAccessControl.users.addNewUser')}</h2>
            </div>
          </div>
        </div>
        <div className='dashboard__main__body px-8 py-6 scroll-0'>
          <div className='card-box pt-4 px-6 pb-8'>
            <div className='tab-section-content flex mt-4'>
              <div className='' style={{ paddingRight: 172 }}>
                <div className='flex flex-wrap -mx-2'>
                  <div className='col-4 px-2 mb-6'>
                    <div className='col-wrapper'>
                      <label
                        className='input-field-label font-semibold'
                        htmlFor='first_name'
                      >{`${t('userAccessControl.users.firstName')}*`}</label>
                      <input
                        type='text'
                        placeholder={t('userAccessControl.users.enterFirstName')}
                        name='firstname'
                        value={formData.firstname}
                        onChange={(e) => handleFirstnameChange(e.target.value)}
                        className='input-field input-field--md input-field--h40 w-full'
                        spellCheck={false}
                      />
                      {errors.firstname && <div className='error-message'>{errors.firstname}</div>}
                    </div>
                  </div>

                  <div className='col-4 px-2 mb-6'>
                    <div className='col-wrapper'>
                      <label
                        className='input-field-label font-semibold'
                        htmlFor='last_name'
                      >{`${t('userAccessControl.users.lastName')}*`}</label>
                      <input
                        type='text'
                        placeholder={t('userAccessControl.users.enterLastName')}
                        name='lastname'
                        value={formData.lastname}
                        onChange={(e) => handleLastnameChange(e.target.value)}
                        className='input-field input-field--md input-field--h40 w-full'
                        spellCheck={false}
                      />
                      {errors.lastname && <div className='error-message'>{errors.lastname}</div>}
                    </div>
                  </div>

                  <div className='col-4 px-2 mb-6'>
                    <div className='col-wrapper'>
                      <label
                        className='input-field-label font-semibold'
                        htmlFor='phone'
                      >{`${t('userAccessControl.users.phone')}`}</label>
                      <input
                        type='number'
                        placeholder={t('userAccessControl.users.enterPhoneNumber')}
                        name='phone'
                        value={formData.phone}
                        pattern='[0-9]{3}-[0-9]{2}-[0-9]{3}'
                        onChange={(e) => handlePhoneChange(e.target.value)}
                        className='input-field input-field--md input-field--h40 w-full'
                      />
                      {errors.phone && <div className='error-message'>{errors.phone}</div>}
                    </div>
                  </div>

                  <div className='col-4 px-2 mb-6'>
                    <div className='col-wrapper'>
                      <label className='input-field-label font-semibold'>
                        {selectedLoginType == 0
                          ? `${t('userAccessControl.users.email')}*`
                          : t('userAccessControl.users.email')}
                      </label>
                      <input
                        type='text'
                        placeholder={t('userAccessControl.users.enterEmail')}
                        name='email'
                        value={formData.email}
                        onChange={(e) => handleEmailChange(e.target.value)}
                        className='input-field input-field--md input-field--h40 w-full'
                      />
                      {errors.email && <div className='error-message'>{errors.email}</div>}
                    </div>
                  </div>

                  <div className='col-4 px-2 mb-6'>
                    <div className='col-wrapper'>
                      <label className='input-field-label font-semibold' htmlFor='department'>
                        {t('userAccessControl.users.department')}
                      </label>
                      <input
                        type='text'
                        placeholder={t('userAccessControl.users.enterDepartment')}
                        name='department'
                        value={formData.department}
                        onChange={(e) => handleDepartmentChange(e.target.value)}
                        className='input-field input-field--md input-field--h40 w-full'
                        spellCheck={false}
                      />
                    </div>
                  </div>

                  <div className='col-12 px-2 mb-6'>
                    <OutsideClickHandler onOutsideClick={() => {}}>
                      <div className='col-wrapper'>
                        <label
                          className='input-field-label font-semibold'
                          htmlFor='roles'
                        >{`${t('userAccessControl.roles.roles')}*`}</label>
                        <div className='custom-select-wrapper'>
                          <CustomSelect
                            options={existingRoles
                              .filter(
                                (roles: any) => roles.role_name !== 'SuperAdmin' && !roles.is_delete
                              )
                              .map((roles: any) => ({
                                value: roles.id,
                                option: roles.role_name,
                              }))}
                            value={
                              selectedValue === t('sharedTexts.select')
                                ? t('sharedTexts.select') + ' '
                                : t('sharedTexts.select')
                            }
                            index={0}
                            onChange={(id: any) => {
                              setSelectedValue(
                                selectedValue === t('sharedTexts.select')
                                  ? t('sharedTexts.select') + ' '
                                  : t('sharedTexts.select')
                              );
                              handleRoleClick(id);

                              // handleDropdown()
                            }}
                            styles={{ paddingRight: '4px' }}
                          ></CustomSelect>
                        </div>
                      </div>
                    </OutsideClickHandler>
                    <div className='pills-box-wrapper mt-3'>
                      {formData.roles.map((roleId: any) => (
                        <div className='pills-box' key={roleId}>
                          {getRoleNameById(roleId)}
                          <button
                            style={{ border: '0px solid', backgroundColor: '#f0ffff00' }}
                            onClick={() => deleteRole(roleId)}
                            type='button'
                          >
                            <img
                              src={closeIcon}
                              alt='close-icon'
                              className='pills-box__close-btn'
                            />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className='col-12 px-2 mb-6'>
                    <label
                      className='input-field-label font-semibold'
                      htmlFor='login_type'
                    >{`${t('userAccessControl.users.loginType')}*`}</label>
                    <div className='modal__radio flex' style={{ padding: '15px 0' }}>
                      <label className='p-1 radio-container'>
                        <input
                          className='p-1'
                          type='radio'
                          name='current-mix-system'
                          value={0}
                          checked={selectedLoginType == 0}
                          onChange={onValueChange}
                        />
                        <span className='radio-text radio-style'>
                          SSO {`(${t('userAccessControl.users.loginWithSso')})`}
                        </span>
                      </label>
                      <div className='col-12 flex mt-4'>
                        <label className='p-1 mt-2 col-2' style={{ width: 'auto' }}>
                          <input
                            className='p-1'
                            type='radio'
                            name='current-mix-system'
                            value={1}
                            checked={selectedLoginType == 1}
                            onChange={onValueChange}
                          />
                          <span className='radio-text radio-style'>
                            {t('userAccessControl.users.userId')}
                          </span>
                        </label>
                        {
                          <div className='p-1 col-10'>
                            <div className='flex' style={{ marginTop: '-12px' }}>
                              <div className='col-4 px-2 mb-6'>
                                <div className='col-wrapper'>
                                  <label
                                    className='input-field-label font-semibold'
                                    htmlFor='user_id'
                                  >
                                    {t('userAccessControl.users.userId')}
                                  </label>
                                  <input
                                    type='text'
                                    placeholder={t('sharedTexts.enterUserId')}
                                    name='username'
                                    disabled={selectedLoginType == 0}
                                    value={formData.username}
                                    onChange={(e) => handleUsernameChange(e.target.value.trim())}
                                    className='input-field input-field--md input-field--h40 w-full'
                                    spellCheck={false}
                                  />
                                  {errors.username && (
                                    <div className='error-message'>{errors.username}</div>
                                  )}
                                </div>
                              </div>
                              {selectedLoginType == 1 && isPasswordVisible && (
                                <div
                                  className='col-4 px-2 mb-6 flex'
                                  style={{ position: 'relative' }}
                                >
                                  <div className='col-wrapper'>
                                    <label
                                      className='input-field-label font-semibold'
                                      htmlFor='password_generated'
                                    >
                                      {t('userAccessControl.users.passwordGenerated')}
                                    </label>
                                    <input
                                      type='password'
                                      disabled
                                      placeholder=''
                                      name='password'
                                      value={formData.password}
                                      // onChange={(e) => handlePasswordChange(e.target.value)}
                                      className='input-field input-field--md input-field--h40 w-full'
                                      style={{ minWidth: '222px' }}
                                    />
                                  </div>
                                  {/* <div > */}
                                  <img
                                    src={copy}
                                    alt='copy-icon'
                                    style={{
                                      cursor: 'pointer',
                                      width: '30px',
                                      marginLeft: '10px',
                                      marginTop: '22px',
                                    }}
                                    // onClick={() => {
                                    //   navigator.clipboard.writeText(formData.password);
                                    // }}
                                    onClick={() => copyTextToClipboard(formData.password)}
                                    onKeyDown={(e) =>
                                      e.key === 'Enter' && copyTextToClipboard(formData.password)
                                    }
                                    data-toggle='tooltip'
                                    data-placement='bottom'
                                    onMouseOver={() => setShowTooltip(true)}
                                    onFocus={() => setShowTooltip(true)}
                                    onMouseOut={() => setShowTooltip(false)}
                                    onBlur={() => setShowTooltip(false)}
                                  />
                                  {showTooltip ? (
                                    <span className='user__tooltip'>
                                      {t('userAccessControl.users.copyPassword')}
                                    </span>
                                  ) : (
                                    ''
                                  )}
                                  {/* </div> */}
                                </div>
                              )}

                              {selectedLoginType == 1 && !isPasswordVisible && (
                                <div className='pt-28'>
                                  <button
                                    type='button'
                                    className={`btn btn--primary btn--h36 px-8 py-2 ml-4`}
                                    onClick={generatePassword}
                                  >
                                    {t('userAccessControl.users.generatePassword')}
                                  </button>
                                </div>
                              )}
                            </div>
                          </div>
                        }
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className='dashboard__main__footer'>
          <div className='dashboard__main__footer__container'>
            <button
              className='btn btn--h36 px-4 py-2'
              type='button'
              onClick={() => navigate(`${paths.usersList}`)}
            >
              {t('sharedTexts.cancel')}
            </button>
            <button
              // type="submit"
              type='button'
              className={`btn btn--primary btn--h36 px-8 py-2 ml-4 ${
                isUserFormFilled(formData) || isUserFormValid(formData) ? '' : 'disabled'
              }`}
              onClick={handleSubmit}
            >
              {t('sharedTexts.saveChanges')}
            </button>
          </div>
        </div>
        {/* </form> */}
      </section>
      {openCloneModal && (
        <ModalCloneUser
          showModal={openCloneModal}
          closeModel={closeCloneModal}
          handleCloneUser={handleCloneUser}
        />
      )}
    </main>
  );
};

export default AddNewUser;
