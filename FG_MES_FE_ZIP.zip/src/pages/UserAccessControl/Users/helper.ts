import _ from 'lodash';

export const userTableHeaders = [
  // extra column for arrow
  {
    label: 'userAccessControl.users.userId',
    alignment: '', // optional
    width: '120px', // optional
    enableSort: true,
    sortKey: 'id',
  },
  {
    label: 'userAccessControl.users.name',
    alignment: '', // optional
    width: '', // optional
    enableSort: true,
    sortKey: 'first_name',
  },
  {
    label: 'userAccessControl.users.username',
    alignment: '', // optional
    width: '', // optional
    enableSort: true,
    sortKey: 'username',
  },
  {
    label: 'userAccessControl.users.ssoStatus',
    alignment: '', // optional
    width: '', // optional
    enableSort: true,
    sortKey: 'login_type',
  },
  {
    label: 'userAccessControl.roles.roles',
    alignment: '', // optional
    width: '', // optional
    enableSort: false,
    sortKey: '',
  },
  {
    label: '',
    alignment: '', // optional
    width: '200px', // optional
    enableSort: false,
    sortKey: '',
  },
];

export function formatUsers(
  data: any // maybe define a type?
) {
  const statusLanguageKey: any = `sharedTexts.pillLogicKeys.dynamic${data.login_type === 'sso' ? 'Enabled' : 'Disabled'}`;
  return {
    userId: data.id,
    name: `${data.first_name} ${data.last_name}`,
    username: data.username,
    ssoStatus: statusLanguageKey,
    roles: data.roles_values,
    // is_super_admin: data.id == 1,
    showActivateButton: data.is_delete,
    showResetButton: data.login_type === 'simple',
    // depending on id set is_super_admin true 1-> super_admin
  };
}

export const toolTipsForUsers = {
  viewIconToolText: 'toolTips.viewUser',
  editIconToolText: 'toolTips.editUser',
  deactivateIconToolText: 'toolTips.deactivateUser',
  activateIconToolText: 'toolTips.activateUser',
  resetIconToolText: 'toolTips.resetPassword',
};

export const generatePassword = (): any => {
  const symbols = '!@#$%^&*';
  const uppercaseLetters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const lowercaseLetters = 'abcdefghijklmnopqrstuvwxyz';
  const numbers = '0123456789';

  let generatedPassword = '';
  const charset = lowercaseLetters + uppercaseLetters + numbers + symbols;

  for (let i = 0; i < 8; i++) {
    generatedPassword += charset.charAt(Math.floor(Math.random() * charset.length));
  }

  // Ensure the password contains at least one uppercase letter, one number, and one symbol
  const hasUppercase = /[A-Z]/.test(generatedPassword);
  const hasNumber = /\d/.test(generatedPassword);
  const hasSymbol = /[!@#$%^&*]/.test(generatedPassword);

  if (!hasUppercase || !hasNumber || !hasSymbol) {
    // If any requirement is not met, recursively call generatePassword function again
    return generatePassword();
  }
  return generatedPassword;
};
