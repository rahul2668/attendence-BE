import { useEffect, useState } from 'react';
import 'assets/styles/scss/pages/dashboard.scss';
import 'assets/styles/scss/components/table-general.scss';
import arrowLeft from 'assets/icons/arrow-left.svg';
import editIcon from 'assets/icons/edit-thick.svg';
import checkIcon from 'assets/icons/check-icon-color.svg';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import httpClient from 'http/httpClient';
import { paths } from 'routes/paths';
import { isEmpty, validatePermissions } from 'utils/utils';
import Loading from 'components/common/Loading';
import { crudType, permissionsMapper } from 'utils/constants';
import { useTranslation } from 'react-i18next';
import { useAppSelector } from 'store';

const actions = ['View', 'Create', 'Delete'];

const UsersListView = () => {
  const navigate = useNavigate();
  const { userId } = useParams();
  const { t } = useTranslation();
  const [userDetails, setUserDetails] = useState<any>({});
  const [isLoggedInUser, setIsLoggedInUser] = useState(false);
  const [allRoles, setAllRoles] = useState<any>([]);
  const [loading, setLoading] = useState(true);

  const actionsItem = [
    t('sharedTexts.view'),
    t('sharedTexts.createOrEdit'),
    // t('sharedTexts.edit'),
    t('sharedTexts.delete'),
  ];

  const UserInfo: any = useAppSelector((state) => state.userData.userData);
  useEffect(() => {
    if (userId) {
      if (!isEmpty(UserInfo)) {
        if (UserInfo.id === Number(userId)) {
          setIsLoggedInUser(true);
        } else {
          setIsLoggedInUser(false);
        }
      }
    }
  }, [userId]);

  useEffect(() => {
    const getRolesAPI = async () => {
      httpClient
        .get('/api/account/roles/?is_delete=false')
        .then((response: any) => {
          if (response.data) {
            setAllRoles(response.data.results);
          }
        })
        .catch((err) => {
          console.log('errored -->', err);
        });
    };
    getRolesAPI();
  }, []);

  const { pathname } = useLocation();
  const module = pathname?.split('/')[1];
  const subModule = pathname?.split('/')[2];

  const hasEditPermission = validatePermissions(
    permissionsMapper[module],
    permissionsMapper[subModule],
    crudType.edit
  );

  const handleEditClick = (event: any) => {
    event.stopPropagation();
    navigate(`${paths.editUser}/${userId}`);
  };

  useEffect(() => {
    if (userId) {
      httpClient
        // .get(`/api/users/${userId}`)
        .get(`/api/account/users/${userId}/?type=view`)
        .then((response) => {
          if (response.data) {
            setUserDetails(response.data);
            setLoading(false);
          }
        })
        .catch((err) => {
          console.log('errored -->', err);
        });
    }
  }, [userId]);

  const renderTableHead = () => {
    return (
      <thead>
        <tr>
          <td>{t('sharedTexts.functions')}</td>
          {actionsItem.map((action: string) => (
            <td key={action}>{action}</td>
          ))}
        </tr>
      </thead>
    );
  };

  const { permission_list } = userDetails;

  const renderTableRow = () => {
    const rows = [];

    for (const module in permission_list) {
      let text: string = 'plantModulesAndFunctions.' + module;
      rows.push(
        <tr key={module} className='title'>
          <td colSpan={5}>{t(text, text)}</td>
        </tr>
      );
      for (const subModule in permission_list[module]) {
        let text: string = 'plantModulesAndFunctions.' + subModule;
        const data = permission_list[module][subModule];
        const row = (
          <tr key={subModule}>
            <td>{t(text, text)}</td>
            {actions.map((permission) => {
              if (
                !(
                  (subModule === 'Active Furnace List' || subModule === 'Bin Contents') &&
                  permission.toLowerCase() === t('sharedTexts.delete')
                ) &&
                !(
                  subModule === 'Bin Contents' &&
                  permission.toLowerCase() === t('sharedTexts.create')
                )
              ) {
                return (
                  <td key={permission}>
                    {data[permission.toLowerCase()] ? (
                      <img src={checkIcon} alt='check-icon' />
                    ) : null}
                  </td>
                );
              } else {
                return <td key={permission}></td>;
              }
            })}
          </tr>
        );

        rows.push(row);
      }
    }

    return <tbody>{rows}</tbody>;
  };

  if (loading) return <Loading />;

  return (
    <main className='dashboard'>
      <section className='dashboard__main'>
        <div className='dashboard__main__header'>
          <div className='flex items-center justify-between h-full'>
            <div className='flex items-center'>
              <button
                style={{ border: '0px solid', backgroundColor: '#f0ffff00' }}
                type='button'
                onClick={() => navigate(`${paths.usersList}`)}
              >
                <img className='cursor-pointer' src={arrowLeft} alt='back-arrow' />
              </button>
              <h2 className='text-xl font-bold ml-4'>
                {userDetails?.first_name + ' ' + userDetails?.last_name}
              </h2>
            </div>
          </div>
        </div>
        <div className='dashboard__main__body px-8 py-6 scroll-0'>
          <div className='card-box px-6 py-8' style={{ paddingTop: '50px' }}>
            <div className='btn-edit-absolute'>
              <button
                onClick={hasEditPermission && !isLoggedInUser && handleEditClick}
                className={`btn btn--h30 py-1 px-2 font-bold ${
                  hasEditPermission && !isLoggedInUser ? '' : 'disabled'
                }`}
              >
                <img src={editIcon} alt='edit' className='mr-3' />
                {''}
                {t('sharedTexts.edit')}
              </button>
            </div>
            <div className='flex'>
              {/* <div className='flex flex-col' style={{ width: 276 }}>
                <h2 className='text-xl font-medium'>
                  {userDetails.first_name + ' ' + userDetails.last_name} Details
                </h2>
               
              </div> */}
              <div className='flex-1'>
                <div className='flex flex-wrap -mx-2'>
                  <div className='col-3 px-2 mb-6'>
                    <label className='input-field-label' htmlFor='id'>
                      {t('userAccessControl.users.userId')}
                    </label>
                    <p className='input-field-text'>{userId}</p>
                  </div>
                  <div className='col-3 px-2 mb-6'>
                    <label className='input-field-label' htmlFor='name'>
                      {t('userAccessControl.users.name')}
                    </label>
                    <p className='input-field-text'>
                      {userDetails?.first_name + ' ' + userDetails?.last_name}
                    </p>
                  </div>
                  <div className='col-3 px-2'>
                    <label className='input-field-label' htmlFor='phone_number'>
                      {t('userAccessControl.users.phoneNumber')}
                    </label>
                    <p className='input-field-text'>{userDetails?.phone || '-'}</p>
                  </div>
                  <div className='col-3 px-2'>
                    <label className='input-field-label' htmlFor='email'>
                      {t('userAccessControl.users.email')}
                    </label>
                    <p className='input-field-text'>{userDetails?.email || '-'}</p>
                  </div>
                </div>
                <div className='flex flex-wrap -mx-2'>
                  <div className='col-3 px-2'>
                    <label className='input-field-label' htmlFor='department'>
                      {t('userAccessControl.users.department')}
                    </label>
                    <p className='input-field-text'>{userDetails?.department || '-'}</p>
                  </div>
                  <div className='col-3 px-2'>
                    <label className='input-field-label' htmlFor='roles'>
                      {t('userAccessControl.roles.roles')}
                    </label>
                    <p className='input-field-text'>
                      {userDetails?.roles
                        ?.map((roleId: any) => {
                          const roles = allRoles.find((r: any) => r.id === roleId);
                          return roles ? roles.role_name : null;
                        })
                        .join(', ')}
                    </p>
                  </div>
                  <div className='col-3 px-2'>
                    <label className='input-field-label' htmlFor='sso_login'>
                      SSO {t('authentication.login.loginText')}
                    </label>
                    <p
                      className='input-field-text'
                      style={{ color: userDetails.login_type == 'sso' ? '#238903' : '#8F1D18' }}
                    >
                      {userDetails.login_type == 'sso'
                        ? t('sharedTexts.enabled')
                        : t('sharedTexts.disabled')}
                    </p>
                  </div>
                  <div className='col-3 px-2'>
                    <label className='input-field-label' htmlFor='user_name'>
                      {t('userAccessControl.users.username')}
                    </label>
                    <p className='input-field-text'>{userDetails?.username || '-'}</p>
                  </div>
                </div>
              </div>
            </div>
            <div style={{ borderBottom: '1px solid var(--grey30)', marginTop: '30px' }}></div>
            {!isEmpty(permission_list) && (
              <>
                <div className='mt-8'>
                  <h3 className='text-xl font-medium'>{t('sharedTexts.functions')}</h3>
                  {/* <p className="color-tertiary-text text-sm mt-2">
                    This could be used to write very important message or instruction to the person
                    who is entering it.
                  </p> */}
                </div>
                <div className='table-general-wrapper mt-4'>
                  <table className='table-general table-general--user-access table-general--user-access--list align-cells-center'>
                    {renderTableHead()}
                    {renderTableRow()}
                  </table>
                </div>
              </>
            )}
          </div>
        </div>
      </section>
    </main>
  );
};

export default UsersListView;
