import React, { useEffect, useState } from 'react';
import 'assets/styles/scss/pages/dashboard.scss';
import 'assets/styles/scss/components/table-general.scss';
import arrowLeft from 'assets/icons/arrow-left.svg';
import clone from 'assets/icons/clone.svg';
import { useLocation, useNavigate } from 'react-router-dom';
import RoleService from 'store/services/roleService';
import { RolesInitialData } from 'types/role.model';
import CloneModalRole from 'components/Modal/CloneModalRole';
import { paths } from 'routes/paths';
import { isEmpty, notify, validatePermissionList, validatePermissions } from 'utils/utils';
import { crudType, permissionsMapper, uniqueCodesMapper } from 'utils/constants';
import Loading from 'components/common/Loading';
import { useTranslation } from 'react-i18next';

interface AddNewRoleProps {
  setAddNewRole: (value: boolean) => void;
}

const AddNewRole: React.FC<AddNewRoleProps> = () => {
  const { t } = useTranslation();
  const [roleName, setRoleName] = useState<string>('');
  const [cloneModal, setCloneModal] = useState<boolean>(false);
  const [initialData, setInitialData] = useState<RolesInitialData>({});
  const [selectedRole, setSelectedRole] = useState<any>(null);
  const [confirmClone, setConfirmClone] = useState<boolean>(false);
  const [errors, setErrors] = useState<any>({});
  const [selectAllChecked, setSelectAllChecked] = useState(false);
  const [loading, setLoading] = useState(true);

  const { pathname } = useLocation();
  const module = pathname?.split('/')[1];
  const subModule = pathname?.split('/')[2];

  const hasClonePermission = validatePermissions(
    permissionsMapper[module],
    permissionsMapper[subModule],
    crudType.create
  );

  const validateRoleName = (value: any) => {
    if (!value.trim()) {
      return t('userAccessControl.roles.roleNameIsRequired');
    }

    const pattern = /^(?! )[a-zA-Z0-9 ]{3,30}(?<! )$/;

    if (!pattern.test(value)) {
      return t('sharedTexts.invalidNameFormat');
    }

    return '';
  };

  const navigate = useNavigate();
  const handleCloneButtonClick = () => {
    setCloneModal(true);
  };
  const closeModel = () => {
    setCloneModal(false);
  };

  const getInitialRoleData = async () => {
    const requestData = { role_id: null, is_clone: confirmClone };
    const response = await RoleService.getRoleDetails(requestData);
    setLoading(false);
    setInitialData(response.data.permission_list);
  };

  const getRoleDetails = async () => {
    const requestData: any = {
      role_id: selectedRole,
      is_clone: confirmClone,
    };
    setLoading(true);
    const response = await RoleService.getRoleDetails(requestData);
    const clonedPermissions: any = response.data.permission_list;
    setLoading(false);
    setInitialData(response.data.permission_list);

    //update select all based on cloned permissions
    const areAllChecked = Object.keys(clonedPermissions).every((cat) =>
      Object.keys(clonedPermissions[cat]).every(
        (k) =>
          clonedPermissions[cat][k].view &&
          clonedPermissions[cat][k].create &&
          clonedPermissions[cat][k].edit &&
          clonedPermissions[cat][k].delete
      )
    );
    setSelectAllChecked(areAllChecked);
  };

  useEffect(() => {
    if (confirmClone) {
      getRoleDetails();
    } else {
      getInitialRoleData();
    }
  }, [selectedRole, confirmClone]);

  const handlePermissionChange = (
    category: string,
    key: string,
    action: string,
    currentStatus: boolean
  ) => {
    setInitialData((prevInitialData) => {
      const updatedInitialData = { ...prevInitialData };
      let checkKeyDownTime =
        updatedInitialData[category][uniqueCodesMapper.furnaceDowntimeLogFunction];
      let checkKeyDownTimeEvent =
        updatedInitialData[category][uniqueCodesMapper.furnaceDowntimeLogEventFunction];
      let checkKeyDownTimeSplit =
        updatedInitialData[category][uniqueCodesMapper.furnaceDowntimeLogSplitFunction];

      if (action === crudType.view) {
        // Allow toggling view only if all create/edit/delete are disabled
        const canToggleView =
          !updatedInitialData[category][key].create &&
          !updatedInitialData[category][key].edit &&
          !updatedInitialData[category][key].delete;

        if (canToggleView) {
          updatedInitialData[category][key][action] = currentStatus;
        }

        if (
          [
            uniqueCodesMapper.furnaceDowntimeLogFunction,
            uniqueCodesMapper.furnaceDowntimeLogEventFunction,
            uniqueCodesMapper.furnaceDowntimeLogSplitFunction,
          ].includes(key) &&
          canToggleView
        ) {
          if (
            checkKeyDownTimeEvent[crudType.create] ||
            checkKeyDownTimeEvent[crudType.edit] ||
            checkKeyDownTimeEvent[crudType.delete] ||
            checkKeyDownTimeSplit[crudType.create] ||
            checkKeyDownTimeSplit[crudType.edit] ||
            checkKeyDownTimeSplit[crudType.delete]
          ) {
            checkKeyDownTime[action] = true;
            checkKeyDownTimeEvent[action] = true;
            checkKeyDownTimeSplit[action] = true;
          } else {
            checkKeyDownTime[crudType.view] = currentStatus;
            checkKeyDownTimeEvent[crudType.view] = currentStatus;
            checkKeyDownTimeSplit[crudType.view] = currentStatus;
          }
        }
      } else {
        // Allow editing create/edit/delete
        updatedInitialData[category][key][action] = currentStatus;
        if (action === crudType.create) updatedInitialData[category][key].edit = currentStatus; // when enabling separate edit, delete this if */}

        // If edit, delete, or create is enabled, enable view if it's false
        if (
          currentStatus &&
          (action === crudType.edit || action === crudType.delete || action === crudType.create)
        ) {
          updatedInitialData[category][key].view = true;
          if (action === crudType.create) {
            // when enabling separate edit, delete this if */}
            updatedInitialData[category][key].edit = true;
          }
        }

        if (
          [
            uniqueCodesMapper.furnaceDowntimeLogFunction,
            uniqueCodesMapper.furnaceDowntimeLogEventFunction,
            uniqueCodesMapper.furnaceDowntimeLogSplitFunction,
          ].includes(key)
        ) {
          if (
            !checkKeyDownTimeEvent[crudType.create] ||
            !checkKeyDownTimeEvent[crudType.edit] ||
            !checkKeyDownTimeEvent[crudType.delete] ||
            !checkKeyDownTimeSplit[crudType.create] ||
            !checkKeyDownTimeSplit[crudType.edit] ||
            !checkKeyDownTimeSplit[crudType.delete]
          ) {
            checkKeyDownTime[crudType.view] = true;
            checkKeyDownTimeEvent[crudType.view] = true;
            checkKeyDownTimeSplit[crudType.view] = true;
          } else {
            checkKeyDownTime[crudType.view] = currentStatus;
            checkKeyDownTimeEvent[crudType.view] = currentStatus;
            checkKeyDownTimeSplit[crudType.view] = currentStatus;
          }
        }

        // Update "Select All" state based on the individual checkbox changes
        const areAllChecked = Object.keys(updatedInitialData).every((cat) =>
          Object.keys(updatedInitialData[cat]).every(
            (k) =>
              updatedInitialData[cat][k].view &&
              updatedInitialData[cat][k].create &&
              updatedInitialData[cat][k].edit &&
              updatedInitialData[cat][k].delete
          )
        );

        setSelectAllChecked(areAllChecked);
      }

      return updatedInitialData;
    });
  };

  const validateForm = () => {
    const validationErrors = {
      role_name: validateRoleName(roleName.trim()),
    };
    setErrors(validationErrors);
    return Object.values(validationErrors).every((error) => !error);
  };

  const handleSaveButton = async () => {
    setLoading(true);
    if (validateForm()) {
      if (!validatePermissionList(initialData)) {
        setLoading(false);
        return notify(
          'error',
          t('userAccessControl.roles.roleMustHaveAtLeastOneViewFunctionEnabled')
        );
      }
      const requestData = {
        permission_list: initialData,
        role_name: roleName.trim(),
        is_superuser: selectAllChecked,
      };
      const response = await RoleService.createRole(requestData);

      if (response.status === 200) {
        setLoading(false);
        notify('success', t('userAccessControl.roles.roleAddedSuccessNotify'));
        navigate(`${paths.rolesList}`);
      } else {
        setLoading(false);
      }
    }
  };

  const handleChangeRoleName = (value: any) => {
    setRoleName(value);
    setErrors({ ...errors, role_name: validateRoleName(value) });
  };

  const handleChange = (checkboxType: 'selectAll') => {
    setSelectAllChecked((prevSelectAllChecked) => {
      const newSelectAllChecked = !prevSelectAllChecked;

      setInitialData((prevInitialData) => {
        const updatedInitialData = { ...prevInitialData };

        Object.keys(updatedInitialData).forEach((category) => {
          Object.keys(updatedInitialData[category]).forEach((key) => {
            updatedInitialData[category][key] = {
              ...updatedInitialData[category][key],
              view:
                checkboxType === 'selectAll'
                  ? newSelectAllChecked
                  : updatedInitialData[category][key].view,
              create:
                checkboxType === 'selectAll' &&
                category !== uniqueCodesMapper.systemAdminModule &&
                category !== uniqueCodesMapper.reportsModule &&
                key !== uniqueCodesMapper.furnaceDowntimeLogFunction
                  ? newSelectAllChecked
                  : updatedInitialData[category][key].create,
              edit:
                checkboxType === 'selectAll' &&
                category !== uniqueCodesMapper.systemAdminModule &&
                category !== uniqueCodesMapper.reportsModule &&
                key !== uniqueCodesMapper.furnaceDowntimeLogFunction
                  ? newSelectAllChecked
                  : updatedInitialData[category][key].edit,
              delete:
                checkboxType === 'selectAll' &&
                category !== uniqueCodesMapper.systemAdminModule &&
                category !== uniqueCodesMapper.reportsModule &&
                category !== uniqueCodesMapper.masterDataModule &&
                category !== uniqueCodesMapper.userAccessControlModule &&
                key !== uniqueCodesMapper.furnaceDowntimeLogFunction
                  ? newSelectAllChecked
                  : updatedInitialData[category][key].delete,
            };
          });
        });

        return updatedInitialData;
      });

      return newSelectAllChecked;
    });
  };

  if (loading) return <Loading />;

  return (
    <main className='dashboard'>
      <section className='dashboard__main'>
        <div className='dashboard__main__header'>
          <div className='flex items-center justify-between h-full'>
            <div className='flex items-center'>
              <button
                onClick={() => navigate(`${paths.rolesList}`)}
                style={{ border: '0px solid', backgroundColor: '#f0ffff00' }}
              >
                <img className='cursor-pointer' src={arrowLeft} alt='back-arrow' />
              </button>

              <h2 className='text-xl font-bold ml-4'>{t('userAccessControl.roles.AddNewRole')}</h2>
            </div>
            <button
              onClick={hasClonePermission && handleCloneButtonClick}
              className={`btn btn--h36 px-4 py-2 ${hasClonePermission ? '' : 'disabled'}`}
            >
              <img src={clone} alt='clone-icon' className='mr-3' /> {t('sharedTexts.clone')}
            </button>
          </div>
        </div>
        <CloneModalRole
          showModal={cloneModal}
          closeModel={closeModel}
          setSelectedRole={setSelectedRole}
          setConfirmClone={setConfirmClone}
        />
        <div className='dashboard__main__body px-8 py-6'>
          <div className='card-box px-6 py-8'>
            <div className='flex'>
              {/* <div className='flex flex-col' style={{ width: 260 }}>
                <h2 className='text-xl font-medium'>Enter Role Details</h2>
              </div> */}
              <div style={{ width: 352 }}>
                <label
                  className='input-field-label'
                  htmlFor='RoleName'
                >{`${t('userAccessControl.roles.roleName')}*`}</label>
                <input
                  type='text'
                  placeholder={t('userAccessControl.roles.enterRoleName')}
                  className={`input-field input-field--h40 input-field--md w-full ${
                    errors.role_name ? `input-field--error` : ''
                  }`}
                  value={roleName}
                  onChange={(e) => handleChangeRoleName(e.target.value)}
                  spellCheck={false}
                />
                {errors.role_name && <div className='error-message'>{errors.role_name}</div>}
              </div>
            </div>
            <div className='flexpr-8 pt-8'>
              <div className='flex'>
                <input
                  type='checkbox'
                  id='selecteAll'
                  checked={selectAllChecked}
                  onChange={() => handleChange('selectAll')}
                />
                <label htmlFor='selecteAll' className='custom-checkbox__label ml-2'>
                  {t('sharedTexts.selectAll')}
                </label>
              </div>
            </div>
            <div className='table-general-wrapper mt-3'>
              <table className='table-general table-general--user-access'>
                <thead>
                  <tr>
                    <td>{t('sharedTexts.functions')}</td>
                    <td>{t('sharedTexts.view')}</td>
                    <td>{t('sharedTexts.createOrEdit')}</td>
                    {/* // when enabling separate edit, uncomment this */}
                    {/* <td>{t('sharedTexts.edit')}</td> */}
                    <td>{t('sharedTexts.delete')}</td>
                  </tr>
                </thead>
                {Object.keys(initialData).map((category) => {
                  const categoryName: any = `plantModulesAndFunctions.${category}`;
                  return (
                    <tbody key={category}>
                      <tr className='title'>
                        <td colSpan={5}>{t(categoryName)}</td>
                      </tr>
                      {Object.keys(initialData[category]).map((key) => {
                        const subCategoryName: any = `plantModulesAndFunctions.${key}`;
                        return (
                          <tr key={key}>
                            <td>{t(subCategoryName)} </td>
                            <td>
                              <div className='custom-checkbox'>
                                <input
                                  type='checkbox'
                                  id={`views-${key}`}
                                  className='custom-checkbox__input'
                                  checked={initialData[category]?.[key]?.view || false}
                                  onChange={(e) =>
                                    handlePermissionChange(
                                      category,
                                      key,
                                      crudType.view,
                                      (e.target as HTMLInputElement).checked
                                    )
                                  }
                                />
                                <label htmlFor={`views-${key}`} className='custom-checkbox__label'>
                                  <code className='custom-checkbox__label__box'></code>
                                </label>
                              </div>
                            </td>
                            <td>
                              {key !== uniqueCodesMapper.furnaceDowntimeLogFunction ? (
                                category !== uniqueCodesMapper.systemAdminModule &&
                                category !== uniqueCodesMapper.reportsModule && (
                                  <div className='custom-checkbox'>
                                    <input
                                      type='checkbox'
                                      id={`create-${key}`}
                                      className='custom-checkbox__input'
                                      checked={initialData[category]?.[key]?.create || false}
                                      onChange={(e) =>
                                        handlePermissionChange(
                                          category,
                                          key,
                                          crudType.create,
                                          (e.target as HTMLInputElement).checked
                                        )
                                      }
                                    />
                                    <label
                                      htmlFor={`create-${key}`}
                                      className='custom-checkbox__label'
                                    >
                                      <code
                                        className={`custom-checkbox${
                                          category == uniqueCodesMapper.systemAdminModule
                                            ? '__label__box__disabled'
                                            : '__label__box'
                                        }`}
                                      ></code>
                                    </label>
                                  </div>
                                )
                              ) : (
                                <div></div>
                              )}
                            </td>

                            {/* $$$ when enabling separate edit, uncomment this $$$$ */}

                            {/* <td>
                              {category !== uniqueCodesMapper.systemAdminModule  && key !==uniqueCodesMapper.furnaceDowntimeLogFunction && (
                                <div className='custom-checkbox'>
                                  <input
                                    type='checkbox'
                                    id={`edit-${key}`}
                                    className='custom-checkbox__input'
                                    checked={initialData[category]?.[key]?.edit || false}
                                    onChange={(e) =>
                                      handlePermissionChange(
                                        category, 
                                        key,
                                        crudType.edit,
                                        (e.target as HTMLInputElement).checked
                                      )
                                    }
                                  />
                                  <label htmlFor={`edit-${key}`} className='custom-checkbox__label'>
                                    <code
                                      className={`custom-checkbox${
                                        category == uniqueCodesMapper.systemAdminModule
                                          ? '__label__box__disabled'
                                          : '__label__box'
                                      }`}
                                    ></code>
                                  </label>
                                </div>
                              )}
                            </td> */}
                            <td>
                              {key !== uniqueCodesMapper.furnaceDowntimeLogFunction ? (
                                category !== uniqueCodesMapper.systemAdminModule &&
                                category !== uniqueCodesMapper.reportsModule &&
                                category !== uniqueCodesMapper.masterDataModule &&
                                category !== uniqueCodesMapper.userAccessControlModule && (
                                  <div className='custom-checkbox'>
                                    <input
                                      type='checkbox'
                                      id={`delete-${key}`}
                                      className='custom-checkbox__input'
                                      checked={initialData[category]?.[key]?.delete || false}
                                      onChange={(e) =>
                                        handlePermissionChange(
                                          category,
                                          key,
                                          crudType.delete,
                                          (e.target as HTMLInputElement).checked
                                        )
                                      }
                                    />
                                    <label
                                      htmlFor={`delete-${key}`}
                                      className='custom-checkbox__label'
                                    >
                                      <code
                                        className={`custom-checkbox${
                                          category == uniqueCodesMapper.systemAdminModule
                                            ? '__label__box__disabled'
                                            : '__label__box'
                                        }`}
                                      ></code>
                                    </label>
                                  </div>
                                )
                              ) : (
                                <div></div>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  );
                })}
              </table>
            </div>
          </div>
        </div>
        <div className='dashboard__main__footer'>
          <div className='dashboard__main__footer__container'>
            <button
              onClick={() => navigate(`${paths.rolesList}`)}
              className='btn btn--h36 px-4 py-2'
            >
              {t('sharedTexts.cancel')}
            </button>
            <button
              disabled={errors.role_name}
              onClick={handleSaveButton}
              className={
                errors.role_name || isEmpty(roleName)
                  ? 'btn btn--primary disabled btn--h36 px-8 py-2 ml-4'
                  : 'btn btn--primary btn--h36 px-8 py-2 ml-4'
              }
            >
              {/* className={'btn btn--primary btn--h36 px-8 py-2 ml-4'}> */}
              {t('sharedTexts.saveChanges')}
            </button>
          </div>
        </div>
      </section>
    </main>
  );
};

export default AddNewRole;
