import { useState } from 'react';
import 'assets/styles/scss/components/table-general.scss';
import { paths } from 'routes/paths';
import { useNavigate, Link } from 'react-router-dom';
import { isEmpty, notify } from 'utils/utils';
import RoleOptionModal from 'components/Modal/RoleOptionModal';
import OutsideClickHandler from 'react-outside-click-handler';
import editIcon from 'assets/icons/edit1.svg';
import viewIcon from 'assets/icons/eye1.svg';
import deactivateIcon from 'assets/icons/deactivate.svg';
import httpClient from 'http/httpClient';
import AlertModal from 'components/Modal/AlertModal';
import Loading from 'components/common/Loading';
import { useTranslation } from 'react-i18next';
import { UnfoldMore as SortIcon } from '@mui/icons-material';
import { North as UpIcon } from '@mui/icons-material';
import { South as DownIcon } from '@mui/icons-material';

const TableRolesList = (props: any) => {
  const {
    roles,
    setRoles,
    // handleOptionModal,
    handleDeleteClick,
    handleOnchangeStatus,
    hasEditPermission,
    hasDeletePermission,
    getRoles,
    sortHandler = () => {},
  } = props;
  const { t } = useTranslation();
  const navigate = useNavigate();

  const [showAlert, setShowAlert] = useState<boolean>(false);
  const [modalTitle, setModalTitle] = useState<string>('');
  const [modalContent, setModalContent] = useState<string>('');
  const [actionButtonLabel, setActionButtonLabel] = useState<string>('');
  const [action, setAction] = useState<any>(null);
  const [singleRole, setSingleRole] = useState<any>(null);
  const [isHovered, setIsHovered] = useState('');
  const [isHoveredIcon, setIsHoveredIcon] = useState(0);
  const [isHoveredActivate, setIsHoveredActivate] = useState(false);
  const [loading, setLoading] = useState(false);
  const [activeSortColumn, setActiveSortColumn] = useState<string>('');
  const [sortOrder, setSortOrder] = useState<string>('');

  const handleMouseEnter = (role: any) => {
    setIsHovered(role);
  };
  const handleMouseLeave = () => {
    setIsHovered('');
  };

  const handleEditClick = (event: any, roleId: number) => {
    event.stopPropagation();
    navigate(`${paths.editRole}/${roleId}`);
  };

  const handleViewClick = (event: any, roleId: number) => {
    event.stopPropagation();
    navigate(`${paths.rolesListView}/${roleId}`);
  };

  const handleOutsideClick = (roleId: any) => {
    const index = roles.findIndex((role: any) => role.id === roleId);
    if (index !== -1) {
      const updatedData: any = [...roles];
      updatedData[index] = {
        ...roles[index],
        showModal: false,
      };
      setRoles(updatedData);
    }
  };

  const userStatusChangeAPI = async (request: any) => {
    setLoading(true);
    httpClient
      // .patch(`/api/users/${actionUserId}/`, { data: request })
      .patch(`/api/account/roles/${singleRole.id}/`, { data: request })
      .then((response: any) => {
        if (response.status === 200) {
          // const statusMessage = !request?.is_delete ? 'Activated the Role' : 'Deactivated the Role';
          if (response.data) {
            // what is this?? y setting the role again??
            setRoles((prevData: any) =>
              prevData.map((role: any) =>
                role.id === singleRole.id ? { ...role, is_delete: !role.is_delete } : role
              )
            );
            getRoles();
            setLoading(false);
            notify('success', t(response.data.message));
            setShowAlert(false);
          }
        } else if (response.status === 400) {
          getRoles();
          setLoading(false);
          setShowAlert(false);
        }
      })
      .catch((err) => {
        getRoles();
        notify('error', t('userAccessControl.roles.failedToChangeRoleStatus'));
        console.log('errored -->', err);
        setShowAlert(false);
      });
  };

  const handleAction = () => {
    if (action == 'Deactivate') {
      if (!hasEditPermission) {
        notify('warning', t('sharedTexts.noPermissionToDoThisOperation'));
        return;
      }

      setShowAlert(false);
      userStatusChangeAPI({ is_delete: !singleRole.status });
    }
  };
  let hoverMessage = '';
  if (isHoveredIcon !== 0) {
    if (isHoveredIcon == 1) {
      hoverMessage = t('sharedTexts.view');
    } else if (isHoveredIcon == 2) {
      hoverMessage = t('sharedTexts.edit');
    } else {
      hoverMessage = t('sharedTexts.deactivate');
    }
  }

  const handleDeactivateAction = (role: any) => {
    setSingleRole(role);
    setAction('Deactivate');
    setShowAlert(true);
    setModalTitle(t('sharedTexts.alert'));
    setActionButtonLabel(t('sharedTexts.deactivate'));
    setModalContent(t('userAccessControl.roles.doYouWantToDeactivateThisRole'));
  };

  const rolesTableHeaders = [
    {
      header: t('userAccessControl.roles.roleId'),
      key: 'id',
      sortEnabled: true,
    },
    {
      header: t('userAccessControl.roles.roleName'),
      key: 'role_name',
      sortEnabled: true,
    },
    {
      header: t('userAccessControl.roles.activeOrInactive'),
      key: '',
      sortEnabled: false,
    },
    {
      header: t('userAccessControl.roles.noOfFunctions'),
      key: 'total_functions',
      sortEnabled: true,
    },
    {
      header: t('sharedTexts.status'),
      key: 'is_delete',
      sortEnabled: true,
    },
  ];

  const handleSortClick = (columnName: string) => {
    const compareController = activeSortColumn === columnName ? sortOrder : '';
    const sortOrderToPass: string =
      compareController === '' ? 'asc' : compareController === 'asc' ? 'desc' : 'asc';
    setSortOrder(sortOrderToPass);
    setActiveSortColumn(columnName);
    sortHandler(columnName, sortOrderToPass);
  };

  if (loading) return <Loading />;
  return (
    <>
      <div className='table-general-wrapper'>
        <table className='table-general' style={{ width: '100%' }}>
          <thead>
            <tr>
              {rolesTableHeaders?.map((item) => (
                <td>
                  {' '}
                  {item.header}
                  {item.sortEnabled && (
                    <span
                      onClick={() => handleSortClick(item.key)}
                      className='ml-2'
                      style={{ cursor: 'pointer' }}
                    >
                      {activeSortColumn !== item.key && (
                        <SortIcon sx={{ color: '#04436b', fontSize: '20px' }} />
                      )}
                      {activeSortColumn === item.key && (
                        <>
                          {sortOrder === 'asc' ? (
                            <DownIcon sx={{ color: '#04436b', fontSize: '15px' }} />
                          ) : (
                            <UpIcon sx={{ color: '#04436b', fontSize: '15px' }} />
                          )}
                        </>
                      )}{' '}
                    </span>
                  )}
                </td>
              ))}
              <td></td>
            </tr>
          </thead>
          <tbody>
            {!isEmpty(roles) &&
              roles.map((role: any) => (
                <tr
                  onMouseEnter={() => handleMouseEnter(role.id)}
                  onMouseLeave={handleMouseLeave}
                  key={role.id}
                  style={{ height: '50px' }}
                >
                  <td style={{ width: '100px', padding: '8px', paddingLeft: '13px' }}>{role.id}</td>
                  <td style={{ width: '210px', padding: '8px', paddingLeft: '13px' }}>
                    {role.role_name}
                  </td>
                  <td
                    style={{ width: '210px', padding: '8px', paddingLeft: '13px' }}
                  >{`${role.total_users?.active_user_count} / ${role.total_users?.inactive_user_count}`}</td>
                  <td style={{ width: '180px', padding: '8px', paddingLeft: '13px' }}>
                    {role.total_functions}
                  </td>
                  <td
                    style={{
                      pointerEvents: role.is_delete && 'auto',
                      width: '210px',
                      padding: '8px',
                      verticalAlign: 'baseline',
                      paddingTop: '12px',
                    }}
                  >
                    <div className='flex items-center'>
                      <div className='switch-container mr-2' style={{ width: 'auto' }}>
                        {role.is_delete ? (
                          <span
                            style={{
                              backgroundColor: '#FFD3CD',
                              color: ' #B60000',
                              padding: '4px 10px',
                              borderRadius: '12px',
                              gap: '10px',
                              fontSize: '13px',
                            }}
                          >
                            {t('sharedTexts.inactive')}
                          </span>
                        ) : (
                          <span
                            style={{
                              backgroundColor: '#D8E9C1',
                              color: '#357821',
                              padding: '4px 15px',
                              borderRadius: '12px',
                              gap: '10px',
                              fontSize: '13px',
                            }}
                          >
                            {t('sharedTexts.active')}
                          </span>
                        )}
                      </div>
                    </div>
                  </td>

                  {/* Other ICONS AND TOOL TIPS ----- */}

                  <td
                    style={{ width: '100px', display: 'flex', justifyContent: 'end' }}
                    onClick={(e) => e.stopPropagation()}
                  >
                    <div
                      className={`${!role.is_delete ? 'cursor-pointer' : 'cursor-default'}`}
                      style={{ width: '15px' }}
                    >
                      <OutsideClickHandler onOutsideClick={() => handleOutsideClick(role.id)}>
                        <div
                          className={`relative flex items-center justify-center ${
                            !role.is_delete ? 'cursor-pointer' : 'cursor-default'
                          } `}
                          style={{ width: 16, height: 16 }}
                        >
                          {isHovered === role.id && !role.is_delete && (
                            <div className='flex items-center'>
                              <Link
                                to='#'
                                onClick={(e) => handleViewClick(e, role.id)}
                                data-tip='View'
                              >
                                <button
                                  style={{ border: '0px solid', backgroundColor: '#f0ffff00' }}
                                  onMouseEnter={() => setIsHoveredIcon(1)}
                                  onMouseLeave={() => setIsHoveredIcon(0)}
                                  type='button'
                                >
                                  <img
                                    src={viewIcon}
                                    alt='view'
                                    className='icon mr-10'
                                    style={{ fill: '#04436B', width: '20px', height: '20px' }}
                                  />
                                </button>
                              </Link>
                              {hasEditPermission && (
                                <Link
                                  to='#'
                                  onClick={(e) => handleEditClick(e, role.id)}
                                  data-tip='Edit'
                                >
                                  <button
                                    style={{ border: '0px solid', backgroundColor: '#f0ffff00' }}
                                    onMouseEnter={() => setIsHoveredIcon(2)}
                                    onMouseLeave={() => setIsHoveredIcon(0)}
                                    type='button'
                                  >
                                    <img
                                      src={editIcon}
                                      alt='edit'
                                      className='icon mr-10'
                                      style={{ fill: '#04436B', width: '15px', height: '15px' }}
                                    />
                                  </button>
                                </Link>
                              )}

                              {/* <Link to={`/deactivate/${role.id}`} data-tip='Deactivate'> */}
                              {hasDeletePermission && role.role_name !== 'SuperAdmin' && (
                                <button
                                  style={{ border: '0px solid', backgroundColor: '#f0ffff00' }}
                                  onClick={() => handleDeactivateAction(role)}
                                  onMouseEnter={() => setIsHoveredIcon(3)}
                                  onMouseLeave={() => setIsHoveredIcon(0)}
                                >
                                  <img
                                    src={deactivateIcon}
                                    alt='deactivate'
                                    className='icon mr-6'
                                    style={{ fill: '#04436B', width: '15px', height: '15px' }}
                                  />
                                </button>
                              )}

                              {/* </Link> */}

                              {isHoveredIcon !== 0 && (
                                <span
                                  style={{
                                    position: 'absolute',
                                    top: '25px',
                                    left: isHoveredIcon == 1 ? '-55px' : '-15px',
                                    backgroundColor: '#022549',
                                    padding: '5px',
                                    color: '#fff',
                                    fontSize: '14px',
                                    borderRadius: '4px',
                                    minWidth: 'max-content',
                                  }}
                                >
                                  {hoverMessage}
                                </span>
                              )}
                            </div>
                          )}

                          {/* Other ICONS AND TOOL TIPS. EASY ----- */}

                          {/* ACTIVATE TOGGLE BUTTON AND ITS TOOLTIP ----- */}
                          {isHovered === role.id && role.is_delete && (
                            <div className='flex items-center justify-start'>
                              <button
                                className='switch-container mr-2'
                                style={{ border: '0px solid', backgroundColor: '#f0ffff00' }}
                                onClick={(e) => e.stopPropagation()}
                                onMouseEnter={() => setIsHoveredActivate(true)}
                                onMouseLeave={() => setIsHoveredActivate(false)}
                              >
                                <input
                                  id={`switch-${role.id}`}
                                  type='checkbox'
                                  className='switch-input'
                                  checked={!role.is_delete}
                                  onChange={(e: any) => handleOnchangeStatus(e, role)}
                                />
                                <label
                                  htmlFor={`switch-${role.id}`}
                                  className='switch-label switch-label--sm'
                                ></label>
                              </button>
                              {isHoveredActivate && (
                                <span
                                  style={{
                                    position: 'absolute',
                                    top: '25px',
                                    left: '-65px',
                                    backgroundColor: '#022549',
                                    padding: '5px',
                                    color: '#fff',
                                    fontSize: '14px',
                                    borderRadius: '4px',
                                    minWidth: 'max-content',
                                  }}
                                >
                                  {t('sharedTexts.activate')}
                                </span>
                              )}
                            </div>
                          )}
                          {/* ACTIVATE TOGGLE BUTTON AND ITS TOOLTIP ----- */}

                          {/* WHAT IS THIS??????? */}
                          <RoleOptionModal
                            role={role}
                            openModal={role.showModal}
                            handleEditClick={handleEditClick}
                            handleDeleteClick={handleDeleteClick}
                            hasEditPermission={hasEditPermission}
                          />
                        </div>
                      </OutsideClickHandler>
                      {/* <ReactTooltip effect='solid' place='bottom' /> */}
                    </div>
                  </td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>

      {/* DEACTIVATION ALERT */}
      <AlertModal
        showModal={showAlert}
        closeModal={() => {
          setShowAlert(false);
        }}
        onConfirmClick={handleAction}
        title={modalTitle}
        content={modalContent}
        confirmButtonText={actionButtonLabel}
      />
    </>
  );
};

export default TableRolesList;
