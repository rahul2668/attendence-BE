import _ from 'lodash';

export const rolesTableHeaders = [
  // extra column for arrow
  {
    label: 'userAccessControl.roles.roleId',
    alignment: '', // optional
    width: '120px', // optional
    enableSort: true,
    sortKey: 'id',
  },
  {
    label: 'userAccessControl.roles.roleName',
    alignment: '', // optional
    width: '200px', // optional
    enableSort: true,
    sortKey: 'role_name',
  },
  {
    label: 'userAccessControl.roles.activeOrInactive',
    alignment: '', // optional
    width: '220px', // optional
    enableSort: false,
    sortKey: 'username',
  },
  {
    label: 'userAccessControl.roles.noOfFunctions',
    alignment: '', // optional
    width: '190px', // optional
    enableSort: true,
    sortKey: 'total_functions',
  },
  {
    label: 'sharedTexts.status',
    alignment: '', // optional
    width: '', // optional
    enableSort: true,
    sortKey: 'is_delete',
  },
  {
    label: '',
    alignment: '', // optional
    width: '', // optional
    enableSort: false,
    sortKey: '',
  },
];

export function formatRoles(
  data: any // maybe define a type?
) {
  const statusLanguageKey: any = `sharedTexts.pillLogicKeys.dynamic${data.is_delete ? 'Inactive' : 'Active'}`;
  return {
    roleId: data.id,
    roleName: data.role_name,
    activeByInactive: `${data.total_users?.active_user_count} / ${data.total_users?.inactive_user_count}`,
    noOfFunctions: data.total_functions,
    status: statusLanguageKey,
    is_super_admin: data.id == 1,
    showActivateButton: data.is_delete,
    // depending on id set is_super_admin true 1-> super_admin
  };
}

export const toolTipsForRoles = {
  viewIconToolText: 'toolTips.viewRole',
  editIconToolText: 'toolTips.editRole',
  deactivateIconToolText: 'toolTips.deactivateRole',
  activateIconToolText: 'toolTips.activateRole',
};
