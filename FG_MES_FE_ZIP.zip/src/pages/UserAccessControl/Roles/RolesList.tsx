import 'assets/styles/scss/pages/dashboard.scss';
import 'assets/styles/scss/components/table-general.scss';
import { useEffect, useState } from 'react';
import Header from 'components/common/MainHeader';
import { paths } from 'routes/paths';
import { useLocation, useNavigate } from 'react-router-dom';
import httpClient from 'http/httpClient';
import Pagination from 'components/common/Pagination';
import { notify, validatePermissions } from 'utils/utils';
import { crudType, permissionsMapper } from 'utils/constants';
import AlertModal from 'components/Modal/AlertModal';
import Loading from 'components/common/Loading';
import _ from 'lodash';
import ReusableTable from 'components/common/ReusableTable/ReusableTable';
import { formatRoles, rolesTableHeaders, toolTipsForRoles } from './helper';
import { useTranslation } from 'react-i18next';

const RolesList = () => {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [roles, setRoles] = useState<any>([]);
  const itemsPerPage = 10;
  const [count, setCount] = useState(null);
  const [previous, setPrevious] = useState(null);
  const [next, setNext] = useState(null);
  const [callApi, setCallApi] = useState(false);
  const [loading, setLoading] = useState(true);
  const [rolesList, setRolesList] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  // data which is passed the reusable table
  const [renderedRoleData, setRenderedRoleData] = useState([]);
  // delete modal control state
  const [showDeactivateOrActivateModal, setShowDeactivateOrActivateModal] =
    useState<boolean>(false);
  // since the activate and deactivate has confirm modals, the role is temporarily stored in a state
  const [selectedRole, setSelectedRole] = useState<any>();

  // Same modal is used for activate and deactivate. so the texts passes are stored in these states
  const [modalConfirmButtonText, setModalConfirmButtonText] = useState<string>(''); // stores if the current flow is deactivate or activate
  const [modalTitle, setModalTitle] = useState('');
  const [modalContent, setModalContent] = useState('');

  //  ------------ permissions (reflected on icons)-------------
  const { pathname } = useLocation();
  const module = pathname?.split('/')[1];
  const subModule = pathname?.split('/')[2];

  const rolesPermissions = {
    hasEdit: validatePermissions(
      permissionsMapper[module],
      permissionsMapper[subModule],
      crudType.edit
    ),
    // delete permission decides the deactivation
    hasDeactivate: validatePermissions(
      permissionsMapper[module],
      permissionsMapper[subModule],
      crudType.delete
    ),
  };
  //  ------------ permissions end -------------

  // role list data fetching and pagination functions  ----------------------------
  const getRoles = () => {
    setCurrentPage(1);
    let url = '';
    url = '/api/account/roles/';
    httpClient
      .get(url)
      .then((response: any) => {
        if (response.data) {
          const roleData: any = (response.data?.results || []).map((role: any) => ({
            ...role,
            showModal: false,
          }));

          setRolesList(roleData);
          setCount(response.data.results.length);
          setPrevious(response.data.results);
          setNext(response.data.results);
          setCallApi(false);
          setLoading(false);
        }
      })
      .catch((err) => {
        setLoading(false);
        console.log('errored -->', err);
      });
  };

  const handleAddNewRole = () => {
    navigate(`${paths.addNewRole}`);
  };

  useEffect(() => {
    getRoles();
    setCurrentPage(1);
  }, [callApi]);

  useEffect(() => {
    if (callApi) {
      getRoles();
      setCurrentPage(1);
    }
  }, [callApi]);

  const onPageChange = (newPage: any) => {
    if (newPage !== 0) {
      setCurrentPage(newPage);
      const filterData = rolesList.filter((val: any, index: any) => {
        if (index >= newPage * itemsPerPage - itemsPerPage && index < newPage * itemsPerPage) {
          return val;
        }
      });

      setRoles(filterData);
    }
  };

  useEffect(() => {
    const filterData = rolesList.filter((val: any, index: any) => {
      if (index >= 1 * itemsPerPage - itemsPerPage && index < 1 * itemsPerPage) {
        return val;
      }
    });

    setRoles(filterData);
  }, [rolesList]);
  // role list data fetching and pagination functions  ----------------------------

  // sort Logic with lodash
  const sortHandler = (columnName: string, sortOrder: 'ASC' | 'DESC') => {
    let sortOrderToPass: 'asc' | 'desc' = sortOrder === 'ASC' ? 'asc' : 'desc';
    const sortedRolesData = _.orderBy(rolesList, [columnName], [sortOrderToPass]);
    setRolesList(sortedRolesData);
  };

  // The data is Formatted to be used in reusable Table. The formatting is needed everywhere the reusable table is used
  useEffect(() => {
    setRenderedRoleData(roles.map(formatRoles));
  }, [roles]);

  // ICONS ICON CALLBACKS PASSED TO THE CHILD (these fire on respective icon click) -----------------

  // gets called on view icon click
  const handleViewClickAction = (rowData: any) => {
    const { roleId } = rowData;
    navigate(`${paths.rolesListView}/${roleId}`);
  };

  // gets called on edit icon click
  const handleEditClickAction = (rowData: any) => {
    const { roleId } = rowData;
    navigate(`${paths.editRole}/${roleId}`);
  };

  // called on deactivate icon onclick
  const handleDeactivateAction = (rowData: any) => {
    //sets up the modal and stores the role data in a state temporarily
    setSelectedRole(rowData);
    setShowDeactivateOrActivateModal(true);
    setModalTitle(t('sharedTexts.alert'));
    setModalConfirmButtonText(t('sharedTexts.deactivate'));
    setModalContent(t('userAccessControl.roles.doYouWantToDeactivateThisRole'));
  };

  // called on activate icon onclick
  const handleActivateIconClick = (rowData: any) => {
    //sets up the modal and stores the role data in a state temporarily
    setSelectedRole(rowData);
    setShowDeactivateOrActivateModal(true);
    setModalTitle(t('sharedTexts.alert'));
    setModalConfirmButtonText(t('sharedTexts.proceed'));
    setModalContent(t('userAccessControl.roles.doYouWantToActivateTheRole'));
  };
  // ICONS ICON CALLBACKS PASSED TO THE CHILD - END ------------------------------

  // MAIN ACTIVATE / deactivate FUNC - gets called after modal confirmation
  // same function, same api call, same param. api logic toggles the active status of a role
  const handleDeactivateOrActivateConfirmClick = () => {
    changeStatusOfRole(selectedRole?.roleId);
  };

  //API call -  the same api has activate and deactivate logic
  const changeStatusOfRole = async (roleId: any) => {
    setLoading(true);
    httpClient
      .patch(`/api/account/roles/${roleId}/`)
      .then((response: any) => {
        if (response.status === 200 && response.data) {
          getRoles();
          notify('success', t(response.data.message));
        } else if (response.data?.error) {
          getRoles();
        }
        setShowDeactivateOrActivateModal(false);
        setLoading(false);
      })
      .catch(() => {
        getRoles();
        notify('error', t('userAccessControl.roles.failedToChangeRoleStatus'));
        setShowDeactivateOrActivateModal(false);
        setLoading(false);
      });
  };

  if (loading) return <Loading />;

  return (
    <main className='dashboard'>
      <section className='dashboard__main'>
        {/* THIS HEADER HAS AN INFINITE LOOP. LOOK INTO IT LATER!  */}
        <Header
          title={t('plantModulesAndFunctions.ROLES')}
          // onSearchChange={(value) => setSearchValue(value)}
          buttonText={t('userAccessControl.roles.AddNewRole')}
          onButtonClick={handleAddNewRole}
          placeholder='Search by Role Name'
          // hasPermission={hasAddRolePermission}
        />
        {/* THIS HEADER HAS AN INFINITE LOOP. LOOK INTO IT LATER!  */}
        <div
          className='dashboard__main__body py-3'
          style={{ padding: '16px 12px', overflow: 'auto' }}
        >
          <ReusableTable
            columnsToDisplayAsPills={['status']}
            mainHeaders={rolesTableHeaders}
            renderData={renderedRoleData}
            showActionIconsInRow // if this is not provided then there wil be a gap in table columns - to fix it pass empty key in formatting function
            sortHandler={sortHandler}
            rowActionsPermission={rolesPermissions}
            callBackOnEditClick={handleEditClickAction}
            callBackOnViewClick={handleViewClickAction}
            callBackOnDeactivationClick={handleDeactivateAction}
            callBackOnActivationClick={handleActivateIconClick}
            onlyViewAndEditDependencyKey={'is_super_admin'} // if the provided keys has value as true, they will only have view and edit - dependKey
            activeButtonDependencyKey={'showActivateButton'}
            // IMP => MAKE SURE THE KEYS WHICH ARE NOT RENDERED IN THE TABLE IS PASSES IN THIS!!
            // ie, showActivateButton and is_super_admin - these are dependency keys here
            columnsToIgnoreInRendering={['is_super_admin', 'showActivateButton']}
            toolTips={toolTipsForRoles}
          />

          <Pagination
            totalItems={count}
            itemsPerPage={itemsPerPage}
            onPageChange={onPageChange}
            currentPage={currentPage}
            previous={previous}
            next={next}
          />

          {/* DEACTIVATE / activate CONFIRMATION MODAL  */}
          {showDeactivateOrActivateModal && (
            <AlertModal
              showModal={showDeactivateOrActivateModal}
              closeModal={() => {
                setShowDeactivateOrActivateModal(false);
              }}
              onConfirmClick={handleDeactivateOrActivateConfirmClick}
              title={modalTitle}
              content={modalContent}
              confirmButtonText={modalConfirmButtonText}
            />
          )}
        </div>
      </section>
    </main>
  );
};

export default RolesList;
