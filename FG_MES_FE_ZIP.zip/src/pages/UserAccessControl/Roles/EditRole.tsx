import { useEffect, useState } from 'react';
import 'assets/styles/scss/pages/dashboard.scss';
import 'assets/styles/scss/components/table-general.scss';
import arrowLeft from 'assets/icons/arrow-left.svg';
import { useNavigate, useParams } from 'react-router-dom';
import RoleService from 'store/services/roleService';
import { paths } from 'routes/paths';
import { clearSessionStorage, isEmpty, notify, validatePermissionList } from 'utils/utils';
import Loading from 'components/common/Loading';
import AlertModal from 'components/Modal/AlertModal';
import { useTranslation } from 'react-i18next';
import { crudType, uniqueCodesMapper } from 'utils/constants';
import { useAppSelector } from 'store';

interface RoleDetails {
  role_name?: string;
  id?: number;
  is_superuser?: boolean;
}
const DashboardRolesEditView = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [roleName, setRoleName] = useState<string>('');
  const [rolePermissions, setRolePermissions] = useState<any>({});
  const [initialData, setInitialData] = useState<any>({});
  const [roleDetails, setRoleDetails] = useState<RoleDetails>({});
  const [errors, setErrors] = useState<any>({});
  const [selectAllChecked, setSelectAllChecked] = useState(false);
  const [openAlertModal, setOpenAlertModal] = useState<boolean>(false);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);

  const handleBackButton = () => {
    navigate(`${paths.rolesList}`);
  };
  const userDataString = useAppSelector((state) => state.userData.userData);
  const userData: any = userDataString ? userDataString : null;

  const handlePermissionChange = (
    category: string,
    key: string,
    action: string,
    currentStatus: boolean
  ) => {
    setInitialData((prevInitialData: any) => {
      const updatedInitialData: any = { ...prevInitialData };

      let checkKeyDownTime =
        updatedInitialData[category][uniqueCodesMapper.furnaceDowntimeLogFunction];
      let checkKeyDownTimeEvent =
        updatedInitialData[category][uniqueCodesMapper.furnaceDowntimeLogEventFunction];
      let checkKeyDownTimeSplit =
        updatedInitialData[category][uniqueCodesMapper.furnaceDowntimeLogSplitFunction];
      if (action === crudType.view) {
        // Allow toggling view only if all create/edit/delete are disabled
        const canToggleView =
          !updatedInitialData[category][key].create &&
          !updatedInitialData[category][key].edit &&
          !updatedInitialData[category][key].delete;

        if (canToggleView) {
          updatedInitialData[category][key][action] = currentStatus;
        }

        if (
          [
            uniqueCodesMapper.furnaceDowntimeLogFunction,
            uniqueCodesMapper.furnaceDowntimeLogEventFunction,
            uniqueCodesMapper.furnaceDowntimeLogSplitFunction,
          ].includes(key) &&
          canToggleView
        ) {
          if (
            checkKeyDownTimeEvent[crudType.create] ||
            checkKeyDownTimeEvent[crudType.edit] ||
            checkKeyDownTimeEvent[crudType.delete] ||
            checkKeyDownTimeSplit[crudType.create] ||
            checkKeyDownTimeSplit[crudType.edit] ||
            checkKeyDownTimeSplit[crudType.delete]
          ) {
            checkKeyDownTime[action] = true;
            checkKeyDownTimeEvent[action] = true;
            checkKeyDownTimeSplit[action] = true;
          } else {
            checkKeyDownTime[crudType.view] = currentStatus;
            checkKeyDownTimeEvent[crudType.view] = currentStatus;
            checkKeyDownTimeSplit[crudType.view] = currentStatus;
          }
        }
      } else {
        // Allow editing create/edit/delete
        updatedInitialData[category][key][action] = currentStatus;
        if (action === crudType.create) updatedInitialData[category][key].edit = currentStatus; // when enabling separate edit, delete this if */}

        // If edit, delete, or create is enabled, enable view if it's false
        if (
          currentStatus &&
          (action === crudType.edit || action === crudType.delete || action === crudType.create)
        ) {
          updatedInitialData[category][key].view = true;
          if (action === crudType.create) {
            // when enabling separate edit, delete this if */}
            updatedInitialData[category][key].edit = true;
          }

          if (
            [
              uniqueCodesMapper.furnaceDowntimeLogFunction,
              uniqueCodesMapper.furnaceDowntimeLogEventFunction,
              uniqueCodesMapper.furnaceDowntimeLogSplitFunction,
            ].includes(key)
          ) {
            checkKeyDownTime[crudType.view] = currentStatus;
            checkKeyDownTimeEvent[crudType.view] = currentStatus;
            checkKeyDownTimeSplit[crudType.view] = currentStatus;
          }
        }

        // Update "Select All" state based on the individual checkbox changes
        const areAllChecked = Object.keys(updatedInitialData).every((cat) =>
          Object.keys(updatedInitialData[cat]).every(
            (k) =>
              updatedInitialData[cat][k].view &&
              updatedInitialData[cat][k].create &&
              updatedInitialData[cat][k].edit &&
              updatedInitialData[cat][k].delete
          )
        );

        setSelectAllChecked(areAllChecked);
      }
      return updatedInitialData;
    });
  };

  const getRoleDetails = async () => {
    setLoading(true);
    const requestData: any = {
      role_id: id,
      is_clone: false,
    };
    const response = await RoleService.getRoleDetails(requestData);
    setInitialData(response?.data.permission_list);
    setRolePermissions(response?.data.permission_list);
    setRoleDetails(response?.data?.role);
    setRoleName(response?.data?.role.role_name);
    setSelectAllChecked(response?.data?.role?.is_superuser);
    setUsers(response?.data?.users);
    setLoading(false);
  };

  useEffect(() => {
    getRoleDetails();
  }, [id]);

  const handleChange = (checkboxType: 'selectAll') => {
    setSelectAllChecked((prevSelectAllChecked) => {
      const newSelectAllChecked = !prevSelectAllChecked;

      setInitialData((prevInitialData: any) => {
        const updatedInitialData = { ...prevInitialData };

        Object.keys(updatedInitialData).forEach((category) => {
          Object.keys(updatedInitialData[category]).forEach((key) => {
            updatedInitialData[category][key] = {
              ...updatedInitialData[category][key],
              view: checkboxType === 'selectAll' ? newSelectAllChecked : false,
              create:
                checkboxType === 'selectAll' &&
                category !== uniqueCodesMapper.systemAdminModule &&
                category !== uniqueCodesMapper.reportsModule &&
                key !== uniqueCodesMapper.furnaceDowntimeLogFunction
                  ? newSelectAllChecked
                  : false,
              edit:
                checkboxType === 'selectAll' &&
                category !== uniqueCodesMapper.systemAdminModule &&
                category !== uniqueCodesMapper.reportsModule &&
                key !== uniqueCodesMapper.furnaceDowntimeLogFunction
                  ? newSelectAllChecked
                  : false,
              delete:
                checkboxType === 'selectAll' &&
                category !== uniqueCodesMapper.systemAdminModule &&
                category !== uniqueCodesMapper.reportsModule &&
                category !== uniqueCodesMapper.masterDataModule &&
                category !== uniqueCodesMapper.userAccessControlModule &&
                key !== uniqueCodesMapper.furnaceDowntimeLogFunction
                  ? newSelectAllChecked
                  : false,
            };
          });
        });

        return updatedInitialData;
      });

      return newSelectAllChecked;
    });
  };

  const handleChangeRoleName = (value: any) => {
    setRoleName(value);
    setErrors({ ...errors, role_name: validateRoleName(value) });
  };

  const validateRoleName = (value: any) => {
    if (!value.trim()) {
      return t('userAccessControl.roles.roleNameIsRequired');
    }
    const pattern = /^(?! )[a-zA-Z0-9 ]{3,30}(?<! )$/;

    if (!pattern.test(value)) {
      return t('sharedTexts.invalidNameFormat');
    }

    return '';
  };

  const validateForm = () => {
    const validationErrors = {
      role_name: validateRoleName(roleName.trim()),
    };
    setErrors(validationErrors);
    return Object.values(validationErrors).every((error) => !error);
  };

  const handleSaveButton = async () => {
    if (validateForm()) {
      if (!validatePermissionList(initialData)) {
        return notify(
          'error',
          t('userAccessControl.roles.roleMustHaveAtLeastOneViewFunctionEnabled')
        );
      }
      const requestData: any = {
        permission_list: initialData,
        role_name: roleName.trim(),
        role_id: id,
        is_superuser: selectAllChecked,
      };
      const response = await RoleService.editRole(requestData);

      if (response.status === 200) {
        notify('success', t(response.data.message));
        if (users.some((item: any) => item.id == userData.id)) {
          setOpenAlertModal(true);
        } else {
          navigate(`${paths.rolesList}`);
        }
      }
    }
  };

  if (isEmpty(roleDetails) || loading) return <Loading />;

  return (
    <main className='dashboard'>
      <section className='dashboard__main'>
        <div className='dashboard__main__header'>
          <div className='flex items-center justify-between h-full'>
            <div className='flex items-center'>
              <button
                style={{ border: '0px solid', backgroundColor: '#f0ffff00' }}
                onClick={handleBackButton}
                type='button'
              >
                <img className='cursor-pointer' src={arrowLeft} alt='back-arrow' />
              </button>
              <h2 className='text-xl font-bold ml-4'>
                {t('sharedTexts.edit')} - {roleDetails?.role_name}
              </h2>
            </div>
          </div>
        </div>
        <div className='dashboard__main__body px-8 py-6 scroll-0'>
          <div className='card-box px-6 py-8'>
            <div className='flex'>
              {/* <div className='flex flex-col' style={{ width: 260 }}>
                <h2 className='text-xl font-medium'>Edit Role</h2>
                <p className='color-tertiary-text text-sm mt-2'>
                  This could be used to write very important message.
                </p>
              </div> */}
              <div style={{ width: 352 }}>
                <label
                  className='input-field-label'
                  htmlFor='roleName'
                >{`${t('userAccessControl.roles.roleName')}*`}</label>
                <input
                  type='text'
                  className={`input-field input-field--h40 input-field--md w-full ${errors.role_name ? `input-field--error` : ''}`}
                  value={roleName}
                  placeholder={t('userAccessControl.roles.enterRoleName')}
                  onChange={(e) => handleChangeRoleName(e.target.value)}
                  spellCheck={false}
                />
                {errors.role_name && <div className='error-message'>{errors.role_name}</div>}
              </div>
            </div>
            <div className='flexpr-8 pt-8'>
              <div className='flex'>
                <input
                  type='checkbox'
                  id='selecteAll'
                  checked={selectAllChecked}
                  onChange={() => handleChange('selectAll')}
                />
                <label htmlFor='selecteAll' className='custom-checkbox__label ml-2'>
                  {t('sharedTexts.selectAll')}
                </label>
              </div>
            </div>
            <div className='table-general-wrapper mt-8'>
              <table className='table-general table-general--user-access'>
                <thead>
                  <tr>
                    <td>{t('sharedTexts.functions')}</td>
                    <td>{t('sharedTexts.view')}</td>
                    <td>{t('sharedTexts.createOrEdit')}</td>
                    {/* // when enabling separate edit, uncomment this */}
                    {/* <td>{t('sharedTexts.edit')}</td> */}
                    <td>{t('sharedTexts.delete')}</td>
                  </tr>
                </thead>
                {Object.keys(initialData).map((category) => {
                  const categoryName: any = `plantModulesAndFunctions.${category}`;
                  return (
                    <tbody key={category}>
                      <tr className='title'>
                        <td colSpan={5}>{t(categoryName)}</td>
                      </tr>
                      {Object.keys(initialData[category]).map((key) => {
                        const subCategoryName: any = `plantModulesAndFunctions.${key}`;

                        return (
                          <tr key={key}>
                            <td>{t(subCategoryName)}</td>
                            <td>
                              <div className='custom-checkbox'>
                                <input
                                  type='checkbox'
                                  id={`views-${key}`}
                                  className='custom-checkbox__input'
                                  checked={initialData[category]?.[key]?.view || false}
                                  onChange={(e) =>
                                    handlePermissionChange(
                                      category,
                                      key,
                                      crudType.view,
                                      (e.target as HTMLInputElement).checked
                                    )
                                  }
                                />
                                <label htmlFor={`views-${key}`} className='custom-checkbox__label'>
                                  <code className='custom-checkbox__label__box'></code>
                                </label>
                              </div>
                            </td>
                            {key !== uniqueCodesMapper.furnaceDowntimeLogFunction ? (
                              <td>
                                {category !== uniqueCodesMapper.systemAdminModule &&
                                  category !== uniqueCodesMapper.reportsModule && (
                                    <div className='custom-checkbox'>
                                      <input
                                        type='checkbox'
                                        id={`create-${key}`}
                                        className='custom-checkbox__input'
                                        checked={rolePermissions[category]?.[key]?.create || false}
                                        disabled={
                                          Object.keys(rolePermissions[category]).includes(
                                            uniqueCodesMapper.rolesFunction
                                          ) && roleDetails.is_superuser
                                        }
                                        onChange={(e) =>
                                          handlePermissionChange(
                                            category,
                                            key,
                                            crudType.create,
                                            (e.target as HTMLInputElement).checked
                                          )
                                        }
                                      />
                                      <label
                                        htmlFor={`create-${key}`}
                                        className='custom-checkbox__label'
                                      >
                                        <code className='custom-checkbox__label__box'></code>
                                      </label>
                                    </div>
                                  )}
                              </td>
                            ) : (
                              <td></td>
                            )}
                            {/* $$$ when enabling separate edit, uncomment this $$$$ */}

                            {/* <td>
                            {category !== uniqueCodesMapper.systemAdminModule && key !==uniqueCodesMapper.furnaceDowntimeLogFunction && (
                              <div className='custom-checkbox'>
                                <input
                                  type='checkbox'
                                  id={`edit-${key}`}
                                  className='custom-checkbox__input'
                                  checked={rolePermissions[category]?.[key]?.edit || false}
                                  onChange={(e) =>
                                    handlePermissionChange(
                                      category,
                                      key,
                                      crudType.edit,
                                      (e.target as HTMLInputElement).checked
                                    )
                                  }
                                />
                                <label htmlFor={`edit-${key}`} className='custom-checkbox__label'>
                                  <code className='custom-checkbox__label__box'></code>
                                </label>
                              </div>
                            )}
                          </td> */}
                            {key !== uniqueCodesMapper.furnaceDowntimeLogFunction ? (
                              <td>
                                {category !== uniqueCodesMapper.systemAdminModule &&
                                  category !== uniqueCodesMapper.reportsModule &&
                                  category !== uniqueCodesMapper.masterDataModule &&
                                  category !== uniqueCodesMapper.userAccessControlModule && (
                                    <div className='custom-checkbox'>
                                      <input
                                        type='checkbox'
                                        disabled={category == uniqueCodesMapper.systemAdminModule}
                                        id={`delete-${key}`}
                                        className='custom-checkbox__input'
                                        checked={rolePermissions[category]?.[key]?.delete || false}
                                        onChange={(e) =>
                                          handlePermissionChange(
                                            category,
                                            key,
                                            crudType.delete,
                                            (e.target as HTMLInputElement).checked
                                          )
                                        }
                                      />
                                      <label
                                        htmlFor={`delete-${key}`}
                                        className='custom-checkbox__label'
                                      >
                                        <code className='custom-checkbox__label__box'></code>
                                      </label>
                                    </div>
                                  )}
                              </td>
                            ) : (
                              <td></td>
                            )}
                          </tr>
                        );
                      })}
                    </tbody>
                  );
                })}
              </table>
            </div>
          </div>
        </div>
        <div className='dashboard__main__footer'>
          <div className='dashboard__main__footer__container'>
            <button
              onClick={() => navigate(`${paths.rolesList}`)}
              className='btn btn--h36 px-4 py-2'
            >
              {t('sharedTexts.cancel')}
            </button>
            <button
              disabled={errors.role_name}
              onClick={handleSaveButton}
              className={
                errors.role_name || isEmpty(roleName)
                  ? 'btn btn--primary disabled btn--h36 px-8 py-2 ml-4'
                  : 'btn btn--primary btn--h36 px-8 py-2 ml-4'
              }
            >
              {t('sharedTexts.saveChanges')}
            </button>
          </div>
        </div>

        {openAlertModal && (
          <AlertModal
            showModal={openAlertModal}
            title={'Logout'}
            content={'Role Updated. You Need to Login again'}
            confirmButtonText='Proceed'
            isShowCloseIcon={false}
            onConfirmClick={async () => {
              setLoading(true);
              clearSessionStorage(['accessToken', 'selectedLanguage']);
              setLoading(false);
              navigate(`${paths.login}`);
            }}
            closeModal={() => {
              setOpenAlertModal(true);
            }}
          />
        )}
      </section>
    </main>
  );
};

export default DashboardRolesEditView;
