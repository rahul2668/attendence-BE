import { FC, useEffect, useRef, useState } from 'react';
import { useReactToPrint } from 'react-to-print';
import arrowUp from '../../assets/icons/up_arrow.svg';
import arrowDown from '../../assets/icons/down_arrow.svg';
import { connect, useDispatch } from 'react-redux';
import {
  MaterialCategoryAction,
  VariantSaveAction,
  fetchReportAction,
  materialIdAction,
  materialTypeAction,
  reportOptionsAction,
  variantDeleteIdAction,
  variantFetchByIdAction,
  variantsList,
} from '../../store/slices/reportsAnalysisSlice';
import ReportModal from '../../components/Modal/ReportModal';
import DateRangePicker from 'components/common/DateRangePicker';
import CompareDateRadio from 'components/common/CompareDateRadio';
import CustomSelect from 'components/common/SelectField';
import ToggleButton from 'components/common/ToggleButton';
import { VisualizationGraph } from 'components/common/VisualizationGraph';
import Reset from '../../assets/icons/reset.svg';
import info from '../../assets/icons/info.svg';
import ReportSequence from 'components/common/ReportSequence';
import Graph from 'components/common/Graph';
import print from '../../assets/icons/Print.svg';
import clone from '../../assets/icons/clone.svg';
import save from '../../assets/icons/Save.svg';
import deleteIcon from '../../assets/icons/delete_icon.svg';
import moment from 'moment';
import Toaster from 'components/common/Toaster/Toaster';
import ReportDropdown from 'components/ReportsDropdown';
import Loader from 'components/Loader';
import AlertModal from 'components/Modal/AlertModal';
import { useTranslation } from 'react-i18next';
import { useAppSelector } from 'store';
import { getLoggedInUser } from '../../utils/utils';
interface Props {
  materialTypes: { value: string; option: string }[];
  materialCategories: { value: string; option: string }[];
  reportOptions: { value: string; option: string }[];
  VariantsList: { value: string; option: string }[];
  matGraphs: any;
  materialTypesCompare: { value: string; option: string }[];
  reportOptionsHeadings: any;
}

interface ReportSequence {
  element: string;
  chart_type: any;
  report_sqn: any;
}

const ReportsPage: FC<Props> = ({
  materialTypes,
  materialCategories,
  reportOptions,
  VariantsList,
  matGraphs,
  materialTypesCompare,
  reportOptionsHeadings,
}) => {
  const printComponentRef = useRef(null);
  const onPrintRecords = useReactToPrint({
    content: () => printComponentRef.current,
  });
  const { t } = useTranslation();

  const [showSelectionCriteriaCard, setShowSelectionCriteriaCard] = useState(true);
  const [showExpandCollapseIcons, setShowExpandCollapseIcons] = useState(false);
  const [variantUpdateFlag, setVariantUpdateFlag] = useState(false);
  const toggleArrowDirection = () => {
    setShowSelectionCriteriaCard(!showSelectionCriteriaCard);
  };
  const [switchChecked, setSwitchChecked] = useState(false);
  const [isVisualizationGraphDisabled, setIsVisualizationGraphDisabled] = useState(false);
  const [variantsaveActivate, setVariantsaveActivate] = useState(false);
  const [variantDeleteActive, setVariantDeleteActive] = useState(false);
  const [variantCloneFlag, setVariantCloneFlag] = useState(false);
  const [materialcategory, setMaterialcategory] = useState({
    value: '',
  });
  const [materialType, setMaterialType] = useState({
    value: '',
  });
  const [materialId, setMaterialId] = useState({
    value: '',
  });
  const [supplier, setSupplier] = useState({
    value: '',
  });
  const [layout, setLayout] = useState({
    value: '',
  });
  const [granularity, setGranularity] = useState({
    value: '',
  });
  const [compareMaterialid1, setCompareMaterialid1] = useState({
    value: '',
  });
  const [compareMaterialid2, setCompareMaterialid2] = useState({
    value: '',
  });
  const [compareMaterialid3, setCompareMaterialid3] = useState({
    value: '',
  });
  const [compareMaterialid4, setCompareMaterialid4] = useState({
    value: '',
  });
  const [selectedVariant, setSelectedVariant] = useState({
    value: '',
  });
  const [isLoggedInUserCreatedVariant, setIsLoggedInUserCreatedVariant] = useState(true);

  const resetFormvalues = () => {
    setIsLoggedInUserCreatedVariant(true);
    setVariantName('');
    setVariantDeleteActive(false);
    setSelectedVariant({ value: '' });
    setCompareMaterialid3({ value: '' });
    setCompareMaterialid1({ value: '' });
    setCompareMaterialid2({ value: '' });
    setGranularity({ value: '' });
    setLayout({ value: '' });
    setSupplier({ value: '' });
    setMaterialId({ value: '' });
    setMaterialType({ value: '' });
    setMaterialcategory({ value: '' });
    setSwitchChecked(false);
    setReportOptionsArray([]);
    setShowSelectionCriteriaCard(true);
    setDaterange({ startdate: new Date(), endDate: new Date() });
    setComparedates({ startDate: new Date(), endDate: new Date() });
    setCompareMaterialid4({ value: '' });
    setVariantsaveActivate(false);
    setVariantCloneFlag(false);
    setShowGraphs(false);
    setCloneVariantModal(false);
    setShowExpandCollapseIcons(false);
    setElementValue({ value: t('sharedTexts.select') });
    setIsVisualizationGraphDisabled(true);
    console.log(isVisualizationGraphDisabled);
  };
  const resetMaterialIds = () => {
    setCompareMaterialid3({ value: '' });
    setCompareMaterialid1({ value: '' });
    setCompareMaterialid2({ value: '' });
    setCompareMaterialid4({ value: '' });
  };
  let localUserData: any;
  const userData = useAppSelector((state) => state.userData.userData);

  if (userData !== null) {
    localUserData = userData;
  } else {
    localUserData = {};
  }
  let plantData: any;
  const plantdata = useAppSelector((state) => state.plantData.plantData);
  if (plantdata !== null) {
    plantData = plantdata;
  } else {
    plantData = {};
  }

  const [imageTooltips, setImageTooltips] = useState(0);
  const [reportOptionsArray, setReportOptionsArray] = useState<any[]>([]);
  const [selectedRadioOption, setSelectedRadioOption] = useState('TimePeriod');
  const [variantCheckbox, setVariantCheckbox] = useState(false);
  const [showGraphs, setShowGraphs] = useState(false);

  const handleRadioButton = (dateRadioValue: string) => {
    setSelectedRadioOption(dateRadioValue);
  };
  const getPlantData = useAppSelector((state) => state.plantData.plantData);
  const generateReport = () => {
    const data = getPlantData;
    let plantData: any = {};
    console.log(variantCloneFlag);
    if (null != data) {
      plantData = data;
    }
    handleReportSequenceIds();
    const payloadForGraph = {
      generate_report: {
        plant: plantData.plant_name,
        category_id: materialcategory?.value,
        type_id: materialType?.value,
        material_id: materialId?.value,
        supplier: '' === supplier?.value ? 'All' : supplier?.value,
        layout: layout?.value,
        granularity: granularity?.value,
        date_range: [
          moment(dateRange.startdate).format('YYYY-MM-DD'),
          moment(dateRange.endDate).format('YYYY-MM-DD'),
        ],
        compare: switchChecked,
        compare_time_flag: switchChecked && selectedRadioOption === 'TimePeriod',
        compare_time_period: [
          switchChecked && selectedRadioOption === 'TimePeriod'
            ? moment(compareDates?.startDate).format('YYYY-MM-DD')
            : '',
          switchChecked && selectedRadioOption === 'TimePeriod'
            ? moment(compareDates?.endDate).format('YYYY-MM-DD')
            : '',
        ],
        compare_material_flag: switchChecked && selectedRadioOption === 'Material',
        report_options: reportOptionsArray,
      },
    };
    setIsLoading(true);
    dispatch(fetchReportAction(payloadForGraph)).then(
      (response: any) => {
        setElementValue({ value: t('sharedTexts.select') });
        if (response.status == 200) {
          setVariantsaveActivate(true);
          setShowGraphs(true);
          setShowExpandCollapseIcons(true);
          setIsLoading(false);
        } else {
          setShowGraphs(false);
          setShowExpandCollapseIcons(false);
          setVariantsaveActivate(false);
          setIsLoading(false);
          if (Array.isArray(response?.data)) {
            setToastResponse({ text: t(response.data[0]), toastType: 'error' });
          }
        }
      },
      (error: any) => {
        console.log('API failred', error);
        setIsLoading(false);
        setToastResponse({ text: t('reports.noDataFoundForSelectedCriteria'), toastType: 'error' });
      }
    );
  };
  const granularityDropDownData = () => {
    let difference = datesDifference();
    if (difference < 1) {
      return [
        { value: 'hour', option: 'Hour', id: 1 },
        { value: 'shift', option: 'Shift', id: 2 },
        { value: 'batch', option: 'Batch', id: 8 },
      ];
    } else if (difference < 8) {
      return [
        { value: 'hour', option: 'Hour', id: 1 },
        { value: 'shift', option: 'Shift', id: 2 },
        { value: 'day', option: 'Day', id: 3 },
        { value: 'batch', option: 'Batch', id: 8 },
      ];
    } else if (difference < 32) {
      return [
        { value: 'shift', option: 'Shift', id: 2 },
        { value: 'day', option: 'Day', id: 3 },
        { value: 'week', option: 'Week', id: 4 },
        { value: 'batch', option: 'Batch', id: 8 },
      ];
    } else if (difference < 94) {
      return [
        { value: 'day', option: 'Day', id: 3 },
        { value: 'week', option: 'Week', id: 4 },
        { value: 'month', option: 'Month', id: 5 },
        { value: 'batch', option: 'Batch', id: 8 },
      ];
    } else if (difference < 367) {
      return [
        { value: 'day', option: 'Day', id: 3 },
        { value: 'week', option: 'Week', id: 4 },
        { value: 'month', option: 'Month', id: 5 },
        { value: 'quarter', option: 'Quarter', id: 6 },
        { value: 'batch', option: 'Batch', id: 8 },
      ];
    } else if (difference > 367) {
      return [
        { value: 'week', option: 'Week', id: 4 },
        { value: 'month', option: 'Month', id: 5 },
        { value: 'quarter', option: 'Quarter', id: 6 },
        { value: 'year', option: 'Year', id: 7 },
        { value: 'batch', option: 'Batch', id: 8 },
      ];
    } else {
      return [
        { value: 'hour', option: 'Hour', id: 1 },
        { value: 'shift', option: 'Shift', id: 2 },
        { value: 'day', option: 'Day', id: 3 },
        { value: 'week', option: 'Week', id: 4 },
        { value: 'month', option: 'Month', id: 5 },
        { value: 'quarter', option: 'Quarter', id: 6 },
        { value: 'year', option: 'Year', id: 7 },
        { value: 'batch', option: 'Batch', id: 8 },
      ];
    }
  };
  const reportOptionsGet = (materialId: any, materialCategory: any, materialType: any) => {
    setIsLoading(true);
    dispatch(reportOptionsAction(materialCategory, materialType, materialId)).then(
      () => {
        setIsLoading(false);
      },
      (error: any) => {
        console.error('reportOptionsGet Failed', error);
        setIsLoading(false);
      }
    );
  };
  const materialTypeFetch = (id: any) => {
    setIsLoading(true);
    dispatch(materialTypeAction(id)).then(
      () => {
        setIsLoading(false);
      },
      (error: any) => {
        console.error('materialTypeFetch Failed', error);
        setIsLoading(false);
      }
    );
  };

  const materialIdFetch = (id: any) => {
    setIsLoading(true);
    dispatch(materialIdAction(id)).then(
      (response: any) => {
        console.log(response);

        setIsLoading(false);
      },
      (error: any) => {
        console.error('materialIdFetch Failed', error);
        setIsLoading(false);
      }
    );
  };

  const variantdetailsFectchByid = (value: any) => {
    setIsLoading(true);
    dispatch(variantFetchByIdAction(value)).then(
      (response: any) => {
        setIsLoading(false);
        setVariantDeleteActive(true);
        setSelectedVariantDetails(response.data[0]);
        if (getLoggedInUser()?.id !== response?.data?.[0]?.user) {
          setIsLoggedInUserCreatedVariant(false);
        }
      },
      (error: any) => {
        setIsLoading(false);
        console.error('Error occured in variantFetchByIdAction ', error);
      }
    );
  };
  const [dateClicked, setDateClicked] = useState(false);
  const [compareDateClicked, setCompareDateClicked] = useState(false);
  const [dateRange, setDaterange] = useState({
    startdate: new Date(),
    endDate: new Date(),
  });

  const [compareDates, setComparedates] = useState({
    startDate: new Date(),
    endDate: new Date(),
  });

  const [toastResponse, setToastResponse] = useState({
    text: '',
    toastType: '',
  });

  const dispatch = useDispatch();
  const [isLoading, setIsLoading] = useState<any>(true);
  useEffect(() => {
    setIsLoading(true);
    dispatch(variantsList()).then(
      (response: any) => {
        if (response) {
          setIsLoading(false);
          console.log(isLoading);
        }
        setIsLoading(false);
      },
      (error: any) => {
        console.error('Error occured in variantsList ', error);
        setIsLoading(false);
      }
    );

    dispatch(MaterialCategoryAction());
  }, []);
  const variantSaveApi = (data: any) => {
    let cloneflag = false;
    if (data === 'clone') {
      cloneflag = true;
    }
    handleReportSequenceIds();

    let payload = {
      variant_name: cloneflag ? cloneVariantName : variantName,
      furnance_flag: false,
      user_id: localUserData?.id,
      user_name: localUserData?.username,
      furnace_flag: false,
      variant_id: '',
      plant: plantData?.plant_name,
      report_save: {
        update_flag: false,
        clone_flag: cloneflag,
        private: cloneflag ? clonePrivateFlag : variantCheckbox,
        category_id: materialcategory?.value,
        type_id: materialType?.value,
        material_id: materialId?.value,
        supplier: '' === supplier?.value ? 'All' : supplier?.value,
        layout: layout?.value,
        granularity: granularity?.value,
        date_range: [
          moment(dateRange.startdate).format('YYYY-MM-DD'),
          moment(dateRange.endDate).format('YYYY-MM-DD'),
        ],
        compare: switchChecked,
        compare_time_flag: !!(switchChecked && selectedRadioOption === 'TimePeriod'),
        compare_time_period: [
          switchChecked && selectedRadioOption === 'TimePeriod'
            ? moment(compareDates?.startDate).format('YYYY-MM-DD')
            : '',
          switchChecked && selectedRadioOption === 'TimePeriod'
            ? moment(compareDates?.endDate).format('YYYY-MM-DD')
            : '',
        ],
        compare_material_flag: !!(switchChecked && selectedRadioOption === 'Material'),
        report_options: reportOptionsArray,
      },
    };
    setIsLoading(true);
    setToastResponse({ text: '', toastType: '' });
    dispatch(VariantSaveAction(payload)).then(
      (response: any) => {
        setOpenConfirmationModal(false);
        setCloneVariantModal(false);
        if (response.status == 200) {
          setIsLoading(false);
          setToastResponse({ text: t(response.data), toastType: 'success' });
          setVariantsaveActivate(false);
          resetFormvalues();
          dispatch(variantsList());
          setClonePrivateFlag(false);
          setCloneVariantName('');
          dispatch(variantsList()).then(
            (response: any) => {
              if (response) {
                setIsLoading(false);
                console.log(isLoading);
              }
              setIsLoading(false);
            },
            (error: any) => {
              console.error('Error occured in variantsList ', error);
              setIsLoading(false);
            }
          );
        }
        if (response.status == 400) {
          setIsLoading(false);
          setToastResponse({ text: t(response.data), toastType: 'error' });
        } else {
          setIsLoading(false);
        }
      },
      (error: any) => {
        setIsLoading(false);
        console.log('err', error);
      }
    );
  };
  const datesDifference = () => {
    const date = new Date(dateRange.startdate);
    const date1 = new Date(dateRange.endDate);
    let dateDiff = date1.getTime() - date.getTime();

    return Math.floor(dateDiff / (1000 * 60 * 60 * 24));
  };
  const handleReportSequenceIds = () => {
    let i = 1;
    reportOptionsArray?.forEach((item) => {
      item.report_sqn = i;
      i++;
    });
  };

  const setSelectedVariantDetails = (data: any) => {
    setMaterialcategory({ value: data?.report_json?.category_id });
    materialTypeFetch(data?.report_json?.category_id);
    materialIdFetch(data?.report_json?.type_id);
    setSwitchChecked(data?.report_json?.compare);
    setGranularity({ value: data?.report_json?.granularity });
    setLayout({ value: data?.report_json?.layout });
    setSupplier({ value: data?.report_json?.supplier });
    setMaterialId({ value: data?.report_json?.material_id });
    setReportOptionsArray(data?.report_json?.report_options);
    setVariantUpdateFlag(true);
    setVariantCheckbox(data?.private);
    setVariantName(data?.variant_name);
    setSelectedRadioOption(
      data?.report_json?.compare_material_flag === true ? 'Material' : 'TimePeriod'
    );
    setMaterialType({ value: data?.report_json?.type_id });
    setMaterialId({ value: data?.report_json?.material_id });
    reportOptionsGet(
      data?.report_json?.material_id,
      data?.report_json?.category_id,
      data?.report_json?.type_id
    );
    setDaterange({
      startdate: new Date(data?.report_json?.date_range[0]),
      endDate: new Date(data?.report_json?.date_range[1]),
    });
    reportOptionsGet(
      data?.report_json?.material_id,
      data?.report_json?.category_id,
      data?.report_json?.type_id
    );
    if (data?.report_json?.compare && data?.report_json?.compare_time_flag) {
      setComparedates({
        startDate: new Date(data?.report_json?.compare_time_period[0]),
        endDate: new Date(data?.report_json?.compare_time_period[1]),
      });
    }
  };

  const variantUpdate = () => {
    handleReportSequenceIds();
    let selectedValues = {
      variant_name: variantName,
      furnance_flag: false,
      user_id: localUserData?.id,
      user_name: localUserData?.username,
      furnance_id: '',
      variant_id: selectedVariant?.value,
      plant: plantData?.plant_name,
      report_save: {
        update_flag: true,
        clone_flag: false,
        private: variantCheckbox,
        type_id: materialType?.value,
        category_id: materialcategory?.value,
        material_id: materialId?.value,
        supplier: '' === supplier?.value ? 'All' : supplier?.value,
        layout: layout?.value,
        granularity: granularity?.value,
        date_range: [
          moment(dateRange.startdate).format('YYYY-MM-DD'),
          moment(dateRange.endDate).format('YYYY-MM-DD'),
        ],
        compare: switchChecked,
        compare_time_flag: !!(switchChecked && selectedRadioOption === 'TimePeriod'),
        compare_time_period: [
          switchChecked && selectedRadioOption === 'TimePeriod'
            ? moment(compareDates?.startDate).format('YYYY-MM-DD')
            : '',
          switchChecked && selectedRadioOption === 'TimePeriod'
            ? moment(compareDates?.endDate).format('YYYY-MM-DD')
            : '',
        ],
        compare_material_flag: !!(switchChecked && selectedRadioOption === 'Material'),
        report_options: reportOptionsArray,
      },
    };
    setIsLoading(true);
    dispatch(VariantSaveAction(selectedValues)).then(
      (response: any) => {
        setIsLoading(false);
        setOpenConfirmationModal(false);
        resetFormvalues();
        setToastResponse({ text: t(response.data), toastType: 'success' });
      },
      (error: any) => {
        setIsLoading(false);
        setToastResponse({ text: t(error.data), toastType: 'error' });
      }
    );
  };

  const compareToggle = (value: any) => {
    setSwitchChecked(value);
    setShowGraphs(false);
    setReportOptionsArray([]);
  };
  const handleVariantName = (value: any) => {
    setVariantName(value);
  };
  const handleVariantNameForClone = (val: any) => {
    setCloneVariantName(val);
  };
  const handlePrivateFlagForClone = (val: any) => {
    setClonePrivateFlag(val);
  };
  const handleEmptyClick = () => {
    console.log('empty Click');
  };
  const handleReportSequenceDuplication = (data: any) => {
    let reportOption = [...reportOptionsArray].filter((item: any) => {
      return (
        item.element_name === data.element_name &&
        item.chart_type === data.chart_type &&
        (item.compare_material_id?.length > 0
          ? item.compare_material_id.some((i1: any) => data.compare_material_id.includes(i1))
          : true)
      );
    });
    if (reportOption.length > 0) {
      setReportDropdown({ value: t('sharedTexts.select') });
      setElementValue({ value: t('sharedTexts.select') });
      console.log(reportDropdown);
      return false;
    } else {
      return true;
    }
  };
  const [clonePrivateFlag, setClonePrivateFlag] = useState(false);
  const [cloneVariantName, setCloneVariantName] = useState('');
  const [showTooltip, setShowTooltip] = useState(false);
  let Granularities: { value: string; option: string; id: number }[] = [
    { value: 'hour', option: 'Hour', id: 1 },
    { value: 'shift', option: 'Shift', id: 2 },
    { value: 'day', option: 'Day', id: 3 },
    { value: 'week', option: 'Week', id: 4 },
    { value: 'month', option: 'Month', id: 5 },
    { value: 'quarter', option: 'Quarter', id: 6 },
    { value: 'year', option: 'Year', id: 7 },
  ];
  const Suppliers: { value: string; option: string }[] = [
    { value: 'Supplier1', option: 'Supplier 1' },
    { value: 'Supplier2', option: 'Supplier 2' },
    { value: 'Supplier3', option: 'Supplier 3' },
  ];
  const Layouts: { value: string; option: string }[] = [
    { value: '1 column', option: '1 Column' },
    { value: '2 columns', option: '2 Column' },
  ];

  const [openConfirmationModal, setOpenConfirmationModal] = useState(false);
  const [CloneVariantmodal, setCloneVariantModal] = useState(false);
  const [deleteVariantModal, setDeleteVariantModal] = useState(false);
  const handleDeleteVariant = () => {
    setToastResponse({ text: '', toastType: '' });
    setIsLoading(true);
    setDeleteVariantModal(false);
    dispatch(
      variantDeleteIdAction(selectedVariant?.value, variantName, localUserData?.username)
    ).then((response: any) => {
      if (response) {
        if (response.status == 400) {
          setIsLoading(false);
          setToastResponse({ text: t(response.data[0]), toastType: 'error' });
        } else {
          setToastResponse({ text: t(response.data[0]), toastType: 'success' });
          resetFormvalues();
          setVariantUpdateFlag(false);
          dispatch(variantsList()).then(
            (response: any) => {
              if (response) {
                setIsLoading(false);
                console.log(isLoading);
              }
              setIsLoading(false);
            },
            (error: any) => {
              console.error('Error occured in variantsList ', error);
              setIsLoading(false);
            }
          );
          setIsLoading(false);
        }
      }
    });
  };
  const handleReportPush = () => {
    let compareMaterialIdArray = [];
    if (handlereportOptionErrors(element.value, chartType.value, compareMaterialid1.value)) {
      if (switchChecked && selectedRadioOption === 'Material' && compareMaterialid1.value) {
        compareMaterialIdArray.push(compareMaterialid1.value);
      }
      if (switchChecked && selectedRadioOption === 'Material' && compareMaterialid2.value) {
        compareMaterialIdArray.push(compareMaterialid2.value);
      }
      if (switchChecked && selectedRadioOption === 'Material' && compareMaterialid3.value) {
        compareMaterialIdArray.push(compareMaterialid3.value);
      }
      if (switchChecked && selectedRadioOption === 'Material' && compareMaterialid4.value) {
        compareMaterialIdArray.push(compareMaterialid4.value);
      }
      setElementValue({ value: t('sharedTexts.select') });
      let report = {
        element_id: element.value,
        element_name: elementValue.value,
        chart_type: chartType.value,
        report_sqn: reportOptionsArray.length + 1,
        compare_material_id: selectedRadioOption == 'Material' ? compareMaterialIdArray : [],
      };
      if (handleReportSequenceDuplication(report)) {
        setReportOptionsArray([...reportOptionsArray, report]);
        setElement({ value: '' });
        setChartType({ value: '' });
        setReportDropdown({ value: '' });
        setCompareMaterialid1({ value: '' });
        setCompareMaterialid2({ value: '' });
        setCompareMaterialid3({ value: '' });
        setCompareMaterialid4({ value: '' });
      } else {
        setToastResponse({
          text: t('reports.selectedReportSequenceAlreadyExist'),
          toastType: 'error',
        });
      }
    } else {
      setToastResponse({
        text: t('reports.pleaseSelectAllRequiredFieldsToCreateReportSequence'),
        toastType: 'error',
      });
    }
  };
  const [element, setElement] = useState({
    value: '',
  });
  const [elementValue, setElementValue] = useState({ value: t('sharedTexts.select') });
  const [chartType, setChartType] = useState({
    value: '',
  });
  const handleElementSet = (val: any) => {
    setElement({ value: val });
  };
  const handleReportOptions = (val: any) => {
    setChartType({ value: val });
  };
  const [reportDropdown, setReportDropdown] = useState({
    value: '',
  });
  const handleStateUpdation = (data: any) => {
    setReportOptionsArray(data);
  };
  const handlereportOptionErrors = (element: any, chartType: any, materialId1: any) => {
    if (element && chartType) {
      if (switchChecked && selectedRadioOption == 'Material') {
        if (materialId1) {
          return true;
        } else {
          return false;
        }
      }

      return true;
    } else {
      return false;
    }
  };

  const privateVariantCheckbox = (val: any) => {
    setVariantCheckbox(val);
  };
  const [variantName, setVariantName] = useState('');

  return (
    <>
      <div className='fluid-container h-full' style={{ overflowY: 'scroll', overflowX: 'hidden' }}>
        <div className=''>
          <div className='row'>
            <div className='col-12 dashboard__main__header'>
              <div className='flex items-center justify-between h-full'>
                <div className='flex items-center'>
                  {toastResponse.toastType == 'success' && (
                    <Toaster
                      text={toastResponse.text}
                      toastType='success'
                      updateToastPropsState={setToastResponse}
                    ></Toaster>
                  )}
                  {toastResponse.toastType == 'warning' && (
                    <Toaster
                      text={toastResponse.text}
                      toastType='warning'
                      updateToastPropsState={setToastResponse}
                    ></Toaster>
                  )}
                  {toastResponse.toastType == 'error' && (
                    <Toaster
                      text={toastResponse.text}
                      toastType='error'
                      updateToastPropsState={setToastResponse}
                    ></Toaster>
                  )}

                  <h2 className='text-xl font-semibold ml-4'>
                    {t('plantModulesAndFunctions.MAT_ANA')}
                  </h2>
                </div>
                <div
                  style={{
                    width: '13%',
                    height: '75%',
                    display: 'flex',
                    justifyContent: 'space-between',
                  }}
                >
                  <div
                    style={{
                      pointerEvents: showGraphs ? 'auto' : 'none',
                      opacity: showGraphs ? '1' : '0.5',
                    }}
                  >
                    <img
                      src={print}
                      style={headerImages}
                      className='w-100 h-100'
                      onClick={() => {
                        if (variantsaveActivate) {
                          onPrintRecords();
                          setShowSelectionCriteriaCard(true);
                        }
                      }}
                      onMouseOver={() => setImageTooltips(1)}
                      onMouseOut={() => setImageTooltips(0)}
                    />
                    {imageTooltips === 1 && (
                      <span
                        className='tooltiptext mt-2'
                        style={{
                          zIndex: 9999,
                          position: 'fixed',
                          width: 'auto',
                          backgroundColor: '#022549',
                          color: 'white',
                          fontSize: '12px',
                          borderRadius: '4px',
                          padding: '10px',
                        }}
                      >
                        {t('reports.print')}
                      </span>
                    )}
                  </div>
                  {/*<div > <img src={download} style={headerImages} className='w-100 h-100' onClick={() =>{ if(variantsaveActivate){handleExportPDF()}}}  onMouseOver={() => setImageTooltips(2)}
          onMouseOut={() => setImageTooltips(0)} />
          {imageTooltips===2 && (
  
  <span className="tooltiptext mt-2"  style={{position:'fixed',width:'85px',backgroundColor:'#022549',color:'white',fontSize:'12px',borderRadius:'4px',padding:'10px'}}>{t('reports.exportPDF')}</span>

 )}
          </div>*/}
                  <div
                    style={{
                      pointerEvents: isLoggedInUserCreatedVariant ? 'auto' : 'none',
                      opacity: isLoggedInUserCreatedVariant ? '1' : '0.5',
                    }}
                  >
                    {' '}
                    <img
                      src={save}
                      className='w-100 h-100'
                      onClick={() => {
                        if (variantsaveActivate) {
                          setOpenConfirmationModal(true);
                        }
                      }}
                      style={headerImages}
                      onMouseOver={() => setImageTooltips(3)}
                      onMouseOut={() => setImageTooltips(0)}
                    />
                    {imageTooltips === 3 && (
                      <span
                        className='tooltiptext mt-2'
                        style={{
                          zIndex: 9999,
                          position: 'fixed',
                          width: 'auto',
                          backgroundColor: '#022549',
                          color: 'white',
                          fontSize: '12px',
                          borderRadius: '4px',
                          padding: '10px',
                        }}
                      >
                        {t('sharedTexts.save')}
                      </span>
                    )}
                  </div>
                  {openConfirmationModal && (
                    <ReportModal
                      updateVariantflag={variantUpdateFlag}
                      privatevariantValue={variantCheckbox}
                      handleprivatevariant={privateVariantCheckbox}
                      variantSaveReport={(val: any) => {
                        setOpenConfirmationModal(false);
                        if (val == 'save') {
                          variantSaveApi(val);
                        }
                        if (val == 'update') {
                          variantUpdate();
                        }
                      }}
                      variantValue={variantName}
                      showModal={openConfirmationModal}
                      closeModal={() => setOpenConfirmationModal(false)}
                      onConfirmClick={() => {
                        setOpenConfirmationModal(false);
                      }}
                      variantName={handleVariantName}
                      content={t('reports.saveVariant')}
                      title='Export To Excel'
                      confirmButtonText={t('sharedTexts.save')}
                    />
                  )}

                  <AlertModal
                    showModal={deleteVariantModal}
                    title={t('sharedTexts.alert')}
                    content={`${t('reports.areYouSureYouWantToDeleteVariant')} ${variantName} ?`}
                    confirmButtonText={t('sharedTexts.proceed')}
                    // onConfirmClick={handleDeleteRole}
                    onConfirmClick={handleDeleteVariant}
                    // closeModal={handleCloseDeleteModal}
                    closeModal={() => setDeleteVariantModal(false)}
                  />
                  {CloneVariantmodal && (
                    <ReportModal
                      updateVariantflag={'clone'}
                      variantValue={cloneVariantName}
                      handleprivatevariant={handlePrivateFlagForClone}
                      privatevariantValue={clonePrivateFlag}
                      variantName={handleVariantNameForClone}
                      showModal={CloneVariantmodal}
                      closeModal={() => setCloneVariantModal(false)}
                      variantSaveReport={(val: any) => {
                        setCloneVariantModal(false);
                        variantSaveApi(val);
                      }}
                      onConfirmClick={() => {
                        setCloneVariantModal(false);
                      }}
                      content={t('reports.cloneVariant')}
                      title='Export To Excel'
                      confirmButtonText={t('sharedTexts.save')}
                    />
                  )}

                  <div
                    style={{
                      pointerEvents: isLoggedInUserCreatedVariant ? 'auto' : 'none',
                      opacity: isLoggedInUserCreatedVariant ? '1' : '0.5',
                    }}
                  >
                    <img
                      src={clone}
                      className='w-100 h-100'
                      style={headerImages}
                      onClick={() => {
                        if (variantsaveActivate) {
                          setCloneVariantModal(true);
                        }
                      }}
                      onMouseOver={() => setImageTooltips(4)}
                      onMouseOut={() => setImageTooltips(0)}
                    />
                    {imageTooltips === 4 && (
                      <span
                        className='tooltiptext mt-2'
                        style={{
                          zIndex: 9999,
                          position: 'fixed',
                          width: 'auto',
                          backgroundColor: '#022549',
                          color: 'white',
                          fontSize: '12px',
                          borderRadius: '4px',
                          padding: '10px',
                        }}
                      >
                        {t('sharedTexts.clone')}
                      </span>
                    )}
                  </div>
                  <div
                    style={{
                      pointerEvents: isLoggedInUserCreatedVariant ? 'auto' : 'none',
                      opacity: isLoggedInUserCreatedVariant ? '1' : '0.5',
                    }}
                  >
                    <img
                      src={deleteIcon}
                      className='w-100 h-100'
                      style={headerImages}
                      onClick={() => {
                        if (variantDeleteActive) {
                          setDeleteVariantModal(true);
                        }
                      }}
                      onMouseOver={() => setImageTooltips(6)}
                      onMouseOut={() => setImageTooltips(0)}
                    />
                    {imageTooltips === 6 && (
                      <span
                        className='tooltiptext mt-2'
                        style={{
                          zIndex: 9999,
                          position: 'fixed',
                          width: 'auto',
                          backgroundColor: '#022549',
                          color: 'white',
                          fontSize: '12px',
                          borderRadius: '4px',
                          padding: '10px',
                          marginLeft: '-16px',
                        }}
                      >
                        {t('sharedTexts.delete')}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {isLoading ? (
              <Loader />
            ) : (
              <div ref={printComponentRef} className='col-12 px-8 py-6 scroll-0'>
                <div className='card'>
                  <div className='card-box pt-4 px-6 pb-8'>
                    <div className='d-flex justify-content-between'>
                      <p style={reportHeader} className='d-flex'>
                        {t('reports.reportFilters')}
                        <div>
                          <img
                            src={Reset}
                            className='ms-3'
                            onClick={resetFormvalues}
                            style={{ cursor: 'pointer', display: 'block' }}
                            onMouseOver={() => setImageTooltips(5)}
                            onMouseOut={() => setImageTooltips(0)}
                          />
                          {imageTooltips === 5 && (
                            <span
                              className='tooltiptext mt-2'
                              style={{
                                zIndex: 9999,
                                position: 'fixed',
                                width: 'auto',
                                backgroundColor: '#022549',
                                color: 'white',
                                fontSize: '12px',
                                borderRadius: '4px',
                                padding: '10px',
                              }}
                            >
                              {t('reports.resetFilters')}
                            </span>
                          )}
                        </div>
                      </p>
                      {showExpandCollapseIcons ? (
                        <span>
                          {showSelectionCriteriaCard ? (
                            <img
                              src={arrowUp}
                              className='me-2'
                              style={{ cursor: 'pointer' }}
                              onClick={toggleArrowDirection}
                            />
                          ) : (
                            <img
                              src={arrowDown}
                              className='me-2'
                              style={{ cursor: 'pointer' }}
                              onClick={toggleArrowDirection}
                            />
                          )}
                        </span>
                      ) : (
                        <></>
                      )}
                    </div>
                    <hr className='line_break' />

                    {showSelectionCriteriaCard && (
                      <div>
                        <div className='row' style={{ cursor: 'pointer' }}>
                          <div className='col-3'>
                            <span style={dropdownHeadingStyle}>{t('reports.variantName')}</span>
                            <CustomSelect
                              index={0}
                              options={VariantsList}
                              onChange={(val: any) => {
                                setShowGraphs(false);
                                setSelectedVariant({ value: val });
                                variantdetailsFectchByid(val);
                                setVariantsaveActivate(true);
                                setVariantCloneFlag(true);
                              }}
                              value={
                                VariantsList.filter(
                                  (item: any): any => item.value == selectedVariant?.value
                                )[0]?.option || t('sharedTexts.select')
                              }
                            />
                          </div>
                        </div>
                        <div className='row mt-3'>
                          <div className='col-3' style={{ cursor: 'pointer' }}>
                            <span style={dropdownHeadingStyle}>
                              {t('reports.materialCategory')} *
                            </span>
                            <CustomSelect
                              index={0}
                              options={materialCategories}
                              toShowTooltip={false}
                              onChange={(val: any) => {
                                setMaterialcategory({ value: val });
                                materialTypeFetch(val);
                                setMaterialType({ value: '' });
                                setMaterialId({ value: '' });
                                //checkAllRequiredFields();
                              }}
                              value={
                                materialCategories.filter(
                                  (item: any): any => item.value == materialcategory?.value
                                )[0]?.option || t('sharedTexts.select')
                              }
                              disabled={!isLoggedInUserCreatedVariant}
                            />
                          </div>
                          <div className='col-3' style={{ cursor: 'pointer' }}>
                            <span style={dropdownHeadingStyle}>
                              {t('masterData.sharedMasterDataTexts.materialType')} *
                            </span>
                            <CustomSelect
                              index={0}
                              options={materialTypes}
                              toShowTooltip={false}
                              onChange={(val: any) => {
                                materialIdFetch(val);
                                setMaterialType({ value: val });
                                setMaterialId({ value: '' });
                                //checkAllRequiredFields();
                              }}
                              value={
                                materialTypes.filter(
                                  (item: any): any => item.value == materialType?.value
                                )[0]?.option || t('sharedTexts.select')
                              }
                              disabled={!isLoggedInUserCreatedVariant}
                            />
                          </div>
                          <div className='col-3' style={{ cursor: 'pointer' }}>
                            <span style={dropdownHeadingStyle}>{t('reports.materialID')} *</span>
                            <CustomSelect
                              index={0}
                              search={true}
                              searchText={t('reports.searchProduct')}
                              options={materialTypesCompare}
                              onChange={(val: any) => {
                                setMaterialId({ value: val });
                                reportOptionsGet(val, materialcategory.value, materialType.value);
                                resetMaterialIds();
                                //checkAllRequiredFields();
                              }}
                              value={
                                materialTypesCompare.filter(
                                  (item: any): any => item.value == materialId?.value
                                )[0]?.option || t('sharedTexts.select')
                              }
                              disabled={!isLoggedInUserCreatedVariant}
                            />
                          </div>
                          <div className='col-3' style={{ cursor: 'pointer' }}>
                            <span style={dropdownHeadingStyle}>{t('reports.supplier')}</span>

                            <CustomSelect
                              index={0}
                              options={Suppliers}
                              onChange={(val: any) => {
                                setSupplier({ value: val });
                              }}
                              value={
                                Suppliers.filter(
                                  (item: any): any => item.value == supplier?.value
                                )[0]?.option || t('sharedTexts.select')
                              }
                              disabled={!isLoggedInUserCreatedVariant}
                            />
                          </div>
                        </div>
                        <div className='row mt-3'>
                          <div className='col-3' style={{ cursor: 'pointer' }}>
                            <label style={dropdownHeadingStyle}>
                              {t('reports.layout')} *
                              <img
                                src={info}
                                className='ms-1'
                                onMouseOver={() => setShowTooltip(true)}
                                onMouseOut={() => setShowTooltip(false)}
                              />
                              {showTooltip && (
                                <span
                                  className='tooltiptext'
                                  style={{
                                    zIndex: 9999,
                                    position: 'fixed',
                                    width: '206px',
                                    backgroundColor: '#022549',
                                    color: 'white',
                                    fontSize: '12px',
                                    borderRadius: '4px',
                                    padding: '10px',
                                  }}
                                >
                                  {t('reports.dataWillBeDisplayedInTheSelectedNoOfColumns')}
                                </span>
                              )}
                            </label>

                            <CustomSelect
                              index={0}
                              options={Layouts}
                              onChange={(val: any) => {
                                setLayout({ value: val });
                                //checkAllRequiredFields();
                              }}
                              value={
                                Layouts.filter((item: any): any => item.value == layout?.value)[0]
                                  ?.option || t('sharedTexts.select')
                              }
                              disabled={!isLoggedInUserCreatedVariant}
                            />
                          </div>
                          <div className='col-3' style={{ cursor: 'pointer' }}>
                            <span style={dropdownHeadingStyle}>{t('reports.dateRange')} *</span>
                            <DateRangePicker
                              startdate={moment(dateRange.startdate).format('MM/DD/YYYY')}
                              enddate={moment(dateRange.endDate).format('MM/DD/YYYY')}
                              handleDates={(_dateArrayObj: any, dateArrayString: any) => {
                                setDateClicked(true);
                                console.log(dateClicked);
                                setDaterange({
                                  startdate: dateArrayString?.[0],
                                  endDate: dateArrayString?.[1],
                                });
                              }}
                              disabled={!isLoggedInUserCreatedVariant}
                            />
                          </div>
                          <div className='col-3' style={{ cursor: 'pointer' }}>
                            <span style={dropdownHeadingStyle}>{t('reports.granularity')} *</span>

                            <CustomSelect
                              index={0}
                              options={granularityDropDownData()}
                              onChange={(val: any) => {
                                setGranularity({ value: val });
                                //checkAllRequiredFields();
                              }}
                              value={
                                Granularities.filter(
                                  (item: any): any => item.value == granularity?.value
                                )[0]?.option || t('sharedTexts.select')
                              }
                              disabled={!isLoggedInUserCreatedVariant}
                            />
                          </div>
                          <div className='col-3'>
                            <span style={dropdownHeadingStyle}>{t('reports.compare')}</span>
                            <ToggleButton
                              onChange={compareToggle}
                              isChecked={switchChecked}
                              text={
                                switchChecked ? t('sharedTexts.enabled') : t('sharedTexts.disabled')
                              }
                              disabled={!isLoggedInUserCreatedVariant}
                            ></ToggleButton>
                          </div>
                        </div>

                        <div className='row mt-3'>
                          {switchChecked === true && (
                            <div className='col-3'>
                              <CompareDateRadio
                                radioOptions={[]}
                                heading={''}
                                selectedValue={selectedRadioOption}
                                onChange={handleRadioButton}
                                disabled={!isLoggedInUserCreatedVariant}
                              ></CompareDateRadio>
                            </div>
                          )}
                          {switchChecked && selectedRadioOption == 'TimePeriod' && (
                            <div className='col-3'>
                              <span style={dropdownHeadingStyle}>
                                {t('reports.compareDateRange')}
                              </span>

                              <DateRangePicker
                                startdate={moment(compareDates.startDate).format('MM/DD/YYYY')}
                                enddate={moment(compareDates.endDate).format('MM/DD/YYYY')}
                                handleDates={(_dateArrayObj: any, dateArrayString: any) => {
                                  setComparedates({
                                    startDate: dateArrayString?.[0],
                                    endDate: dateArrayString?.[1],
                                  });
                                  setCompareDateClicked(true);
                                  console.log(compareDateClicked);
                                }}
                                disabled={!isLoggedInUserCreatedVariant}
                              ></DateRangePicker>
                            </div>
                          )}
                          {switchChecked && selectedRadioOption == 'Material' && (
                            <div className='col-3' style={{ cursor: 'pointer' }}>
                              <span style={dropdownHeadingStyle}>
                                {t('reports.compareMaterialId')} *
                              </span>
                              <CustomSelect
                                index={0}
                                options={materialTypesCompare.filter(
                                  (item) =>
                                    ![
                                      materialId?.value,
                                      compareMaterialid1?.value,
                                      compareMaterialid2?.value,
                                      compareMaterialid3?.value,
                                      compareMaterialid4?.value,
                                    ].includes(item.value)
                                )}
                                onChange={(val: any) => {
                                  setCompareMaterialid1({ value: val });
                                  //checkAllRequiredFields();
                                }}
                                value={
                                  materialTypesCompare.filter(
                                    (item: any): any => item.value == compareMaterialid1?.value
                                  )[0]?.option || t('sharedTexts.select')
                                }
                                disabled={!isLoggedInUserCreatedVariant}
                              />
                            </div>
                          )}
                          {switchChecked && selectedRadioOption == 'Material' && (
                            <div className='col-3' style={{ cursor: 'pointer' }}>
                              <span style={dropdownHeadingStyle}>
                                {t('reports.compareMaterialId')}
                              </span>
                              <CustomSelect
                                index={0}
                                options={materialTypesCompare.filter(
                                  (item) =>
                                    ![
                                      materialId?.value,
                                      compareMaterialid1?.value,
                                      compareMaterialid2?.value,
                                      compareMaterialid3?.value,
                                      compareMaterialid4?.value,
                                    ].includes(item.value)
                                )}
                                onChange={(val: any) => {
                                  setCompareMaterialid2({ value: val });
                                }}
                                value={
                                  materialTypesCompare.filter(
                                    (item: any): any => item.value == compareMaterialid2?.value
                                  )[0]?.option || t('sharedTexts.select')
                                }
                                disabled={!isLoggedInUserCreatedVariant}
                              />
                            </div>
                          )}
                          {switchChecked && selectedRadioOption == 'Material' && (
                            <div className='col-3' style={{ cursor: 'pointer' }}>
                              <span style={dropdownHeadingStyle}>
                                {t('reports.compareMaterialId')}
                              </span>
                              <CustomSelect
                                index={0}
                                options={materialTypesCompare.filter(
                                  (item) =>
                                    ![
                                      materialId?.value,
                                      compareMaterialid1?.value,
                                      compareMaterialid2?.value,
                                      compareMaterialid3?.value,
                                      compareMaterialid4?.value,
                                    ].includes(item.value)
                                )}
                                onChange={(val: any) => {
                                  setCompareMaterialid3({ value: val });
                                }}
                                value={
                                  materialTypesCompare.filter(
                                    (item: any): any => item.value == compareMaterialid3?.value
                                  )[0]?.option || t('sharedTexts.select')
                                }
                                disabled={!isLoggedInUserCreatedVariant}
                              />
                            </div>
                          )}
                          <div className='row mt-3'>
                            {switchChecked === true && selectedRadioOption == 'Material' && (
                              <div className='col-3' style={{ cursor: 'pointer' }}>
                                <span style={dropdownHeadingStyle}>
                                  {t('reports.compareMaterialId')}
                                </span>

                                <CustomSelect
                                  index={0}
                                  options={materialTypesCompare.filter(
                                    (item) =>
                                      ![
                                        materialId?.value,
                                        compareMaterialid1?.value,
                                        compareMaterialid2?.value,
                                        compareMaterialid3?.value,
                                        compareMaterialid4?.value,
                                      ].includes(item.value)
                                  )}
                                  onChange={(val: any) => {
                                    setCompareMaterialid4({ value: val });
                                  }}
                                  value={
                                    materialTypesCompare.filter(
                                      (item: any): any => item.value == compareMaterialid4?.value
                                    )[0]?.option || t('sharedTexts.select')
                                  }
                                  disabled={!isLoggedInUserCreatedVariant}
                                />
                              </div>
                            )}
                            <div className='col-3' style={{ cursor: 'pointer' }}>
                              <span style={dropdownHeadingStyle}>
                                {t('reports.reportOptions')} *
                              </span>

                              <ReportDropdown
                                index={0}
                                options={reportOptions}
                                onChange={(val: any) => {
                                  handleElementSet(val);
                                  setReportDropdown({ value: val });
                                  const selectedElement = reportOptions.filter(
                                    (item) =>
                                      item.value === val &&
                                      !reportOptionsHeadings.includes(item.option)
                                  )[0].option;
                                  if (reportOptionsHeadings.includes(selectedElement)) {
                                    setElementValue({ value: t('sharedTexts.select') });
                                  } else {
                                    setElementValue({ value: selectedElement });
                                    //checkAllRequiredFields();
                                  }
                                }}
                                value={elementValue.value}
                                search={true}
                                searchText={t('reports.searchReportOptions')}
                                filterData={reportOptionsHeadings}
                                disabled={
                                  (materialcategory.value && materialType.value && materialId.value
                                    ? false
                                    : true) || !isLoggedInUserCreatedVariant
                                }
                              />
                            </div>

                            <div className='col-3'>
                              <VisualizationGraph
                                showStacked={switchChecked}
                                disabled={
                                  (materialcategory.value && materialType.value && materialId.value
                                    ? false
                                    : true) || !isLoggedInUserCreatedVariant
                                }
                                handleGraph={(val: any) => {
                                  handleReportOptions(val);
                                }}
                                handleReportAdd={() => {
                                  handleReportPush();
                                }}
                              ></VisualizationGraph>
                            </div>
                          </div>{' '}
                        </div>

                        {reportOptionsArray.length > 0 && (
                          <div className='card mt-3 me-4'>
                            <ReportSequence
                              items={reportOptionsArray}
                              stateUpdation={handleStateUpdation}
                              element={undefined}
                              selectedName='element_name'
                              disabled={!isLoggedInUserCreatedVariant}
                            ></ReportSequence>
                          </div>
                        )}
                        <span className='d-flex justify-content-end me-4'>
                          <button
                            className='btn btn--h36 px-4 py-2 mt-3'
                            style={{
                              backgroundColor:
                                reportOptionsArray?.length > 0 ? '#0D659E' : '#DEE3E4',
                              color: 'white',
                              fontWeight: '500',
                            }}
                            onClick={
                              reportOptionsArray.length > 0 ? generateReport : handleEmptyClick
                            }
                          >
                            {t('reports.generateReport')}
                          </button>
                        </span>
                      </div>
                    )}
                  </div>
                </div>
                <div className='d-flex analysis-graph'>
                  {showGraphs && (
                    <div className='col-12 card-box mt-5 pt-4 px-6 pb-8'>
                      <Graph
                        graphPayload={matGraphs}
                        layout={layout.value}
                        date_range={[
                          moment(dateRange.startdate).format('YYYY-MM-DD'),
                          moment(dateRange.endDate).format('YYYY-MM-DD'),
                        ]}
                        compare_time_period={[
                          switchChecked && selectedRadioOption === 'TimePeriod'
                            ? moment(compareDates?.startDate).format('YYYY-MM-DD')
                            : '',
                          switchChecked && selectedRadioOption === 'TimePeriod'
                            ? moment(compareDates?.endDate).format('YYYY-MM-DD')
                            : '',
                        ]}
                      />
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
};
const mapStateToProps = (state: any) => ({
  materialTypes: state.reportReducer?.materialTypes,
  materialCategories: state.reportReducer?.materialCategories,
  materialIds: state.reportReducer?.materialIds,
  reportOptions: state.reportReducer?.reportOptions,
  VariantsList: state.reportReducer?.VariantsList,
  matGraphs: state.reportReducer?.matGraphs,
  materialTypesCompare: state.reportReducer?.materialTypesCompare,
  reportOptionsHeadings: state.reportReducer?.reportOptionsHeadings,
  materialIdsForSelection: state.reportReducer?.materialIdsForSelection,
});

export default connect(mapStateToProps)(ReportsPage);

const headerImages: any = {
  marginleft: '2%',
  cursor: 'pointer',
  display: 'block',
};
const dropdownHeadingStyle: any = {
  fontWeight: 500,
  fontSize: '14px',
  color: 'var(--primary75)',
};
const reportHeader = {
  color: 'var(--primary75)',
  fontWeight: 500,
  fontSize: '16px',
};
