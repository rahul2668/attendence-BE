import { FC } from 'react';
import 'assets/styles/scss/pages/dashboard.scss';
import 'assets/styles/scss/components/table-general.scss';
import logo from 'assets/img/blue_FG_logo.png';

const Dashboard: FC = () => {
  return (
    <div style={{ display: 'flex', margin: 'auto' }}>
      <img src={logo} alt='logo' style={{ height: '15vh' }} />
    </div>
  );
};
export default Dashboard;
