import { FC, useEffect, useRef, useState } from 'react';
import { connect, useDispatch } from 'react-redux';
import arrowUp from '../../assets/icons/up_arrow.svg';
import arrowDown from '../../assets/icons/down_arrow.svg';
import {
  MaterialCategoryAction,
  consumptionvariantsaveAction,
  fetchConsumptionReportAction,
  fetchVariantList,
  fetchvariantDetails,
  furnanceListget,
  materialIdAction,
  materialTypeAction,
  variantDeleteIdAction,
} from '../../store/slices/consumptionSlice';
import 'assets/styles/scss/pages/reports.scss';
import CustomSelect from 'components/common/SelectField';
import Reset from '../../assets/icons/reset.svg';
import ToggleButton from 'components/common/ToggleButton';
import CompareDateRadio from 'components/common/CompareDateRadio';
import DateRangePicker from 'components/common/DateRangePicker';
import print from '../../assets/icons/Print.svg';
import deleteIcon from '../../assets/icons/delete_icon.svg';
import clone from '../../assets/icons/clone.svg';
import save from '../../assets/icons/Save.svg';
import { VisualizationGraph } from 'components/common/VisualizationGraph';
import ReportModal from 'components/Modal/ReportModal';
import ReportSequence from 'components/common/ReportSequence';
import moment from 'moment';
import info from '../../assets/icons/info.svg';
import Loader from 'components/Loader';
import Toaster from 'components/common/Toaster/Toaster';
import Graph from 'components/common/Graph';
import AlertModal from 'components/Modal/AlertModal';
import { useReactToPrint } from 'react-to-print';
import { useTranslation } from 'react-i18next';
import { useAppSelector } from 'store';
import { getLoggedInUser } from '../../utils/utils';

interface MaterialConsumptionReportProps {
  materialTypes: { value: string; option: string }[];
  materialCategories: { value: string; option: string }[];
  materialIds: { value: string; option: string }[];
  furnanceOptions: { value: string; option: string }[];
  variantList: { value: string; option: string }[];
  materialTypesCompare: { value: string; option: string }[];
  matGraphs: any;
}

const MaterialConsumptionReport: FC<MaterialConsumptionReportProps> = ({
  materialTypes,
  materialCategories,
  materialIds,
  materialTypesCompare,
  variantList,
  furnanceOptions,
  matGraphs,
}) => {
  const [mesMaterialCode, setMesMaterialCode] = useState<any>('');
  const { t } = useTranslation();
  const printComponentRef = useRef(null);
  const onPrintRecords = useReactToPrint({
    content: () => printComponentRef.current,
  });
  const [switchChecked, setSwitchChecked] = useState<boolean>(false);
  const [isVisualizationGraphDisabled, setIsVisualizationGraphDisabled] = useState(true);
  const [selectedRadioOption, setSelectedRadioOption] = useState('TimePeriod');
  const [materialcategory, setMaterialcategory] = useState({
    value: '',
  });
  const [materialType, setMaterialType] = useState({
    value: '',
  });
  const [materialTypeName, setMaterialTypeName] = useState({ name: '' });
  const [materialId, setMaterialId] = useState({
    value: '',
  });
  const [layout, setLayout] = useState({
    value: '',
  });
  const [granularity, setGranularity] = useState({
    value: '',
  });
  const [furnanceId, setFurnanceId] = useState({
    value: '',
  });
  const [variantId, setVariantId] = useState({
    value: '',
  });
  const [compareMaterialid1, setCompareMaterialid1] = useState({
    value: '',
  });
  const [compareMaterialid2, setCompareMaterialid2] = useState({
    value: '',
  });
  const [compareMaterialid3, setCompareMaterialid3] = useState({
    value: '',
  });
  const [compareMaterialid4, setCompareMaterialid4] = useState({
    value: '',
  });
  const [variantName, setVariantName] = useState('');
  const [toastResponse, setToastResponse] = useState({
    text: '',
    toastType: '',
  });
  const [variantCloneFlag, setVariantCloneFlag] = useState(false);
  const [clonePrivateFlag, setClonePrivateFlag] = useState(false);
  const [cloneVariantName, setCloneVariantName] = useState('');
  const [deleteVariantModal, setDeleteVariantModal] = useState(false);
  const [isLoggedInUserCreatedVariant, setIsLoggedInUserCreatedVariant] = useState(true);
  const handleDeleteVariant = () => {
    setIsLoading(true);
    setToastResponse({ text: '', toastType: '' });
    setDeleteVariantModal(false);
    dispatch(variantDeleteIdAction(variantId.value, variantName, localUserData?.username)).then(
      (response: any) => {
        if (response.status === 200) {
          resetDropdownsData();
          setVariantUpdateFlag(false);
          setToastResponse({ text: t(response.data[0]), toastType: 'success' });
          dispatch(fetchVariantList()).then(
            (response: any) => {
              if (response) {
                setIsLoading(false);
                console.log(isLoading);
              }
              setIsLoading(false);
            },
            (error: any) => {
              console.error('Error occured in variantsList ', error);
              setIsLoading(false);
            }
          );
          setIsLoading(false);
        } else {
          setToastResponse({
            text: t(response?.data?.[0] || 'reports.errorOccurredInVariantDelete'),
            toastType: 'error',
          });
          setIsLoading(false);
        }
      },
      (error: any) => {
        console.error('Error occured in variant delete', error);
        setToastResponse({ text: t('reports.errorOccurredInVariantDelete'), toastType: 'error' });
      }
    );
  };

  const handleVariantNameForClone = (val: any) => {
    setCloneVariantName(val);
  };
  const handlePrivateFlagForClone = (val: any) => {
    setClonePrivateFlag(val);
  };

  const compareToggle = (value: any) => {
    setSwitchChecked(value);
    setReportOptionsArray([]);
    setShowGraphs(false);
  };

  const resetDropdownsData = () => {
    setIsLoggedInUserCreatedVariant(true);
    setVariantDeleteActive(false);
    setMaterialcategory({ value: '' });
    setGranularity({ value: '' });
    setLayout({ value: '' });
    setMaterialId({ value: '' });
    setMaterialType({ value: '' });
    setFurnanceId({ value: '' });
    setVariantId({ value: '' });
    setVariantName('');
    setShowSelectionCriteriaCard(true);
    setSwitchChecked(false);
    setSelectedRadioOption('TimePeriod');
    setShowExpandCollapseIcons(false);
    setVariantsaveActivate(false);
    setVariantCloneFlag(false);
    setReportOptionsArray([]);
    setShowGraphs(false);
    setDateRange({ startdate: new Date(), endDate: new Date() });
    setCompareDates({ startDate: new Date(), endDate: new Date() });
    setIsVisualizationGraphDisabled(true);
  };

  const materialTypeFetch = (id: any) => {
    setIsLoading(true);
    dispatch(materialTypeAction(id)).then(() => {
      setIsLoading(false);
    });
  };

  const materialIdFetch = (id: any) => {
    setIsLoading(true);
    dispatch(materialIdAction(id)).then(() => {
      setIsLoading(false);
    });
  };

  const Layouts: { value: string; option: string }[] = [
    { value: '1 column', option: '1 Column' },
    { value: '2 columns', option: '2 Column' },
  ];

  const handleVariantName = (value: any) => {
    setVariantName(value);
  };

  const dispatch = useDispatch();

  useEffect(() => {
    setIsLoading(true);
    dispatch(MaterialCategoryAction()).then(() => {
      setIsLoading(false);
    });
    dispatch(furnanceListget());
    dispatch(fetchVariantList()).then(() => {
      setIsLoading(false);
    });
  }, []);
  const [dateClicked, setDateClicked] = useState(false);
  const [compareDateClicked, setCompareDateClicked] = useState(false);
  const [showSelectionCriteriaCard, setShowSelectionCriteriaCard] = useState(true);
  const [showExpandCollapseIcons, setShowExpandCollapseIcons] = useState(false);
  const [openConfirmationModal, setOpenConfirmationModal] = useState(false);
  const [variantUpdateFlag, setVariantUpdateFlag] = useState(false);
  const [variantCheckbox, setVariantCheckbox] = useState(false);
  const [showGraphs, setShowGraphs] = useState(false);
  const [showTooltip, setShowTooltip] = useState(false);
  const [variantsaveActivate, setVariantsaveActivate] = useState(false);
  const [isLoading, setIsLoading] = useState<any>(true);
  const [imageTooltips, setImageTooltips] = useState(0);
  const [variantDeleteActive, setVariantDeleteActive] = useState(false);

  const privateVariantCheckbox = (val: any) => {
    setVariantCheckbox(val);
  };
  const variantdetailsFectchByid = (value: any) => {
    setIsLoading(true);
    dispatch(fetchvariantDetails(value)).then(
      (response: any) => {
        const reportJson = response.data[0]?.report_json;
        setIsLoading(false);
        setIsVisualizationGraphDisabled(false);
        console.log(isVisualizationGraphDisabled);
        setDateClicked(true);
        setVariantDeleteActive(true);
        setSelectedVariantDetails(response.data[0]);
        setMaterialType({ value: reportJson?.report_options[0]?.type_id });
        if (getLoggedInUser()?.id !== response?.data?.[0]?.user) {
          setIsLoggedInUserCreatedVariant(false);
        }
      },
      (error: any) => {
        console.error('Error occured in variantFetchByIdAction ', error);
        setIsLoading(false);
      }
    );
  };

  const checkAllRequiredFields = () => {
    if (!switchChecked) {
      setIsVisualizationGraphDisabled(
        materialcategory.value &&
          materialType.value &&
          materialId.value &&
          layout.value &&
          dateClicked &&
          granularity.value
          ? false
          : true
      );
    } else if (selectedRadioOption === 'TimePeriod') {
      setIsVisualizationGraphDisabled(
        materialcategory.value &&
          materialType.value &&
          materialId.value &&
          layout.value &&
          dateClicked &&
          granularity.value &&
          compareDateClicked
          ? false
          : true
      );
    } else {
      setIsVisualizationGraphDisabled(
        materialcategory.value &&
          materialType.value &&
          materialId.value &&
          layout.value &&
          dateClicked &&
          granularity.value &&
          compareMaterialid1.value
          ? false
          : true
      );
    }
  };

  const setSelectedVariantDetails = (data: any) => {
    setMaterialcategory({ value: data?.report_json?.category_id });
    materialTypeFetch(data?.report_json?.category_id);
    setSwitchChecked(data?.report_json?.compare);
    setGranularity({ value: data?.report_json?.granularity });
    setLayout({ value: data?.report_json?.layout });
    setMaterialId({ value: data?.report_json?.material_id });
    setReportOptionsArray(data?.report_json?.report_options);
    setVariantUpdateFlag(true);
    setVariantsaveActivate(true);
    setFurnanceId({ value: data?.furnace });
    setVariantName(data?.variant_name);
    setVariantCheckbox(data?.private);
    setSelectedRadioOption(data?.report_json?.compare_material_flag ? 'Material' : 'TimePeriod');
    materialIdFetch(data?.report_json?.report_options[0]?.type_id);
    setMaterialId({
      value: data?.report_json?.material_id
        ? data?.report_json?.material_id
        : data?.report_json?.report_options[0].compare_material_code_name[0],
    });

    setDateRange({
      startdate: new Date(data?.report_json?.date_range[0]),
      endDate: new Date(data?.report_json?.date_range[1]),
    });
    if (data?.report_json?.compare && data?.report_json?.compare_time_flag) {
      setCompareDates({
        startDate: new Date(data?.report_json?.compare_time_period[0]),
        endDate: new Date(data?.report_json?.compare_time_period[1]),
      });
    }
  };

  let Granularities: { value: string; option: string; id: number }[] = [
    { value: 'hour', option: 'Hour', id: 1 },
    { value: 'shift', option: 'Shift', id: 2 },
    { value: 'day', option: 'Day', id: 3 },
    { value: 'week', option: 'Week', id: 4 },
    { value: 'month', option: 'Month', id: 5 },
    { value: 'quarter', option: 'Quarter', id: 6 },
    { value: 'year', option: 'Year', id: 7 },
  ];
  const granularityDropDownData = () => {
    let difference = datesDifference();
    if (difference < 1) {
      return [
        { value: 'hour', option: 'Hour', id: 1 },
        { value: 'shift', option: 'Shift', id: 2 },
        { value: 'batch', option: 'Batch', id: 8 },
      ];
    } else if (difference < 8) {
      return [
        { value: 'hour', option: 'Hour', id: 1 },
        { value: 'shift', option: 'Shift', id: 2 },
        { value: 'day', option: 'Day', id: 3 },
        { value: 'batch', option: 'Batch', id: 8 },
      ];
    } else if (difference < 32) {
      return [
        { value: 'shift', option: 'Shift', id: 2 },
        { value: 'day', option: 'Day', id: 3 },
        { value: 'week', option: 'Week', id: 4 },
        { value: 'batch', option: 'Batch', id: 8 },
      ];
    } else if (difference < 94) {
      return [
        { value: 'day', option: 'Day', id: 3 },
        { value: 'week', option: 'Week', id: 4 },
        { value: 'month', option: 'Month', id: 5 },
        { value: 'batch', option: 'Batch', id: 8 },
      ];
    } else if (difference < 367) {
      return [
        { value: 'day', option: 'Day', id: 3 },
        { value: 'week', option: 'Week', id: 4 },
        { value: 'month', option: 'Month', id: 5 },
        { value: 'quarter', option: 'Quarter', id: 6 },
        { value: 'batch', option: 'Batch', id: 8 },
      ];
    } else if (difference > 367) {
      return [
        { value: 'week', option: 'Week', id: 4 },
        { value: 'month', option: 'Month', id: 5 },
        { value: 'quarter', option: 'Quarter', id: 6 },
        { value: 'year', option: 'Year', id: 7 },
        { value: 'batch', option: 'Batch', id: 8 },
      ];
    } else {
      return [
        { value: 'hour', option: 'Hour', id: 1 },
        { value: 'shift', option: 'Shift', id: 2 },
        { value: 'day', option: 'Day', id: 3 },
        { value: 'week', option: 'Week', id: 4 },
        { value: 'month', option: 'Month', id: 5 },
        { value: 'quarter', option: 'Quarter', id: 6 },
        { value: 'year', option: 'Year', id: 7 },
        { value: 'batch', option: 'Batch', id: 8 },
      ];
    }
  };

  const getPlantData = useAppSelector((state) => state.plantData.plantData);
  const generateReport = () => {
    const data = getPlantData;
    let plantData: any = {};
    if (null != data) {
      plantData = data;
    }
    const payloadForGraph = {
      generate_report: {
        plant: plantData.plant_name,
        category_id: materialcategory?.value,
        user_id: localUserData?.id,
        user_name: localUserData?.username,
        furnace_id: furnanceId.value,
        layout: layout?.value,
        granularity: granularity?.value,
        date_range: [
          moment(dateRange.startdate).format('YYYY-MM-DD'),
          moment(dateRange.endDate).format('YYYY-MM-DD'),
        ],
        compare: switchChecked,
        compare_time_flag: !!(switchChecked && selectedRadioOption === 'TimePeriod'),
        compare_time_period: [
          switchChecked && selectedRadioOption === 'TimePeriod'
            ? moment(compareDates.startDate).format('YYYY-MM-DD')
            : '',
          switchChecked && selectedRadioOption === 'TimePeriod'
            ? moment(compareDates.endDate).format('YYYY-MM-DD')
            : '',
        ],
        compare_material_flag: !!(switchChecked && selectedRadioOption === 'Material'),
        report_options: reportOptionsArray,
      },
    };
    setIsLoading(true);
    dispatch(fetchConsumptionReportAction(payloadForGraph)).then(
      (response: any) => {
        if (response.status == 200) {
          setIsLoading(false);
          setShowExpandCollapseIcons(true);
          setVariantsaveActivate(true);
          setShowGraphs(true);
        } else if (400 === response.status) {
          setIsLoading(false);
          setShowExpandCollapseIcons(false);
          setShowGraphs(false);
          if (Array.isArray(response?.data)) {
            setToastResponse({ text: t(response.data[0]), toastType: 'error' });
          }
        } else {
          setIsLoading(false);
          setShowGraphs(false);
          setToastResponse({
            text: t('reports.noDataFoundForSelectedCriteria'),
            toastType: 'error',
          });
        }
      },
      (error: any) => {
        setIsLoading(false);
        console.log('API failred', error);
      }
    );
  };
  const handleEmptyClick = () => {
    console.log('Empty Click');
  };
  const datesDifference = () => {
    const date = new Date(dateRange.startdate);
    const date1 = new Date(dateRange.endDate);
    let dateDiff = date1.getTime() - date.getTime();

    return Math.floor(dateDiff / (1000 * 60 * 60 * 24));
  };
  let localUserData: any;
  const userData = useAppSelector((state) => state.userData.userData);

  if (userData !== null) {
    localUserData = userData;
  } else {
    localUserData = {};
  }
  let plantData: any;
  const plantdata = useAppSelector((state) => state.plantData.plantData);
  if (plantdata !== null) {
    plantData = plantdata;
  } else {
    plantData = {};
  }

  const variantSaveApi = (data: any) => {
    let cloneflag = false;
    if (data === 'clone') {
      cloneflag = true;
    }
    let payload: any = {
      variant_name: cloneflag ? cloneVariantName : variantName,
      furnace_flag: true,
      user_name: localUserData?.username,
      furnace_id: furnanceId.value,
      variant_id: '',
      plant: plantData.plant_name,
      report_save: {
        update_flag: false,
        clone_flag: cloneflag,
        private: cloneflag ? clonePrivateFlag : variantCheckbox,
        category_id: materialcategory?.value,
        layout: layout?.value,
        granularity: granularity?.value,
        date_range: [
          moment(dateRange.startdate).format('YYYY-MM-DD'),
          moment(dateRange.endDate).format('YYYY-MM-DD'),
        ],
        compare: switchChecked,
        compare_time_flag: !!(switchChecked && selectedRadioOption === 'TimePeriod'),
        compare_time_period: [
          switchChecked && selectedRadioOption === 'TimePeriod'
            ? moment(dateRange.startdate).format('YYYY-MM-DD')
            : '',
          switchChecked && selectedRadioOption === 'TimePeriod'
            ? moment(dateRange.endDate).format('YYYY-MM-DD')
            : '',
        ],
        compare_material_flag: !!(switchChecked && selectedRadioOption === 'Material'),
        report_options: reportOptionsArray,
      },
    };
    setIsLoading(true);
    setOpenConfirmationModal(false);
    setCloneVariantModal(false);
    dispatch(consumptionvariantsaveAction(payload)).then((response: any) => {
      setIsLoading(false);
      if (response.status == 200) {
        dispatch(fetchVariantList());
        setToastResponse({ text: t(response.data), toastType: 'success' });
        setSwitchChecked(false);
        resetDropdownsData();
        setVariantName('');
      }
      if (response.status == 400) {
        setToastResponse({ text: t(response.data), toastType: 'error' });
      }
    });
  };
  const [reportOptionsArray, setReportOptionsArray] = useState<any[]>([]);
  const [cloneVariantModal, setCloneVariantModal] = useState(false);
  const handlereportOptionErrors = (
    materialId: any,
    chartType: any,
    materialId1: any,
    materialType: any
  ) => {
    if (materialId && chartType && materialType) {
      if (switchChecked && selectedRadioOption == 'Material') {
        if (materialId != 'All') {
          if (materialId1) {
            return true;
          } else {
            return false;
          }
        }
      }

      return true;
    } else {
      return false;
    }
  };
  const toggleArrowDirection = () => {
    setShowSelectionCriteriaCard(!showSelectionCriteriaCard);
  };
  const handleReportSequenceDuplication = (data: any) => {
    let reportOption = [...reportOptionsArray].filter((item: any) => {
      if (data.material_id_all) {
        return (
          item.chart_type === data.chart_type &&
          item.type_id === data.type_id &&
          item.material_id_all === data.material_id_all
        );
      } else {
        return (
          item.chart_type === data.chart_type &&
          item.type_id === data.type_id &&
          item.mes_mat_code === data.mes_mat_code &&
          (item.compare_material_id?.length > 0
            ? item.compare_material_id.some((i1: any) => data.compare_material_id.includes(i1))
            : true)
        );
      }
    });
    if (reportOption.length > 0) {
      return false;
    } else {
      return true;
    }
  };
  const handleReportPush = () => {
    let compareMaterialIdArray = [];
    // console.log(materialType);
    if (
      handlereportOptionErrors(
        materialId.value,
        chartType.value,
        compareMaterialid1.value,
        materialType.value
      )
    ) {
      if (switchChecked && selectedRadioOption === 'Material' && compareMaterialid1.value) {
        compareMaterialIdArray.push(compareMaterialid1.value);
      }
      if (switchChecked && selectedRadioOption === 'Material' && compareMaterialid2.value) {
        compareMaterialIdArray.push(compareMaterialid2.value);
      }
      if (switchChecked && selectedRadioOption === 'Material' && compareMaterialid3.value) {
        compareMaterialIdArray.push(compareMaterialid3.value);
      }
      if (switchChecked && selectedRadioOption === 'Material' && compareMaterialid4.value) {
        compareMaterialIdArray.push(compareMaterialid4.value);
      }

      let report = {
        report_sqn: reportOptionsArray.length + 1,
        chart_type: chartType.value,
        material_id_all: materialId.value === 'All',
        type_id: materialType.value,
        compare_material_id:
          switchChecked && selectedRadioOption === 'Material' && materialId.value != 'All'
            ? compareMaterialIdArray
            : [],
        mes_mat_code: materialId.value === 'All' ? '' : mesMaterialCode,
      };
      if (handleReportSequenceDuplication(report)) {
        setReportOptionsArray([...reportOptionsArray, report]);
        setChartType({ value: '' });
        setCompareMaterialid1({ value: '' });
        setCompareMaterialid2({ value: '' });
        setCompareMaterialid3({ value: '' });
        setCompareMaterialid4({ value: '' });
        //  setMaterialType({value:''});
        setMaterialId({ value: '' });
        materialIdFetch(materialType?.value);
        setToastResponse({ text: '', toastType: '' });
      } else {
        setToastResponse({
          text: t('reports.selectedReportSequenceAlreadyExist'),
          toastType: 'error',
        });
      }
    } else {
      setToastResponse({
        text: t('reports.pleaseSelectAllRequiredFieldsToCreateReportSequence'),
        toastType: 'error',
      });
    }
  };
  const variantUpdate = () => {
    let selectedValues = {
      variant_name: variantName,
      furnace_flag: true,
      user_name: localUserData?.username,
      furnace_id: furnanceId.value,
      variant_id: variantId?.value,
      plant: plantData?.plant_name,
      report_save: {
        update_flag: true,
        clone_flag: false,
        private: variantCheckbox,
        type_id: materialType?.value,
        category_id: materialcategory?.value,
        layout: layout?.value,
        granularity: granularity?.value,
        date_range: [
          moment(dateRange.startdate).format('YYYY-MM-DD'),
          moment(dateRange.endDate).format('YYYY-MM-DD'),
        ],
        compare: switchChecked,
        compare_time_flag: !!(switchChecked && selectedRadioOption === 'TimePeriod'),
        compare_time_period: [
          switchChecked && selectedRadioOption === 'TimePeriod'
            ? moment(compareDates?.startDate).format('YYYY-MM-DD')
            : '',
          switchChecked && selectedRadioOption === 'TimePeriod'
            ? moment(compareDates?.endDate).format('YYYY-MM-DD')
            : '',
        ],
        compare_material_flag: !!(switchChecked && selectedRadioOption === 'Material'),
        report_options: reportOptionsArray,
      },
    };
    setIsLoading(true);
    setOpenConfirmationModal(false);
    dispatch(consumptionvariantsaveAction(selectedValues)).then((response: any) => {
      setIsLoading(false);
      if (response.status === 200) {
        setToastResponse({ text: t(response.data), toastType: 'success' });
        resetDropdownsData();
        setSwitchChecked(false);
      }
      if (response.status == 400) {
        setToastResponse({ text: t(response.data), toastType: 'error' });
      }
    });
  };

  const [chartType, setChartType] = useState({
    value: '',
  });
  const handleReportOptions = (val: any) => {
    setChartType({ value: val });
  };

  const [dateRange, setDateRange] = useState({
    startdate: new Date(),
    endDate: new Date(),
  });

  const [compareDates, setCompareDates] = useState({
    startDate: new Date(),
    endDate: new Date(),
  });

  const handleStateUpdation = (data: any) => {
    setReportOptionsArray(data);
  };

  const handleRadioButton = (dateRadioValue: string) => {
    setSelectedRadioOption(dateRadioValue);
  };

  return (
    <>
      <div className='fluid-container h-full' style={{ overflowY: 'scroll', overflowX: 'hidden' }}>
        <div className=''>
          <div className='row'>
            <div
              className='col-12 dashboard__main__header'
              // style={{ overflowY: 'scroll', overflowX: 'hidden' }}
            >
              <div className='flex items-center justify-between h-full'>
                <div className='flex items-center'>
                  {toastResponse.toastType == 'success' && (
                    <Toaster
                      text={toastResponse.text}
                      toastType='success'
                      updateToastPropsState={setToastResponse}
                    ></Toaster>
                  )}
                  {toastResponse.toastType == 'warning' && (
                    <Toaster
                      text={toastResponse.text}
                      toastType='warning'
                      updateToastPropsState={setToastResponse}
                    ></Toaster>
                  )}
                  {toastResponse.toastType == 'error' && (
                    <Toaster
                      text={toastResponse.text}
                      toastType='error'
                      updateToastPropsState={setToastResponse}
                    ></Toaster>
                  )}

                  <h2 className='text-xl font-semibold ml-4'>
                    {t('plantModulesAndFunctions.MAT_CON')}
                  </h2>
                </div>
                <div
                  style={{
                    width: '13%',
                    height: '75%',
                    display: 'flex',
                    justifyContent: 'space-between',
                  }}
                >
                  <div
                    style={{
                      pointerEvents: showGraphs ? 'auto' : 'none',
                      opacity: showGraphs ? '1' : '0.5',
                    }}
                  >
                    <img
                      src={print}
                      style={headerImages}
                      className='w-100 h-100'
                      onClick={() => {
                        if (variantsaveActivate) {
                          onPrintRecords();
                          setShowSelectionCriteriaCard(true);
                        }
                      }}
                      onMouseOver={() => setImageTooltips(1)}
                      onMouseOut={() => setImageTooltips(0)}
                      alt='print'
                    />
                    {imageTooltips === 1 && (
                      <span
                        className='tooltiptext mt-2'
                        style={{
                          zIndex: 9999,
                          position: 'fixed',
                          width: 'auto',
                          backgroundColor: '#022549',
                          color: 'white',
                          fontSize: '12px',
                          borderRadius: '4px',
                          padding: '10px',
                        }}
                      >
                        {t('reports.print')}
                      </span>
                    )}
                  </div>
                  <div
                    style={{
                      pointerEvents: isLoggedInUserCreatedVariant ? 'auto' : 'none',
                      opacity: isLoggedInUserCreatedVariant ? '1' : '0.5',
                    }}
                  >
                    <img
                      src={save}
                      onClick={() => {
                        if (variantsaveActivate) {
                          setOpenConfirmationModal(true);
                        }
                      }}
                      style={headerImages}
                      onMouseOver={() => setImageTooltips(3)}
                      onMouseOut={() => setImageTooltips(0)}
                    />
                    {imageTooltips === 3 && (
                      <span
                        className='tooltiptext mt-2'
                        style={{
                          zIndex: 9999,
                          position: 'fixed',
                          width: 'auto',
                          backgroundColor: '#022549',
                          color: 'white',
                          fontSize: '12px',
                          borderRadius: '4px',
                          padding: '10px',
                        }}
                      >
                        {t('sharedTexts.save')}
                      </span>
                    )}
                  </div>
                  {openConfirmationModal && (
                    <ReportModal
                      updateVariantflag={variantUpdateFlag}
                      privatevariantValue={variantCheckbox}
                      handleprivatevariant={privateVariantCheckbox}
                      variantSaveReport={(val: any) => {
                        if (val == 'save') {
                          variantSaveApi(val);
                        }
                        if (val == 'update') {
                          variantUpdate();
                        }
                      }}
                      variantValue={variantName}
                      showModal={openConfirmationModal}
                      closeModal={() => setOpenConfirmationModal(false)}
                      onConfirmClick={() => {
                        setOpenConfirmationModal(false);
                      }}
                      variantName={handleVariantName}
                      content={t('reports.saveVariant')}
                      title='Export To Excel'
                      confirmButtonText={t('sharedTexts.save')}
                    />
                  )}
                  <AlertModal
                    showModal={deleteVariantModal}
                    title={t('sharedTexts.alert')}
                    content={`${t('reports.areYouSureYouWantToDeleteVariant')} ${variantName} ?`}
                    confirmButtonText='Proceed'
                    // onConfirmClick={handleDeleteRole}
                    onConfirmClick={handleDeleteVariant}
                    // closeModal={handleCloseDeleteModal}
                    closeModal={() => setDeleteVariantModal(false)}
                  />
                  {cloneVariantModal && (
                    <ReportModal
                      updateVariantflag={'clone'}
                      variantValue={cloneVariantName}
                      handleprivatevariant={handlePrivateFlagForClone}
                      privatevariantValue={clonePrivateFlag}
                      variantName={handleVariantNameForClone}
                      showModal={cloneVariantModal}
                      closeModal={() => setCloneVariantModal(false)}
                      variantSaveReport={variantSaveApi}
                      onConfirmClick={() => {
                        setCloneVariantModal(false);
                      }}
                      content={t('reports.cloneVariant')}
                      title='Export To Excel'
                      confirmButtonText={t('sharedTexts.save')}
                    />
                  )}
                  <div
                    style={{
                      pointerEvents: isLoggedInUserCreatedVariant ? 'auto' : 'none',
                      opacity: isLoggedInUserCreatedVariant ? '1' : '0.5',
                    }}
                  >
                    <img
                      src={clone}
                      style={headerImages}
                      onClick={() => {
                        if (variantCloneFlag) {
                          setCloneVariantModal(true);
                        }
                      }}
                      onMouseOver={() => setImageTooltips(4)}
                      onMouseOut={() => setImageTooltips(0)}
                    />
                    {imageTooltips === 4 && (
                      <span
                        className='tooltiptext mt-2'
                        style={{
                          zIndex: 9999,
                          position: 'fixed',
                          width: 'auto',
                          backgroundColor: '#022549',
                          color: 'white',
                          fontSize: '12px',
                          borderRadius: '4px',
                          padding: '10px',
                        }}
                      >
                        {t('sharedTexts.clone')}
                      </span>
                    )}
                  </div>
                  <div
                    style={{
                      pointerEvents: isLoggedInUserCreatedVariant ? 'auto' : 'none',
                      opacity: isLoggedInUserCreatedVariant ? '1' : '0.5',
                    }}
                  >
                    <img
                      src={deleteIcon}
                      className='w-100 h-100'
                      style={headerImages}
                      onClick={() => {
                        if (variantDeleteActive) {
                          setDeleteVariantModal(true);
                        }
                      }}
                      onMouseOver={() => setImageTooltips(6)}
                      onMouseOut={() => setImageTooltips(0)}
                    />
                    {imageTooltips === 6 && (
                      <span
                        className='tooltiptext mt-2'
                        style={{
                          zIndex: 9999,
                          position: 'fixed',
                          width: 'auto',
                          backgroundColor: '#022549',
                          color: 'white',
                          fontSize: '12px',
                          borderRadius: '4px',
                          padding: '10px',
                        }}
                      >
                        {t('sharedTexts.delete')}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className='row'>
            {isLoading ? (
              <Loader />
            ) : (
              <div ref={printComponentRef} className='col-12 px-8 py-6 scroll-0'>
                <div className='card-box pt-4 px-6 pb-8'>
                  <div className='d-flex justify-content-between'>
                    <p style={reportHeader}>
                      {t('reports.reportFilters')}{' '}
                      <div>
                        <img
                          src={Reset}
                          className='ms-3'
                          onClick={resetDropdownsData}
                          style={{ cursor: 'pointer', display: 'block', color: '#04436b' }}
                          onMouseOver={() => setImageTooltips(5)}
                          onMouseOut={() => setImageTooltips(0)}
                        />
                        {imageTooltips === 5 && (
                          <span
                            className='tooltiptext mt-2'
                            style={{
                              zIndex: 9999,
                              position: 'fixed',
                              width: 'auto',
                              backgroundColor: '#022549',
                              color: 'white',
                              fontSize: '12px',
                              borderRadius: '4px',
                              padding: '10px',
                            }}
                          >
                            {t('reports.resetFilters')}
                          </span>
                        )}
                      </div>
                    </p>
                    {showExpandCollapseIcons ? (
                      <span>
                        {showSelectionCriteriaCard ? (
                          <img
                            src={arrowUp}
                            className='me-2'
                            style={{ cursor: 'pointer' }}
                            onClick={toggleArrowDirection}
                          />
                        ) : (
                          <img
                            src={arrowDown}
                            className='me-2'
                            style={{ cursor: 'pointer' }}
                            onClick={toggleArrowDirection}
                          />
                        )}
                      </span>
                    ) : (
                      <></>
                    )}
                  </div>
                  <hr className='line_break' />
                  {showSelectionCriteriaCard && (
                    <div>
                      <div className='row'>
                        <div className='col-3' style={dropdownSelectCss}>
                          <span style={dropdownHeadingStyle}>{t('reports.variantName')}</span>

                          <CustomSelect
                            index={0}
                            options={variantList}
                            onChange={(val: any) => {
                              setShowGraphs(false);
                              setVariantId({ value: val });
                              variantdetailsFectchByid(val);
                              setVariantCloneFlag(true);
                            }}
                            value={
                              variantList.filter(
                                (item: any): any => item.value == variantId?.value
                              )[0]?.option || t('sharedTexts.select')
                            }
                          />
                        </div>
                      </div>

                      <div className='row mt-3'>
                        <div className='col-3' style={dropdownSelectCss}>
                          <span style={dropdownHeadingStyle}>
                            {t('systemAdmin.furnaceConfiguration.furnaceNo')} *
                          </span>
                          <CustomSelect
                            index={0}
                            options={furnanceOptions}
                            onChange={(val: any) => {
                              setFurnanceId({ value: val });
                            }}
                            value={
                              furnanceOptions.filter(
                                (item: any): any => item.value == furnanceId?.value
                              )[0]?.option || t('sharedTexts.select')
                            }
                            disabled={!isLoggedInUserCreatedVariant}
                          />
                        </div>
                        <div className='col-3' style={dropdownSelectCss}>
                          <span style={dropdownHeadingStyle}>{t('reports.dateRange')} *</span>
                          <DateRangePicker
                            startdate={moment(dateRange.startdate).format('MM/DD/YYYY')}
                            enddate={moment(dateRange.endDate).format('MM/DD/YYYY')}
                            handleDates={(_dateArrayObj: any, dateArrayString: any) => {
                              setDateRange({
                                startdate: dateArrayString?.[0],
                                endDate: dateArrayString?.[1],
                              });
                              setDateClicked(true);
                              checkAllRequiredFields();
                            }}
                            disabled={!isLoggedInUserCreatedVariant}
                          ></DateRangePicker>
                        </div>
                        <div className='col-3' style={dropdownSelectCss}>
                          <span style={dropdownHeadingStyle}>Granularity *</span>
                          <CustomSelect
                            index={0}
                            options={granularityDropDownData()}
                            onChange={(val: any) => {
                              setGranularity({ value: val });
                              checkAllRequiredFields();
                            }}
                            value={
                              Granularities.filter(
                                (item: any): any => item.value == granularity?.value
                              )[0]?.option || t('sharedTexts.select')
                            }
                            disabled={!isLoggedInUserCreatedVariant}
                          />
                        </div>
                        <div className='col-3' style={dropdownSelectCss}>
                          <label style={dropdownHeadingStyle}>
                            {t('reports.layout')} *
                            <img
                              src={info}
                              className='ms-1'
                              onMouseOver={() => setShowTooltip(true)}
                              onMouseOut={() => setShowTooltip(false)}
                            />
                            {showTooltip && (
                              <span
                                className='tooltiptext'
                                style={{
                                  zIndex: 9999,
                                  position: 'fixed',
                                  width: '206px',
                                  backgroundColor: '#022549',
                                  color: 'white',
                                  fontSize: '12px',
                                  borderRadius: '4px',
                                  padding: '10px',
                                }}
                              >
                                {t('reports.dataWillBeDisplayedInTheSelectedNoOfColumns')}
                              </span>
                            )}
                          </label>
                          <CustomSelect
                            index={0}
                            options={Layouts}
                            onChange={(val: any) => {
                              setLayout({ value: val });
                              checkAllRequiredFields();
                            }}
                            value={
                              Layouts.filter((item: any): any => item.value == layout?.value)[0]
                                ?.option || t('sharedTexts.select')
                            }
                            disabled={!isLoggedInUserCreatedVariant}
                          />
                        </div>
                      </div>
                      <div className='row mt-3'>
                        <div className='col-3' style={dropdownSelectCss}>
                          <span style={dropdownHeadingStyle}>{t('reports.compare')}</span>
                          <ToggleButton
                            onChange={compareToggle}
                            isChecked={switchChecked}
                            text={
                              switchChecked ? t('sharedTexts.enabled') : t('sharedTexts.disabled')
                            }
                            disabled={!isLoggedInUserCreatedVariant}
                          ></ToggleButton>
                        </div>
                        {switchChecked === true && (
                          <div className='col-3'>
                            <CompareDateRadio
                              radioOptions={[]}
                              heading={''}
                              selectedValue={selectedRadioOption}
                              onChange={handleRadioButton}
                              disabled={!isLoggedInUserCreatedVariant}
                            ></CompareDateRadio>
                          </div>
                        )}
                        {switchChecked === true && selectedRadioOption == 'TimePeriod' && (
                          <div className='col-3'>
                            <span style={dropdownHeadingStyle}>
                              {t('reports.compareDateRange')} *
                            </span>

                            <DateRangePicker
                              startdate={moment(compareDates.startDate).format('MM/DD/YYYY')}
                              enddate={moment(compareDates.endDate).format('MM/DD/YYYY')}
                              handleDates={(_dateArrayObj: any, dateArrayString: any) => {
                                setCompareDates({
                                  startDate: dateArrayString?.[0],
                                  endDate: dateArrayString?.[1],
                                });
                                setCompareDateClicked(true);
                                checkAllRequiredFields();
                              }}
                              disabled={!isLoggedInUserCreatedVariant}
                            ></DateRangePicker>
                          </div>
                        )}
                      </div>

                      <div className='row mt-3'>
                        <div className='col-3' style={dropdownSelectCss}>
                          <span style={dropdownHeadingStyle}>
                            {t('reports.materialCategory')} *
                          </span>
                          <CustomSelect
                            index={0}
                            options={materialCategories}
                            toShowTooltip={false}
                            onChange={(val: any) => {
                              setMaterialcategory({ value: val });
                              setReportOptionsArray([]);
                              setShowGraphs(false);
                              materialTypeFetch(val);
                              setMaterialType({ value: '' });
                              setMaterialId({ value: '' });
                              checkAllRequiredFields();
                            }}
                            value={
                              materialCategories.filter(
                                (item: any): any => item.value == materialcategory?.value
                              )[0]?.option || t('sharedTexts.select')
                            }
                            disabled={!furnanceId.value || !isLoggedInUserCreatedVariant}
                          />
                        </div>
                        <div className='col-3' style={dropdownSelectCss}>
                          <span style={dropdownHeadingStyle}>
                            {t('masterData.sharedMasterDataTexts.materialType')} *
                          </span>
                          <CustomSelect
                            index={0}
                            options={materialTypes}
                            toShowTooltip={false}
                            onChange={(val: any) => {
                              setMaterialType({ value: val });
                              materialIdFetch(val);
                              setMaterialTypeName({
                                name: materialTypes.filter((item) => item.value === val)[0].option,
                              });
                              console.log(materialTypeName);
                              checkAllRequiredFields();
                            }}
                            value={
                              materialTypes.filter(
                                (item: any): any => item.value == materialType?.value
                              )[0]?.option || t('sharedTexts.select')
                            }
                            disabled={!furnanceId.value || !isLoggedInUserCreatedVariant}
                          />
                        </div>
                        <div className='col-3' style={dropdownSelectCss}>
                          <span style={dropdownHeadingStyle}>{t('reports.materialID')} *</span>
                          <CustomSelect
                            index={0}
                            options={materialIds}
                            toShowTooltip={true}
                            onChange={(val: any) => {
                              const option = materialIds.filter(
                                (item: any): any => item.value == val
                              )[0]?.option;
                              setMaterialId({ value: val });
                              setMesMaterialCode(option.split('-')[0].replace(/\s/g, ''));
                              checkAllRequiredFields();
                            }}
                            search={true}
                            searchText={t('reports.searchProduct')}
                            value={
                              materialIds.filter(
                                (item: any): any => item.value == materialId?.value
                              )[0]?.option || t('sharedTexts.select')
                            }
                            disabled={!furnanceId.value || !isLoggedInUserCreatedVariant}
                          />
                        </div>
                        {!(switchChecked === true && selectedRadioOption == 'Material') && (
                          <div className='col-3' style={dropdownSelectCss}>
                            <VisualizationGraph
                              disabled={!furnanceId.value || !isLoggedInUserCreatedVariant}
                              handleGraph={(val: any) => {
                                handleReportOptions(val);
                              }}
                              handleReportAdd={() => {
                                handleReportPush();
                              }}
                              showStacked={switchChecked}
                            ></VisualizationGraph>
                          </div>
                        )}
                        <div className='row mt-3'>
                          {switchChecked === true && selectedRadioOption == 'Material' && (
                            <div className='col-3' style={dropdownSelectCss}>
                              <span style={dropdownHeadingStyle}>
                                {t('reports.compareMaterialId')} *
                              </span>

                              <CustomSelect
                                index={0}
                                search={true}
                                searchText={t('reports.searchProduct')}
                                options={materialTypesCompare.filter(
                                  (item) =>
                                    ![
                                      mesMaterialCode,
                                      compareMaterialid1?.value,
                                      compareMaterialid2?.value,
                                      compareMaterialid3?.value,
                                      compareMaterialid4?.value,
                                    ].includes(item?.option?.split('-')[0].replace(/\s/g, ''))
                                )}
                                onChange={(val: any) => {
                                  const option = materialIds.filter(
                                    (item: any): any => item?.value == val
                                  )[0]?.option;
                                  setCompareMaterialid1({
                                    value: option?.split('-')[0].replace(/\s/g, ''),
                                  });
                                  checkAllRequiredFields();
                                }}
                                value={
                                  materialTypesCompare.filter(
                                    (item: any): any => item.value == compareMaterialid1?.value
                                  )[0]?.option || t('sharedTexts.select')
                                }
                                disabled={
                                  materialId.value === 'All' || !isLoggedInUserCreatedVariant
                                }
                              />
                            </div>
                          )}
                          {switchChecked === true && selectedRadioOption == 'Material' && (
                            <div className='col-3' style={dropdownSelectCss}>
                              <span style={dropdownHeadingStyle}>
                                {t('reports.compareMaterialId')}
                              </span>

                              <CustomSelect
                                index={0}
                                options={materialTypesCompare.filter(
                                  (item) =>
                                    ![
                                      mesMaterialCode,
                                      compareMaterialid1?.value,
                                      compareMaterialid2?.value,
                                      compareMaterialid3?.value,
                                      compareMaterialid4?.value,
                                    ].includes(item?.option?.split('-')[0].replace(/\s/g, ''))
                                )}
                                search={true}
                                searchText={t('reports.searchProduct')}
                                onChange={(val: any) => {
                                  //setCompareMaterialid2({value:val});
                                  const option = materialIds.filter(
                                    (item: any): any => item.value == val
                                  )[0]?.option;
                                  setCompareMaterialid2({
                                    value: option?.split('-')[0].replace(/\s/g, ''),
                                  });
                                }}
                                value={
                                  materialTypesCompare.filter(
                                    (item: any): any => item.value == compareMaterialid2?.value
                                  )[0]?.option || t('sharedTexts.select')
                                }
                                disabled={
                                  materialId.value === 'All' || !isLoggedInUserCreatedVariant
                                }
                              ></CustomSelect>
                            </div>
                          )}
                          {switchChecked === true && selectedRadioOption == 'Material' && (
                            <div className='col-3' style={dropdownSelectCss}>
                              <span style={dropdownHeadingStyle}>
                                {t('reports.compareMaterialId')}
                              </span>

                              <CustomSelect
                                index={0}
                                options={materialTypesCompare.filter(
                                  (item) =>
                                    ![
                                      mesMaterialCode,
                                      compareMaterialid1?.value,
                                      compareMaterialid2?.value,
                                      compareMaterialid3?.value,
                                      compareMaterialid4?.value,
                                    ].includes(item?.option?.split('-')[0].replace(/\s/g, ''))
                                )}
                                search={true}
                                searchText={t('reports.searchProduct')}
                                onChange={(val: any) => {
                                  //setCompareMaterialid3({value:val});
                                  const option = materialIds.filter(
                                    (item: any): any => item?.value == val
                                  )[0]?.option;
                                  setCompareMaterialid3({
                                    value: option?.split('-')[0].replace(/\s/g, ''),
                                  });
                                }}
                                value={
                                  materialTypesCompare.filter(
                                    (item: any): any => item.value == compareMaterialid3?.value
                                  )[0]?.option || t('sharedTexts.select')
                                }
                                disabled={
                                  materialId.value === 'All' || !isLoggedInUserCreatedVariant
                                }
                              />
                            </div>
                          )}
                          {switchChecked === true && selectedRadioOption == 'Material' && (
                            <div className='col-3' style={dropdownSelectCss}>
                              <span style={dropdownHeadingStyle}>
                                {t('reports.compareMaterialId')}
                              </span>

                              <CustomSelect
                                index={0}
                                options={materialTypesCompare.filter(
                                  (item) =>
                                    ![
                                      mesMaterialCode,
                                      compareMaterialid1?.value,
                                      compareMaterialid2?.value,
                                      compareMaterialid3?.value,
                                      compareMaterialid4?.value,
                                    ].includes(item?.option?.split('-')[0].replace(/\s/g, ''))
                                )}
                                search={true}
                                searchText={t('reports.searchProduct')}
                                onChange={(val: any) => {
                                  //setCompareMaterialid4({value:val});
                                  const option = materialIds.filter(
                                    (item: any): any => item?.value == val
                                  )[0]?.option;
                                  setCompareMaterialid4({
                                    value: option?.split('-')[0].replace(/\s/g, ''),
                                  });
                                }}
                                value={
                                  materialTypesCompare.filter(
                                    (item: any): any => item?.value == compareMaterialid4?.value
                                  )[0]?.option || t('sharedTexts.select')
                                }
                                disabled={
                                  materialId.value === 'All' || !isLoggedInUserCreatedVariant
                                }
                              />
                            </div>
                          )}
                        </div>
                        {switchChecked === true && selectedRadioOption == 'Material' && (
                          <div className='col-3 mt-2'>
                            <VisualizationGraph
                              showStacked={switchChecked}
                              handleGraph={(val: any) => {
                                handleReportOptions(val);
                              }}
                              handleReportAdd={() => {
                                handleReportPush();
                              }}
                              disabled={!furnanceId.value || !isLoggedInUserCreatedVariant}
                            ></VisualizationGraph>
                          </div>
                        )}{' '}
                      </div>
                      {reportOptionsArray.length > 0 && (
                        <div className='card mt-3 me-4'>
                          <ReportSequence
                            items={reportOptionsArray}
                            stateUpdation={handleStateUpdation}
                            element={'material_type_and_id'}
                            selectedName='consumption'
                            disabled={!isLoggedInUserCreatedVariant}
                          ></ReportSequence>
                        </div>
                      )}

                      <span className='d-flex justify-content-end me-4'>
                        <button
                          className='btn btn--h36 px-4 py-2 mt-3'
                          style={{
                            backgroundColor: reportOptionsArray?.length > 0 ? '#0D659E' : '#DEE3E4',
                            color: 'white',
                            fontWeight: '500',
                          }}
                          onClick={
                            reportOptionsArray.length > 0 ? generateReport : handleEmptyClick
                          }
                        >
                          {t('reports.generateReport')}
                        </button>
                      </span>
                    </div>
                  )}
                </div>
                <div className='d-flex consumption-graph'>
                  {showGraphs && (
                    <div className='col-12 card-box mt-5 pt-4 px-6 pb-8'>
                      <Graph
                        graphPayload={matGraphs}
                        layout={layout.value}
                        date_range={[
                          moment(dateRange.startdate).format('YYYY-MM-DD'),
                          moment(dateRange.endDate).format('YYYY-MM-DD'),
                        ]}
                        compare_time_period={[
                          switchChecked && selectedRadioOption === 'TimePeriod'
                            ? moment(compareDates?.startDate).format('YYYY-MM-DD')
                            : '',
                          switchChecked && selectedRadioOption === 'TimePeriod'
                            ? moment(compareDates?.endDate).format('YYYY-MM-DD')
                            : '',
                        ]}
                      />
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

const mapStateToProps = (state: any) => ({
  materialTypes: state.consumption?.materialTypes,
  materialCategories: state.consumption?.materialCategories,
  materialIds: state.consumption?.materialIds,
  furnanceOptions: state.consumption?.furnanceList,
  variantList: state.consumption?.variantList,
  materialTypesCompare: state.consumption?.materialTypesCompare,
  matGraphs: state.consumption?.matGraphs,
  materialIdsForSelection: state.reportReducer?.materialIdsForSelection,
});

export default connect(mapStateToProps)(MaterialConsumptionReport);

const headerImages: any = {
  marginleft: '2%',
  cursor: 'pointer',
  display: 'block',
};
const dropdownHeadingStyle: any = {
  fontWeight: 500,
  fontSize: '14px',
  color: 'var(--primary75)',
};
const reportHeader = {
  color: 'var(--primary75)',
  fontWeight: 500,
  fontSize: '16px',
  display: 'flex',
};
const dropdownSelectCss = {
  //width:'245px',
  cursor: 'pointer',
};
