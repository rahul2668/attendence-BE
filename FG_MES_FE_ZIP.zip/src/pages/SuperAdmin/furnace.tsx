import 'assets/styles/scss/pages/furnace.scss';
import BasicInformation from './FurnaceConfiguration/furnaceView';
import RefiningSteps from './FurnaceConfiguration/refiningStepsView';
import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import httpClient from 'http/httpClient';
import Header from 'components/common/EmptyHeader';
import { paths } from 'routes/paths';
import { useTranslation } from 'react-i18next';

const AddFurnace = () => {
  const { t } = useTranslation();
  const [tab, setTab] = useState(1);
  const [furnaceData, setFurnaceData] = useState<any>(null);
  //   const [addId,setAddId] = useState('')
  const { id } = useParams();
  const navigate = useNavigate();
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await httpClient.get(`/api/furnace-config/basic-info/${id}/`);
        const data = response.data;
        setFurnaceData({ furnace: [data] });
      } catch (error) {
        console.error('Error fetching data:', error);
        // Handle the error, e.g., set an error state or show a message to the user
      }
    };

    fetchData();
  }, [id]);

  const handleBackClick = () => {
    navigate(paths.furnaceConfig.list);
  };

  let titleId: string = '';
  furnaceData?.furnace.map((furnace: any) => (titleId = furnace.furnace_no));
  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Header
        title={`${t('systemAdmin.furnaceConfiguration.furnace')} ${titleId}`}
        onBackClick={handleBackClick}
      />

      {tab == 1 ? <BasicInformation setTab={setTab} viewId={id} /> : <RefiningSteps />}
    </div>
  );
};

export default AddFurnace;
