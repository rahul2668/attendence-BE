import Accordion from 'components/common/Accordion';
import React, { useEffect, useRef, useState } from 'react';
import editIcon from 'assets/icons/edit-thick.svg';
import { useNavigate } from 'react-router-dom';
import Loading from 'components/common/Loading';
import httpClient from 'http/httpClient';
import Header from 'components/common/EmptyHeader';
import { useTranslation } from 'react-i18next';
import { useAppDispatch, useAppSelector } from 'store';
import dayjs from 'dayjs';
import MUIToolTip from 'components/common/ToolTip/MUIToolTip';
import DownloadExcel from 'components/common/ExcelDownload';
import { getPlantExcel, setPlantExcelList } from 'store/slices/plantGetData';
import { getUnitByFieldName } from 'utils/utils';
import { globalString } from 'utils/constants';

interface InfoBlockProps {
  label: any;
  value: string | number;
  flexBasis: string;
  marginBottom: any;
}

interface TimeRangeProps {
  label: any;
  value: string;
}

const InfoBlock: React.FC<InfoBlockProps> = ({ label, value, flexBasis, marginBottom }) => (
  <div style={{ flexBasis, marginBottom: `${marginBottom}px` }}>
    <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
      <label className='input-field-label font-semibold'>{label}</label>
      <span style={{ height: '40px', fontSize: '14px', fontWeight: 600 }}>{value}</span>
    </div>
  </div>
);

const TimeRange: React.FC<TimeRangeProps> = ({ label, value }) => (
  <div style={{ display: 'flex', gap: '4px' }}>
    <label style={{ fontWeight: 600, fontSize: '14px', gap: '10px', color: '#5F6466' }}>
      {label}
    </label>
    <span style={{ fontSize: '14px', gap: '10px', fontWeight: 600 }}>{value}</span>
  </div>
);

const PlantView = () => {
  const [functionList, setFunctionList] = useState<any>([]);
  const [modelList, setModelList] = useState<any>([]);
  const [masterData, setMasterData] = useState<any>([]);
  const [loading, setLoading] = useState(true);
  const csvLinkRef: any = useRef();
  const dispatch = useAppDispatch();

  const plantDataString = useAppSelector((state) => state.plantData.plantData);
  const plant: any = plantDataString ?? null;

  const userDataString = useAppSelector((state) => state.userData.userData);
  const user: any = userDataString ? userDataString : null;

  const plant_id: any = plant.plant_id;
  const { plantExcelList } = useAppSelector((state) => state.plant_config);

  const { t } = useTranslation();

  const navigate = useNavigate();

  // State to store the fetched data
  const [plantData, setPlantData] = useState<any>({});
  // const functionData: any = [
  //   'User Control Access',
  //   'Master Data',
  //   'Core Process',
  //   'Lab Analysis',
  //   'Reports',
  // ];

  // const dataMapping: any = {
  //   'User Control Access': ['Users', 'Roles'],
  //   'Master Data': [
  //     uniqueCodesMapper.additivesFunction,
  //     'Standard BOM',
  //     'Customer Specifications',
  //     'Active Furnace List',
  //     'Material Maintenance',
  //     uniqueCodesMapper.furnaceRawMaterialFunction,
  //   ],
  //   'Core Process': [
  //     'Heat Maintenance',
  //     'Bin Contents',
  //     'Production Schedule',
  //     'Silicon Grade Material Maintenance',
  //     'Silicon Grade Heat Maintenance',
  //   ],
  //   'Lab Analysis': [
  //     ' Additive Analysis',
  //     'Ladle(Heat) Analysis',
  //     'Furnace Mix Analysis',
  //     'Spout Analysis',
  //   ],
  //   Reports: ['Primary Heat Report', 'Production Schedule Analysis Report'],
  // };

  // const validFunctionData = functionData || [];

  // const maxItems = Math.max(
  //   ...validFunctionData.map((val: any) => (dataMapping[val] || []).length)
  // );

  const allUnits = useAppSelector((state) => state.unit.units);
  const unit = getUnitByFieldName(allUnits, globalString.currency);

  const excelHeader = [
    {
      label: t('sharedTexts.effectiveDate'),
      key: 'effective_date',
    },
    {
      label: t('systemAdmin.plantConfiguration.plantName'),
      key: 'plant_config_value',
    },
    {
      label: t('systemAdmin.plantConfiguration.energyPrice'),
      key: 'energy_price',
    },
    {
      label: t('systemAdmin.plantConfiguration.createdBy'),
      key: 'created_username',
    },
    {
      label: t('systemAdmin.plantConfiguration.modifiedBy'),
      key: 'updated_username',
    },
    {
      label: t('systemAdmin.plantConfiguration.createdAt'),
      key: 'created_date',
    },
    {
      label: t('systemAdmin.plantConfiguration.modifiedAt'),
      key: 'modified_date',
    },
  ];

  const handleExcelClick = async () => {
    if (plant_id) {
      const response = await dispatch(getPlantExcel());
      const data = response.payload.data;

      if (response.payload.status >= 200 && response.payload.status < 300) {
        dispatch(setPlantExcelList(data.data));
      }
    }
  };

  useEffect(() => {
    if (plantExcelList && plantExcelList.length > 0) {
      csvLinkRef?.current?.link?.click();
      dispatch(setPlantExcelList([]));
    }
  }, [plantExcelList]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const masterResponse = await httpClient.get('/api/master/master/');

        setMasterData(masterResponse.data);

        const response = await httpClient.get(`/api/plant/plant-config/${plant_id}/`);

        setPlantData(response.data);

        const functionResponse: any = await httpClient.get('/api/plant/function/');

        const functionResponseData: any = functionResponse.data;

        const filteredModelList = functionResponseData.map((val: any) => {
          const models = { option: val.module_code, value: val.id };

          return models;
        });
        const removedElement: any = filteredModelList.splice(3, 1)[0];

        filteredModelList.push(removedElement);
        setModelList(filteredModelList);

        const functions = functionResponseData.flatMap((item: any) => item.module_functions);

        setFunctionList(functions);
        setLoading(false);
      } catch (error) {
        console.error('Error:', error);
      }
    };

    fetchData();
  }, []);

  const shift1_from = plantData?.shift1_from;
  const shift1_to = plantData?.shift1_to;
  const shift2_from = plantData?.shift2_from;
  const shift2_to = plantData?.shift2_to;
  const shift3_from = plantData?.shift3_from;
  const shift3_to = plantData?.shift3_to;

  const shiftTimes = [
    { label: 'Shift 1', from: shift1_from, to: shift1_to },
    { label: 'Shift 2', from: shift2_from, to: shift2_to },
    { label: 'Shift 3', from: shift3_from, to: shift3_to },
  ];
  const uniqueModules = Array.from(
    new Set(plantData?.function_json?.map((item: any) => item.module))
  );

  const uniqueModulesWithFunctions = uniqueModules?.map((moduleId) => {
    return {
      moduleId: moduleId,
      functions: plantData?.function_json.filter((item: any) => item.module === moduleId),
    };
  });

  if (loading) return <Loading />;

  const handleTranslate = (label: string, isPlantModuleOrFunction: boolean = false) => {
    const translationKey: any = isPlantModuleOrFunction
      ? `plantModulesAndFunctions.${label}`
      : `systemAdmin.plantConfiguration.${label}`;
    const translatedString = t(translationKey);

    // If the translation exists, `translatedString` will be the translated value,
    // otherwise, it will be the same as `translationKey`
    const displayString = translatedString !== translationKey ? translatedString : label;

    return displayString;
  };

  return (
    <>
      <Header title={t('plantModulesAndFunctions.PLT_CFG')} />
      <div className='container mt-3 mb-3' style={{ height: '100%', overflow: 'auto' }}>
        <div className='card'>
          <div
            className='card-body'
            style={{ padding: user.is_superuser ? '0px 20px 0px 20px' : '5px 20px 0px 20px' }}
          >
            {user.is_superuser && (
              <div className='btn-edit-absolute d-flex justify-content-end'>
                <button
                  className={`btn btn--h30 py-1 px-3 font-bold mt-4 `}
                  onClick={() => navigate('/system-admin/plant-configuration/edit')}
                >
                  <img src={editIcon} alt='edit' className='mr-2' /> {`${t('sharedTexts.edit')}`}
                </button>
              </div>
            )}

            <div
              style={{
                display: 'flex',
                flexWrap: 'wrap',
                justifyContent: 'space-between',
                marginTop: '12px',
              }}
            >
              <InfoBlock
                label={`${t('systemAdmin.plantConfiguration.plantId')}`}
                value={plantData?.plant_id}
                flexBasis='20%'
                marginBottom='5'
              />
              <InfoBlock
                label={`${t('systemAdmin.plantConfiguration.areaCode')}`}
                value={plantData?.area_code}
                flexBasis='15%'
                marginBottom='5'
              />
              <InfoBlock
                label={`${t('systemAdmin.plantConfiguration.plantName')}`}
                value={plantData?.plant_name}
                flexBasis='15%'
                marginBottom='5'
              />
              <InfoBlock
                label={`${t('systemAdmin.plantConfiguration.plantAddress')}`}
                value={plantData?.plant_address}
                flexBasis='30%'
                marginBottom='5'
              />
            </div>

            <div
              style={{
                display: 'flex',
                flexWrap: 'wrap',
                justifyContent: 'space-between',
                marginBottom: '1px',
              }}
            >
              <InfoBlock
                label={`${t('systemAdmin.plantConfiguration.timeZone')}`}
                value={
                  masterData?.filter((val: any) => val.master_code == plantData?.timezone)[0]?.value
                }
                flexBasis='20%'
                marginBottom='5'
              />
              <InfoBlock
                label={`${t('systemAdmin.plantConfiguration.language')}`}
                value={handleTranslate(
                  masterData.filter((val: any) => val.master_code == plantData?.language)[0]?.value
                )}
                flexBasis='15%'
                marginBottom='5'
              />
              <InfoBlock
                label={`${t('systemAdmin.plantConfiguration.unitSystem')}`}
                value={handleTranslate(
                  masterData?.filter((val: any) => val.master_code == plantData?.unit)[0]?.value
                )}
                flexBasis='15%'
                marginBottom='5'
              />
              <InfoBlock
                label={`${t('systemAdmin.plantConfiguration.currency')}`}
                value={
                  masterData?.filter((val: any) => val.master_code == plantData?.currency)[0]?.value
                }
                flexBasis='30%'
                marginBottom='5'
              />
            </div>

            <hr style={{ borderTop: '2px solid #CDD0D1', width: '100%' }} />

            <div>
              <div style={{ display: 'flex', alignItems: 'center' }}>
                <p className='title mr-1'>{t('systemAdmin.plantConfiguration.energyPrice')} |</p>
                <p className='title'>
                  {t('sharedTexts.effectiveDate')}:{' '}
                  {dayjs(plantData.parameters.effective_date).format('DD.MM.YY')}
                </p>
                <div className='mb-1 ml-1'>
                  <MUIToolTip text={t(`sharedTexts.downloadExcel`)}>
                    <DownloadExcel
                      csvData={plantExcelList}
                      headersForCSV={excelHeader}
                      excelTitle='Plant details'
                      handleClick={handleExcelClick}
                      csvLinkRef={csvLinkRef}
                    />
                  </MUIToolTip>
                </div>
              </div>

              {/* Dummy data for Workshop No and Workshop Name */}
              <div className='row'>
                <div className=' mt-1'>
                  <div className='workshop-wrapper mr-10' style={{ width: '30%' }}>
                    <table className='table table-borderless '>
                      <thead>
                        <tr>
                          <th style={{ fontSize: '14px', color: '#5F6466', paddingLeft: '0px' }}>
                            {t('systemAdmin.plantConfiguration.energyPrice')}
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td style={{ fontSize: '14px', fontWeight: 600, paddingLeft: '0px' }}>
                            {plantData.parameters.energy_price}
                            {unit}
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>

            <hr style={{ borderTop: '2px solid #CDD0D1', width: '100%' }} />

            <div>
              <p className='title mb-1'>{t('systemAdmin.plantConfiguration.workshops')}</p>

              {/* Dummy data for Workshop No and Workshop Name */}
              <div className='row'>
                <div className=' mt-1'>
                  <div className='workshop-wrapper mr-10' style={{ width: '30%' }}>
                    <table className='table table-borderless '>
                      <thead>
                        <tr>
                          <th style={{ fontSize: '14px', color: '#5F6466', paddingLeft: '0px' }}>
                            {t('systemAdmin.plantConfiguration.workshopName')}
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {plantData?.workshops_json?.map((workshop: any) =>
                          workshop.record_status ? (
                            <tr key={workshop?.workshop_id}>
                              {/* <td style={{ fontSize: '14px', fontWeight: 600, paddingLeft: '0px' }}>
                                {workshop?.workshop_id}
                              </td> */}
                              <td style={{ fontSize: '14px', fontWeight: 600, paddingLeft: '0px' }}>
                                {workshop?.workshop_name}
                              </td>
                            </tr>
                          ) : (
                            ''
                          )
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>

            <hr style={{ borderTop: '2px solid #CDD0D1', width: '100%' }} />

            <div>
              <p className='title mb-3'>{t('systemAdmin.plantConfiguration.products')}</p>

              {/* Display enabled product names */}
              <div
                style={{
                  display: 'flex',
                  flexDirection: 'row',
                  gap: '27px',
                  alignItems: 'flex-start',
                }}
              >
                {plantData?.products_json?.map((product: any) => (
                  <div key={product?.product_id}>
                    <label
                      style={{
                        fontWeight: 600,
                        fontSize: '14px',
                        color: '#041724',
                      }}
                    >
                      {
                        masterData.filter((val: any) => val.master_code == product?.product)[0]
                          ?.value
                      }
                    </label>
                  </div>
                ))}
              </div>
            </div>

            <hr style={{ border: '1px solid #CDD0D1', width: '100%' }} />
            <div style={{ width: '100%' }}>
              <p className='title mb-3'>{t('sharedTexts.functions')}</p>
              {uniqueModulesWithFunctions?.map((value: any) => (
                <div key={value.moduleId} style={{ marginBottom: '20px' }}>
                  <Accordion
                    title={handleTranslate(
                      modelList?.filter((val: any) => val.option == value.moduleId)[0]?.option,
                      true
                    )}
                  >
                    <div
                      style={{
                        display: 'flex',
                        flexDirection: 'row',
                        flexWrap: 'wrap',
                        gap: '15px',
                        // justifyContent: 'space-between',
                      }}
                    >
                      {value.functions?.map((item: any) => (
                        <div
                          key={item?.function_code}
                          style={{
                            // flexBasis: `calc(${100 / maxItems}% - 10px)`,
                            // padding: '5px 0px 5px 20px',
                            minWidth: '240px',
                            fontSize: '14px',
                            fontWeight: 600,
                          }}
                        >
                          {handleTranslate(
                            functionList.filter(
                              (val: any) => val.function_code == item?.function
                            )[0]?.function_code,
                            true
                          )}
                        </div>
                      ))}
                    </div>
                  </Accordion>
                </div>
              ))}
            </div>

            <hr style={{ border: '1px solid #CDD0D1', width: '100%' }} />

            <div style={{ width: '100%' }}>
              <p className='title mb-2'>
                {t('systemAdmin.plantConfiguration.shiftSchedule')} (
                {masterData?.filter((val: any) => val.id == plantData?.timezone_id)[0]?.value})
              </p>

              <div
                className='shift_time mb-4'
                style={{ display: 'flex', flexDirection: 'column', gap: '25px', fontWeight: 500 }}
              >
                {shiftTimes?.map((shiftTime: any, index: any) => (
                  <div
                    key={shiftTime.from}
                    style={{
                      display: 'flex',
                      flexDirection: 'row',
                      marginLeft: '35px',
                      gap: '15px',
                      marginTop: '5px',
                    }}
                  >
                    <span
                      style={{
                        fontSize: '14px',
                        fontWeight: 600,
                        marginRight: '20px',
                        color: '#212529',
                      }}
                    >{`${t('systemAdmin.plantConfiguration.shift')} ${index + 1}`}</span>
                    <TimeRange label={`${t('sharedTexts.from')}`} value={shiftTime.from} />
                    <span
                      style={{
                        color: '#818182',
                        fontWeight: 400,
                        fontSize: '14px',
                        marginRight: '15px',
                      }}
                    >
                      HH:MM
                    </span>
                    <TimeRange label={`${t('sharedTexts.to')}`} value={shiftTime.to} />
                    <span style={{ color: '#818182', fontWeight: 400, fontSize: '14px' }}>
                      HH:MM
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* </div> */}
    </>
  );
};

export default PlantView;
