/* eslint-disable no-inner-declarations */
import { useEffect, useState } from 'react';
import '../../../../assets/styles/scss/pages/plant.scss';
import PlantFooter from 'components/common/PlantFooter';
import { useFormik } from 'formik';
import * as yup from 'yup';
import CustomSelect from 'components/common/SelectField';
import { useNavigate } from 'react-router-dom';
import AlertModal from 'components/Modal/AlertModal';
import { clearSessionStorage, getUnitByFieldName, notify } from 'utils/utils';
import { paths } from 'routes/paths';
import Loading from 'components/common/Loading';
import httpClient from 'http/httpClient';
import {
  globalString,
  plantConfigFunctions,
  plantConfigModules,
  uniqueCodesMapper,
} from 'utils/constants';
import Header from 'components/common/EmptyHeader';
import { useTranslation } from 'react-i18next';
import { useAppSelector } from 'store';
import { Grid, InputLabel } from '@mui/material';
import { DesktopDatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import dayjs from 'dayjs';

// const validateShiftDuration = (from: any, to: any) => {
//   const fromTime = dayjs(`2000-01-01T${from}`);
//   const toTime = dayjs(`2000-01-01T${to}`);
//   const differenceInHours = Math.abs(toTime.diff(fromTime, 'hour'));
//   return differenceInHours <= 24;
// };

const AddPlant = () => {
  const currentURL = window.location.href;

  const { t } = useTranslation();

  const formValidationSchema = yup.object({
    plant_address: yup
      .string()
      .required(`${t('systemAdmin.plantConfiguration.plantAddressIsRequired')}`),
    timezone: yup.string().required(`${t('systemAdmin.plantConfiguration.selectTheTimeZone')}`),
    language: yup.string().required(`${t('systemAdmin.plantConfiguration.selectTheLanguage')}`),
    unit: yup.string().required(`${t('systemAdmin.plantConfiguration.selectTheUnitSystem')}`),
    currency: yup.string().required(`${t('systemAdmin.plantConfiguration.selectTheCurrency')}`),
    productName: yup
      .array()
      .min(1, `${t('systemAdmin.plantConfiguration.productNameIsRequired')}`)
      .required(`${t('systemAdmin.plantConfiguration.productNameIsRequired')}`),
    workshops: yup
      .array()
      .min(1, `${t('systemAdmin.plantConfiguration.workShopIsRequired')}`)
      .required(`${t('systemAdmin.plantConfiguration.workShopIsRequired')}`),
    shift1: yup.object({
      from: yup
        .string()
        .required(`${t('systemAdmin.plantConfiguration.shiftStartTimeIsRequired')}`)
        .matches(/^([01]\d|2[0-3]):([0-5]\d)$/, 'Invalid time'), // railway time regex
      to: yup
        .string()
        .required(`${t('systemAdmin.plantConfiguration.shiftEndTimeIsRequired')}`)
        .matches(/^([01]\d|2[0-3]):([0-5]\d)$/, 'Invalid time'), // railway time regex
      // .test('shift-duration', 'Shift duration cannot exceed 24 hours', function (value) {
      //   return validateShiftDuration(this.parent.from, value);
      // }),
    }),
    shift2: yup.object({
      from: yup
        .string()
        .required(`${t('systemAdmin.plantConfiguration.shiftStartTimeIsRequired')}`)
        .matches(/^([01]\d|2[0-3]):([0-5]\d)$/, 'Invalid time'), // railway time regex
      to: yup
        .string()
        .required(`${t('systemAdmin.plantConfiguration.shiftEndTimeIsRequired')}`)
        .matches(/^([01]\d|2[0-3]):([0-5]\d)$/, 'Invalid time'), // railway time regex
      // .test('shift-duration', 'Shift duration cannot exceed 24 hours', function (value) {
      //   return validateShiftDuration(this.parent.from, value);
      // }),
    }),
    shift3: yup.object({
      from: yup
        .string()
        .required(`${t('systemAdmin.plantConfiguration.shiftStartTimeIsRequired')}`)
        .matches(/^([01]\d|2[0-3]):([0-5]\d)$/, 'Invalid time'), // railway time regex
      to: yup
        .string()
        .required(`${t('systemAdmin.plantConfiguration.shiftEndTimeIsRequired')}`)
        .matches(/^([01]\d|2[0-3]):([0-5]\d)$/, 'Invalid time'), // railway time regex
      // .test('shift-duration', 'Shift duration cannot exceed 24 hours', function (value) {
      //   return validateShiftDuration(this.parent.from, value);
      // }),
    }),
    function: yup
      .array()
      .min(1, `${t('systemAdmin.plantConfiguration.functionsIsRequired')}`)
      .required(`${t('systemAdmin.plantConfiguration.functionsIsRequired')}`),
  });

  // Parse the URL using URL object
  const url = new URL(currentURL);

  // Extract the path name (route) from the URL
  const pathName = url.pathname;

  const navigate = useNavigate();

  const [workshop, setWorkshop] = useState<any>({ workshop_name: '' });
  const [workshopList, setWorkshopList] = useState<any>([]);
  const [selectFunction, setSelectFunction] = useState<any>(2);
  const [timeZoneList, setTimeZoneList] = useState<any>([]);
  const [languageList, setLanguageList] = useState<any>([]);
  const [unitSystemList, setUnitSystemList] = useState<any>([]);
  const [currencyList, setCurrencyList] = useState<any>([]);
  const [productList, setProductList] = useState<any>([]);
  const [functionList, setFunctionList] = useState<any>({
    userAccessControl: [],
    masterData: [],
    coreProcess: [],
    labAbalysis: [],
    reports: [],
    systemAdmin: [],
    logBook: [],
  });
  const [openAlertModal, setOpenAlertModal] = useState<boolean>(false);
  const [alertMsg, setAlertMsg] = useState<string>('');
  const [modelList, setModelList] = useState<any>([]);
  const [editData, setEditData] = useState<any>(null);
  const [showTooltip, setShowTooltip] = useState<any>('');
  const [modulesAndFunctionList, setModulesAndFunctionList] = useState<any>([]);
  const [functionCategory, setFunctionCategory] = useState<any>(3);
  const [isEdit, setIsEdit] = useState(
    pathName == '/system-admin/plant-configuration/edit' || false
  );

  const [loading, setLoading] = useState(true);
  const [duplicate, setDuplicate] = useState(false);
  const [deleteModal, setDeleteModal] = useState<boolean>(false);
  const [removeWorkShopId, setRemoveWorkShopId] = useState('');
  const [showPlantUpdatePrompt, setShowPlantUpdatePrompt] = useState<boolean>(false);

  const plantDataString = useAppSelector((state) => state.plantData.plantData);
  const plantData: any = plantDataString ?? null;
  const local_plant_id: any = plantData.plant_id;

  const allUnits = useAppSelector((state) => state.unit.units);
  const unit = getUnitByFieldName(allUnits, globalString.currency);

  const defaultFunctionsStateValue = isEdit
    ? []
    : [
        {
          module_id: plantConfigModules.systemAdmin,
          function_id: plantConfigFunctions.plantConfigFunction,
        },
        {
          module_id: plantConfigModules.systemAdmin,
          function_id: plantConfigFunctions.furnaceConfigFunction,
        },
        {
          module_id: plantConfigModules.userAccessControl,
          function_id: plantConfigFunctions.users,
        },
        {
          module_id: plantConfigModules.userAccessControl,
          function_id: plantConfigFunctions.roles,
        },
      ];

  useEffect(() => {
    setIsEdit(pathName == '/system-admin/plant-configuration/edit' || false);
  }, []);
  const initialValuesObj = {
    plant_id: plantData?.plant_id,
    plant_name: plantData?.plant_name,
    area_code: plantData?.area_code,
    plant_address: '',
    parameters: {
      energy_price: '',
      effective_date: dayjs().format('YYYY-MM-DD'),
    },
    timezone: '',
    language: '',
    unit: '',
    currency: '',
    workshops: [],
    productName: [],
    function: defaultFunctionsStateValue, // since plant configuration is default..
    shift1: {
      from: '',
      to: '',
    },
    shift2: {
      from: '',
      to: '',
    },
    shift3: {
      from: '',
      to: '',
    },
  };
  const { handleSubmit, values, handleBlur, handleChange, setFieldValue, touched, errors }: any =
    useFormik({
      initialValues: editData || initialValuesObj,
      validationSchema: formValidationSchema,
      enableReinitialize: true,
      onSubmit: async (values: any) => {
        const data = {
          ...values,
          ...{
            shift1_from:
              values.shift1.from.length < 3
                ? `${String(values.shift1.from).padStart(2, '0')}:00`
                : values.shift1.from,
            shift1_to:
              values.shift1.to.length < 3
                ? `${String(values.shift1.to).padStart(2, '0')}:00`
                : values.shift1.to,

            shift2_from:
              values.shift2.from.length < 3
                ? `${String(values.shift2.from).padStart(2, '0')}:00`
                : values.shift2.from,
            shift2_to:
              values.shift2.to.length < 3
                ? `${String(values.shift2.to).padStart(2, '0')}:00`
                : values.shift2.to,

            shift3_from:
              values.shift3.from.length < 3
                ? `${String(values.shift3.from).padStart(2, '0')}:00`
                : values.shift3.from,
            shift3_to:
              values.shift3.to.length < 3
                ? `${String(values.shift3.to).padStart(2, '0')}:00`
                : values.shift3.to,
          },
        };
        if (isEdit) {
          const result = data.function.every((obj: any) => Object.hasOwn(obj, 'id'));
          const response: any = await httpClient.put(`/api/plant/plant-config/${local_plant_id}/`, {
            data: data,
          });

          if (response?.data?.user_approval_needed) {
            setShowPlantUpdatePrompt(true);
          } else {
            setLoading(true);
            if (response) {
              notify('success', t(response.data.message));
              setLoading(false);
              if (result && data.function.length == editData.function.length) {
                navigate('/system-admin/plant-configuration/view');
              } else {
                setOpenAlertModal(true);
                setAlertMsg(t(response.data.message));
              }
            }
          }
        } else {
          const response: any = await httpClient.post('/api/plant/plant-config-post/', {
            data: data,
          });

          if (response.status == 200) {
            setLoading(false);
            notify('success', t(response.data.message));
            setOpenAlertModal(true);
            setAlertMsg(t(response.data.message));
          } else if (response.status == 400) {
            setLoading(false);
            notify('error', response.data.plant_id[0]);
            navigate('/system-admin/plant-configuration/view');
          }
        }
        setWorkshopList([]);
      },
    });
  useEffect(() => {
    const fetchData = async () => {
      try {
        const plantConfigResponse = await httpClient.get(
          `/api/plant/plant-config/${local_plant_id}/`
        );

        const editData: any = plantConfigResponse?.data;

        if (editData?.plant_id && !isEdit) {
          navigate(paths.plantScreen.view);
        }
        if (editData) {
          const editObj = {
            plant_id: editData.plant_id,
            plant_name: editData.plant_name,
            area_code: editData.area_code,
            plant_address: editData.plant_address,
            parameters: editData.parameters,
            timezone: editData.timezone,
            language: editData.language,
            unit: editData.unit,
            currency: editData.currency,
            workshops: editData?.workshops_json?.map((val: any) => {
              const workshopData = {
                id: val.id,
                workshop_name: val.workshop_name,
                record_status: val.record_status,
                is_deactivate: val.is_deactivate,
              };
              return workshopData;
            }),
            productName: editData.products_json.map((val: any) => {
              const productData = {
                id: val.id,
                product_id: val.product,
              };
              return productData;
            }),
            function: editData.function_json.map((val: any) => {
              const functionData = {
                id: val.id,
                module_id: val.module,
                function_id: val.function,
              };
              return functionData;
            }),
            shift1: {
              from: editData.shift1_from,
              to: editData.shift1_to,
            },
            shift2: {
              from: editData.shift2_from,
              to: editData.shift2_to,
            },
            shift3: {
              from: editData.shift3_from,
              to: editData.shift3_to,
            },
          };
          setEditData(editObj);
        }
      } catch (error) {
        console.error('Error fetching plant config data:', error);
      }
    };

    fetchData();
  }, []);

  const handleWorkshop = (value: any) => {
    setWorkshop({ workshop_name: value });
    setDuplicate(false);
  };

  const handleAddWorkshop = () => {
    const check = workshopList.some(
      (item: any) =>
        item.workshop_name.toLowerCase() === workshop.workshop_name.toLowerCase() &&
        item.record_status
    );
    if (workshop.workshop_name && !check) {
      setDuplicate(false);
      const newWorkshopList = [...workshopList, { ...workshop, record_status: true }];
      setWorkshopList(newWorkshopList);
      setFieldValue('workshops', newWorkshopList);
      setWorkshop({ workshop_name: '' });
    } else if (workshop.workshop_name) {
      setDuplicate(true);
    }
  };

  const handleRemoveWorkshop = (index: any) => {
    handleBlur('workshops');
    if (!isEdit) {
      const arrayToRemove = [...workshopList];
      arrayToRemove.splice(index, 1);
      setWorkshopList(arrayToRemove);
      setFieldValue('workshops', arrayToRemove);
    } else if (isEdit) {
      const arrayToRemove = [...workshopList];

      const check = arrayToRemove.some((item, i) => {
        if (index === i) {
          if (Object.hasOwn(item, 'is_deactivate')) {
            return item.is_deactivate;
          } else {
            arrayToRemove.splice(index, 1);
            setWorkshopList(arrayToRemove);
            setFieldValue('workshops', arrayToRemove);
            setDeleteModal(false);
          }
        }
      });
      if (check) {
        const editedArray = arrayToRemove.map((val, i) => {
          if (index == i) {
            const obj = {
              id: val.id,
              workshop_name: val.workshop_name,
              record_status: false,
            };
            return obj;
          }
          return val;
        });
        setWorkshopList(editedArray);
        const editedDatalist = editedArray.filter((item: any) => item.record_status);
        if (editedDatalist.length > 0) {
          setFieldValue('workshops', editedArray);
        } else {
          setFieldValue('workshops', []);
        }
      } else {
        if (arrayToRemove[index]?.id) {
          // Check if the workshop is saved in the backend
          notify(
            'error',
            `${arrayToRemove[index].workshop_name} ${t('systemAdmin.plantConfiguration.workshopAlreadyMappedWithFurnace')}`
          );
        }
      }
    }
    setDeleteModal(false);
  };
  const timeZoneSelect = {
    label: `${t('systemAdmin.plantConfiguration.timeZone')}*`,
    option: [...timeZoneList],
    name: 'timezone',
  };
  const languageSelect = {
    label: `${t('systemAdmin.plantConfiguration.language')}*`,
    option: [...languageList],
    name: 'language',
  };
  const unitSystemSelect = {
    label: `${t('systemAdmin.plantConfiguration.unitSystem')}*`,
    option: [...unitSystemList],
    name: 'unit',
  };
  const currencySelect = {
    label: `${t('systemAdmin.plantConfiguration.currency')}*`,
    option: [...currencyList],
    name: 'currency',
  };
  const Products = [...productList];
  const moduleFunction = [...modelList];

  const userAccessControl = [...functionList.userAccessControl];

  const masterData = [...functionList.masterData];

  const coreProcess = [...functionList.coreProcess];
  const logBook = [...functionList.logBook];

  const labAbalysis = [...functionList.labAbalysis];
  const reports = [...functionList.reports];
  const systemAdmin = [...functionList.systemAdmin];

  const handleFunctionAndModules = (value: any, index: any) => {
    if (value === uniqueCodesMapper.userAccessControlModule) {
      setModulesAndFunctionList(userAccessControl);
      setFunctionCategory(value);
    } else if (value === uniqueCodesMapper.masterDataModule) {
      setModulesAndFunctionList(masterData);
      setFunctionCategory(value);
    } else if (value === uniqueCodesMapper.coreProcessModule) {
      setModulesAndFunctionList(coreProcess);
      setFunctionCategory(value);
    } else if (value === uniqueCodesMapper.logBookModule) {
      setModulesAndFunctionList(logBook);
      setFunctionCategory(value);
    } else if (value === uniqueCodesMapper.labAnalysisModule) {
      setModulesAndFunctionList(labAbalysis);
      setFunctionCategory(value);
    } else if (value === uniqueCodesMapper.systemAdminModule) {
      setModulesAndFunctionList(systemAdmin);
      setFunctionCategory(value);
    } else if (value === uniqueCodesMapper.reportsModule) {
      setModulesAndFunctionList(reports);
      setFunctionCategory(value);
    }
    setSelectFunction(index);
  };

  const handleProductChange = (value: any) => {
    const { productName } = values;
    const updatedProduct = productName.some((item: any) => item?.product_id === value)
      ? productName.filter((pro: any) => pro.product_id !== value)
      : [
          ...productName,
          {
            product_id: value,
          },
        ];
    setFieldValue('productName', updatedProduct);
  };

  const handleModulesAndFunctionsChange = (category: any, value: any) => {
    const { function: functions }: any = values;
    const updatedFunctions = functions.some((item: any) => item?.function_id === value)
      ? functions.filter((item: any) => item.function_id !== value)
      : [
          ...functions,
          {
            module_id: category,
            function_id: value,
          },
        ];
    setFieldValue('function', updatedFunctions);
  };

  const validateNumberInput = (event: any) => {
    const { key, target } = event;
    const { value } = target;
    const digitCount = (value.match(/\d/g) || []).length; // Count the number of digits
    const colonExists = value.includes(':');

    // Allow only numbers and a single colon key
    if (!(key >= '0' && key <= '9') && key !== ':') {
      event.preventDefault();
    }

    // If colon is pressed and it's already present or not enough digits, prevent adding colon
    if (key === ':' && (colonExists || digitCount < 2)) {
      event.preventDefault();
    }

    // If two digits are entered and a colon doesn't exist yet, allow entering colon
    if (digitCount === 2 && key !== ':' && !colonExists) {
      target.value = value + ':';
    }
  };

  const validateInteger = (value: any) => {
    const numberRegex = /^\d{0,8}(\.\d{0,2})?$/;
    return numberRegex.test(value);
  };

  const fetchData = async () => {
    try {
      const masterResponse: any = await httpClient.get('/api/master/master/');

      const masterResponseList = masterResponse?.data?.map((val: any) => {
        const translationKey: any =
          val.type == 'TIMEZONE' && val.type == 'UNITSYSTEM'
            ? `systemAdmin.plantConfiguration.${val.value}`
            : val.value;
        const translatedString = t(translationKey);

        // If the translation exists, `translatedString` will be the translated value,
        // otherwise, it will be the same as `translationKey`
        const displayString = translatedString !== translationKey ? translatedString : val.value;
        const list = {
          option: displayString,
          value: val.master_code,
          type: val.category,
        };
        return list;
      });

      const createOptions = (masterData: any, type: any) => [
        { option: 'Select', value: 'Select' },
        ...(masterData.filter((val: any) => val?.type === type) || []),
      ];
      const createProductOptions = (masterData: any, type: any) => [
        ...(masterData.filter((val: any) => val?.type === type) || []),
      ];

      const TimeZoneResponseList = createOptions(masterResponseList, 'TIMEZONE');

      const languageResponseList = createOptions(masterResponseList, 'LANGUAGE');

      const unitSystemResponseList = createOptions(masterResponseList, 'UNITSYSTEM');

      const currencyResponseList = createOptions(masterResponseList, 'CURRENCY');

      const productResponseList = createProductOptions(masterResponseList, 'PRODUCT');

      const functionResponse: any = await httpClient.get('/api/plant/function/');

      const functionResponseData: any = functionResponse.data;

      setTimeZoneList(TimeZoneResponseList);
      setLanguageList(languageResponseList);
      setUnitSystemList(unitSystemResponseList);
      setCurrencyList(currencyResponseList);
      setProductList(productResponseList);

      const filteredModelList = functionResponse.data.map((val: any) => {
        const models = { option: val.module_code, value: val.id };

        return models;
      });
      const removedElement: any = filteredModelList.splice(3, 1)[0];

      filteredModelList.push(removedElement);
      setModelList(filteredModelList);

      const functions: any = {
        userAccessControl: [],
        masterData: [],
        coreProcess: [],
        labAbalysis: [],
        reports: [],
        systemAdmin: [],
        logBook: [],
      };
      functionResponseData.forEach((module: any) => {
        const functionNameValuePairs: any = module.module_functions.map((func: any) => ({
          option: func.function_code,
          value: func.id,
          module_id: func.module,
        }));

        switch (module.module_code) {
          case uniqueCodesMapper.userAccessControlModule:
            functions.userAccessControl.push(...functionNameValuePairs);
            break;
          case uniqueCodesMapper.masterDataModule:
            functions.masterData.push(...functionNameValuePairs);
            break;
          case uniqueCodesMapper.coreProcessModule:
            functions.coreProcess.push(...functionNameValuePairs);
            break;
          case uniqueCodesMapper.logBookModule:
            functions.logBook.push(...functionNameValuePairs);
            break;
          case uniqueCodesMapper.labAnalysisModule:
            functions.labAbalysis.push(...functionNameValuePairs);
            break;
          case uniqueCodesMapper.reportsModule:
            functions.reports.push(...functionNameValuePairs);
            break;
          case uniqueCodesMapper.systemAdminModule:
            functions.systemAdmin.push(...functionNameValuePairs);
            break;
        }
      });
      setLoading(false);
      setFunctionList(functions);
    } catch (error) {
      // Handle errors here
      console.error('Error fetching data:', error);
    }
  };
  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    if (isEdit) {
      setWorkshopList(editData?.workshops);
    }
  }, [editData]);

  useEffect(() => {
    if (moduleFunction[2]?.value) {
      if (
        moduleFunction.filter((item) => item.value === moduleFunction[2]?.value)[0].option ==
        uniqueCodesMapper.userAccessControlModule
      ) {
        setModulesAndFunctionList(userAccessControl);
      } else if (
        moduleFunction.filter((item) => item.value === moduleFunction[2]?.value)[0].option ==
        uniqueCodesMapper.masterDataModule
      ) {
        setModulesAndFunctionList(masterData);
      } else if (
        moduleFunction.filter((item) => item.value === moduleFunction[2]?.value)[0].option ==
        uniqueCodesMapper.coreProcessModule
      ) {
        setModulesAndFunctionList(coreProcess);
      } else if (
        moduleFunction.filter((item) => item.value === moduleFunction[2]?.value)[0].option ==
        uniqueCodesMapper.labAnalysisModule
      ) {
        setModulesAndFunctionList(labAbalysis);
      } else if (
        moduleFunction.filter((item) => item.value === moduleFunction[2]?.value)[0].option ==
        uniqueCodesMapper.systemAdminModule
      ) {
        setModulesAndFunctionList(systemAdmin);
      } else if (
        moduleFunction.filter((item) => item.value === moduleFunction[2]?.value)[0].option ==
        uniqueCodesMapper.reportsModule
      ) {
        setModulesAndFunctionList(reports);
      } else if (
        moduleFunction.filter((item) => item.value === moduleFunction[2]?.value)[0].option ==
        uniqueCodesMapper.logBookModule
      ) {
        setModulesAndFunctionList(logBook);
      }
    }
  }, [functionList.coreProcess]);

  const handleBackClick = () => {
    navigate(-1);
  };

  const handleCloseAlertModal = () => {
    setDeleteModal(false);
  };

  const handleElectrodePromptCancel = () => {
    setShowPlantUpdatePrompt(false);
  };

  const handleElectrodePromptConfirm = async () => {
    const data = {
      ...values,
      ...{
        shift1_from:
          values.shift1.from.length < 3
            ? `${String(values.shift1.from).padStart(2, '0')}:00`
            : values.shift1.from,
        shift1_to:
          values.shift1.to.length < 3
            ? `${String(values.shift1.to).padStart(2, '0')}:00`
            : values.shift1.to,

        shift2_from:
          values.shift2.from.length < 3
            ? `${String(values.shift2.from).padStart(2, '0')}:00`
            : values.shift2.from,
        shift2_to:
          values.shift2.to.length < 3
            ? `${String(values.shift2.to).padStart(2, '0')}:00`
            : values.shift2.to,

        shift3_from:
          values.shift3.from.length < 3
            ? `${String(values.shift3.from).padStart(2, '0')}:00`
            : values.shift3.from,
        shift3_to:
          values.shift3.to.length < 3
            ? `${String(values.shift3.to).padStart(2, '0')}:00`
            : values.shift3.to,
        is_user_approved: true,
      },
    };
    const result = data.function.every((obj: any) => Object.hasOwn(obj, 'id'));
    const response: any = await httpClient.put(`/api/plant/plant-config/${local_plant_id}/`, {
      data: data,
    });

    if (response) {
      notify('success', t(response.data.message));
      setLoading(false);
      if (result && data.function.length == editData.function.length) {
        navigate('/system-admin/plant-configuration/view');
      } else {
        setOpenAlertModal(true);
        setAlertMsg(t(response.data.message));
      }
    }
  };

  if (loading) return <Loading />;

  return (
    <>
      <form onSubmit={handleSubmit} className='form'>
        <Header title={t('plantModulesAndFunctions.PLT_CFG')} onBackClick={handleBackClick} />

        <div className='container mt-3 mb-3'>
          <div className='child-container card'>
            <div className='card-body card_body_container'>
              <div className='plant'>
                <div className='plant__plant_child'>
                  <label className='input-field-label font-semibold' htmlFor='plant_id'>
                    {t('systemAdmin.plantConfiguration.plantId')}
                  </label>
                  <input
                    className='plant__input'
                    name='plant_id'
                    disabled
                    value={values.plant_id}
                    onChange={handleChange}
                    onBlur={handleBlur}
                  />
                </div>

                <div className='plant__plant_child'>
                  <label className='input-field-label font-semibold' htmlFor='plant_name'>
                    {t('systemAdmin.plantConfiguration.plantName')}
                  </label>
                  <input
                    className='plant__input'
                    name='plant_name'
                    disabled
                    value={values.plant_name}
                    onChange={handleChange}
                    onBlur={handleBlur}
                  />
                </div>

                <div className='plant__plant_child'>
                  <label className='input-field-label font-semibold' htmlFor='plant_label'>
                    {t('systemAdmin.plantConfiguration.areaCode')}
                  </label>
                  <input
                    className='plant__input'
                    name='area_code'
                    disabled
                    value={values.area_code}
                    onChange={handleChange}
                    onBlur={handleBlur}
                  />
                </div>
              </div>

              <div className='plant_address'>
                <label className='input-field-label font-semibold' htmlFor='plant_address__label'>
                  {t('systemAdmin.plantConfiguration.plantAddress')}*
                </label>
                <input
                  className='plant_address__input'
                  name='plant_address'
                  placeholder='Enter Address'
                  value={values.plant_address}
                  onChange={handleChange}
                  onBlur={handleBlur}
                />
                {errors.plant_address && touched.plant_address ? (
                  <p style={{ fontSize: '12px', color: '#ff0000', marginTop: '5px' }}>
                    {errors.plant_address}
                  </p>
                ) : (
                  ''
                )}
              </div>

              <div className='select_body'>
                <div className='select_body__container' style={{ width: '370px' }}>
                  <label className='input-field-label font-semibold'>{timeZoneSelect.label}</label>

                  <CustomSelect
                    index={0}
                    options={timeZoneSelect.option}
                    onChange={(val: any) => {
                      setFieldValue('timezone', val);
                      handleBlur('timezone');
                    }}
                    disabled={isEdit}
                    toShowTooltip={false}
                    value={
                      timeZoneSelect?.option.filter((item: any) => item.value == values.timezone)[0]
                        ?.option || 'Select'
                    }
                  />
                  {errors.timezone && touched.timezone ? (
                    <p style={{ fontSize: '12px', color: '#ff0000' }}>{errors.timezone}</p>
                  ) : (
                    ''
                  )}
                </div>

                <div className='select_body__container'>
                  <label className='input-field-label font-semibold'>{languageSelect.label}</label>

                  <CustomSelect
                    index={0}
                    options={languageSelect.option}
                    onChange={(val: any) => {
                      setFieldValue('language', val);
                      handleBlur('language');
                    }}
                    disabled={isEdit}
                    value={
                      languageSelect?.option.filter((item: any) => item.value == values.language)[0]
                        ?.option || 'Select'
                    }
                  />
                  {errors.language && touched.language ? (
                    <p style={{ fontSize: '12px', color: '#ff0000' }}>{errors.language}</p>
                  ) : (
                    ''
                  )}
                </div>
                <div className='select_body__container'>
                  <label className='input-field-label font-semibold'>
                    {unitSystemSelect.label}
                  </label>

                  <CustomSelect
                    index={0}
                    options={unitSystemSelect.option}
                    onChange={(val: any) => {
                      setFieldValue('unit', val);
                      handleBlur('unit');
                    }}
                    disabled={isEdit}
                    value={
                      unitSystemSelect?.option.filter((item: any) => item.value == values.unit)[0]
                        ?.option || 'Select'
                    }
                  />
                  {errors.unit && touched.unit ? (
                    <p style={{ fontSize: '12px', color: '#ff0000' }}>{errors.unit}</p>
                  ) : (
                    ''
                  )}
                </div>
                <div className='select_body__container'>
                  <label className='input-field-label font-semibold'>{currencySelect.label}</label>

                  <CustomSelect
                    index={0}
                    options={currencySelect.option}
                    onChange={(val: any) => {
                      setFieldValue('currency', val);
                      handleBlur('currency');
                    }}
                    disabled={isEdit}
                    value={
                      currencySelect?.option.filter((item: any) => item.value == values.currency)[0]
                        ?.option || 'Select'
                    }
                  />
                  {errors.currency && touched.currency ? (
                    <p style={{ fontSize: '12px', color: '#ff0000' }}>{errors.currency}</p>
                  ) : (
                    ''
                  )}
                </div>
              </div>

              <hr className='line_break' />

              <div className='energyPrice'>
                <p className='title mb-4'>{t('systemAdmin.plantConfiguration.energyPrice')}</p>
                <Grid container spacing={{ xs: 2, md: 3 }} columns={{ xs: 4, sm: 8, md: 12 }}>
                  <Grid item>
                    <div className='plant__plant_child'>
                      <label className='input-field-label font-semibold' htmlFor='plant_label'>
                        {t('systemAdmin.plantConfiguration.energyPrice')}*
                      </label>
                      <div style={{ position: 'relative' }}>
                        <input
                          className='plant_energy__input'
                          name='parameters.energy_price'
                          // disabled
                          value={values.parameters.energy_price}
                          style={{ paddingRight: '25px' }}
                          onChange={(e) => {
                            const { value } = e.target;
                            if (validateInteger(value) || value === '') {
                              handleChange(e);
                            }
                          }}
                          onBlur={handleBlur}
                        />
                        <span
                          style={{
                            position: 'absolute',
                            right: '5%',
                            top: '50%',
                            transform: 'translateY(-50%)',
                          }}
                        >
                          {unit}
                        </span>
                      </div>
                    </div>
                  </Grid>
                  <Grid item xs={2} sm={4} md={4}>
                    <InputLabel
                      id='fn'
                      sx={{
                        fontWeight: 600,
                        color: '#606466',
                        fontSize: '14px',
                        marginBottom: '13px',
                      }}
                    >
                      {t('sharedTexts.effectiveDate')}*
                    </InputLabel>
                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                      <DesktopDatePicker
                        closeOnSelect={false}
                        format='DD/MM/YYYY'
                        sx={{
                          '& .MuiInputBase-input': {
                            height: '40px',
                            padding: '0px 0px 0px 14px',
                            fontSize: '14px',
                          },
                          width: '250px!important', // this solved a UI bug in date
                        }}
                        onChange={(value) =>
                          setFieldValue(
                            'parameters.effective_date',
                            dayjs(value).format('YYYY-MM-DD')
                          )
                        }
                        value={dayjs(values.parameters.effective_date)}
                      />
                    </LocalizationProvider>
                  </Grid>
                </Grid>
              </div>

              <hr className='line_break' />

              <div className='workshop'>
                <p className='title mb-4'>{t('systemAdmin.plantConfiguration.workshops')}</p>

                <div className='workshop__workshop_container'>
                  <div className='workshop__child'>
                    <label className='input-field-label font-semibold' htmlFor='workshop_name'>
                      {' '}
                      {`${t('systemAdmin.plantConfiguration.workshopName')}*`}{' '}
                    </label>
                    <input
                      className='workshop__input'
                      value={workshop.workshop_name}
                      onChange={(e) => {
                        const isValid = /^(\w|-)+$/.test(e.target.value) || e.target.value === '';;
                        if (isValid) {
                          handleWorkshop(e.target.value);
                        }
                      }}
                      placeholder='EnterName'
                      maxLength={50}
                    />
                  </div>

                  <button
                    className={
                      workshop.workshop_name
                        ? 'workshop__add_container'
                        : 'workshop__add_container workshop__disabled'
                    }
                    style={{ border: 0 }}
                    type='button'
                    onClick={handleAddWorkshop}
                    onKeyDown={(e) => e.key === 'Enter' && handleAddWorkshop()}
                  >
                    <svg
                      xmlns='http://www.w3.org/2000/svg'
                      width='40'
                      height='40'
                      fill='#fff'
                      className='bi bi-plus'
                      viewBox='0 0 16 16'
                    >
                      <path d='M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4' />
                    </svg>
                  </button>
                </div>
                {(errors.workshops && touched.workshops) || duplicate ? (
                  <p style={{ fontSize: '12px', color: '#ff0000', marginTop: '5px' }}>
                    {duplicate ? 'Workshop must be unique' : errors.workshops}
                  </p>
                ) : (
                  ''
                )}
                <div className='workshop__list_container'>
                  {workshopList?.length > 0 && (
                    <table className='workshop__table'>
                      <tr>
                        <th className='workshop__table_head'>{`${t('systemAdmin.plantConfiguration.workshopName')}`}</th>
                        <th></th>
                      </tr>

                      {workshopList.map((val: any, index: any) =>
                        val.record_status ? (
                          <tr className='workshop__table_data' key={val.workshop_name}>
                            <td>{val.workshop_name}</td>
                            <td style={{ paddingLeft: '15px' }}>
                              <button
                                onClick={() => {
                                  setDeleteModal(true);
                                  setRemoveWorkShopId(index);
                                }}
                                onKeyDown={() => {
                                  setDeleteModal(true);
                                  setRemoveWorkShopId(index);
                                }}
                                data-toggle='tooltip'
                                data-placement='bottom'
                                onMouseOver={() => setShowTooltip(index)}
                                onMouseOut={() => setShowTooltip('')}
                                onBlur={() => setShowTooltip('')}
                                onFocus={() => setShowTooltip(index)}
                                style={{ backgroundColor: '#ffffff00', border: 0 }}
                                type='button'
                              >
                                <svg
                                  xmlns='http://www.w3.org/2000/svg'
                                  width='17'
                                  height='17'
                                  fill='#8F1D18'
                                  className='bi bi-trash'
                                  viewBox='0 0 16 16'
                                >
                                  <path d='M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z' />
                                  <path d='M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z' />
                                </svg>

                                {showTooltip === index ? (
                                  <span className='workshop__tooltip'> Delete</span>
                                ) : (
                                  ''
                                )}
                              </button>
                            </td>
                          </tr>
                        ) : (
                          ''
                        )
                      )}
                    </table>
                  )}
                </div>
              </div>

              <hr className='line_break' />

              <div className='products'>
                <p className='title mb-3'> {t('systemAdmin.plantConfiguration.products')} </p>
                <label className='input-field-label font-semibold' htmlFor='product_name'>
                  {`${t('systemAdmin.plantConfiguration.productName')}*`}{' '}
                </label>
                <div className='products__container'>
                  {Products.map((val: any) => (
                    <div className='form-check' style={{ display: 'flex' }} key={val.option}>
                      <input
                        className='form-check-input products__input'
                        type='checkbox'
                        value={val.value}
                        id={val.option}
                        name='productName'
                        onChange={() => handleProductChange(val.value)}
                        checked={values.productName.some(
                          (item: any) => item?.product_id === val.value
                        )}
                        onBlur={handleBlur}
                      />
                      <label
                        className='form-check-label products__checkbox_label'
                        htmlFor={val.option}
                      >
                        {val.option}
                      </label>
                    </div>
                  ))}
                </div>
                {errors.productName && touched.productName ? (
                  <p style={{ fontSize: '12px', color: '#ff0000', marginTop: '5px' }}>
                    {errors.productName}
                  </p>
                ) : (
                  ''
                )}
              </div>

              <hr className='line_break' />
              <div className='functions'>
                <p className='title mb-3'> {`${t('sharedTexts.functions')}`} </p>
                <label className='input-field-label font-semibold' htmlFor='modules_functions'>
                  {' '}
                  {`${t('systemAdmin.plantConfiguration.moduleAndFunctions')}`}*
                </label>

                <div className='functions__container'>
                  <div className='functions__selector_container'>
                    {moduleFunction.map((category: any, index: any) => {
                      const categoryName: any = `plantModulesAndFunctions.${category.option}`;

                      return (
                        <button
                          type='button'
                          className='functions__text'
                          style={{
                            backgroundColor: selectFunction === index ? 'white' : '#c1d3df40',
                            border: 0,
                            borderRight: selectFunction === index ? '3px solid #0D659E' : '0px',
                            color: selectFunction === index ? '#0D659E' : '#757e85',
                            width: '-webkit-fill-available',
                          }}
                          onClick={() => {
                            handleFunctionAndModules(category.option, index);
                          }}
                          onKeyDown={(e) =>
                            e.key === 'Enter' && handleFunctionAndModules(category.option, index)
                          }
                          key={category.option}
                        >
                          {t(categoryName)}
                        </button>
                      );
                    })}
                  </div>

                  <div className='functions__check_container'>
                    {modulesAndFunctionList.map((val: any) => {
                      const functionName: any = `plantModulesAndFunctions.${val.option}`;
                      return (
                        <div className='form-check functions__checkbox' key={val.option}>
                          <input
                            className='form-check-input functions__input'
                            type='checkbox'
                            name='function'
                            id={val.option}
                            onChange={() =>
                              handleModulesAndFunctionsChange(functionCategory, val.option)
                            }
                            checked={values.function.some(
                              (item: any) => item?.function_id === val.option
                            )}
                            disabled={
                              val.option === uniqueCodesMapper.plantConfigFunction ||
                              val.option === uniqueCodesMapper.furnaceConfigFunction ||
                              val.option === uniqueCodesMapper.rolesFunction ||
                              val.option === uniqueCodesMapper.usersFunction
                            }
                            onBlur={handleBlur}
                          />
                          <label
                            className='form-check-label functions__checkbox_label'
                            htmlFor={val.option}
                          >
                            {t(functionName)}
                          </label>
                        </div>
                      );
                    })}
                  </div>
                </div>
                {errors.function && touched.function ? (
                  <p style={{ fontSize: '12px', color: '#ff0000' }}>{errors.function}</p>
                ) : (
                  ''
                )}
              </div>

              <hr className='line_break' />

              <div className='schedule'>
                <p className='title mb-3'>
                  {t('systemAdmin.plantConfiguration.shiftSchedule')} (
                  {timeZoneSelect?.option.filter((item: any) => item.value == values.timezone)[0]
                    ?.option || ''}
                  )
                </p>
                {/* shift start  */}
                <div className='schedule__main_container mt-3'>
                  <div className='schedule__container'>
                    <p className='schedule__input_title'>
                      {t('systemAdmin.plantConfiguration.shift')} 1*
                    </p>
                    <div className='schedule__input_container'>
                      <label className='input-field-label font-semibold' htmlFor='shift1from'>
                        {' '}
                        {t('sharedTexts.from')} :{' '}
                      </label>
                      <div>
                        <input
                          className='schedule__input'
                          placeholder='HH:MM'
                          name='shift1.from'
                          value={values.shift1.from}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          onKeyPress={validateNumberInput}
                          maxLength={5}
                        />
                        {errors.shift1?.from && touched.shift1?.from ? (
                          <p style={{ fontSize: '12px', color: '#ff0000', position: 'absolute' }}>
                            {errors.shift1?.from}
                          </p>
                        ) : (
                          ''
                        )}
                      </div>
                    </div>

                    <div className='schedule__input_container'>
                      <label className='input-field-label font-semibold' htmlFor='shift1to'>
                        {' '}
                        {t('sharedTexts.to')} :{' '}
                      </label>
                      <div>
                        <input
                          className='schedule__input'
                          placeholder='HH:MM'
                          name='shift1.to'
                          value={values.shift1.to}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          onKeyPress={validateNumberInput}
                          maxLength={5}
                        />
                        {errors.shift1?.to && touched.shift1?.to ? (
                          <p style={{ fontSize: '12px', color: '#ff0000', position: 'absolute' }}>
                            {errors.shift1?.to}
                          </p>
                        ) : (
                          ''
                        )}
                      </div>
                    </div>
                  </div>
                  <div className='schedule__container'>
                    <p className='schedule__input_title'>
                      {t('systemAdmin.plantConfiguration.shift')} 2*
                    </p>
                    <div className='schedule__input_container'>
                      <label className='input-field-label font-semibold' htmlFor='shift2from'>
                        {' '}
                        {t('sharedTexts.from')} :{' '}
                      </label>
                      <div>
                        <input
                          className='schedule__input'
                          placeholder='HH:MM'
                          name='shift2.from'
                          value={values.shift2.from}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          onKeyPress={validateNumberInput}
                          maxLength={5}
                        />
                        {errors.shift2?.from && touched.shift2?.from ? (
                          <p style={{ fontSize: '12px', color: '#ff0000', position: 'absolute' }}>
                            {errors.shift2?.from}
                          </p>
                        ) : (
                          ''
                        )}
                      </div>
                    </div>

                    <div className='schedule__input_container'>
                      <label className='input-field-label font-semibold' htmlFor='shift2to'>
                        {' '}
                        {t('sharedTexts.to')} :{' '}
                      </label>
                      <div>
                        <input
                          className='schedule__input'
                          placeholder='HH:MM'
                          name='shift2.to'
                          value={values.shift2.to}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          onKeyPress={validateNumberInput}
                          maxLength={5}
                        />
                        {errors.shift2?.to && touched.shift2?.to ? (
                          <p style={{ fontSize: '12px', color: '#ff0000', position: 'absolute' }}>
                            {errors.shift2?.to}
                          </p>
                        ) : (
                          ''
                        )}
                      </div>
                    </div>
                  </div>
                  <div className='schedule__container'>
                    <p className='schedule__input_title'>
                      {t('systemAdmin.plantConfiguration.shift')} 3*
                    </p>
                    <div className='schedule__input_container'>
                      <label className='input-field-label font-semibold' htmlFor='shift3from'>
                        {' '}
                        {t('sharedTexts.from')} :{' '}
                      </label>
                      <div>
                        <input
                          className='schedule__input'
                          placeholder='HH:MM'
                          name='shift3.from'
                          value={values.shift3.from}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          onKeyPress={validateNumberInput}
                          maxLength={5}
                        />
                        {errors.shift3?.from && touched.shift3?.from ? (
                          <p style={{ fontSize: '12px', color: '#ff0000', position: 'absolute' }}>
                            {errors.shift3?.from}
                          </p>
                        ) : (
                          ''
                        )}
                      </div>
                    </div>

                    <div className='schedule__input_container'>
                      <label className='input-field-label font-semibold' htmlFor='shift3to'>
                        {' '}
                        {t('sharedTexts.to')} :{' '}
                      </label>
                      <div>
                        <input
                          className='schedule__input'
                          placeholder='HH:MM'
                          name='shift3.to'
                          value={values.shift3.to}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          onKeyPress={validateNumberInput}
                          maxLength={5}
                        />
                        {errors.shift3?.to && touched.shift3?.to ? (
                          <p style={{ fontSize: '12px', color: '#ff0000', position: 'absolute' }}>
                            {errors.shift3?.to}
                          </p>
                        ) : (
                          ''
                        )}
                      </div>
                    </div>
                  </div>
                </div>
                {/* shift end  */}
              </div>
            </div>
          </div>
        </div>
        {openAlertModal && (
          <AlertModal
            showModal={openAlertModal}
            title={`${t('authentication.login.logout')}`}
            content={alertMsg}
            confirmButtonText='Proceed'
            isShowCloseIcon={false}
            onConfirmClick={async () => {
              setLoading(true);
              clearSessionStorage(['accessToken', 'selectedLanguage']);
              setLoading(false);
              navigate(`${paths.login}`);
            }}
            closeModal={() => {
              setOpenAlertModal(true);
            }}
          />
        )}

        <PlantFooter currentTab={1} onback={() => navigate(-1)} />
      </form>
      <AlertModal
        showModal={deleteModal}
        title={t('sharedTexts.message')}
        content={t('sharedTexts.areYouSureYouWantToDeleteTheWorkshop')}
        confirmButtonText={t('sharedTexts.proceed')}
        // onConfirmClick={handleDeleteRole}
        onConfirmClick={() => handleRemoveWorkshop(removeWorkShopId)}
        // closeModal={handleCloseDeleteModal}
        closeModal={handleCloseAlertModal}
      />
      <AlertModal
        showModal={showPlantUpdatePrompt}
        title={t('systemAdmin.plantConfiguration.existingPlantParamTitle')}
        content={t('systemAdmin.plantConfiguration.existingPlantParamContent')}
        confirmButtonText={t('sharedTexts.proceed')}
        onConfirmClick={() => handleElectrodePromptConfirm()}
        closeModal={() => handleElectrodePromptCancel()}
      />
    </>
  );
};

export default AddPlant;
