import { useTranslation } from 'react-i18next';

interface ViewControlParameters {
  controlParameterData: Array<any>;
  item: any;
}

const ViewControlParameters = ({ controlParameterData, item }: ViewControlParameters) => {
  const { t } = useTranslation();
  return (
    <div>
      <label
        htmlFor='Parameters'
        style={{
          color: '#04436B',
          fontSize: '16px',
          fontWeight: 600,
        }}
      >
        {t('systemAdmin.furnaceConfiguration.parameters')}
      </label>
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '40px',
        }}
      >
        {item.controlParameters.map((val: any) =>
          val.record_status || !Object.hasOwn(val, 'record_status') ? (
            <div key={val.param}>
              <p
                style={{
                  color: '#606466',
                  fontSize: '14px',
                  fontWeight: 600,
                }}
              >
                {
                  controlParameterData[0].option.filter((item: any) => item.value == val.param)[0]
                    ?.option
                }
              </p>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '4px',
                }}
              >
                <p
                  style={{
                    fontSize: '14px',
                    fontWeight: 600,
                  }}
                >
                  {val.value}
                  <span className='ms-1 fw-semibold' style={{ fontSize: '13px' }}>
                    {val?.icon}
                  </span>
                </p>
                <span
                  style={{ margin: '0 4px', fontSize: '14px', fontWeight: 600, color: '#989A9C' }}
                >
                  |
                </span>
                <div>
                  <p style={{ fontSize: '14px', fontWeight: 600 }}>
                    {val.is_mandatory
                      ? `${t('systemAdmin.furnaceConfiguration.mandatory')}`
                      : `${t('systemAdmin.furnaceConfiguration.notMandatory')}`}
                  </p>
                </div>
              </div>
            </div>
          ) : (
            ''
          )
        )}
      </div>
    </div>
  );
};

export default ViewControlParameters;
