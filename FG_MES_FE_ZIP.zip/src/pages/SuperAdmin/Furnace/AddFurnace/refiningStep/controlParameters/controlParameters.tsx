import InputField from 'components/common/InputWithIcon';
import CustomSelect from 'components/common/SelectField';
import ToggleButton from 'components/common/ToggleButton';
import { useTranslation } from 'react-i18next';
import { FieldUnit } from 'types/unit.model';

interface AddControlParameters {
  controlParameterData: Array<any>;
  isAdd: boolean;
  controlParameters: any;
  handleControlParametersChange: (value: any, type: string, cat: string, option?: any) => void;
  controlParametersList: Array<any>;
  setEnabled: (value: boolean) => void;
  enabled: boolean;
  handleAddControlParameters: () => void;
  isAdded: boolean;
  control_parameters: Array<any>;
  handleInputChange: (e: any, index: number, type: string) => void;
  allUnits: Array<any>;
  handleToggleChange: (value: any, index: number, type: string) => void;
  setControlParameterDeleteModal: (value: any) => void;
  setShowControlParametersTooltip: (value: string | number) => void;
  showControlParametersTooltip: (value: number) => void;
}
const AddControlParameters = ({
  controlParameterData,
  isAdd,
  controlParameters,
  handleControlParametersChange,
  controlParametersList,
  setEnabled,
  enabled,
  handleAddControlParameters,
  isAdded,
  control_parameters,
  handleInputChange,
  allUnits,
  handleToggleChange,
  setControlParameterDeleteModal,
  setShowControlParametersTooltip,
  showControlParametersTooltip,
}: AddControlParameters) => {
  const { t } = useTranslation();
  return (
    <div className='control_parameters'>
      <p className='control_parameters__title mb-4'>
        {' '}
        {`${t('systemAdmin.furnaceConfiguration.controlParameters')}`}
      </p>

      <div className='control_parameters__parameter_container'>
        {controlParameterData.map((val: any, index: number) => (
          <div
            key={val.id}
            style={{
              width: val.type !== 'select' && val.type !== 'input' ? '170px' : '255px',
            }}
          >
            {val.type === 'input' && (
              <InputField
                type={'number'}
                icon={val.icon}
                value={(isAdd && controlParameters.value) || ''}
                onChange={(value: any) => {
                  const regex = /^\d{0,5}(\.\d{1,3})?$/;
                  if (regex.test(value) || value === '') {
                    handleControlParametersChange(value, 'input', 'add');
                  }
                }}
              />
            )}

            {val.type === 'select' && (
              <CustomSelect
                index={index}
                options={val.option.filter(
                  (option: any) =>
                    !controlParametersList?.some((item: any) => item.param == option.value)
                )}
                onChange={(value: any) =>
                  handleControlParametersChange(value, 'select', 'add', val['option'])
                }
                value={
                  (isAdd &&
                    val.option.filter((item: any) => item.value == controlParameters.param)[0]
                      ?.option) ||
                  t('sharedTexts.select')
                }
              />
            )}

            {val.type === 'toggle' && (
              <ToggleButton
                onChange={(val: any) => {
                  setEnabled(!enabled);
                  handleControlParametersChange(val, 'toggle', 'add');
                }}
                text={
                  enabled
                    ? `${t('systemAdmin.furnaceConfiguration.mandatory')}`
                    : `${t('systemAdmin.furnaceConfiguration.notMandatory')}`
                }
                isChecked={isAdd && enabled}
                style={{ color: '#757E85', width: 'max-content' }}
              />
            )}
            {val.type === 'add-button' ? (
              <button
                type='button'
                style={{ border: '0px' }}
                className={`${
                  controlParameters.param && controlParameters.value
                    ? 'control_parameters__add_container '
                    : 'control_parameters__add_container control_parameters__disabledbtn'
                }`}
                onClick={handleAddControlParameters}
                onKeyDown={(event) => {
                  event.key === 'Enter' && handleAddControlParameters();
                }}
              >
                <svg
                  xmlns='http://www.w3.org/2000/svg'
                  width='40'
                  height='40'
                  fill='#fff'
                  className='bi bi-plus'
                  viewBox='0 0 16 16'
                >
                  <path d='M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4' />
                </svg>
              </button>
            ) : null}
          </div>
        ))}
      </div>
      {controlParametersList.length < 1 && isAdded && (
        <p style={{ fontSize: '12px', color: '#ff0000' }}>Parameters is required</p>
      )}
      <div className='control_parameters__list_container'>
        {controlParametersList?.length > 0 && (
          <table className='control_parameters__table'>
            <tr>
              <th className='control_parameters__table_head '>
                {' '}
                {`${t('systemAdmin.furnaceConfiguration.controlParameters')}`}{' '}
              </th>
              <th className='control_parameters__table_head'> {`${t('sharedTexts.value')}`} </th>
              <th></th>
              <th></th>
            </tr>

            {controlParametersList?.map((val: any, index: any) => (
              <tr className='control_parameters__table_data' key={val.param}>
                <td>
                  {
                    control_parameters[0].option.filter((item: any) => item.value == val.param)[0]
                      ?.option
                  }
                </td>
                <td>
                  <input
                    type={'number'}
                    onChange={(e) => {
                      const regex = /^\d{0,5}(\.\d{1,3})?$/;
                      if (regex.test(e.target.value) || e.target.value === '') {
                        handleInputChange(e, index, 'controlParameters');
                      }
                    }}
                    className='control_parameters__table_value'
                    value={val.value}
                  ></input>
                  <span className='ms-2 fw-semibold' style={{ fontSize: '13px' }}>
                    {
                      allUnits.filter(
                        (unitInfo: FieldUnit) =>
                          unitInfo.name ===
                          control_parameters[0].option.filter(
                            (item: any) => item.value == val.param
                          )[0]?.option
                      )[0]?.unit
                    }
                  </span>
                </td>
                <td>
                  {' '}
                  <ToggleButton
                    text={
                      val.is_mandatory
                        ? `${t('systemAdmin.furnaceConfiguration.mandatory')}`
                        : `${t('systemAdmin.furnaceConfiguration.notMandatory')}`
                    }
                    isChecked={val.is_mandatory}
                    enabled={val.is_mandatory}
                    onChange={(val: any) => {
                      handleToggleChange(val, index, 'controlParameters');
                    }}
                  />
                </td>
                <td>
                  <button
                    onClick={() =>
                      setControlParameterDeleteModal({
                        bool: true,
                        index: index,
                        mainIndex: null,
                      })
                    }
                    style={{ border: '0px', backgroundColor: '#fff' }}
                    type='button'
                    onKeyDown={(event) => {
                      event.key === 'Enter' &&
                        setControlParameterDeleteModal({
                          bool: true,
                          index: index,
                          mainIndex: null,
                        });
                    }}
                    data-toggle='tooltip'
                    data-placement='bottom'
                    onMouseOver={() => setShowControlParametersTooltip(index)}
                    onMouseOut={() => setShowControlParametersTooltip('')}
                    onFocus={() => setShowControlParametersTooltip(index)}
                    onBlur={() => setShowControlParametersTooltip('')}
                  >
                    <svg
                      xmlns='http://www.w3.org/2000/svg'
                      width='17'
                      height='17'
                      fill='#8F1D18'
                      className='bi bi-trash'
                      viewBox='0 0 16 16'
                    >
                      <path d='M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z' />
                      <path d='M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z' />
                    </svg>

                    {showControlParametersTooltip === index ? (
                      <span className='control_parameters__tooltip'>{'Delete'}</span>
                    ) : (
                      ''
                    )}
                  </button>
                </td>
              </tr>
            ))}
          </table>
        )}
      </div>
    </div>
  );
};

export default AddControlParameters;
