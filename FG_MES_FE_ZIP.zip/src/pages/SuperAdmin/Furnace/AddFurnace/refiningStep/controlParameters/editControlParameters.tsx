import InputField from 'components/common/InputWithIcon';
import CustomSelect from 'components/common/SelectField';
import ToggleButton from 'components/common/ToggleButton';
import { useTranslation } from 'react-i18next';
import { FieldUnit } from 'types/unit.model';
interface EditControlParameters {
  controlParameterData: Array<any>;
  isAdd: boolean;
  controlParameters: any;
  handleControlParametersChange: (value: any, type: string, cat?: string, option?: any) => void;
  setEnabled: (value: boolean) => void;
  enabled: boolean;
  control_parameters: Array<any>;
  allUnits: Array<any>;
  setControlParameterDeleteModal: (value: any) => void;
  setShowControlParametersTooltip: (value: string | number) => void;
  showControlParametersTooltip: (value: number) => void;
  dataList: Array<any>;
  item: any;
  index: number;
  handleEditControlParameters: (value: number) => void;
  handleEditInputChange: (e: any, index: number, value: string, type: string) => void;
  handleEditToggleChange: (e: any, index: number, value: string, type: string) => void;
}
const EditControlParameters = ({
  controlParameterData,
  isAdd,
  controlParameters,
  handleControlParametersChange,
  setEnabled,
  enabled,
  control_parameters,
  allUnits,
  setControlParameterDeleteModal,
  setShowControlParametersTooltip,
  showControlParametersTooltip,
  dataList,
  item,
  index,
  handleEditControlParameters,
  handleEditInputChange,
  handleEditToggleChange,
}: EditControlParameters) => {
  const { t } = useTranslation();
  return (
    <div>
      <label
        htmlFor='Parameters'
        style={{
          color: '#04436B',
          fontSize: '16px',
          fontWeight: 600,
          paddingBottom: '16px',
        }}
      >
        {t('systemAdmin.furnaceConfiguration.parameters')}
      </label>
      <div className='control_parameters__parameter_container'>
        {controlParameterData.map((val: any, i: any) => (
          <div
            key={val.id}
            className='control_parameters__container'
            style={{
              width: val.type !== 'select' && val.type !== 'input' ? '170px' : '255px',
            }}
          >
            {val.type === 'input' && (
              <InputField
                type={'number'}
                icon={val.icon}
                value={!isAdd ? controlParameters.value : ''}
                onChange={(value: any) => {
                  const regex = /^\d{0,5}(\.\d{1,3})?$/;
                  if (regex.test(value) || value === '') {
                    handleControlParametersChange(value, 'input');
                  }
                }}
              />
            )}

            {val.type === 'select' && (
              <CustomSelect
                index={i}
                // options={val.option}
                options={val.option.filter((option: any) => {
                  // Check if option value is not present in any control parameter in dataList
                  return !dataList.some(
                    (items: any) =>
                      items.controlParameters.some(
                        (e: any) => e.param === option.value && e.record_status
                      ) && items.step == item.step
                  );
                })}
                onChange={(value: any) => {
                  handleControlParametersChange(value, 'select', '', val['option']);
                }}
                value={
                  val.option.filter(
                    (val: any) => val.value == controlParameters.param && index == i && !isAdd
                  )[0]?.option || t('sharedTexts.select')
                }
              />
            )}
            {val.type === 'toggle' && (
              <ToggleButton
                onChange={(val: any) => {
                  setEnabled(!enabled);
                  handleControlParametersChange(val, 'toggle');
                }}
                text={
                  enabled
                    ? `${t('systemAdmin.furnaceConfiguration.mandatory')}`
                    : `${t('systemAdmin.furnaceConfiguration.notMandatory')}`
                }
                isChecked={!isAdd ? enabled : false}
                style={{ width: 'max-content' }}
              />
            )}
            {val.type === 'add-button' ? (
              <button
                type='button'
                className={`${
                  controlParameters.param && controlParameters.value
                    ? 'control_parameters__add_container '
                    : 'control_parameters__add_container control_parameters__disabledbtn'
                }`}
                style={{ border: '0px' }}
                onClick={() => handleEditControlParameters(index)}
                onKeyDown={(event) => {
                  event.key === 'Enter' && handleEditControlParameters(index);
                }}
              >
                <svg
                  xmlns='http://www.w3.org/2000/svg'
                  width='40'
                  height='40'
                  fill='#fff'
                  className='bi bi-plus'
                  viewBox='0 0 16 16'
                >
                  <path d='M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4' />
                </svg>
              </button>
            ) : null}
          </div>
        ))}
      </div>

      {item.controlParameters.filter((item: any) => item.record_status === true)?.length < 1 && (
        <p
          style={{
            fontSize: '12px',
            color: '#ff0000',
            marginTop: '5px',
          }}
        >
          Parameters is required
        </p>
      )}

      {item.controlParameters.length > 0 && (
        <div className='control_parameters__list_container'>
          {item.controlParameters.filter((item: any) => item.record_status === true)?.length >
            0 && (
            <table className='control_parameters__table'>
              <tr>
                <th className='control_parameters__table_head '>
                  {' '}
                  {`${t('systemAdmin.furnaceConfiguration.controlParameters')}`}{' '}
                </th>
                <th className='control_parameters__table_head'> {`${t('sharedTexts.value')}`}</th>
                <th></th>
                <th></th>
              </tr>

              {[...item.controlParameters]?.map((val: any, i: any) =>
                val.record_status || !Object.hasOwn(val, 'record_status') ? (
                  <tr key={val.param} className='control_parameters__table_data'>
                    <td>
                      {
                        control_parameters[0].option.filter(
                          (item: any) => item.value == val.param
                        )[0]?.option
                      }
                    </td>
                    <td>
                      <input
                        type={'number'}
                        className='control_parameters__table_value'
                        onChange={(e) => {
                          const regex = /^\d{0,5}(\.\d{1,3})?$/;
                          if (regex.test(e.target.value) || e.target.value === '') {
                            handleEditInputChange(e, i, item.step, 'controlParameters');
                          }
                        }}
                        value={val.value}
                      ></input>
                      <span className='ms-2 fw-semibold' style={{ fontSize: '13px' }}>
                        {
                          allUnits.filter(
                            (unitInfo: FieldUnit) =>
                              unitInfo.name ===
                              control_parameters[0].option.filter(
                                (item: any) => item.value == val.param
                              )[0]?.option
                          )[0]?.unit
                        }
                      </span>
                    </td>
                    <td>
                      {' '}
                      <ToggleButton
                        enabled={val.is_mandatory}
                        text={
                          val.is_mandatory
                            ? `${t('systemAdmin.furnaceConfiguration.mandatory')}`
                            : `${t('systemAdmin.furnaceConfiguration.notMandatory')}`
                        }
                        onChange={(val: any) => {
                          handleEditToggleChange(val, i, item.step, 'controlParameters');
                        }}
                        isChecked={val.is_mandatory}
                      />
                    </td>
                    <td>
                      <div data-toggle='tooltip' data-placement='bottom'>
                        <svg
                          onClick={() =>
                            setControlParameterDeleteModal({
                              bool: true,
                              index: i,
                              mainIndex: index,
                            })
                          }
                          onMouseOver={() => setShowControlParametersTooltip(i)}
                          onMouseOut={() => setShowControlParametersTooltip('')}
                          xmlns='http://www.w3.org/2000/svg'
                          width='17'
                          height='17'
                          fill='#8F1D18'
                          className='bi bi-trash'
                          viewBox='0 0 16 16'
                        >
                          <path d='M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z' />
                          <path d='M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z' />
                        </svg>

                        {showControlParametersTooltip === i ? (
                          <span className='control_parameters__tooltip'>{'Delete'}</span>
                        ) : (
                          ''
                        )}
                      </div>
                    </td>
                  </tr>
                ) : (
                  ''
                )
              )}
            </table>
          )}
        </div>
      )}
    </div>
  );
};

export default EditControlParameters;
