import { FC } from 'react';
import closeIcon from '../../../../../assets/icons/close-btn.svg';
import { useTranslation } from 'react-i18next';

interface ModalAlertProps {
  title: string;
  children: React.ReactNode;
  showModal: boolean;
  closeModal: () => void;
  confirmButtonText: string;
  isShowCloseIcon?: boolean;
  disabled: boolean;
}

const RefiningStepModal: FC<ModalAlertProps> = ({
  title,
  children,
  showModal,
  closeModal,
  confirmButtonText,
  isShowCloseIcon = true,
  disabled,
}) => {
  const { t } = useTranslation();
  return (
    <section className={`modal modal--plant-selection ${showModal ? 'open' : ''}`}>
      <div className='modal__container' style={{ width: '80vw' }}>
        <div className='modal__header'>
          <div className='flex items-center justify-between'>
            <div className='flex-1 pr-8'>
              <h3 className='modal__title'>{title}</h3>
            </div>
            {isShowCloseIcon && (
              <button
                type='button'
                style={{ border: '0px solid', backgroundColor: '#f0ffff00' }}
                className='modal__close'
                onClick={closeModal}
                onKeyDown={closeModal}
              >
                <img src={closeIcon} alt='close-icon' />
              </button>
            )}
          </div>
        </div>
        <div className='modal__body p-4 overflow-auto' style={{ minHeight: '55vh' }}>
          {children}
        </div>

        <div className='modal__footer py-3 px-6'>
          {isShowCloseIcon && (
            <button className='btn btn--sm btn--h36' type='button' onClick={closeModal}>
              {t('sharedTexts.cancel')}
            </button>
          )}
          <button disabled={disabled} className='btn btn--primary btn--sm btn--h36' type='submit'>
            {confirmButtonText}
          </button>
        </div>
      </div>
    </section>
  );
};

export default RefiningStepModal;
