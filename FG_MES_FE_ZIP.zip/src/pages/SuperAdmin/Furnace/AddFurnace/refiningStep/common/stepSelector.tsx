import CustomSelect from 'components/common/SelectField';
import { t } from 'i18next';

interface StepSelector {
  steps: any;
  dataList: Array<any>;
  setFieldValue: (type: string, value: any) => void;
  values: any;
  disabled: boolean;
}
const StepSelector = ({ steps, dataList, setFieldValue, values, disabled }: StepSelector) => {
  return (
    <div className='select_body'>
      <div className='select_body__container'>
        <label className='input-field-label font-semibold'>{steps.label}</label>

        <CustomSelect
          disabled={disabled}
          index={0}
          options={steps?.option?.filter(
            (val: any) => !dataList.some((item: any) => item.step == val.value)
          )}
          onChange={(val: any) => {
            setFieldValue('step', val);
          }}
          value={
            steps?.option?.filter((item: any) => item.value == values.step)[0]?.option ||
            t('sharedTexts.select')
          }
        />
      </div>
    </div>
  );
};

export default StepSelector;
