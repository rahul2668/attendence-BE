import { useTranslation } from 'react-i18next';

interface Header {
  isEdit: boolean;
  setTab: (value: number) => void;
}

const Header = ({ isEdit, setTab }: Header) => {
  const { t } = useTranslation();
  return (
    <div style={{ display: 'flex' }}>
      <button
        style={{
          display: 'flex',
          width: '50%',
          alignItems: 'center',
          gap: '15px',
          padding: '14px 31px 14px 31px',
          backgroundColor: '#C1D3DF40',
          cursor: 'pointer',
          border: '0px',
        }}
        type='button'
        onClick={() => isEdit && setTab(1)}
        onKeyDown={(event) => {
          event.key === 'Enter' && isEdit && setTab(1);
        }}
      >
        <p
          style={{
            width: '32px',
            height: '32px',
            border: '1px solid #CDD0D1',
            borderRadius: '50%',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            backgroundColor: '#fff',
          }}
        >
          1
        </p>
        <p
          style={{
            fontSize: '14px',
            fontWeight: 700,
            color: '#757E85',
          }}
        >
          {t('systemAdmin.furnaceConfiguration.basicInformation')}
        </p>
      </button>
      <div
        style={{
          display: 'flex',
          width: '50%',
          alignItems: 'center',
          padding: '14px 31px 14px 31px',
          gap: '15px',
          borderTop: '2px solid #0D659E',
          borderTopRightRadius: '4px',
        }}
      >
        <p
          style={{
            width: '32px',
            height: '32px',
            borderRadius: '50%',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            backgroundColor: '#0D659E',
            color: '#fff',
          }}
        >
          2
        </p>
        <p
          style={{
            fontSize: '14px',
            fontWeight: 700,
            color: '#0D659E',
          }}
        >
          {t('systemAdmin.furnaceConfiguration.refiningSteps')}
        </p>
      </div>
    </div>
  );
};

export default Header;
