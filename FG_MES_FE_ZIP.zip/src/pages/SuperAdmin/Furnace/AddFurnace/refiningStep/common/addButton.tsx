import { useTranslation } from 'react-i18next';

interface AddRefiningStepButton {
  setIsSaved: (value: boolean) => void;
  setComponentAction: (value: string) => void;
  cardEdit: Array<any>;
  componentAction: string;
  dataList: Array<any>;
  steps: any;
}
const AddRefiningStepButton = ({
  setIsSaved,
  setComponentAction,
  cardEdit,
  componentAction,
  dataList,
  steps,
}: AddRefiningStepButton) => {
  const { t } = useTranslation();
  return (
    <div style={{ display: 'flex', justifyContent: 'end' }}>
      <button
        onClick={() => {
          setIsSaved(false);
          setComponentAction('AddRefiningStep');
        }}
        style={{
          border: '1px solid #CDD0D1',
          fontWeight: 700,
          fontSize: '14px',
          borderRadius: '4px',
          padding: '8px 16px 8px 16px',
          color: '#fff',
          backgroundColor: '#0D659E',
        }}
        // className={componentAction==="EditStep" ? 'opacity-50' : "" }
        className={cardEdit.length && componentAction === 'EditStep' ? 'opacity-50' : ''}
        type='button'
        disabled={
          dataList.length + 1 === steps.option.length ||
          (componentAction === 'EditStep' && cardEdit.length > 0)
        }
      >
        + {t('systemAdmin.furnaceConfiguration.addRefiningStep')}
      </button>
    </div>
  );
};

export default AddRefiningStepButton;
