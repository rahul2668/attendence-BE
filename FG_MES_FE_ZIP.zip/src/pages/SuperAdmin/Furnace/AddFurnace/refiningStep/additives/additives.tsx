import InputField from 'components/common/InputWithIcon';
import CustomSelect from 'components/common/SelectField';
import { useTranslation } from 'react-i18next';
import { FieldUnit } from 'types/unit.model';

interface AddAdditives {
  additiveData: Array<any>;
  isAdd: boolean;
  handleInputChange: (e: any, value: number, type: string) => void;
  allUnits: Array<any>;
  additive: any;
  handleAdditivesChange: (value: string, def: string, type: string) => void;
  additiveList: Array<any>;
  handleAddAdditive: () => void;
  additives: Array<any>;
  setAdditiveDeleteModal: (value: any) => void;
  setShowAdditiveTooltip: (value: string | number) => void;
  showAdditiveTooltip: number;
}

const AddAdditives = ({
  additiveData,
  isAdd,
  handleInputChange,
  allUnits,
  additive,
  handleAdditivesChange,
  additiveList,
  handleAddAdditive,
  additives,
  setAdditiveDeleteModal,
  setShowAdditiveTooltip,
  showAdditiveTooltip,
}: AddAdditives) => {
  const { t } = useTranslation();
  return (
    <div className='additives'>
      <p className='additives__title mb-4'>
        {' '}
        {`${t('systemAdmin.furnaceConfiguration.additives')}`}{' '}
      </p>

      <div className='additives__additive_container'>
        {additiveData.map((val: any, index: any) => (
          <div
            key={val.id}
            className='additives__container'
            style={{
              width: val.type !== 'select' && val.type !== 'input' ? '150px' : '255px',
            }}
          >
            <label className='input-field-label font-semibold'>{val.label}</label>
            {val.type === 'input' && (
              <InputField
                type={'number'}
                icon={val.icon}
                value={(isAdd && additive.quantity) || ''}
                onChange={(value: any) => {
                  const regex = /^\d{0,5}(\.\d{1,3})?$/;
                  if (regex.test(value) || value === '') {
                    handleAdditivesChange(value, 'input', 'add');
                  }
                }}
              />
            )}
            {val.type === 'select' && (
              <CustomSelect
                index={index}
                options={val.option.filter(
                  (option: any) => !additiveList?.some((item: any) => item.material == option.value)
                )}
                onChange={(value: any) => handleAdditivesChange(value, 'select', 'add')}
                value={
                  (isAdd &&
                    val.option.filter((item: any) => item.value == additive.material)[0]?.option) ||
                  t('sharedTexts.select')
                }
              />
            )}
            {val.type === 'add-button' ? (
              <button
                className={`${
                  additive.material && additive.quantity
                    ? 'additives__add_container '
                    : 'additives__add_container additives__disabledbtn'
                }`}
                style={{ border: '0px' }}
                type='button'
                onClick={handleAddAdditive}
                onKeyDown={(event) => {
                  event.key === 'Enter' && handleAddAdditive();
                }}
              >
                <svg
                  xmlns='http://www.w3.org/2000/svg'
                  width='40'
                  height='40'
                  fill='#fff'
                  className='bi bi-plus'
                  viewBox='0 0 16 16'
                >
                  <path d='M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4' />
                </svg>
              </button>
            ) : null}
          </div>
        ))}
      </div>

      <div className='control_parameters__list_container'>
        {additiveList?.length > 0 && (
          <table className='control_parameters__table'>
            <tr>
              <th className='control_parameters__table_head '>Material</th>
              <th className='control_parameters__table_head'>Quantity</th>
              <th></th>
            </tr>

            {additiveList?.map((val: any, index: any) => (
              <tr className='control_parameters__table_data' key={val.material}>
                <td>
                  {additives[0].option.filter((item: any) => item.value == val.material)[0]?.option}
                </td>
                <td>
                  <input
                    type={'number'}
                    className='control_parameters__table_value'
                    onChange={(e) => {
                      const regex = /^\d{0,5}(\.\d{1,3})?$/;
                      if (regex.test(e.target.value) || e.target.value === '') {
                        handleInputChange(e, index, 'additives');
                      }
                    }}
                    value={val.quantity}
                  ></input>
                  <span className='ms-2 fw-semibold' style={{ fontSize: '13px' }}>
                    {
                      allUnits.filter((unitInfo: FieldUnit) => unitInfo.name === 'Quantity')[0]
                        ?.unit
                    }
                  </span>
                </td>
                <td>
                  <button
                    onClick={() =>
                      setAdditiveDeleteModal({
                        bool: true,
                        index: index,
                        mainIndex: null,
                      })
                    }
                    style={{ border: '0px', backgroundColor: '#fff' }}
                    type='button'
                    onKeyDown={(event) => {
                      event.key === 'Enter' &&
                        setAdditiveDeleteModal({
                          bool: true,
                          index: index,
                          mainIndex: null,
                        });
                    }}
                    data-toggle='tooltip'
                    data-placement='bottom'
                    onMouseOver={() => setShowAdditiveTooltip(index)}
                    onFocus={() => setShowAdditiveTooltip(index)}
                    onMouseOut={() => setShowAdditiveTooltip('')}
                    onBlur={() => setShowAdditiveTooltip('')}
                  >
                    <svg
                      xmlns='http://www.w3.org/2000/svg'
                      width='17'
                      height='17'
                      fill='#8F1D18'
                      className='bi bi-trash'
                      viewBox='0 0 16 16'
                    >
                      <path d='M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z' />
                      <path d='M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z' />
                    </svg>

                    {showAdditiveTooltip === index ? (
                      <span className='control_parameters__tooltip'>{'Delete'}</span>
                    ) : (
                      ''
                    )}
                  </button>
                </td>
              </tr>
            ))}
          </table>
        )}
      </div>
    </div>
  );
};

export default AddAdditives;
