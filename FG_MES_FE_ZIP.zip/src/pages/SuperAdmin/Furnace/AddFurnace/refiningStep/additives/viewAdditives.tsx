import { useTranslation } from 'react-i18next';

interface ViewAdditives {
  additives: Array<any>;
  isEdit: boolean;
  item: any;
}

const ViewAdditives = ({ additives, isEdit, item }: ViewAdditives) => {
  const { t } = useTranslation();
  return (
    <div>
      <label
        htmlFor=''
        style={{
          color: '#04436B',
          fontSize: '16px',
          fontWeight: 600,
        }}
      >
        {!isEdit && item.additives?.filter((item: any) => item.record_status === true).length === 0
          ? `${t('systemAdmin.furnaceConfiguration.additives')}`
          : ''}
        {item.additives?.filter((item: any) => item.record_status === true).length > 0
          ? `${t('systemAdmin.furnaceConfiguration.additives')}`
          : ''}
      </label>
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '40px',
        }}
      >
        {item.additives.map((val: any) =>
          val.record_status || !Object.hasOwn(val, 'record_status') ? (
            <div
              key={val.material}
              style={{
                display: 'flex',
                alignItems: 'center',
              }}
            >
              <p
                style={{
                  fontSize: '14px',
                  fontWeight: 600,
                }}
              >
                {additives[0].option.filter((item: any) => item.value == val.material)[0]?.option}
              </p>
              <hr
                style={{
                  transform: 'rotate(90deg)',
                  border: '1px solid',
                  width: '20px',
                }}
              />
              <p
                style={{
                  fontSize: '14px',
                  fontWeight: 600,
                }}
              >
                Qty: {val.quantity}
                <span className='ms-1 fw-semibold' style={{ fontSize: '13px' }}>
                  {val?.icon}
                </span>
              </p>
            </div>
          ) : (
            ''
          )
        )}
      </div>
    </div>
  );
};

export default ViewAdditives;
