import InputField from 'components/common/InputWithIcon';
import CustomSelect from 'components/common/SelectField';
import { useTranslation } from 'react-i18next';
import { FieldUnit } from 'types/unit.model';

interface EditAdditives {
  additiveData: Array<any>;
  isAdd: boolean;
  allUnits: Array<any>;
  additive: any;
  handleAdditivesChange: (value: string, type: string) => void;
  setAdditiveDeleteModal: (value: any) => void;
  setShowAdditiveTooltip: (value: string | number) => void;
  showAdditiveTooltip: number;
  dataList: Array<any>;
  item: any;
  handleEditAdditive: (value: number) => void;
  index: number;
  handleEditInputChange: (e: any, index: number, value: string, type: string) => void;
}

const EditAdditives = ({
  additiveData,
  isAdd,
  allUnits,
  additive,
  handleAdditivesChange,
  setAdditiveDeleteModal,
  setShowAdditiveTooltip,
  showAdditiveTooltip,
  dataList,
  item,
  handleEditAdditive,
  index,
  handleEditInputChange,
}: EditAdditives) => {
  const { t } = useTranslation();
  return (
    <div>
      <label
        htmlFor='Additives'
        style={{
          color: '#04436B',
          fontSize: '16px',
          fontWeight: 600,
          paddingBottom: '16px',
        }}
      >
        {`${t('systemAdmin.furnaceConfiguration.additives')}`}
      </label>
      <div className='additives__additive_container'>
        {additiveData.map((val: any, i: any) => (
          <div
            key={val.id}
            className='additives__container'
            style={{
              width: val.type !== 'select' && val.type !== 'input' ? '150px' : '255px',
            }}
          >
            <label className='input-field-label font-semibold'>{val.label}</label>
            {val.type === 'input' && (
              <InputField
                type={'number'}
                icon={val.icon}
                value={!isAdd ? additive.quantity : ''}
                onChange={(value: any) => {
                  const regex = /^\d{0,5}(\.\d{1,3})?$/;
                  if (regex.test(value) || value === '') {
                    handleAdditivesChange(value, 'input');
                  }
                }}
              />
            )}
            {val.type === 'select' && (
              <CustomSelect
                index={i}
                options={val.option.filter((option: any) => {
                  // Check if option value is not present in any control parameter in dataList
                  return !dataList.some(
                    (items: any) =>
                      items.additives.some(
                        (e: any) => e.material == option.value && e.record_status
                      ) && items.step == item.step
                  );
                })}
                onChange={(value: any) => handleAdditivesChange(value, 'select')}
                value={
                  val.option.filter((item: any) => item.value == additive.material && !isAdd)[0]
                    ?.option || t('sharedTexts.select')
                }
              />
            )}
            {val.type === 'add-button' ? (
              <button
                type='button'
                style={{ border: '0px' }}
                className={`${
                  additive.material && additive.quantity
                    ? 'additives__add_container '
                    : 'additives__add_container additives__disabledbtn'
                }`}
                onClick={() => handleEditAdditive(index)}
                onKeyDown={(event) => {
                  event.key === 'Enter' && handleEditAdditive(index);
                }}
              >
                <svg
                  xmlns='http://www.w3.org/2000/svg'
                  width='40'
                  height='40'
                  fill='#fff'
                  className='bi bi-plus'
                  viewBox='0 0 16 16'
                >
                  <path d='M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4' />
                </svg>
              </button>
            ) : null}
          </div>
        ))}
      </div>

      {item.additives.length > 0 && (
        <div className='control_parameters__list_container'>
          {item.additives.filter((item: any) => item.record_status === true)?.length > 0 && (
            <table className='control_parameters__table'>
              <tr>
                <th className='control_parameters__table_head '> {t('reports.material')}</th>
                <th className='control_parameters__table_head'>
                  {t('systemAdmin.furnaceConfiguration.quality')}
                </th>
                <th></th>
              </tr>

              {[...item.additives]?.map((val: any, i: any) =>
                val.record_status || !Object.hasOwn(val, 'record_status') ? (
                  <tr key={val.material} className='control_parameters__table_data'>
                    <td>
                      {additiveData[0].option.filter((item: any) => item.value == val.material)[0]
                        ?.option ?? val.material_value}
                    </td>
                    <td>
                      <input
                        type={'number'}
                        onChange={(e) => {
                          const regex = /^\d{0,5}(\.\d{1,3})?$/;
                          if (regex.test(e.target.value) || e.target.value === '') {
                            handleEditInputChange(e, i, item.step, 'additives');
                          }
                        }}
                        value={val.quantity}
                        className='control_parameters__table_value'
                      ></input>
                      <span className='ms-2 fw-semibold' style={{ fontSize: '13px' }}>
                        {
                          allUnits.filter((unitInfo: FieldUnit) => unitInfo.name === 'Quantity')[0]
                            ?.unit
                        }
                      </span>
                    </td>

                    <td>
                      <button
                        type='button'
                        style={{ border: '0px', backgroundColor: '#fff' }}
                        onClick={() =>
                          setAdditiveDeleteModal({
                            bool: true,
                            index: i,
                            mainIndex: index,
                          })
                        }
                        data-toggle='tooltip'
                        data-placement='bottom'
                        onMouseOver={() => setShowAdditiveTooltip(i)}
                        onMouseOut={() => setShowAdditiveTooltip('')}
                        onFocus={() => setShowAdditiveTooltip(i)}
                        onBlur={() => setShowAdditiveTooltip('')}
                      >
                        <svg
                          xmlns='http://www.w3.org/2000/svg'
                          width='17'
                          height='17'
                          fill='#8F1D18'
                          className='bi bi-trash'
                          viewBox='0 0 16 16'
                        >
                          <path d='M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z' />
                          <path d='M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z' />
                        </svg>

                        {showAdditiveTooltip === i ? (
                          <span className='control_parameters__tooltip'>{'Delete'}</span>
                        ) : (
                          ''
                        )}
                      </button>
                    </td>
                  </tr>
                ) : (
                  ''
                )
              )}
            </table>
          )}
        </div>
      )}
    </div>
  );
};

export default EditAdditives;
