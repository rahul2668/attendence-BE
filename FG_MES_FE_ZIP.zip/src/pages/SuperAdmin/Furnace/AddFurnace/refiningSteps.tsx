import 'assets/styles/scss/pages/furnace.scss';
import { useEffect, useState } from 'react';
import PlantFooter from 'components/common/PlantFooter';
import { useFormik } from 'formik';
import * as yup from 'yup';
import { DragDropContext, Draggable, Droppable } from 'react-beautiful-dnd';
import gridDots from '../../../../assets/icons/gridDots.svg';
import info from '../../../../assets/icons/info.svg';
import editIcon from '../../../../assets/icons/edit1.svg';
import { useNavigate } from 'react-router-dom';
import { notify } from 'utils/utils';
import Loading from 'components/common/Loading';
import httpClient from 'http/httpClient';
import AlertModal from 'components/Modal/AlertModal';
import IconToolTip from 'components/common/Tooltip';
import { useAppSelector } from 'store';
import AddAdditives from './refiningStep/additives/additives';
import AddControlParameters from './refiningStep/controlParameters/controlParameters';
import EditControlParameters from './refiningStep/controlParameters/editControlParameters';
import EditAdditives from './refiningStep/additives/editAdditives';
import ViewControlParameters from './refiningStep/controlParameters/viewControlParameters';
import ViewAdditives from './refiningStep/additives/viewAdditives';
import RefiningStepModal from './refiningStep/refiningStepModal';
import StepSelector from './refiningStep/common/stepSelector';
import AddRefiningStepButton from './refiningStep/common/addButton';
import { useTranslation } from 'react-i18next';
import { Box } from '@mui/material';
import _ from 'lodash';

const formValidationSchema = yup.object({});

const RefiningSteps = ({ addId, edit_Id }: any) => {
  const [enabled, setEnabled] = useState<any>(false);
  const [isEdit, setIsEdit] = useState<any>(!!edit_Id);

  const { t } = useTranslation();

  const [controlParameters, setControlParameters] = useState<any>({
    param: '',
    value: '',
    is_mandatory: false,
    icon: '',
  });
  const [additive, setAdditive] = useState<any>({ material: '', quantity: '', icon: 'lb/ton' });
  const [controlParametersList, setControlParametersList] = useState<any>([]);
  const [isAdd, setIsAdd] = useState<boolean>(false);
  const [additiveList, setAdditiveList] = useState<any>([]);
  const [isSaved, setIsSaved] = useState<any>(true);
  const [dataList, setDataList] = useState<any>([]);
  const [showDragDeleteTooltip, setShowDragDeleteTooltip] = useState<any>('');
  const [showInfoTooltip, setShowInfoTooltip] = useState<any>('');
  const [showControlParametersTooltip, setShowControlParametersTooltip] = useState<any>('');
  const [showAdditiveTooltip, setShowAdditiveTooltip] = useState<any>('');
  const [cardEdit, setCardEdit] = useState<any>([]);
  const [masterData, setMasterData] = useState<any>([]);
  const [editId, setEditId] = useState<any>(edit_Id);
  const [loading, setLoading] = useState<any>(true);
  const [isHoverEditIconTooltip, setIsHoverEditIconTooltip] = useState<any>('');
  const [componentAction, setComponentAction] = useState<string>('');
  const [isAdded, setIsAdded] = useState<boolean>(false);
  const [isAddEditMode, setIsAddEditMode] = useState<boolean>(false);
  const [disableButtonFlag, setDisableButtonFlag] = useState<boolean>(false);
  const [currentEditedStepIndex, setCurrentEditedStepIndex] = useState<any>()
  const navigate = useNavigate();
  const [deleteModal, setDeleteModal] = useState<any>({ bool: false, index: 0 });
  const [additiveDeleteModal, setAdditiveDeleteModal] = useState<any>({
    bool: false,
    index: 0,
    mainIndex: null,
  });
  const [controlParameterDeleteModal, setControlParameterDeleteModal] = useState<any>({
    bool: false,
    index: 0,
    mainIndex: null,
  });
  const allUnits = useAppSelector((state: any) => state?.unit?.units);

  const handleAddList = (values: any) => {
    if (isEdit) {
      setDataList([...dataList, values]);
    } else {
      const index: number = dataList.findIndex((item: any) => item.step === values.step);
      if (index !== -1) {
        dataList[index] = values;
      } else {
        dataList.push(values);
      }
      setDataList([...dataList]);
    }
  };

  const { handleSubmit, values, setFieldValue } = useFormik({
    initialValues: {
      step: '',
      controlParameters: [],
      additives: [],
    },
    validationSchema: formValidationSchema,
    onSubmit: async (values, { resetForm }) => {
      setIsAddEditMode(false);
      setComponentAction('');
      if (!isSaved) {
        if (values.step) {
          handleAddList(values);
        } else {
          setDataList([...dataList]);
        }
      }
      if (isEdit) {
        if (!isSaved) {
          if (values.step) {
            handleEditSubmit([...dataList, { ...values, order: dataList.length + 1 }]);
          } else {
            handleEditSubmit([...dataList]);
          }
        } else {
          handleEditSubmit(dataList);
        }
      } else if (isSaved) {
        setLoading(true);
        const response: any = await httpClient.post(`/api/furnace-config/refining-steps/${addId}`, {
          data: { step_data: dataList },
        });
        if (response.status == 201) {
          setLoading(false);
          navigate(`/system-admin/furnace-configuration/list`);
          notify('success', t(response.data.message));
        } else {
          setLoading(false);
        }
      }
      setIsSaved(true);
      setControlParametersList([]);
      setAdditiveList([]);
      setIsAdded(false);
      // navigate(`/system-admin/furnace-configuration/view/${viewId}/1`)
      // navigate(`/system-admin/furnace-configuration/list`)

      resetForm();
    },
  });
  const filterUnitvalue = (name: string) => {
    try {
      return allUnits?.filter((item: any) => item?.name === name)[0]['unit'];
    } catch (error) {
      return '';
    }
  };

  const getEditData = async () => {
    const refiningStepsResponse: any = await httpClient.get(
      `/api/furnace-config/refining-steps/${editId}/`
    );
    setLoading(false);
    const filteredItems = allUnits?.filter((item: any) => item.name === 'Quantity');
    let convertedData = refiningStepsResponse.data.data.map((item: any) => ({
      step: parseInt(item.step),
      id: item.id,
      order: item.order,
      controlParameters: item.control_parameters.map((controlParam: any) => ({
        param: parseInt(controlParam.param),
        value: controlParam.value.toString(),
        icon: filterUnitvalue(controlParam?.param_value),
        is_mandatory: controlParam.is_mandatory,
        furnace_config_step: controlParam.furnace_config_step,
        id: controlParam.id,
        record_status: controlParam.record_status,
      })),
      additives: item.additives.map((additive: any) => ({
        material: additive.material,
        icon: filteredItems && filteredItems.length > 0 ? filteredItems[0]['unit'] : '',
        quantity: additive.quantity.toString(),
        furnace_config_step: additive.furnace_config_step,
        id: additive.id,
        record_status: additive.record_status,
      })),
    }));

    // if an object in api resp is not there in previous main state, its a deleted one. the only way it should pop is on component mount
    // therefore remove it from intermitten api response data
    if (dataList?.length > 0) {
      // Extract ids from dataList(mainstate) into a set for quick lookup
      const idsInMainState = new Set(_.map(dataList, 'id'));
      // Filter convertedData based on the presence of ids in dataList
      convertedData = _.filter(convertedData, (obj) => idsInMainState.has(obj.id));
    }

    setDataList(convertedData);
  };
  useEffect(() => {
    if (isEdit) {
      getEditData();
    }
  }, []);

  const fetchData = async () => {
    try {
      const masterResponse: any = await httpClient.get('/api/master/master/');

      const masterResponseList: any = masterResponse?.data?.map((val: any) => {
        const translationKey: any = `systemAdmin.furnaceConfiguration.${val.value}`;
        const translatedString = t(translationKey);

        // If the translation exists, `translatedString` will be the translated value,
        // otherwise, it will be the same as `translationKey`
        const displayString = translatedString !== translationKey ? translatedString : val.value;
        const list = {
          option: displayString,
          value: val.id,
          type: val.category,
        };
        return list;
      });
      setMasterData(masterResponseList);
    } catch (error) {
      // Handle errors here
      console.error('Error fetching data:', error);
    }
  };

  useEffect(() => {
    if (masterData) {
      setAdditiveData([...additives]);
    }
  }, [masterData]);

  useEffect(() => {
    fetchData();
  }, []);
  const createOptions = (masterData: any, type: any) => [
    { option: t('sharedTexts.select'), value: 'Select' },
    ...(masterData?.filter((val: any) => val?.type === type) || []),
  ];
  const steps = {
    label: `${t('systemAdmin.furnaceConfiguration.step')}`,
    option: createOptions(masterData, 'STEPS'),
    name: 'step',
  };

  const control_parameters: any = [
    {
      id: 1,
      option: createOptions(masterData, 'CONTROLPARAMETERS'),
      type: 'select',
    },
    { id: 2, type: 'input', icon: '' },
    { id: 3, type: 'toggle' },
    { id: 4, type: 'add-button' },
  ];

  const additives: any = [
    {
      id: 1,
      label: `${t('reports.material')}`,
      option: createOptions(masterData, 'ADDITIVES'),
      type: 'select',
    },
    { id: 2, label: `${t('systemAdmin.furnaceConfiguration.quality')}`, type: 'input', icon: '' },
    { id: 3, type: 'add-button' },
  ];
  const [controlParameterData, setControlParameterData] = useState([...control_parameters]);
  const [additiveData, setAdditiveData] = useState([...additives]);
  useEffect(() => {
    if (masterData?.length > 0) getUnit();
  }, [masterData]);
  const getUnit = async () => {
    setLoading(false);
    setControlParameterData([...control_parameters]);
    const filterValue = allUnits.filter((item: any) => item.name === 'Quantity')[0]['unit'];
    const updatedData = additives.map((item: any) => ({
      ...item,
      icon: filterValue,
    }));
    setAdditiveData([...updatedData]);

    // setAdditiveData([...additives])
  };

  const filterByValue = (array: any[], value: number | string) => {
    return array.filter((item) => item.value === value);
  };
  const filterUnit = (name: string) => {
    return allUnits.filter((item: any) => item.name === name);
  };
  const handleControlParametersChange = (value: any, type: any, action = '', val = null) => {
    let filterValue = '';
    if (val) {
      filterValue = filterUnit(filterByValue(val, value)?.[0]?.['option'])?.[0]?.['unit'];
      const updatedData = controlParameterData.map((item) => ({
        ...item,
        icon: filterValue,
      }));
      setControlParameterData(updatedData);
    }
    if (type === 'select') {
      setControlParameters({
        param: value,
        value: controlParameters.value,
        is_mandatory: controlParameters.is_mandatory,
        icon: filterValue,
      });
    } else if (type == 'input') {
      setControlParameters({
        param: controlParameters.param,
        value: value,
        is_mandatory: controlParameters.is_mandatory,
        icon: controlParameters.icon,
      });
    } else {
      setControlParameters({
        param: controlParameters.param,
        value: controlParameters.value,
        is_mandatory: value,
        icon: controlParameters.icon,
      });
    }
    const added: boolean = action == 'add' || false;
    setIsAdd(added);
  };

  const handleAdditivesChange = (value: any, type: any, action = '') => {
    let filterValue = 'lb/t';
    if (type === 'select') {
      filterValue = allUnits.filter((item: any) => item.name === 'Quantity')[0]['unit'];
      const updatedData = additiveData.map((item) => ({
        ...item,
        icon: filterValue,
      }));
      setAdditiveData(updatedData);

      setAdditive({ material: value, quantity: additive.quantity, icon: filterValue });
    } else if (type == 'input') {
      setAdditive({ material: additive.material, quantity: value, icon: additive.icon });
    }
    const added: boolean = action == 'add' || false;
    setIsAdd(added);
  };

  const handleAddControlParameters = () => {
    if (controlParameters.param && controlParameters.value) {
      setIsAdded(true);
      const newControlParametersList = [...controlParametersList, controlParameters];
      setControlParametersList(newControlParametersList);
      setFieldValue('controlParameters', newControlParametersList);
      setControlParameters({ param: '', value: '', is_mandatory: false, icon: '' });

      setEnabled(false);
    }
    const updatedData = controlParameterData.map((item) => ({
      ...item,
      icon: '',
    }));
    setControlParameterData(updatedData);
  };

  const handleAddAdditive = () => {
    if (additive.material && additive.quantity) {
      const newAdditiveList = [...additiveList, additive];
      setAdditiveList(newAdditiveList);
      setFieldValue('additives', newAdditiveList);
      setAdditive({ material: '', quantity: '', icon: '' });
    }
  };

  const handleEditControlParameters = (index: any) => {
    if (isEdit && cardEdit.length > 0) {
      if (controlParameters.param && controlParameters.value) {
        const newControlParametersList = [...dataList];

        newControlParametersList.map((val: any, i: any) => {
          if (index == i) {
            const newArray = val.controlParameters.push({
              ...controlParameters,
              record_status: true,
            });
            return newArray;
          }
          return val;
        });

        setDataList(newControlParametersList);
        setControlParameters({ param: '', value: '', is_mandatory: false, icon: '' });
        setEnabled(false);
      }
    }
  };

  const handleEditAdditive = (index: any) => {
    if (isEdit && cardEdit.length > 0) {
      if (additive.material && additive.quantity) {
        const newAdditiveList = [...dataList];

        newAdditiveList.map((val: any, i: any) => {
          if (index == i) {
            const newArray = val.additives.push({ ...additive, record_status: true });
            return newArray;
          }
          return val;
        });
        setDataList(newAdditiveList);
        setAdditive({ material: '', quantity: '', icon: '' });
      }
    }
  };

  const handleRemoveControlParameters = (index: any, mainIndex = null) => {
    if (!isEdit) {
      const arrayToRemove = [...controlParametersList];
      arrayToRemove.splice(index, 1);
      setControlParametersList(arrayToRemove);
      setFieldValue('controlParameters', arrayToRemove);
    } else if (isEdit) {
      const arrayToRemove = [...dataList];
      const editedArray = arrayToRemove.map((val: any, i: any) => {
        if (i === mainIndex && val.controlParameters[index]) {
          val.controlParameters[index].record_status = false;
        }
        return val;
      });
      const controlParametersArrayToRemove = [...controlParametersList];
      controlParametersArrayToRemove.splice(index, 1);
      setControlParametersList(controlParametersArrayToRemove);
      setFieldValue('controlParameters', controlParametersArrayToRemove);
      setDataList(editedArray);
    }
  };

  const handleRemoveAdditiveList = (index: any, mainIndex = null) => {
    if (!isEdit) {
      const arrayToRemove = [...additiveList];
      arrayToRemove.splice(index, 1);
      setAdditiveList(arrayToRemove);
      setFieldValue('additives', arrayToRemove);
    } else if (isEdit) {
      const arrayToRemove = [...dataList];
      const editedArray = arrayToRemove.map((val: any, i: any) => {
        if (i === mainIndex && val.additives[index]) {
          val.additives[index].record_status = false;
        }
        return val;
      });

      const additiveArrayToRemove = [...additiveList];
      additiveArrayToRemove.splice(index, 1);
      setAdditiveList(additiveArrayToRemove);
      setFieldValue('additives', additiveArrayToRemove);

      setDataList(editedArray);
    }
  };

  const handleRemoveDataList = (index: any) => {
    const arrayToRemove = [...dataList];
    arrayToRemove.splice(index, 1);
    setDataList(arrayToRemove);
  };

  const handleDragEnd = (result: any) => {
    if (!result.destination) return;

    const updatedCards = [...dataList];
    const [reorderedCard] = updatedCards.splice(result.source.index, 1);
    updatedCards.splice(result.destination.index, 0, reorderedCard);

    const updatedDataList = updatedCards.map((card: any, index: any) => ({
      ...card,
      order: index + 1, // Assuming order starts from 1
    }));

    setDataList(updatedDataList);
  };

  const handleEditSubmit = async (values: any) => {
    setLoading(true);
    const response: any = await httpClient.put(`/api/furnace-config/refining-steps/${editId}`, {
      data: {
        step_data: values,
      },
    });
    setLoading(false);
    if (response.status == 200) {
      navigate('/system-admin/furnace-configuration/list');
      notify('success', `${t(response.data.message)}`);
    } else {
      notify('error', response.statusText);
    }
    setCardEdit([]);
  };

  const handleInputChange = (event: any, index: any, category: any) => {
    const newValue = event.target.value;

    if (category == 'controlParameters') {
      const newControlParametersList = [...controlParametersList];

      newControlParametersList.map((val: any, i: any) => {
        if (index == i) {
          const newArray = (val.value = newValue);
          return newArray;
        }
        return val;
      });
      setControlParametersList(newControlParametersList);
      setFieldValue('controlParameters', newControlParametersList);
    } else if (category == 'additives') {
      const newAdditiveList = [...additiveList];

      newAdditiveList.map((val: any, i: any) => {
        if (index == i) {
          const newArray = (val.quantity = newValue);
          return newArray;
        }
        return val;
      });
      setAdditiveList(newAdditiveList);
      setFieldValue('additives', newAdditiveList);
    }
  };

  const handleToggleChange = (value: any, index: any, category: any) => {
    const newValue = value;
    if (category == 'controlParameters') {
      const newControlParametersList = [...controlParametersList];

      newControlParametersList.map((val: any, i: any) => {
        if (index == i) {
          const newArray = (val.is_mandatory = newValue);
          return newArray;
        }
        return val;
      });
      setControlParametersList(newControlParametersList);
      setFieldValue('controlParameters', newControlParametersList);
    }
  };

  const handleEditInputChange = (event: any, index: any, step: any, category: any) => {
    const newValue = event.target.value;
    if (category == 'controlParameters') {
      const newControlParametersList = [...dataList];

      newControlParametersList.map((val: any) => {
        if (step == val.step) {
          const newArray = (val.controlParameters[index].value = newValue);
          return newArray;
        }
        return val;
      });

      setDataList(newControlParametersList);
    } else if (category == 'additives') {
      const newAdditiveList = [...dataList];

      newAdditiveList.map((val: any) => {
        if (step == val.step) {
          const newArray = (val.additives[index].quantity = newValue);
          return newArray;
        }
        return val;
      });
      setDataList(newAdditiveList);
    }
  };
  const handleEditToggleChange = (value: any, index: any, step: any, category: any) => {
    const newValue = value;
    if (category == 'controlParameters') {
      const newControlParametersList = [...dataList];

      newControlParametersList.map((val: any) => {
        if (step == val.step) {
          const newArray = (val.controlParameters[index].is_mandatory = newValue);
          return newArray;
        }
        return val;
      });

      setDataList(newControlParametersList);
    } else if (category == 'additives') {
      const newAdditiveList = [...dataList];

      newAdditiveList.map((val: any) => {
        if (step == val.step) {
          const newArray = (val.additives[index].quantity = newValue);
          return newArray;
        }
        return val;
      });
      setDataList(newAdditiveList);
    }
  };
  useEffect(() => {
    if (edit_Id) {
      setIsEdit(true);
      setEditId(edit_Id);
    }
  }, []);

  useEffect(() => {
    if (componentAction === 'AddRefiningStep') {
      setDisableButtonFlag(checkStateForEmtpyFieldsInAddModal(controlParametersList, additiveList));
    } else if (componentAction === 'EditStep') {
      setDisableButtonFlag(checkStateForEmtpyFieldsInEditModal(dataList[currentEditedStepIndex]))  
    }
  }, [dataList, controlParametersList, additiveList]);

  const checkStateForEmtpyFieldsInAddModal = (
    controlParametersList: any[],
    additiveList: any[]
  ) => {
    const hasEmptyValueInParams = _.some(controlParametersList, (param: any) =>
      _.isEmpty(param.value)
    );
    const hasEmptyQuantityInAdditives = _.some(additiveList, (additive: any) =>
      _.isEmpty(additive.quantity)
    );
    return hasEmptyValueInParams || hasEmptyQuantityInAdditives;
  };

  const checkStateForEmtpyFieldsInEditModal = (dataList: any) => {   
    const hasEmptyValueInParams = _.some(dataList.controlParameters, (param: any) => {
      return param.record_status && _.isEmpty(param.value);
    });
    const hasEmptyQuantityInAdditives = _.some(dataList.additives, (additive: any) => {
      return additive.record_status && _.isEmpty(additive.quantity);
    });
    return hasEmptyValueInParams || hasEmptyQuantityInAdditives;
  };

  const saveDisableValidation = (data: any) => {
    // Check if all objects in either additives or controlParameters have record_status set to false
    const allRecordStatusFalse = data.some((item: any) => {
      // Check record_status in controlParameters
      const controlParams = item.controlParameters || [];
      const controlParamsAllFalse =
        controlParams.length > 0
          ? controlParams.every((param: any) => !param.record_status)
          : false;

      // Return true if all objects in both controlParameters and additives have record_status set to false
      return controlParamsAllFalse;
    });

    return allRecordStatusFalse;
  };

  const handleUpdateView = () => {
    getEditData();
  };

  const handleCreateEditMode = (item: any) => {
    setFieldValue('step', item.step);
    setControlParametersList(item.controlParameters);
    setAdditiveList(item.additives);
    setFieldValue('controlParameters', item.controlParameters);
    setFieldValue('additives', item.additives);
    setIsSaved(false);
    setComponentAction('EditStep');
    setIsAddEditMode(true);
  };

  const handleCloseModel = () => {
    setControlParameters({ param: '', value: '', is_mandatory: false, icon: '' });
    setFieldValue('step', '');
    setIsSaved(true);
    setComponentAction('');
    setIsAddEditMode(false);
    setControlParametersList([]);
    setAdditiveList([]);
    setIsAdd(false);
    setIsAdded(false);
  };

  if (loading) return <Loading />;

  return (
    <>
      <div className='tab-container'>
        <form onSubmit={handleSubmit} className='form'>
          <div className='container mt-3 mb-3' style={{ display: 'flex', flexDirection: 'column' }}>
            <div
              className='child-container card'
              style={{ height: 'max-content', flex: 1, border: 0 }}
            >
              {/* <Header isEdit={isEdit} setTab={setTab} /> */}

              <div className='card-body card_body_container'>
                <RefiningStepModal
                  title={`${t('systemAdmin.furnaceConfiguration.addRefiningStep')}`}
                  showModal={!isSaved}
                  closeModal={() => handleCloseModel()}
                  confirmButtonText={`${t('sharedTexts.save')}`}
                  isShowCloseIcon={true}
                  disabled={
                    isEdit
                      ? disableButtonFlag ||
                        saveDisableValidation(dataList) ||
                        (controlParametersList.length < 1 && !isSaved) ||
                        (dataList.length < 1 && controlParametersList.length < 1) ||
                        (!isSaved && values.step && controlParametersList.length < 1)
                      : disableButtonFlag ||
                        (dataList.length < 1 && controlParametersList.length < 1) ||
                        (!isSaved && values.step && controlParametersList.length < 1)
                  }
                >
                  {!isSaved ? (
                    <div className='card-body card_body_container'>
                      <StepSelector
                        steps={steps}
                        dataList={dataList}
                        setFieldValue={setFieldValue}
                        values={values}
                        disabled={isAddEditMode}
                      />
                      <hr className='line_break' />
                      {values.step ? (
                        <>
                          <AddControlParameters
                            controlParameterData={controlParameterData}
                            isAdd={isAdd}
                            controlParameters={controlParameters}
                            handleControlParametersChange={handleControlParametersChange}
                            controlParametersList={controlParametersList}
                            setEnabled={setEnabled}
                            enabled={enabled}
                            handleAddControlParameters={handleAddControlParameters}
                            isAdded={isAdded}
                            control_parameters={control_parameters}
                            handleInputChange={handleInputChange}
                            allUnits={allUnits}
                            handleToggleChange={handleToggleChange}
                            setControlParameterDeleteModal={setControlParameterDeleteModal}
                            setShowControlParametersTooltip={setShowControlParametersTooltip}
                            showControlParametersTooltip={showControlParametersTooltip}
                          />

                          <AddAdditives
                            additiveData={additiveData}
                            isAdd={isAdd}
                            handleInputChange={handleInputChange}
                            allUnits={allUnits}
                            additive={additive}
                            handleAdditivesChange={handleAdditivesChange}
                            additiveList={additiveList}
                            handleAddAdditive={handleAddAdditive}
                            additives={additives}
                            setAdditiveDeleteModal={setAdditiveDeleteModal}
                            setShowAdditiveTooltip={setShowAdditiveTooltip}
                            showAdditiveTooltip={showAdditiveTooltip}
                          />
                        </>
                      ) : (
                        ''
                      )}
                    </div>
                  ) : null}
                </RefiningStepModal>

                <div className='card-body card_body_container'>
                  {isSaved && (
                    <AddRefiningStepButton
                      setIsSaved={setIsSaved}
                      setComponentAction={setComponentAction}
                      cardEdit={cardEdit}
                      componentAction={componentAction}
                      dataList={dataList}
                      steps={steps}
                    />
                  )}
                  {dataList.length > 0 && (
                    <div>
                      <DragDropContext onDragEnd={handleDragEnd}>
                        <Droppable droppableId='cardList'>
                          {(provided) => (
                            <ul {...provided.droppableProps} ref={provided.innerRef}>
                              {dataList.map((item: any, index: any) => (
                                <Draggable
                                  key={item.step}
                                  draggableId={item.step.toString()}
                                  index={index}
                                >
                                  {(provided) => (
                                    <li ref={provided.innerRef} {...provided.draggableProps}>
                                      <div
                                        style={{
                                          boxShadow: '1px 2px 8px 0px #79787852',
                                          marginBottom: '27px',
                                        }}
                                      >
                                        <div
                                          style={{
                                            backgroundColor: '#F5F8FA',
                                            padding: '5px 16px 5px 16px',
                                            display: 'flex',
                                            justifyContent: 'space-between',
                                          }}
                                        >
                                          <div
                                            style={{
                                              display: 'flex',
                                              gap: '10px',
                                              alignItems: 'center',
                                            }}
                                          >
                                            <img
                                              {...provided.dragHandleProps}
                                              src={gridDots}
                                              alt='grid dots'
                                            />
                                            <p style={{ fontWeight: 600, fontSize: '20px' }}>
                                              {
                                                steps?.option.filter(
                                                  (val: any) => val.value == item.step
                                                )[0]?.option
                                              }
                                            </p>
                                            <button
                                              type='button'
                                              style={{
                                                border: '0px solid',
                                                backgroundColor: '#f0ffff00',
                                              }}
                                              onMouseOver={() => setShowInfoTooltip(index)}
                                              onMouseOut={() => setShowInfoTooltip('')}
                                              onFocus={() => setShowInfoTooltip(index)}
                                              onBlur={() => setShowInfoTooltip('')}
                                            >
                                              <img
                                                src={info}
                                                alt='info'
                                                width='21px'
                                                height='21px'
                                              />
                                            </button>
                                            {showInfoTooltip === index ? (
                                              <div style={{ position: 'relative' }}>
                                                <span
                                                  style={{
                                                    position: 'absolute',
                                                    top: '10px',
                                                    left: '-15px',
                                                    backgroundColor: '#022549',
                                                    width: '206px',
                                                    padding: '5px',
                                                    color: '#fff',
                                                    fontSize: '14px',
                                                    borderRadius: '4px',
                                                  }}
                                                >
                                                  {'Drag and drop the steps to change their order '}
                                                </span>
                                              </div>
                                            ) : (
                                              ''
                                            )}
                                          </div>

                                          <div
                                            style={{
                                              display: 'flex',
                                              gap: '10px',
                                              alignItems: 'center',
                                            }}
                                          >
                                            {
                                              <div>
                                                <button
                                                  type='button'
                                                  style={{
                                                    border: '0px solid',
                                                    backgroundColor: '#f0ffff00',
                                                  }}
                                                  onClick={() => {
                                                    if (isEdit) {
                                                      cardEdit.includes(item.step)
                                                        ? setCardEdit([])
                                                        : setCardEdit([item.step]);
                                                      setComponentAction('EditStep');
                                                      setCurrentEditedStepIndex(index);
                                                    } else {
                                                      handleCreateEditMode(item);
                                                      setCurrentEditedStepIndex(index);
                                                    }
                                                  }}
                                                  onKeyDown={(event) => {
                                                    event.key === 'Enter' &&
                                                      setCardEdit([...cardEdit, item.step]);
                                                  }}
                                                  onMouseEnter={() =>
                                                    setIsHoverEditIconTooltip(item.step)
                                                  }
                                                  onMouseLeave={() => setIsHoverEditIconTooltip('')}
                                                >
                                                  <img
                                                    src={editIcon}
                                                    alt='edit'
                                                    style={
                                                      componentAction === 'AddRefiningStep'
                                                        ? { opacity: 0.4, pointerEvents: 'none' }
                                                        : {}
                                                    }
                                                  />
                                                </button>
                                                {isHoverEditIconTooltip == item.step && (
                                                  <IconToolTip
                                                    hoverMessage={'Edit'}
                                                    styles={{ left: '-10px' }}
                                                  />
                                                )}
                                              </div>
                                            }
                                            <button
                                              type='button'
                                              style={{
                                                border: '0px solid',
                                                backgroundColor: '#f0ffff00',
                                              }}
                                              data-toggle='tooltip'
                                              data-placement='bottom'
                                              onMouseOver={() => setShowDragDeleteTooltip(index)}
                                              onMouseOut={() => setShowDragDeleteTooltip('')}
                                              onFocus={() => setShowDragDeleteTooltip(index)}
                                              onBlur={() => setShowDragDeleteTooltip('')}
                                            >
                                              <svg
                                                onClick={() => {
                                                  if (dataList.length === 1) {
                                                    notify(
                                                      'warning',
                                                      `${t('systemAdmin.furnaceConfiguration.furnaceConfigurationRequiresAtLeastOneRefiningStep')}`
                                                    );
                                                  } else if (dataList.length > 1) {
                                                    setDeleteModal({ bool: true, index: index });
                                                  }
                                                }}
                                                xmlns='http://www.w3.org/2000/svg'
                                                width='18'
                                                height='18'
                                                fill='#8F1D18'
                                                className='bi bi-trash'
                                                viewBox='0 0 16 16'
                                              >
                                                <path d='M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z' />
                                                <path d='M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z' />
                                              </svg>

                                              {showDragDeleteTooltip === index ? (
                                                <div style={{ position: 'relative' }}>
                                                  <span
                                                    style={{
                                                      position: 'absolute',
                                                      top: '10px',
                                                      right: '-15px',
                                                      backgroundColor: '#022549',
                                                      padding: '5px',
                                                      color: '#fff',
                                                      fontSize: '14px',
                                                      borderRadius: '4px',
                                                    }}
                                                  >
                                                    {'Delete'}
                                                  </span>
                                                </div>
                                              ) : (
                                                ''
                                              )}
                                            </button>
                                          </div>
                                        </div>

                                        {cardEdit.includes(item.step) ? (
                                          <div
                                            style={{
                                              padding: '10px 23px 10px 23px',
                                              display: 'flex',
                                              flexDirection: 'column',
                                              gap: '15px',
                                            }}
                                          >
                                            <RefiningStepModal
                                              title={`Edit Refining Step - ${
                                                steps?.option.filter(
                                                  (val: any) => val.value == item.step
                                                )[0]?.option
                                              }`}
                                              showModal={cardEdit.includes(item.step)}
                                              closeModal={() => {
                                                cardEdit.includes(item.step)
                                                  ? setCardEdit([])
                                                  : setCardEdit([item.step]);
                                                setComponentAction('EditStep');
                                                handleUpdateView();
                                              }}
                                              confirmButtonText={`${t('sharedTexts.saveChanges')}`}
                                              isShowCloseIcon={true}
                                              disabled={
                                                isEdit
                                                  ? disableButtonFlag ||
                                                    saveDisableValidation(dataList) ||
                                                    (dataList.length < 1 &&
                                                      controlParametersList.length < 1) ||
                                                    (!isSaved &&
                                                      values.step &&
                                                      controlParametersList.length < 1)
                                                  : disableButtonFlag ||
                                                    (dataList.length < 1 &&
                                                      controlParametersList.length < 1) ||
                                                    (!isSaved &&
                                                      values.step &&
                                                      controlParametersList.length < 1)
                                              }
                                            >
                                              <div className='d-flex flex-column gap-5'>
                                                <EditControlParameters
                                                  controlParameterData={controlParameterData}
                                                  isAdd={isAdd}
                                                  controlParameters={controlParameters}
                                                  handleControlParametersChange={
                                                    handleControlParametersChange
                                                  }
                                                  setEnabled={setEnabled}
                                                  enabled={enabled}
                                                  control_parameters={control_parameters}
                                                  allUnits={allUnits}
                                                  setControlParameterDeleteModal={
                                                    setControlParameterDeleteModal
                                                  }
                                                  setShowControlParametersTooltip={
                                                    setShowControlParametersTooltip
                                                  }
                                                  showControlParametersTooltip={
                                                    showControlParametersTooltip
                                                  }
                                                  dataList={dataList}
                                                  item={item}
                                                  index={index}
                                                  handleEditControlParameters={
                                                    handleEditControlParameters
                                                  }
                                                  handleEditInputChange={handleEditInputChange}
                                                  handleEditToggleChange={handleEditToggleChange}
                                                />

                                                <EditAdditives
                                                  additiveData={additiveData}
                                                  isAdd={isAdd}
                                                  allUnits={allUnits}
                                                  additive={additive}
                                                  handleAdditivesChange={handleAdditivesChange}
                                                  setAdditiveDeleteModal={setAdditiveDeleteModal}
                                                  setShowAdditiveTooltip={setShowAdditiveTooltip}
                                                  showAdditiveTooltip={showAdditiveTooltip}
                                                  dataList={dataList}
                                                  item={item}
                                                  handleEditAdditive={handleEditAdditive}
                                                  index={index}
                                                  handleEditInputChange={handleEditInputChange}
                                                />
                                              </div>
                                            </RefiningStepModal>
                                          </div>
                                        ) : (
                                          <div
                                            style={{
                                              padding: '10px 23px 10px 23px',
                                              display: 'flex',
                                              flexDirection: 'column',
                                              gap: '15px',
                                            }}
                                          >
                                            {item.controlParameters.length > 0 && (
                                              <ViewControlParameters
                                                controlParameterData={controlParameterData}
                                                item={item}
                                              />
                                            )}
                                            {item.additives.length > 0 && (
                                              <ViewAdditives
                                                additives={additives}
                                                isEdit={isEdit}
                                                item={item}
                                              />
                                            )}
                                          </div>
                                        )}
                                      </div>
                                    </li>
                                  )}
                                </Draggable>
                              ))}
                              {provided.placeholder}
                            </ul>
                          )}
                        </Droppable>
                      </DragDropContext>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
          {
            <Box position='fixed' bottom={0} left={0} right={0}>
              <PlantFooter
                currentTab={2}
                disabled={
                  isEdit
                    ? saveDisableValidation(dataList) ||
                      (dataList.length < 1 && controlParametersList.length < 1) ||
                      (!isSaved && values.step && controlParametersList.length < 1)
                    : (dataList.length < 1 && controlParametersList.length < 1) ||
                      (!isSaved && values.step && controlParametersList.length < 1)
                }
                onback={() => navigate(-1)}
              />
            </Box>
          }
        </form>
      </div>
      <AlertModal
        showModal={deleteModal?.bool}
        closeModal={() => setDeleteModal({ ...deleteModal, bool: false })}
        onConfirmClick={() => {
          setDeleteModal({ ...deleteModal, bool: false });
          handleRemoveDataList(deleteModal.index);
        }}
        content={`${t('systemAdmin.furnaceConfiguration.youAreTryingToDeleteRefiningStepDoYouWantToContinue')}`}
        title={`${t('systemAdmin.furnaceConfiguration.deleteRefiningStep')}`}
        confirmButtonText={`${t('sharedTexts.confirm')}`}
      />
      <AlertModal
        showModal={additiveDeleteModal?.bool}
        closeModal={() => setAdditiveDeleteModal({ ...additiveDeleteModal, bool: false })}
        onConfirmClick={() => {
          setAdditiveDeleteModal({ ...additiveDeleteModal, bool: false });
          handleRemoveAdditiveList(additiveDeleteModal?.index, additiveDeleteModal?.mainIndex);
        }}
        content={`${t('systemAdmin.furnaceConfiguration.youAreTryingToDeleteAdditiveDoYouWantToContinue')}`}
        title={`${t('systemAdmin.furnaceConfiguration.deleteAdditive')}`}
        confirmButtonText={`${t('sharedTexts.confirm')}`}
      />
      <AlertModal
        showModal={controlParameterDeleteModal?.bool}
        closeModal={() =>
          setControlParameterDeleteModal({ ...controlParameterDeleteModal, bool: false })
        }
        onConfirmClick={() => {
          setControlParameterDeleteModal({ ...controlParameterDeleteModal, bool: false });
          handleRemoveControlParameters(
            controlParameterDeleteModal?.index,
            controlParameterDeleteModal?.mainIndex
          );
        }}
        content={`${t('systemAdmin.furnaceConfiguration.youAreTryingToDeleteControlParameterDoYouWantToContinue')}`}
        title={`${t('systemAdmin.furnaceConfiguration.deleteControlParameter')}`}
        confirmButtonText={`${t('sharedTexts.confirm')}`}
      />
    </>
  );
};

export default RefiningSteps;
