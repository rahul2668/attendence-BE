import 'assets/styles/scss/pages/furnace.scss';
import Accordion from 'components/common/Accordion';
import CustomSelect from 'components/common/SelectField';
import { useEffect, useState } from 'react';
import { useFormik } from 'formik';
import * as yup from 'yup';
import PlantFooter from 'components/common/PlantFooter';
import ToggleButton from 'components/common/ToggleButton';
import InputField from 'components/common/InputWithIcon';
import { useNavigate } from 'react-router-dom';
import Loading from 'components/common/Loading';
import httpClient from 'http/httpClient';
import { useGetFurnaceList } from 'hooks/useGetFurnaceList';
import { useAppSelector } from 'store';
import LazyDropDown from 'components/common/LazyDropDown/LazyDropDown';
import GetLazyLoadData from 'store/services/lazyLoadService';
import { useTranslation } from 'react-i18next';
import '../../../../assets/styles/scss/base/global.scss';

const BasicInformation = ({ setTab, setAddId, edit_Id }: any) => {
  const { t } = useTranslation();
  const fetchFurnaceList = useGetFurnaceList();
  const allUnits = useAppSelector((state: any) => state.unit.units);

  const checkDuplicateId = (value: string) => {
    // eslint-disable-next-line react-hooks/rules-of-hooks

    const check = fetchFurnaceList.results.some(
      (item: any) => Number(item.furnace_no) === Number(value) && item.id !== edit_Id
    );
    return check;
  };

  const formValidationSchema = yup.object({
    furnace_no: yup
      .string()
      .required(`${t('systemAdmin.furnaceConfiguration.furnaceNoIsRequired')}`)
      .test(
        'unique',
        `${t('systemAdmin.furnaceConfiguration.furnaceNoAlreadyExists')}`,
        async function (value) {
          return !checkDuplicateId(value); // Assuming this function returns true if ID is duplicate
        }
      ),
    furnace_description: yup
      .string()
      .required(`${t('systemAdmin.furnaceConfiguration.furnaceDescriptionIsRequired')}`),
    workshop: yup
      .number()
      .required(`${t('systemAdmin.furnaceConfiguration.workshopNoIsRequired')}`),
    power_delivery_id: yup
      .number()
      .required(`${t('systemAdmin.furnaceConfiguration.powerDeliveryIsRequired')}`),
    cost_center_id: yup
      .number()
      .required(`${t('systemAdmin.furnaceConfiguration.costCenterIsRequired')}`),
    electrode_type_id: yup
      .number()
      .required(`${t('systemAdmin.furnaceConfiguration.electrodeTypeIsRequired')}`),
    electrodes: yup
      .array()
      .min(3, `${t('systemAdmin.furnaceConfiguration.electrodesIsRequired')}`)
      .of(
        yup.object().shape({
          type: yup.string().required(`${t('systemAdmin.furnaceConfiguration.typeIsRequired')}`),
          core: yup.number().required(`${t('systemAdmin.furnaceConfiguration.coreIsRequired')}`),
          coreMassLength: yup
            .string()
            .required(`${t('systemAdmin.furnaceConfiguration.coreMassPerLengthIsRequired')}`)
            .test('not-zero', t('sharedTexts.enterValidData'), (value) => value !== '0'),
          paste: yup.number().required(`${t('systemAdmin.furnaceConfiguration.pasteIsRequired')}`),
          pasteMassLength: yup
            .string()
            .required(`${t('systemAdmin.furnaceConfiguration.pasteMassPerLengthIsRequired')}`)
            .test('not-zero', t('sharedTexts.enterValidData'), (value) => value !== '0'),
          casing: yup
            .number()
            .required(`${t('systemAdmin.furnaceConfiguration.casingIsRequired')}`),
          casingMassLength: yup
            .string()
            .required(`${t('systemAdmin.furnaceConfiguration.casingMassPerLengthIsRequired')}`)
            .test('not-zero', t('sharedTexts.enterValidData'), (value) => value !== '0'),
        })
      ),
    products: yup.array().min(1, `${t('systemAdmin.furnaceConfiguration.productsIsRequired')}`),
    energy_losses: yup.number().nullable().moreThan(0, t('sharedTexts.enterValidData')),
    joule_losses_coeffient: yup.number().nullable().moreThan(0, t('sharedTexts.enterValidData')),
    default_epi_index: yup.number().nullable().moreThan(0, t('sharedTexts.enterValidData')),
    corrected_reactance_coefficient: yup
      .number()
      .nullable()
      .moreThan(0, t('sharedTexts.enterValidData')),
    design_mv: yup.number().nullable().moreThan(0, t('sharedTexts.enterValidData')),
  });

  const navigate = useNavigate();
  const [electrode, setElectrode] = useState<any>([]);
  const [enabled, setEnabled] = useState<any>(false);
  const [resetProductDropDown, setResetProductDropDown] = useState<boolean>(false);
  const [productIdsToHide, setProductIdsToHide] = useState<number[]>([]); // the selected product codes should be hidden
  const [productSelected, setProductSelected] = useState<any>({
    productState: '',
    productType: '',
    productCode: '',
  });
  const [productList, setProductList] = useState<any>([]);
  // const [productCodeList, setProductCodeList] = useState<any>([]); // replaced with new component
  const [product, setProduct] = useState<any>({
    productState: '',
    productType: '',
    productCode: '',
  });
  const [masterData, setMasterData] = useState<any>([]);
  const [workshopDropdownData, setWorkshopDropdownData] = useState<any>([]);
  const [isEdit, setIsEdit] = useState(!!edit_Id);
  const [editData, setEditData] = useState<any>(null);
  const [editId, setEditId] = useState<any>(edit_Id);
  const [productDataList, setProductDataList] = useState<any>([]);
  const [isTouched, setIsTouched] = useState<any>({
    workshopNo: false,
    powerDelivery: false,
    electrodeType: false,
    electrodes: false,
    costCenter: false,
  });
  const [electrodesList, setElectrodesList] = useState<any>([
    {
      type: 'E1',
      core: '',
      coreMassLength: '',
      paste: '',
      pasteMassLength: '',
      casing: '',
      casingMassLength: '',
    },
    {
      type: 'E2',
      core: '',
      coreMassLength: '',
      paste: '',
      pasteMassLength: '',
      casing: '',
      casingMassLength: '',
    },
    {
      type: 'E3',
      core: '',
      coreMassLength: '',
      paste: '',
      pasteMassLength: '',
      casing: '',
      casingMassLength: '',
    },
  ]);
  const [loading, setLoading] = useState<any>(true);
  // const [dropDownLoading, setDropDownLoading] = useState<any>(false);
  const plantDataString = useAppSelector((state) => state.plantData.plantData);
  const plantData: any = plantDataString ?? null;

  const local_plant_id: any = plantData.plant_id;

  const initialValues = {
    furnace_no: '',
    furnace_description: '',
    workshop: '',
    power_delivery_id: '',
    cost_center_id: '',
    electrode_type_id: '',
    electrodes: [
      {
        type: 'E1',
        core: '',
        coreMassLength: '',
        paste: '',
        pasteMassLength: '',
        casing: '',
        casingMassLength: '',
      },
      {
        type: 'E2',
        core: '',
        coreMassLength: '',
        paste: '',
        pasteMassLength: '',
        casing: '',
        casingMassLength: '',
      },
      {
        type: 'E3',
        core: '',
        coreMassLength: '',
        paste: '',
        pasteMassLength: '',
        casing: '',
        casingMassLength: '',
      },
    ],
    products: [],
    energy_losses: '',
    joule_losses_coeffient: '',
    default_epi_index: '',
    corrected_reactance_coefficient: '',
    design_mv: '',
    silica_fume_default_material_id: '',
    default_moisture: false,
    remelt_id: '',
    sand_id: '',
    ai_id: '',
    lime_id: '',
    slag_id: '',
    skull_id: '',
  };

  function replaceEmptyStringWithNull(obj: any) {
    for (const key in obj) {
      if (typeof obj[key] === 'object' && obj[key] !== null) {
        replaceEmptyStringWithNull(obj[key]);
      } else if (obj[key] === '') {
        obj[key] = null;
      }
    }
  }

  const { handleSubmit, values, handleBlur, handleChange, setFieldValue, touched, errors }: any =
    useFormik({
      initialValues: editData || initialValues,
      validationSchema: formValidationSchema,
      enableReinitialize: true,
      onSubmit: async (values, { resetForm }) => {
        const myObject: { [key: string]: any } = {
          ...values,
        };

        const filteredObject: { [key: string]: any } = {};

        Object.entries(myObject).forEach(([key, value]) => {
          if (value || value === false) {
            filteredObject[key] = value;
          }
        });
        setLoading(true);

        if (!isEdit) {
          const response = await httpClient.post('/api/furnace/furnace-config/', {
            data: {
              ...filteredObject,
              plant_id: local_plant_id,
            },
          });
          if (response.status == 201) {
            const responseData: any = response.data;
            setAddId(responseData.id);
            setTab(2);
          }
        } else {
          delete values.modified_by;
          delete values.modified_at;
          delete values.created_by;
          delete values.created_at;
          replaceEmptyStringWithNull(values);
          const response = await httpClient.put(`/api/furnace-config/basic-info/${editId}/`, {
            data: {
              ...values,
            },
          });
          console.log(response);
          setTab(2);
        }
        setLoading(false);
        setElectrode([]);
        setProductList([]);
        setEnabled(false);
        resetForm();
      },
    });

  useEffect(() => {
    const getEditData = async () => {
      const furnaceConfigResponse: any = await httpClient.get(
        `/api/furnace-config/basic-info/${editId}/`
      );

      const transformData = (inputData: any) => {
        const result = inputData?.reduce((acc: any, item: any) => {
          const productType = {
            option: item.product_type_value,
            value: item.product_type,
          };

          const productCode = {
            option: item.product_code_value,
            value: item.material_master,
          };

          const product = {
            id: item.id,
            productCode,
            record_status: item.record_status,
          };

          const existingProductState = acc.find(
            (entry: any) => entry.productType.option === productType.option
          );

          if (existingProductState) {
            existingProductState.products.push(product);
          } else {
            acc.push({
              productType,
              products: [product],
            });
          }

          return acc;
        }, []);

        return result;
      };

      const transformedData = transformData(furnaceConfigResponse.data.furnace_products);

      const transformElectrodeData = (inputData: any) => {
        const result = inputData.map((item: any) => {
          const transformedItem = {
            id: item.id,
            type: item.electrode_name,
            core: item.core || null,
            coreMassLength: Number(item.core_mass_length.split(' ')[0]) || null,
            paste: item.paste || null,
            pasteMassLength: Number(item.paste_mass_length.split(' ')[0]) || null,
            casing: item.casing || null,
            casingMassLength: Number(item.casing_mass_length.split(' ')[0]) || null,
          };
          return transformedItem;
        });

        return result;
      };

      const transformedElectrodeData = transformElectrodeData(
        furnaceConfigResponse.data.furnace_electrodes
      );

      const editObj: any = {
        ...furnaceConfigResponse.data,
        products: transformedData,
        electrodes: transformedElectrodeData,
        power_delivery_id: furnaceConfigResponse.data.power_delivery,
        cost_center_id: furnaceConfigResponse.data.cost_center,
        electrode_type_id: furnaceConfigResponse.data.electrode_type,
        silica_fume_default_material_id: furnaceConfigResponse.data.silica_fume_default_material,
        slag_product_default_material_id: furnaceConfigResponse.data.slag_product_default_material,
        remelt_id: furnaceConfigResponse.data.remelt,
        sand_id: furnaceConfigResponse.data.sand,
        ai_id: furnaceConfigResponse.data.ai,
        lime_id: furnaceConfigResponse.data.lime,
        slag_id: furnaceConfigResponse.data.slag,
        skull_id: furnaceConfigResponse.data.skull,
      };

      delete editObj.furnace_electrodes;
      delete editObj.furnace_products;
      delete editObj.ai;
      delete editObj.electrode_type;
      delete editObj.lime;
      delete editObj.power_delivery;
      delete editObj.remelt;
      delete editObj.sand;
      delete editObj.silica_fume_default_material;
      delete editObj.skull;
      delete editObj.slag;
      delete editObj.slag_product_default_material;
      delete editObj.workshop_value;
      delete editObj.step2;

      setElectrodesList(editObj.electrodes);
      setProductList(editObj.products);
      setEditData(editObj);
    };

    if (isEdit) {
      getEditData();
    }
  }, [masterData, isEdit, editId]);
  const createOptions = (masterData: any, type: any) => [
    { option: t('sharedTexts.select'), value: 'Select' },
    ...(masterData?.filter((val: any) => val?.type === type) || []),
  ];
  const workshopOptions = (workshopDropdownData: any, type: any) => [
    { option: t('sharedTexts.select'), value: 'Select' },
    ...(workshopDropdownData?.filter((val: any) => val?.type === type) || []),
  ];

  const WorkshopNo = {
    label: `${t('systemAdmin.furnaceConfiguration.workshop')}*`,
    option: workshopOptions(workshopDropdownData, 'WORKSHOPNO'),
  };

  const powerDelivery = {
    label: `${t('systemAdmin.furnaceConfiguration.powerDelivery')}*`,
    option: createOptions(masterData, 'POWERDELIVERY'),
  };

  const costCenter = {
    label: `${t('systemAdmin.furnaceConfiguration.costCenter')}*`,
    option: createOptions(masterData, 'COSTCENTER'),
  };

  const createProductOptions = (productData: any) => [
    { option: t('sharedTexts.select'), value: 'Select' },
    ...(productData?.map((val: any) => {
      return { option: val.name, value: val.id };
    }) || []),
  ];

  const productFields = [
    {
      label: `${t('systemAdmin.furnaceConfiguration.productType')}*`,
      option: createProductOptions(productDataList),
      value: productSelected.productType?.option || t('sharedTexts.select'),
    },
    {
      label: `${t('systemAdmin.furnaceConfiguration.productCode')}*`,
      // option: createProductOptions(productCodeList), //replaced with new component and logic
      value: productSelected.productCode?.option || t('sharedTexts.select'),
    },
  ];

  const createOptionsByType = (masterData: any, type: any) => [
    { option: t('sharedTexts.select'), value: 'Select' },
    ...(masterData.filter((val: any) => val?.type === type) || []),
  ];

  // DO NOT DELETE THIS - NEEDED WHEN UNCOMMENTING Ladle

  // const createOptionsByTypeForLadle = (masterData: any, type: any) => [
  //   { option: 'Select', value: 'Select' },
  //   ...(masterData?.filter((val: any) => val?.type === type) || []),
  // ];

  // const ladleAdditions = [
  //   {
  //     label: 'Remelt',
  //     option: createOptionsByTypeForLadle(masterData, 'REMELT'),
  //     name: 'remelt_id',
  //   },
  //   { label: 'Sand', option: createOptionsByTypeForLadle(masterData, 'SAND'), name: 'sand_id' },
  //   { label: 'AI', option: createOptionsByTypeForLadle(masterData, 'AI'), name: 'ai_id' },
  //   { label: 'Lime', option: createOptionsByTypeForLadle(masterData, 'LIME'), name: 'lime_id' },
  // ];

  const createOptionsByTypeForRecoveries = (masterData: any, type: any) => [
    { option: t('sharedTexts.select'), value: 'Select' },
    ...(masterData?.filter((val: any) => val?.type === type) || []),
  ];

  const recoveries = [
    {
      label: `${t('systemAdmin.furnaceConfiguration.slagProductDefaultMaterial')}`,
      option: createOptionsByTypeForRecoveries(masterData, 'SLAG'),
      name: 'slag_id',
    },
    {
      label: `${t('systemAdmin.furnaceConfiguration.silicaFumeDefaultMaterial')}`,
      option: createOptionsByType(masterData, 'SILICAFUMEDEFAULTMATERIAL'),
      type: 'select',
      name: 'silica_fume_default_material_id',
    },
    {
      label: `${t('systemAdmin.furnaceConfiguration.skullDefaultMaterial')}`,
      option: createOptionsByTypeForRecoveries(masterData, 'SKULL'),
      name: 'skull_id',
    },
  ];

  const core = createOptionsByType(masterData, 'CORE');
  const paste = createOptionsByType(masterData, 'PASTE');
  const casing = createOptionsByType(masterData, 'CASING');
  const [composite, setComposite] = useState<any>([]);
  const [parameters, setParameters] = useState<any>([]);

  const getUnit = async () => {
    const parameterData = [
      {
        label: `${t('systemAdmin.furnaceConfiguration.energyLosses')}`,
        type: 'input',
        icon: '',
        name: 'energy_losses',
      },
      {
        label: `${t('systemAdmin.furnaceConfiguration.jouleLossesCoefficient')}`,
        type: 'input',
        icon: '',
        name: 'joule_losses_coeffient',
      },
      {
        label: `${t('systemAdmin.furnaceConfiguration.defaultEpiIndex')}`,
        type: 'input',
        icon: '',
        name: 'default_epi_index',
      },
      {
        label: `${t('systemAdmin.furnaceConfiguration.correctedReactanceCoefficient')}`,
        type: 'input',
        icon: '',
        name: 'corrected_reactance_coefficient',
      },
      {
        label: `${t('systemAdmin.furnaceConfiguration.designMW')}`,
        type: 'input',
        icon: '',
        name: 'design_mv',
      },
      {
        label: `${t('systemAdmin.furnaceConfiguration.defaultMoisture')}`,
        type: 'toggle',
        name: 'default_moisture',
      },
    ];

    const compositeData = [
      {
        label: `${t('systemAdmin.furnaceConfiguration.core')}*`,
        option: core,
        type: 'select',
        name: 'core',
      },
      {
        label: `${t('systemAdmin.furnaceConfiguration.coreMassOrLength')}*`,
        type: 'input',
        icon: 'kg/cm',
        name: 'coreMassLength',
      },
      {
        label: `${t('systemAdmin.furnaceConfiguration.paste')}*`,
        option: paste,
        type: 'select',
        name: 'paste',
      },
      {
        label: `${t('systemAdmin.furnaceConfiguration.pasteMassOrLength')}*`,
        type: 'input',
        icon: 'kg/cm',
        name: 'pasteMassLength',
      },
      {
        label: `${t('systemAdmin.furnaceConfiguration.casing')}*`,
        option: casing,
        type: 'select',
        name: 'casing',
      },
      {
        label: `${t('systemAdmin.furnaceConfiguration.casingMassOrLength')}*`,
        type: 'input',
        icon: 'kg/cm',
        name: 'casingMassLength',
      },
    ];
    const updatedParameters = parameterData.map((parameter) => {
      const matchingUnit = allUnits.find((unit: any) => unit?.name == parameter.label);
      if (matchingUnit) {
        return { ...parameter, icon: matchingUnit.unit };
      }
      return parameter;
    });
    setLoading(false);
    setParameters(updatedParameters);

    const updatedComposite = compositeData.map((parameter: any) => {
      const matchingUnit = allUnits.find((unit: any) => parameter.label.startsWith(unit?.name));
      if (matchingUnit) {
        return { ...parameter, icon: matchingUnit.unit };
      }
      return parameter;
    });
    setComposite(updatedComposite);
  };

  useEffect(() => {
    if (masterData.length > 0) {
      getUnit();
    }
  }, [masterData]);

  const electrodes = ['E1', 'E2', 'E3'];

  const electrodesOption = [
    { option: t('sharedTexts.select'), value: 'Select' },
    ...(masterData?.filter((val: any) => {
      if (val?.type == 'ELECTRODES') {
        return val;
      }
    }) || []),
  ];

  const handleElectrodesChange = (value: any) => {
    if (value) {
      setElectrode(composite);
    } else {
      setElectrode([]);
    }

    if (isEdit) {
      const result = electrodesList?.map((item: any) => {
        const newItem: any = { id: item.id, type: item.type }; // Start with id
        // Set all other keys to null
        Object.keys(item).forEach((key) => {
          if (key !== 'id' && key !== 'type') {
            newItem[key] = null;
          }
        });
        return newItem;
      });

      setElectrodesList(result as any[]);
    }
  };

  const handleProductChange = (value: any, index: any, option: any, label: any) => {
    try {
      const newState: any = { ...productSelected }; // Create a copy of the current state

      // Update the state based on the selected option
      if (label === `${t('systemAdmin.furnaceConfiguration.productType')}*`) {
        if (value) {
          newState.productType = { option, value };
        } else {
          newState.productType = '';
        }
        newState.productCode = '';
        // getProductCode(value);
      } else if (label === `${t('systemAdmin.furnaceConfiguration.productCode')}*`) {
        if (value) {
          newState.productCode = { option, value };
        } else {
          newState.productCode = '';
        }
      } else if (value === 'Select') {
        if (index === 0) {
          newState.productState = '';
        } else if (index === 1) {
          newState.productType = '';
        }
      }
      setProductSelected(newState);
      setProduct(newState);
    } catch (error) {
      // Handle the error
      console.error('An error occurred:', error);
    }
  };

  const handleAddProduct = (type: any) => {
    try {
      if (product.productType && product.productCode) {
        addIndividualProduct(type[0].value);
      }
    } catch (error) {
      console.error('An error occurred:', error);
    }
  };

  const addIndividualProduct = (type: string) => {
    const newProductState = product.productType;
    const newProduct = { productCode: product.productCode, record_status: true };

    let newProductList = productList.map((value: any) =>
      value.productType.option === type
        ? { ...value, products: [...value.products, newProduct] }
        : value
    );

    if (!newProductList.some((item: any) => item.productType.option === type)) {
      newProductList = [
        ...newProductList,
        { productType: newProductState, products: [newProduct] },
      ];
    }

    setProductList(newProductList);
    setFieldValue('products', newProductList);
    setProduct({ productState: '', productType: '', productCode: '' });
    setProductSelected({ productState: '', productType: '', productCode: '' });
    setResetProductDropDown((prev: boolean) => !prev); //reset product code dropdown
  };

  const handleRemoveProduct = (index: any, state: any, status = false) => {
    const arrayToRemove = [...productList];

    if (!isEdit) {
      const check = arrayToRemove?.some(
        (item) => item.productType?.option == state && item.products.length == 1
      );

      if (check) {
        const newArr = arrayToRemove.filter((value: any) => {
          return value.productType?.option !== state;
        });

        setProductList(newArr);
        setFieldValue('products', newArr);
      } else {
        arrayToRemove.map((value: any) => {
          if (value.productType?.option == state) {
            const removedArr = value.products?.splice(index, 1);
            return removedArr;
          }
          return value;
        });
        setFieldValue('products', arrayToRemove);
        setProductList(arrayToRemove);
      }
    } else {
      arrayToRemove.map((value: any) => {
        if (value.productType?.option == state) {
          const removedArr = (value.products[index].record_status = status);
          return removedArr;
        }
        return value;
      });

      setFieldValue('products', arrayToRemove);
      setProductList(arrayToRemove);
    }
  };

  const fetchData = async () => {
    try {
      const masterResponse: any = await httpClient.get('/api/master/master/');
      const productResponse: any = await httpClient.get('/api/furnace-config/product-type/');
      const workshopResponse: any = await httpClient.get(
        `/api/plant/plant-config/${local_plant_id}/`
      );

      const masterResponseList: any = masterResponse?.data?.map((val: any) => {
        const list = {
          option: val.value,
          value: val.id,
          type: val.category,
        };
        return list;
      });

      const workshopResponseList = workshopResponse?.data?.workshops_json.map((val: any) => {
        if (val.record_status) {
          const list = {
            option: val.workshop_name,
            value: val.id,
            type: 'WORKSHOPNO',
          };
          return list;
        }
      });

      setProductDataList(productResponse.data);

      setMasterData(masterResponseList);
      setWorkshopDropdownData(workshopResponseList);
    } catch (error) {
      // Handle errors here
      console.error('Error fetching data:', error);
    }
  };
  useEffect(() => {
    fetchData();
  }, []);

  const handleElectrodesFieldChange = (label: any, fieldName: any, value: any) => {
    const updatedElectrodes = values.electrodes.map((electrode: any) => {
      if (electrode.type === label) {
        return { ...electrode, type: label, [fieldName]: value || null };
      }
      return electrode;
    });

    setElectrodesList(updatedElectrodes);
    setFieldValue('electrodes', updatedElectrodes);
  };

  useEffect(() => {
    if (values.electrode_type_id) {
      setElectrode(composite);
    }
  }, [composite, values.electrode_type_id]);

  useEffect(() => {
    if (edit_Id) {
      setIsEdit(true);
      setEditId(edit_Id);
    }
  }, [edit_Id]);

  const validationInputParam = (value: any, icon: string) => {
    const regex = /^\d*\.?\d{0,3}$/;

    const regex2 = /^\d{0,4}(\.\d{1,3})?$/;

    if (icon !== '%' && icon !== '' && regex2.test(value)) {
      return true;
    }
    if (value <= 100 && regex.test(value)) {
      return true;
    } else {
      return false;
    }
  };

  useEffect(() => {
    // Function to extract productCode ids
    const extractProductCodeIds = () => {
      const productIds: number[] = [];
      productList.forEach((item: any) => {
        item.products.forEach((product: any) => {
          productIds.push(product.productCode.value);
        });
      });
      return productIds;
    };

    setProductIdsToHide(extractProductCodeIds()); // passed to lazy load component
  }, [productList]);

  if (loading) return <Loading />;

  return (
    <form onSubmit={handleSubmit} className='form'>
      <div className='container mt-3 mb-3'>
        <div className='child-container card'>
          <div style={{ display: 'flex' }}>
            <div
              style={{
                display: 'flex',
                width: '50%',
                alignItems: 'center',
                padding: '14px 31px 14px 31px',
                gap: '15px',
                borderTop: '2px solid #0D659E',
                borderTopLeftRadius: '4px',
              }}
            >
              <p
                style={{
                  width: '32px',
                  height: '32px',
                  borderRadius: '50%',
                  display: 'flex',
                  justifyContent: 'center',
                  alignItems: 'center',
                  backgroundColor: '#0D659E',
                  color: '#fff',
                }}
              >
                1
              </p>
              <p
                style={{
                  fontSize: '14px',
                  fontWeight: 700,
                  color: '#0D659E',
                }}
              >
                {t('systemAdmin.furnaceConfiguration.basicInformation')}
              </p>
            </div>
            <button
              style={{
                display: 'flex',
                width: '50%',
                alignItems: 'center',
                gap: '15px',
                padding: '14px 31px 14px 31px',
                backgroundColor: '#C1D3DF40',
                cursor: 'pointer',
                border: '0px',
              }}
              type='button'
              onClick={() => isEdit && setTab(2)}
              onKeyDown={(event) => {
                event.key === 'Enter' && setTab(2);
              }}
            >
              <p
                style={{
                  width: '32px',
                  height: '32px',
                  border: '1px solid #CDD0D1',
                  borderRadius: '50%',
                  display: 'flex',
                  justifyContent: 'center',
                  alignItems: 'center',
                  backgroundColor: '#fff',
                }}
              >
                2
              </p>
              <p
                style={{
                  fontSize: '14px',
                  fontWeight: 700,
                  color: '#757E85',
                }}
              >
                {t('systemAdmin.furnaceConfiguration.refiningSteps')}
              </p>
            </button>
          </div>
          <div className='card-body card_body_container'>
            <div className='furnace'>
              <div className='furnace__furnace_child'>
                <label className='input-field-label font-semibold' htmlFor='Furnace'>
                  {`${t('systemAdmin.furnaceConfiguration.furnaceNo')}*`}
                </label>
                <input
                  type='number'
                  className='furnace__input'
                  name='furnace_no'
                  onChange={(e) => {
                    const { value, name } = e.target;
                    // Convert the input value to a number
                    const numericValue = Number(value);

                    // Check if the entered value is a positive number
                    if (numericValue > 0 || value === '') {
                      // Update state or do whatever you need with the value
                      setFieldValue(name, value);
                    }
                  }}
                  onBlur={handleBlur}
                  value={values.furnace_no}
                  placeholder={`${t('systemAdmin.furnaceConfiguration.enterValue')}`}
                  maxLength={15}
                  onKeyDown={(e) => {
                    if (e.key === ' ') {
                      e.preventDefault();
                    }
                  }}
                />
                {errors.furnace_no && touched.furnace_no ? (
                  <p style={{ fontSize: '12px', color: '#ff0000', marginTop: '5px' }}>
                    {errors.furnace_no}
                  </p>
                ) : (
                  ''
                )}
              </div>

              <div className='furnace__furnace_description'>
                <label className='input-field-label font-semibold' htmlFor='FurnaceDescription'>
                  {`${t('systemAdmin.furnaceConfiguration.furnaceDescription')}*`}
                </label>
                <input
                  className='furnace__input_description'
                  name='furnace_description'
                  onChange={handleChange}
                  onBlur={handleBlur}
                  value={values.furnace_description}
                  placeholder={`${t('systemAdmin.furnaceConfiguration.enterDescription')}`}
                />
                {errors.furnace_description && touched.furnace_description ? (
                  <p style={{ fontSize: '12px', color: '#ff0000', marginTop: '5px' }}>
                    {errors.furnace_description}
                  </p>
                ) : (
                  ''
                )}
              </div>
            </div>

            <div className='select_body'>
              <div className='select_body__container'>
                <label className='input-field-label font-semibold'>{WorkshopNo.label}</label>

                <CustomSelect
                  index={0}
                  options={WorkshopNo.option}
                  onChange={(val: any) => {
                    setFieldValue('workshop', val);
                    setIsTouched({ ...isTouched, workshopNo: true });
                    handleBlur('workshop');
                  }}
                  value={
                    WorkshopNo?.option.filter((item: any) => item.value == values.workshop)[0]
                      ?.option || t('sharedTexts.select')
                  }
                />
                {errors.workshop && touched.workshop ? (
                  <p style={{ fontSize: '12px', color: '#ff0000' }}>{errors.workshop}</p>
                ) : (
                  ''
                )}
              </div>
              <div className='select_body__container '>
                <label className='input-field-label font-semibold'>{powerDelivery.label}</label>
                <CustomSelect
                  index={0}
                  options={powerDelivery.option}
                  onChange={(val: any) => {
                    setFieldValue('power_delivery_id', val);
                    setIsTouched({ ...isTouched, powerDelivery: true });
                    handleBlur('power_delivery_id');
                  }}
                  value={
                    powerDelivery?.option.filter(
                      (item: any) => item.value == values.power_delivery_id
                    )[0]?.option || t('sharedTexts.select')
                  }
                />
                {errors.power_delivery_id && touched.power_delivery_id ? (
                  <p style={{ fontSize: '12px', color: '#ff0000' }}>{errors.power_delivery_id}</p>
                ) : (
                  ''
                )}
              </div>
              {/* Cost Center dropdown */}

              <div className='select_body__container '>
                <label className='input-field-label font-semibold'>{costCenter.label}</label>
                <CustomSelect
                  index={0}
                  options={costCenter.option}
                  onChange={(val: any) => {
                    setFieldValue('cost_center_id', val);
                    setIsTouched({ ...isTouched, costCenter: true }); // the form is is using touched from formik
                  }}
                  value={
                    // the component has a search attribute which enables searching in options... this prop is used for that.
                    costCenter?.option.filter((item: any) => item.value == values.cost_center_id)[0]
                      ?.option || t('sharedTexts.select')
                  }
                />
                {errors.cost_center_id && touched.cost_center_id ? (
                  <p style={{ fontSize: '12px', color: '#ff0000' }}>{errors.cost_center_id}</p>
                ) : (
                  ''
                )}
              </div>
              {/* Cost Center dropdown - end */}
            </div>

            <hr className='line_break' />

            <div className='electrodes'>
              <p className='title mb-4'>{`${t('systemAdmin.furnaceConfiguration.electrodes')}`} </p>

              <div className='electrodes__electrode_container'>
                <div className='electrodes__container'>
                  <label className='input-field-label font-semibold' htmlFor='ElectrodeType'>
                    {`${t('systemAdmin.furnaceConfiguration.electrodeType')}*`}
                  </label>

                  <CustomSelect
                    index={0}
                    options={electrodesOption}
                    onChange={(val: any) => {
                      setFieldValue('electrode_type_id', val);
                      handleElectrodesChange(val);
                      handleBlur('electrode_type_id');
                    }}
                    value={
                      electrodesOption.filter(
                        (item: any) => item.value == values.electrode_type_id
                      )[0]?.option || t('sharedTexts.select')
                    }
                  />
                  {errors.electrode_type_id && touched.electrode_type_id ? (
                    <p style={{ fontSize: '12px', color: '#ff0000' }}>{errors.electrode_type_id}</p>
                  ) : (
                    ''
                  )}
                </div>
              </div>
            </div>

            {electrode.length > 0
              ? electrodes.map((value: any, index: any) => (
                  <Accordion title={value} key={value}>
                    <div className='electrode_accordion'>
                      <div className='electrode_accordion__electrode_accordion_container'>
                        {electrode.map((val: any) => (
                          <div className='electrode_accordion__container' key={val.label}>
                            <label className='input-field-label font-semibold'>{val.label}</label>
                            {val.type === 'input' && (
                              <div className='electrode_accordion__input_container input-group mb-3'>
                                <input
                                  type='number'
                                  className='electrode_accordion__input form-control'
                                  placeholder={`${t('systemAdmin.furnaceConfiguration.enterValue')}`}
                                  onKeyDown={(event) => {
                                    if (event.key === 'e' || event.key === 'E') {
                                      event.preventDefault();
                                    }
                                  }}
                                  onChange={(e) => {
                                    const inputValue = e.target.value;
                                    handleBlur('electrodes');
                                    // Regular expression to match numbers with optional up to three decimal places
                                    const regex = /^\d{0,4}(\.\d{1,3})?$/;
                                    if (inputValue === '' || regex.test(inputValue)) {
                                      handleElectrodesFieldChange(value, val.name, inputValue);
                                    }
                                  }}
                                  value={
                                    values?.electrodes?.filter(
                                      (item: any) => item.type == value
                                    )?.[0]?.[val.name] || ''
                                  }
                                />

                                <div className='input-group-append'>
                                  <span className='electrode_accordion__input_icon input-group-text'>
                                    {val.icon}
                                  </span>
                                </div>
                                {touched.electrodes && errors?.electrodes?.[index]?.[val.name] ? (
                                  <p
                                    style={{ fontSize: '12px', color: '#ff0000', marginTop: '5px' }}
                                  >
                                    {errors.electrodes[index][val.name]}
                                  </p>
                                ) : (
                                  ''
                                )}
                              </div>
                            )}
                            {val.type === 'select' && (
                              <div>
                                <CustomSelect
                                  index={index}
                                  options={val?.option}
                                  onChange={(item: any) => {
                                    handleElectrodesFieldChange(value, val.name, item);
                                    handleBlur('electrodes');
                                  }}
                                  value={
                                    val?.option?.filter(
                                      (item: any) =>
                                        item.value ==
                                        values?.electrodes?.filter(
                                          (item: any) => item.type == value
                                        )?.[0]?.[val.name]
                                    )[0]?.option || t('sharedTexts.select')
                                  }
                                />
                                {touched.electrodes && errors.electrodes?.[index]?.[val.name] ? (
                                  <p
                                    style={{ fontSize: '12px', color: '#ff0000', marginTop: '5px' }}
                                  >
                                    {errors.electrodes[index][val.name]}
                                  </p>
                                ) : (
                                  ''
                                )}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  </Accordion>
                ))
              : ''}

            <hr className='line_break' />

            <div className='products'>
              <p className='products__title mb-4'>
                {' '}
                {`${t('systemAdmin.plantConfiguration.products')}`}{' '}
              </p>

              <div className='products__product_container'>
                {productFields.map((val: any, index: any) => (
                  <div
                    className='products__container'
                    style={{ ...(index === 1 ? { width: '45%' } : {}) }}
                    key={val.label}
                  >
                    <label className='input-field-label font-semibold'>{val.label}</label>
                    {/* --------- change this old one ----- */}
                    {val.label === `${t('systemAdmin.furnaceConfiguration.productType')}*` ? (
                      <CustomSelect
                        index={index}
                        options={val.option}
                        onChange={(value: any) =>
                          handleProductChange(
                            value,
                            index,
                            val.option.filter((val: any) => val.value == value)[0]?.option,
                            val.label
                          )
                        }
                        disabled={
                          !productSelected.productType && productFields.length === index + 1
                        }
                        searchText='Search Product Code'
                        search={productFields.length === index + 1}
                        value={val.value}
                        // loading={dropDownLoading}
                      />
                    ) : (
                      <>
                        {/* --------- new lazy drop down ----- */}
                        <LazyDropDown
                          valueKey='material_code'
                          placeholder={`${t('systemAdmin.furnaceConfiguration.selectProductCode')}`}
                          idsToBeExcluded={productIdsToHide}
                          apiCall={GetLazyLoadData.getProductCodes}
                          disabled={
                            !productSelected.productType && productFields.length === index + 1
                          }
                          otherParams={
                            productSelected.productType
                              ? { product_type: productSelected.productType.option }
                              : {}
                          }
                          firstCallDependency={productSelected.productType.option} // this has to be true to make the first api call
                          onChange={(selectedProductCode) => {
                            handleProductChange(
                              selectedProductCode.id, // id
                              index,
                              selectedProductCode.material_code, // the text
                              `${t('systemAdmin.furnaceConfiguration.productCode')}*`
                            );
                          }}
                          resetProductDropDown={resetProductDropDown}
                        />
                      </>
                    )}
                  </div>
                ))}
                <button
                  className='products__add_container'
                  onClick={() => handleAddProduct(productFields)}
                  type='button'
                  style={{
                    backgroundColor:
                      product.productType && product.productCode ? '#0d659e' : '#6993af',
                  }}
                >
                  <svg
                    xmlns='http://www.w3.org/2000/svg'
                    width='40'
                    height='40'
                    fill='#fff'
                    className='bi bi-plus'
                    viewBox='0 0 16 16'
                  >
                    <path d='M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4' />
                  </svg>
                </button>
              </div>
              {errors.products && touched.products ? (
                <p style={{ fontSize: '12px', color: '#ff0000', marginTop: '5px' }}>
                  {errors.products}
                </p>
              ) : (
                ''
              )}

              <div className='products__list_container'>
                {productList?.length > 0 &&
                  productList?.map((value: any) => (
                    <Accordion title={value?.productType?.option} key={value?.productType?.option}>
                      <table className='products__table'>
                        <thead>
                          <tr>
                            {/* <th className='products__table_head '>Product Type</th> */}
                            <th className='products__table_head'>
                              {t('systemAdmin.furnaceConfiguration.productCode')}
                            </th>
                            <th></th>
                          </tr>
                        </thead>

                        {value?.products?.map((val: any, index: any) => (
                          <tbody key={val?.productCode?.option}>
                            <tr className='products__table_data'>
                              {/* <td>{val?.productType?.option}</td> */}
                              <td>{val?.productCode?.option}</td>

                              <td style={{ paddingLeft: '18px' }}>
                                {!isEdit ? (
                                  <button
                                    onClick={() =>
                                      handleRemoveProduct(index, value?.productType?.option)
                                    }
                                    type='button'
                                    style={{ border: '0px', backgroundColor: '#fff' }}
                                    onKeyDown={(event) => {
                                      event.key === 'Enter' &&
                                        handleRemoveProduct(index, value?.productType?.option);
                                    }}
                                    data-toggle='tooltip'
                                    data-placement='bottom'
                                  >
                                    <svg
                                      xmlns='http://www.w3.org/2000/svg'
                                      width='17'
                                      height='17'
                                      fill='#8F1D18'
                                      className='bi bi-trash'
                                      viewBox='0 0 16 16'
                                    >
                                      <path d='M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z' />
                                      <path d='M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z' />
                                    </svg>
                                  </button>
                                ) : (
                                  <div>
                                    <ToggleButton
                                      onChange={() => {
                                        handleRemoveProduct(
                                          index,
                                          value?.productType?.option,
                                          !val.record_status
                                        );
                                      }}
                                      text={
                                        val.record_status
                                          ? t('sharedTexts.activated')
                                          : t('sharedTexts.deactivated')
                                      }
                                      isChecked={'record_status' in val ? val.record_status : true}
                                      style={{ alignItems: 'center' }}
                                    />
                                  </div>
                                )}
                              </td>
                            </tr>
                          </tbody>
                        ))}
                      </table>
                    </Accordion>
                  ))}
              </div>
            </div>

            <hr className='line_break' />

            <div className='parameters'>
              <p className='title mb-4'> {t('systemAdmin.furnaceConfiguration.parameters')}</p>

              <div className='parameters__parameter_container'>
                {parameters.map((val: any, index: any) => (
                  <div key={val.label} className='parameters__container'>
                    <label className='input-field-label font-semibold'>{val.label}</label>
                    {val.type === 'input' && (
                      <InputField
                        icon={val.icon}
                        value={values[val.name] || ''}
                        onChange={(value: any) => {
                          if (validationInputParam(Number(value), val.icon) || value === '') {
                            setFieldValue(val.name, value);
                          }
                        }}
                        name={val.name}
                        handleBlur={handleBlur}
                      />
                    )}
                    {errors?.[val.name] && touched?.[val.name] ? (
                      <p
                        style={{
                          fontSize: '12px',
                          color: '#ff0000',
                          position: 'relative',
                          bottom: '20px',
                        }}
                      >
                        {errors?.[val.name]}
                      </p>
                    ) : (
                      ''
                    )}
                    {val.type === 'select' && (
                      <CustomSelect
                        index={index}
                        options={val.option}
                        onChange={(value: any) => {
                          setFieldValue(val.name, value);
                        }}
                        value={
                          val?.option?.filter((item: any) => item.value == values[val.name])[0]
                            ?.option || t('sharedTexts.select')
                        }
                      />
                    )}
                    {val.type === 'toggle' && (
                      <ToggleButton
                        onChange={(value: any) => {
                          setEnabled(!enabled);
                          setFieldValue(val.name, value);
                        }}
                        text={
                          values.default_moisture
                            ? `${t('sharedTexts.enabled')}`
                            : `${t('sharedTexts.disabled')}`
                        }
                        isChecked={values.default_moisture}
                        style={{ alignItems: 'center' }}
                      />
                    )}
                  </div>
                ))}
              </div>
            </div>

            <hr className='line_break' />

            {/* hidded as per request on 28/3/2024 */}
            {/* <div className='ladle_Additions'>
              <p className='title mb-4'>Default Ladle Additions</p>

              <div className='ladle_Additions__ladle_Addition_container'>
                {ladleAdditions.map((val: any, index: any) => (
                  <div className='ladle_Additions__container' key={val.label}>
                    <label className='input-field-label font-semibold'>{val.label}</label>
                    <CustomSelect
                      index={index}
                      options={val.option}
                      onChange={(value: any) => {
                        setFieldValue(val.name, value);
                      }}
                      value={
                        val?.option?.filter((item: any) => item.value == values[val.name])[0]
                          ?.option || 'Select'
                      }
                    />
                  </div>
                ))}
              </div>
            </div> */}

            <div className='recoveries'>
              <p className='title mb-4'>
                {t('systemAdmin.furnaceConfiguration.defaultRecoveries')}
              </p>

              <div className='recoveries__recover_container'>
                {recoveries.map((val: any, index: any) => (
                  <div className='recoveries__container' key={val.label}>
                    <label className='input-field-label font-semibold'>{val.label}</label>
                    <CustomSelect
                      index={index}
                      options={val.option}
                      onChange={(value: any) => {
                        setFieldValue(val.name, value);
                      }}
                      value={
                        val?.option?.filter((item: any) => item.value == values[val.name])[0]
                          ?.option || t('sharedTexts.select')
                      }
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
      <PlantFooter currentTab={1} onback={() => navigate(-1)} />
    </form>
  );
};

export default BasicInformation;
