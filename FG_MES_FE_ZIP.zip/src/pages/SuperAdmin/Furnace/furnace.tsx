import 'assets/styles/scss/pages/furnace.scss';
import BasicInformation from './AddFurnace/basicInformation';
import RefiningSteps from './AddFurnace/refiningSteps';
import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import Header from 'components/common/EmptyHeader';
import httpClient from 'http/httpClient';
import { paths } from 'routes/paths';
import { useTranslation } from 'react-i18next';

const AddFurnace = () => {
  const { t } = useTranslation();
  const [tab, setTab] = useState<any>(1);
  const [addId, setAddId] = useState<any>(null);
  const [editId, setEditId] = useState<any>(null);
  const params = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    if (params?.id && params?.tab) {
      setTab(parseInt(params.tab));
      setEditId(parseInt(params.id));
    }
  }, [params.id, params.tab]);

  const [furnaceData, setFurnaceData] = useState<any>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await httpClient.get(`/api/furnace/furnace-config/${editId}/`);
        const data = response.data;
        setFurnaceData({ furnace: [data] });
      } catch (error) {
        console.error('Error fetching data:', error);
        // Handle the error, e.g., set an error state or show a message to the user
      }
    };

    if (editId) {
      fetchData();
    }
  }, [editId]);

  const handleBackClick = () => {
    navigate(paths.furnaceConfig.list);
  };

  let titleId: string = '';
  furnaceData?.furnace.map((furnace: any) => (titleId = furnace.furnace_no));
  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Header
        title={
          params?.id && params?.tab
            ? `${t('sharedTexts.edit')} ${titleId}`
            : t('systemAdmin.furnaceConfiguration.addNewFurnace')
        }
        onBackClick={handleBackClick}
      />
      {tab === 1 ? (
        <BasicInformation setAddId={setAddId} setTab={setTab} edit_Id={editId} />
      ) : (
        <RefiningSteps addId={addId} setTab={setTab} edit_Id={editId} titleId={titleId} />
      )}
    </div>
  );
};

export default AddFurnace;
