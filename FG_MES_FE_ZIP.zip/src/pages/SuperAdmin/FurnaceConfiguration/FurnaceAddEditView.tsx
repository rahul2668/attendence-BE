// THE MAIN
import 'assets/styles/scss/pages/furnace.scss';
import { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Header from 'components/common/EmptyHeader';
import { paths } from 'routes/paths';
import { useTranslation } from 'react-i18next';
import MainTab from 'components/common/MainTab';
import BasicInfo from './Tabs/BasicInfo';
import ElectrodeInfo from './Tabs/ElectrodeInfo';
import { crudType, furnaceConfigTabs } from 'utils/constants';
import Loading from 'components/common/Loading';
import { useAppDispatch, useAppSelector } from 'store';
import {
  clearAllStatesToInitialValue,
  getBasicInfo,
  setFormAction,
  setFurnaceBasicInfo,
  setFurnaceConfigId,
  setFurnaceNo,
} from 'store/slices/furnaceConfigurationSlice';
import ParameterInfo from './Tabs/ParameterInfo';
import RefiningSteps from '../Furnace/AddFurnace/refiningSteps';
import RefiningStepsView from '../FurnaceConfiguration/refiningStepsView';

const FurnaceAddEditView = () => {
  const location = useLocation();
  const { t } = useTranslation();
  const dispatch = useAppDispatch();
  const loading = useAppSelector((state) => state.furnaceConfiguration.loading);
  const formAction = useAppSelector((state) => state.furnaceConfiguration.formAction);
  const [tab, setTab] = useState<number>(furnaceConfigTabs.basicInfo);
  const navigate = useNavigate();
  const { furnaceBasicInfo, furnaceConfigId, furnaceNo } = useAppSelector(
    (state) => state.furnaceConfiguration
  );

  const [headerTitle, setHeaderTitle] = useState<string>('');

  const tabs: Tabs[] = [
    { label: 'Basic Information', value: furnaceConfigTabs.basicInfo },
    { label: 'Electrodes', value: furnaceConfigTabs.electrodes },
    { label: 'Parameters', value: furnaceConfigTabs.parameters },
    { label: 'Refining steps', value: furnaceConfigTabs.refiningSteps },
  ];

  // on component unmount we are clearing the global state
  useEffect(() => {
    return () => {
      dispatch(clearAllStatesToInitialValue());
    };
  }, []);

  useEffect(() => {
    if (location.state) {
      const locationState = location.state as NavigateState;
      dispatch(setFormAction(locationState.action));
      dispatch(setFurnaceConfigId(locationState.viewOrEditId));
      dispatch(setFurnaceNo(locationState.title));
      // setFurnaceNo(locationState.title);
    }
  }, [location.state]);

  const handleBackClick = () => {
    navigate(paths.furnaceConfig.list);
  };

  const handleTabClick = (tab: number) => {
    setTab(tab);
  };

  useEffect(() => {
    if (furnaceConfigId && formAction === crudType.edit) {
      setHeaderTitle('sharedTexts.edit');
      dispatch(getBasicInfo(furnaceConfigId)).then((thenData) => {
        dispatch(setFurnaceBasicInfo(thenData.payload.data));
      });
    }
    if (furnaceConfigId && formAction === crudType.view) {
      setHeaderTitle('sharedTexts.view');
      dispatch(getBasicInfo(furnaceConfigId)).then((thenData) => {
        dispatch(setFurnaceBasicInfo(thenData.payload.data));
      });
    }
    if (formAction === crudType.create) {
      setHeaderTitle('systemAdmin.furnaceConfiguration.addNewFurnace');
    }
  }, [formAction, furnaceConfigId]);

  return (
    <div>
      {loading && <Loading />}
      <Header
        title={`${t(headerTitle, headerTitle)} ${furnaceNo ?? ''}`}
        onBackClick={handleBackClick}
      />
      <div className='dashboard__main__body container mt-3 mb-3' style={{ height: '100vh' }}>
        <div className='card-box'>
          <div className={`${formAction !== crudType.edit ? 'tab - wrapper' : ''}`}>
            {/* <button onClick={() => test()}>do api call</button> */}
            <MainTab
              tabs={tabs}
              setActiveTab={setTab}
              activeTab={tab}
              isNextTabAllowed={formAction !== crudType.create}
            />
            {(() => {
              switch (tab) {
                case furnaceConfigTabs.basicInfo:
                  return <BasicInfo tabValue={tab} handleTabClick={handleTabClick} />;
                case furnaceConfigTabs.electrodes:
                  return <ElectrodeInfo tabValue={tab} handleTabClick={handleTabClick} />;
                case furnaceConfigTabs.parameters:
                  return <ParameterInfo tabValue={tab} handleTabClick={handleTabClick} />;
                case furnaceConfigTabs.refiningSteps:
                  return formAction === crudType.view ? (
                    <RefiningStepsView />
                  ) : (
                    <RefiningSteps addId={furnaceBasicInfo.furnaceId} edit_Id={furnaceConfigId} />
                  );
              }
            })()}
          </div>
        </div>
      </div>
    </div>
  );
};

export default FurnaceAddEditView;
