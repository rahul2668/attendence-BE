import _ from 'lodash';

export const furnaceConfigTableHeaders = [
  {
    label: 'systemAdmin.furnaceConfiguration.furnaceNo',
    alignment: '', // optional
    width: '180px', // optional
    enableSort: true,
    sortKey: 'furnace_no',
  },
  {
    label: 'systemAdmin.furnaceConfiguration.shopNo',
    alignment: '', // optional
    width: '200px', // optional
    enableSort: true,
    sortKey: 'workshop_value',
  },
  {
    label: 'systemAdmin.furnaceConfiguration.powerDelivery',
    alignment: '', // optional
    width: '220px', // optional
    enableSort: true,
    sortKey: 'power_delivery_value',
  },
  {
    label: 'systemAdmin.furnaceConfiguration.electrodeType',
    alignment: '', // optional
    width: '230px', // optional
    enableSort: true,
    sortKey: 'electrode_type_value',
  },
  {
    label: 'sharedTexts.status',
    alignment: '', // optional
    width: '', // optional
    enableSort: true,
    sortKey: 'record_status',
  },
  {
    label: '',
    alignment: '', // optional
    width: '', // optional
    enableSort: false,
    sortKey: '',
  },
];

export function formatFurnace(
  data: any // maybe define a type?
) {
  const statusLanguageKey: any = `sharedTexts.pillLogicKeys.dynamic${data.record_status ? 'Active' : 'Inactive'}`;
  return {
    furnaceNo: data.furnace_no,
    shopNo: data.workshop_value,
    powerDelivery: data.power_delivery_value,
    electrodeType: data.electrode_type_value,
    status: statusLanguageKey,
    // always give rendered keys first and the additional keys(not displayed ones) at last - else the component logic will break
    showOnlyAddButton: !data.is_mandates_completed,
    showOnlyActivateAndAddButton: !data.record_status && data.is_mandates_completed,
    furnaceId: data.id,

    // depending on id set is_super_admin true 1-> super_admin
  };
}

export const toolTipsForFurnace = {
  viewIconToolText: 'toolTips.viewFurnace',
  editIconToolText: 'toolTips.editFurnace',
  deactivateIconToolText: 'toolTips.deactivateFurnace',
  activateIconToolText: 'toolTips.activateFurnace',
  addIconToolText: 'toolTips.addFurnace',
};
