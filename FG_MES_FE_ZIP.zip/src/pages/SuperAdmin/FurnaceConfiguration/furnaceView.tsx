/* eslint-disable react-hooks/rules-of-hooks */
import React, { useEffect, useState } from 'react';
import editIcon from 'assets/icons/edit-thick.svg';
import Accordion from 'components/common/Accordion';
import ParameterComponent from '../../../components/common/ToggleTextComponent';
import { useLocation, useNavigate } from 'react-router-dom';
import Loader from 'components/Loader';
import httpClient from 'http/httpClient';
import '../../../assets/styles/scss/components/changeHistory.scss';
import { validatePermissions } from 'utils/utils';
import { crudType, permissionsMapper } from 'utils/constants';
import { useTranslation } from 'react-i18next';
import '../../../assets/styles/scss/base/global.scss';

const FurnaceView = ({ setTab, viewId }: any) => {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const ProductData = ['E1', 'E2', 'E3'];
  const [isLoading, setIsLoading] = useState<any>(true);
  const [furnaceData, setFurnaceData] = useState<any>(null);
  const [masterData, setMasterData] = useState<any>([]);
  const [productDataList, setProductDataList] = useState<any>([]);
  const { pathname } = useLocation();
  const module = pathname?.split('/')[1];
  const subModule = pathname?.split('/')[2];

  const hasEditPermission = validatePermissions(
    permissionsMapper[module],
    permissionsMapper[subModule],
    crudType.edit
  );

  let coreValue,
    CoreMassLengthValue,
    pasteValue,
    pasteMassLengthValue,
    casingValue,
    casingMassLenthValue;
  let coreValue2,
    CoreMassLengthValue2,
    pasteValue2,
    pasteMassLengthValue2,
    casingValue2,
    casingMassLenthValue2;
  let coreValue3,
    CoreMassLengthValue3,
    pasteValue3,
    pasteMassLengthValue3,
    casingValue3,
    casingMassLenthValue3;

  furnaceData?.furnace
    .map((val: any) =>
      val.furnace_electrodes.find((electrode: any) => electrode.electrode_name === 'E1')
    )
    .filter((e1Electrode: any) => e1Electrode !== undefined)
    .map((e1Electrode: any) => {
      coreValue = e1Electrode.core_value;
      CoreMassLengthValue = e1Electrode.core_mass_length;
      pasteValue = e1Electrode.paste_value;
      pasteMassLengthValue = e1Electrode.paste_mass_length;
      casingValue = e1Electrode.casing_value;
      casingMassLenthValue = e1Electrode.casing_mass_length;
      // return e1Electrode; // You can return or use the core_value as needed
    });

  furnaceData?.furnace
    .map((val: any) =>
      val.furnace_electrodes.find((electrode: any) => electrode.electrode_name === 'E2')
    )
    .filter((e1Electrode: any) => e1Electrode !== undefined)
    .map((e1Electrode: any) => {
      coreValue2 = e1Electrode.core_value;
      CoreMassLengthValue2 = e1Electrode.core_mass_length;
      pasteValue2 = e1Electrode.paste_value;
      pasteMassLengthValue2 = e1Electrode.paste_mass_length;
      casingValue2 = e1Electrode.casing_value;
      casingMassLenthValue2 = e1Electrode.casing_mass_length;
      // return e1Electrode; // You can return or use the core_value as needed
    });

  furnaceData?.furnace
    .map((val: any) =>
      val.furnace_electrodes.find((electrode: any) => electrode.electrode_name === 'E3')
    )
    .filter((e1Electrode: any) => e1Electrode !== undefined)
    .map((e1Electrode: any) => {
      coreValue3 = e1Electrode.core_value;
      CoreMassLengthValue3 = e1Electrode.core_mass_length;
      pasteValue3 = e1Electrode.paste_value;
      pasteMassLengthValue3 = e1Electrode.paste_mass_length;
      casingValue3 = e1Electrode.casing_value;
      casingMassLenthValue3 = e1Electrode.casing_mass_length;
    });

  const productDataMapping: any = [];
  useEffect(() => {
    furnaceData?.furnace.forEach((product: any) => {
      product.furnace_products.forEach((val: any) => {
        if (val.record_status) {
          productSeparation(val);
        }
      });
    });

    setProductDataList(productDataMapping);
  }, [furnaceData]);

  const productSeparation = (val: any) => {
    const existingProduct = productDataMapping.find(
      (item: any) => item.product === val.product_type_value
    );
    if (existingProduct) {
      existingProduct.code.push({
        productCode: val.product_code_value,
      });
    } else {
      productDataMapping.push({
        product: val.product_type_value,
        code: [
          {
            productCode: val.product_code_value,
          },
        ],
      });
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await httpClient.get(`/api/furnace-config/basic-info/${viewId}/`);
        const data = response?.data;
        setIsLoading(false);
        setFurnaceData({ furnace: [data] });
      } catch (error) {
        console.error('Error fetching data:', error);
        // Handle the error, e.g., set an error state or show a message to the user
      }
    };

    fetchData();
  }, []);

  const appmasterData = async () => {
    try {
      const masterResponse = await httpClient.get('/api/master/master/');

      const masterResponseList = masterResponse?.data;
      setMasterData(masterResponseList);
    } catch (error) {
      // Handle errors here
      console.error('Error fetching data:', error);
    }
  };
  useEffect(() => {
    appmasterData();
  }, []);

  const dataMapping2 = {
    E1: [
      { label: `${t('systemAdmin.furnaceConfiguration.core')}`, value: coreValue },
      {
        label: `${t('systemAdmin.furnaceConfiguration.coreMassOrLength')}`,
        value: CoreMassLengthValue,
      },

      { label: `${t('systemAdmin.furnaceConfiguration.paste')}`, value: pasteValue },
      {
        label: `${t('systemAdmin.furnaceConfiguration.pasteMassOrLength')}`,
        value: pasteMassLengthValue,
      },

      { label: `${t('systemAdmin.furnaceConfiguration.casing')}`, value: casingValue },
      {
        label: `${t('systemAdmin.furnaceConfiguration.casingMassOrLength')}`,
        value: casingMassLenthValue,
      },
    ],
    E2: [
      { label: `${t('systemAdmin.furnaceConfiguration.core')}`, value: coreValue2 },
      {
        label: `${t('systemAdmin.furnaceConfiguration.coreMassOrLength')}`,
        value: CoreMassLengthValue2,
      },

      { label: `${t('systemAdmin.furnaceConfiguration.paste')}`, value: pasteValue2 },
      {
        label: `${t('systemAdmin.furnaceConfiguration.pasteMassOrLength')}`,
        value: pasteMassLengthValue2,
      },

      { label: `${t('systemAdmin.furnaceConfiguration.casing')}`, value: casingValue2 },
      {
        label: `${t('systemAdmin.furnaceConfiguration.casingMassOrLength')}`,
        value: casingMassLenthValue2,
      },
    ],
    E3: [
      { label: `${t('systemAdmin.furnaceConfiguration.core')}`, value: coreValue3 },
      {
        label: `${t('systemAdmin.furnaceConfiguration.coreMassOrLength')}`,
        value: CoreMassLengthValue3,
      },

      { label: `${t('systemAdmin.furnaceConfiguration.paste')}`, value: pasteValue3 },
      {
        label: `${t('systemAdmin.furnaceConfiguration.pasteMassOrLength')}`,
        value: pasteMassLengthValue3,
      },

      { label: `${t('systemAdmin.furnaceConfiguration.casing')}`, value: casingValue3 },
      {
        label: `${t('systemAdmin.furnaceConfiguration.casingMassOrLength')}`,
        value: casingMassLenthValue3,
      },
    ],
  };

  return (
    <div style={{ height: '100%', flex: 1, overflow: 'auto' }}>
      {isLoading ? (
        <Loader />
      ) : (
        <div className='container mt-3 mb-3' style={{ height: 'auto' }}>
          <div className=' card'>
            <div style={{ display: 'flex' }}>
              <div
                style={{
                  display: 'flex',
                  width: '50%',
                  alignItems: 'center',
                  padding: '14px 31px 14px 31px',
                  gap: '15px',
                  borderTop: '2px solid #0D659E',
                  borderTopLeftRadius: '4px',
                }}
              >
                <p
                  style={{
                    width: '32px',
                    height: '32px',
                    borderRadius: '50%',
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    backgroundColor: '#0D659E',
                    color: '#fff',
                  }}
                >
                  1
                </p>
                <p
                  style={{
                    fontSize: '14px',
                    fontWeight: 700,
                    color: '#0D659E',
                  }}
                >
                  {`${t('systemAdmin.furnaceConfiguration.basicInformation')}`}
                </p>
              </div>
              <button
                style={{
                  display: 'flex',
                  width: '50%',
                  alignItems: 'center',
                  gap: '15px',
                  padding: '14px 31px 14px 31px',
                  backgroundColor: '#C1D3DF40',
                  cursor: 'pointer',
                  border: 0,
                }}
                onClick={() => setTab(2)}
                onKeyDown={() => setTab(2)}
              >
                <p
                  style={{
                    width: '32px',
                    height: '32px',
                    border: '1px solid #CDD0D1',
                    borderRadius: '50%',
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    backgroundColor: '#fff',
                  }}
                >
                  2
                </p>
                <p
                  style={{
                    fontSize: '14px',
                    fontWeight: 700,
                    color: '#757E85',
                  }}
                >
                  {`${t('systemAdmin.furnaceConfiguration.refiningSteps')}`}
                </p>
              </button>
            </div>
            <div className='card-body' style={{ padding: '0px 20px 0px 20px' }}>
              <div className='btn-edit-absolute d-flex justify-content-end'>
                {hasEditPermission && (
                  <button
                    // onClick={hasEditPermission && handleEditRoleClick}
                    className={`btn btn--h30 py-1 px-2 font-bold mt-4 `}
                    //   ${
                    //   hasEditPermission ? '' : 'disabled'
                    // }`}
                    onClick={() => navigate(`/system-admin/furnace-configuration/edit/${viewId}/1`)}
                  >
                    <img src={editIcon} alt='edit' className='mr-2' /> {`${t('sharedTexts.edit')}`}
                  </button>
                )}
              </div>
              {/* <div>
            {furnaceData.furnace.map((furnace, index) => (
            <div key={index}>

            </div>
            ))}

                
            </div> */}

              {furnaceData?.furnace.map((furnace: any) => (
                <React.Fragment key={furnace}>
                  <div
                    style={{
                      display: 'flex',
                      flexWrap: 'wrap',
                      gap: '15px',
                    }}
                  >
                    {/* Furnace No */}
                    <div style={{ flexBasis: '23%', marginBottom: '5px' }}>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                        <label className='input-field-label font-semibold' htmlFor='furnace_no'>
                          {' '}
                          {`${t('systemAdmin.furnaceConfiguration.furnaceNo')}`}{' '}
                        </label>
                        <span style={{ height: '40px', fontSize: '14px', fontWeight: 600 }}>
                          {furnace.furnace_no}
                        </span>
                      </div>
                    </div>

                    {/* Furnace Description */}
                    <div style={{ flexBasis: '23%', marginBottom: '5px' }}>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                        <label
                          className='input-field-label font-semibold'
                          htmlFor='furnace_description'
                        >{`${t('systemAdmin.furnaceConfiguration.furnaceDescription')}`}</label>
                        <span style={{ height: '40px', fontSize: '14px', fontWeight: 600 }}>
                          {furnace.furnace_description}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div
                    style={{
                      display: 'flex',
                      flexWrap: 'wrap',
                      // justifyContent: 'space-between',
                      gap: '15px',
                      marginBottom: '1px',
                    }}
                  >
                    <div style={{ flexBasis: '23%', marginBottom: '5px' }}>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                        <label className='input-field-label font-semibold' htmlFor='workshop'>
                          {' '}
                          {`${t(`systemAdmin.furnaceConfiguration.workshop`)}`}{' '}
                        </label>
                        <span style={{ height: '20px', fontSize: '14px', fontWeight: 600 }}>
                          {' '}
                          {furnace.workshop_value}
                        </span>
                      </div>
                    </div>

                    <div style={{ flexBasis: '23%', marginBottom: '5px' }}>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                        <label className='input-field-label font-semibold' htmlFor='power_delivery'>
                          {' '}
                          {`${t('systemAdmin.furnaceConfiguration.powerDelivery')}`}{' '}
                        </label>
                        <span style={{ height: '20px', fontSize: '14px', fontWeight: 600 }}>
                          {
                            masterData.filter((val: any) => val.id == furnace.power_delivery)?.[0]
                              ?.value
                          }
                        </span>
                      </div>
                    </div>

                    <div style={{ flexBasis: '23%', marginBottom: '5px' }}>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                        <label className='input-field-label font-semibold' htmlFor='cost_center'>
                          {' '}
                          {`${t('systemAdmin.furnaceConfiguration.costCenter')}`}{' '}
                        </label>
                        <span style={{ height: '20px', fontSize: '14px', fontWeight: 600 }}>
                          {
                            masterData.filter((val: any) => val.id == furnace.cost_center)?.[0]
                              ?.value
                          }
                        </span>
                      </div>
                    </div>

                    {/* <div style={{ flexBasis: '23%', marginBottom: '5px' }}>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                        <label className='input-field-label font-semibold'>Taps Per Day</label>
                        <span style={{ height: '20px', fontSize: '14px', fontWeight: 600 }}>
                          14
                        </span>
                      </div>
                    </div> */}
                  </div>

                  <hr style={{ borderTop: '2px solid #CDD0D1', width: '100%' }} />

                  <div>
                    <p className='title mb-3'>
                      {`${t('systemAdmin.furnaceConfiguration.electrodes')}`} (
                      {
                        masterData.filter((val: any) => val.id == furnace.electrode_type)?.[0]
                          ?.value
                      }
                      )
                    </p>
                    {ProductData.map((val: any) => (
                      <div key={val} style={{ marginBottom: '20px' }}>
                        <Accordion title={val}>
                          <div
                            style={{
                              display: 'grid',
                              gridTemplateColumns: '1fr 1fr',
                              gap: '20px',
                              width: 'fit-content',
                              gridColumnGap: '60px',
                            }}
                          >
                            {dataMapping2[val as keyof typeof dataMapping2].map(
                              (item: any) =>
                                item.value && (
                                  <div
                                    style={{
                                      display: 'flex',
                                      flexDirection: 'row',
                                      gap: '110px',
                                    }}
                                    key={item}
                                  >
                                    <div
                                      style={{
                                        // flex: 1, // Allow the item to grow
                                        minWidth: '150px', // Set a minimum width
                                        fontSize: '14px',
                                        fontWeight: 600,
                                      }}
                                    >
                                      <div
                                        style={{
                                          fontSize: '14px',
                                          fontWeight: 600,
                                          color: ' #5F6466',
                                        }}
                                      >
                                        {item.label}
                                      </div>
                                      <div
                                        style={{
                                          fontSize: '14px',
                                          fontWeight: 600,
                                        }}
                                      >
                                        {item.value}
                                      </div>
                                    </div>
                                  </div>
                                )
                            )}
                          </div>
                        </Accordion>
                      </div>
                    ))}
                  </div>

                  <hr style={{ borderTop: '2px solid #CDD0D1', width: '100%' }} />

                  <div>
                    <p className='title mb-3'>
                      {`${t('systemAdmin.plantConfiguration.products')}`}
                    </p>

                    <div>
                      {productDataList.map((val: any) => (
                        // Check if there is data for the current val before rendering the Accordion
                        <div key={val.product} style={{ marginBottom: '20px' }}>
                          <Accordion title={val.product}>
                            <table style={{ borderCollapse: 'collapse', width: '40%' }}>
                              <thead>
                                <tr>
                                  <th className='input-field-label font-semibold'>
                                    {`${t('systemAdmin.furnaceConfiguration.productCode')}`}
                                  </th>
                                </tr>
                              </thead>
                              <tbody>
                                {val.code.map((item: any) => (
                                  <tr key={item.productCode}>
                                    <td
                                      key={item.productCode}
                                      style={{
                                        fontSize: '14px',
                                        fontWeight: 600,
                                        color: '#041724',
                                      }}
                                    >
                                      {item.productCode}
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </Accordion>
                        </div>
                      ))}
                    </div>
                  </div>

                  <hr style={{ borderTop: '2px solid #CDD0D1', width: '100%' }} />

                  <div>
                    <p className='title mb-3'>{t('systemAdmin.furnaceConfiguration.parameters')}</p>

                    <div
                      style={{
                        display: 'flex',
                        flexWrap: 'wrap',
                        gap: '15px',
                        marginTop: '5px',
                        marginLeft: '2px',
                      }}
                    >
                      {furnace.energy_losses && (
                        <ParameterComponent
                          label={`${t('systemAdmin.furnaceConfiguration.energyLosses')}`}
                          value={furnace.energy_losses}
                        />
                      )}
                      {furnace.joule_losses_coeffient && (
                        <ParameterComponent
                          label={`${t('systemAdmin.furnaceConfiguration.jouleLossesCoefficient')}`}
                          value={furnace.joule_losses_coeffient}
                        />
                      )}
                      {furnace.default_epi_index && (
                        <ParameterComponent
                          label={`${t('systemAdmin.furnaceConfiguration.defaultEpiIndex')}`}
                          value={furnace.default_epi_index}
                        />
                      )}
                      {furnace.corrected_reactance_coefficient && (
                        <ParameterComponent
                          label={`${t('systemAdmin.furnaceConfiguration.correctedReactanceCoefficient')}`}
                          value={furnace.corrected_reactance_coefficient}
                        />
                      )}
                      {furnace.design_mv && (
                        <ParameterComponent
                          label={`${t('systemAdmin.furnaceConfiguration.designMW')}`}
                          value={furnace.design_mv}
                        />
                      )}

                      <ParameterComponent
                        label={`${t('systemAdmin.furnaceConfiguration.defaultMoisture')}`}
                        value={furnace.default_moisture === true ? 'Enabled' : 'Disabled'}
                        color={furnace.default_moisture === true ? '#238903' : 'red'}
                      />
                    </div>
                  </div>

                  <hr style={{ borderTop: '2px solid #CDD0D1', width: '100%' }} />

                  {(furnace.remelt || furnace.sand || furnace.ai || furnace.lime) && (
                    <div>
                      <p className='title mb-3'>Default Ladle Additions</p>

                      <div
                        style={{
                          display: 'flex',
                          flexWrap: 'wrap',
                          //   justifyContent: 'space-between',
                          gap: '15px',
                          marginTop: '12px',
                          marginLeft: '2px',
                        }}
                      >
                        <div style={{ flexBasis: '23%', marginBottom: '5px' }}>
                          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                            <label
                              className={`input-field-label font-semibold ${!furnace.remelt ? 'hidden' : ''}`}
                              htmlFor='remelt'
                            >
                              Remelt
                            </label>
                            <span style={{ height: '40px', fontSize: '14px', fontWeight: 600 }}>
                              {
                                masterData.filter((val: any) => val.id == furnace.remelt)?.[0]
                                  ?.value
                              }
                            </span>
                          </div>
                        </div>

                        <div style={{ flexBasis: '23%', marginBottom: '5px' }}>
                          <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                            <label
                              htmlFor='sand'
                              className={`input-field-label font-semibold ${!furnace.sand ? 'hidden' : ''}`}
                            >
                              Sand
                            </label>
                            <span style={{ height: '40px', fontSize: '14px', fontWeight: 600 }}>
                              {masterData.filter((val: any) => val.id == furnace.sand)?.[0]?.value}
                            </span>
                          </div>
                        </div>
                        <div style={{ flexBasis: '23%', marginBottom: '5px' }}>
                          <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                            <label
                              htmlFor='al'
                              className={`input-field-label font-semibold ${!furnace.ai ? 'hidden' : ''}`}
                            >
                              Al
                            </label>
                            <span style={{ height: '40px', fontSize: '14px', fontWeight: 600 }}>
                              {masterData.filter((val: any) => val.id == furnace.ai)?.[0]?.value}
                            </span>
                          </div>
                        </div>
                        <div style={{ flexBasis: '23%', marginBottom: '5px' }}>
                          <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                            <label
                              htmlFor='lime'
                              className={`input-field-label font-semibold ${!furnace.lime ? 'hidden' : ''}`}
                            >
                              Lime
                            </label>
                            <span style={{ height: '40px', fontSize: '14px', fontWeight: 600 }}>
                              {masterData.filter((val: any) => val.id == furnace.lime)?.[0]?.value}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {(furnace.skull || furnace.slag || furnace.silica_fume_default_material) && (
                    <div>
                      <p
                        className='mt-3'
                        style={{ fontWeight: 500, fontSize: '20px', color: '#041724' }}
                      >
                        {`${t('systemAdmin.furnaceConfiguration.defaultRecoveries')}`}
                      </p>

                      <div
                        style={{
                          display: 'flex',
                          flexWrap: 'wrap',
                          //   justifyContent: 'space-between',
                          gap: '15px',
                          marginTop: '12px',
                          marginLeft: '2px',
                          marginBottom: '20px',
                        }}
                      >
                        <div style={{ flexBasis: '23%', marginBottom: '5px' }}>
                          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                            <label
                              htmlFor='slag'
                              className={`input-field-label font-semibold ${!furnace.slag ? 'hidden' : ''}`}
                            >
                              {`${t('systemAdmin.furnaceConfiguration.slagProductDefaultMaterial')}`}
                            </label>
                            <span style={{ height: '40px', fontSize: '14px', fontWeight: 600 }}>
                              {masterData.filter((val: any) => val.id == furnace.slag)?.[0]?.value}
                            </span>
                          </div>
                        </div>

                        <div style={{ flexBasis: '23%', marginBottom: '5px' }}>
                          <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                            <label
                              className={`input-field-label font-semibold ${!furnace.skull ? 'hidden' : ''}`}
                              htmlFor='skull'
                            >
                              {`${t('systemAdmin.furnaceConfiguration.skullDefaultMaterial')}`}
                            </label>
                            <span
                              style={{
                                height: '40px',
                                width: '200px',
                                fontSize: '14px',
                                fontWeight: 600,
                              }}
                            >
                              {masterData.filter((val: any) => val.id == furnace.skull)?.[0]?.value}
                            </span>
                          </div>
                        </div>

                        {furnace.silica_fume_default_material && (
                          <ParameterComponent
                            label={`${t('systemAdmin.furnaceConfiguration.silicaFumeDefaultMaterial')}`}
                            value={
                              masterData.filter(
                                (val: any) => val.id == furnace.silica_fume_default_material
                              )?.[0]?.value
                            }
                          />
                        )}
                      </div>
                    </div>
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FurnaceView;
