import BasicInfoNameSection from 'components/common/FormComponents/BasicInfoNameSection/BasicInfoNameSection';
import DefaultRecoveries from 'components/common/FormComponents/DefaultRecoveries/DefaultRecoveries';
import ProductsSection from 'components/common/FormComponents/ProductsSection/ProductsSection';
import PlantFooter from 'components/common/PlantFooter';
import _ from 'lodash';
import { useEffect, useState } from 'react';
// import { useTranslation } from 'react-i18next';
import { useAppDispatch, useAppSelector } from 'store';
// import { submitBasicInfo, updateBasicInfo } from 'store/slices/furnaceConfigurationSlice';
import { crudType } from 'utils/constants';
import {
  getBasicInfo,
  setFurnaceBasicInfo,
  submitBasicInfo,
  updateBasicInfo,
} from 'store/slices/furnaceConfigurationSlice';
import { furnaceConfigTabs } from 'utils/constants';
import { Box } from '@mui/material';
import { paths } from 'routes/paths';
import { useNavigate } from 'react-router-dom';
import { notify } from 'utils/utils';
import { useTranslation } from 'react-i18next';
import editIcon from 'assets/icons/edit-thick.svg';

interface BasicInfoProps {
  tabValue: number;
  handleTabClick: (tab: number) => void;
}

const BasicInfo: React.FC<BasicInfoProps> = ({ tabValue, handleTabClick }) => {
  // const { t } = useTranslation();
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const { t } = useTranslation();
  const furnaceBasicInfo = useAppSelector((state) => state.furnaceConfiguration.furnaceBasicInfo);
  const furnaceBasicInfoErrors = useAppSelector(
    (state) => state.furnaceConfiguration.furnaceBasicInfoErrors
  );
  const { furnaceConfigId, furnaceNo } = useAppSelector((state) => state.furnaceConfiguration);
  const userDataString = useAppSelector((state) => state.userData.userData);
  const user: any = userDataString ? userDataString : null;

  const plantDataString = useAppSelector((state) => state.plantData.plantData);
  const plantData: any = plantDataString ?? null;
  const local_plant_id: any = plantData.plant_id;
  const formAction = useAppSelector((state) => state.furnaceConfiguration.formAction);

  const [submitButtonDisabled, setSubmitButtonDisabled] = useState<boolean>();

  // disabling of button - each tab will have its own
  useEffect(() => {
    const checkFurnaceBasicInfo = () => {
      // Keys required for submission
      const requiredKeys = [
        'furnace_no',
        'furnace_description',
        'workshop',
        'power_delivery',
        'cost_center',
        'furnace_products',
      ];
      const allKeysPresent = _.every(
        requiredKeys,
        (key) => furnaceBasicInfo[key] !== undefined && furnaceBasicInfo[key] !== ''
      );

      // Check if there are any errors
      const hasErrors = Object.values(furnaceBasicInfoErrors).some((error) => error !== '');

      // Enable/disable submit button based on presence of required keys and absence of errors or any error keys
      setSubmitButtonDisabled(!allKeysPresent || hasErrors);
    };

    // Call the function to check furnaceBasicInfo initially and whenever it changes
    checkFurnaceBasicInfo();
  }, [furnaceBasicInfo, furnaceBasicInfoErrors]);

  const handleBasicInfoTabPrimaryClick = () => {
    // alert('api call');
    // alert("plant id " + local_plant_id)
    if (formAction === crudType.edit) {
      // alert('edit api call');
      dispatch(updateBasicInfo({ ...furnaceBasicInfo })).then((response) => {
        // console.log('response', response.payload.data.id);
        // DO A DISPATCH, GET THE NEW DATA
        if (response.payload.data.id) {
          // alert('fired !!');
          notify('success', t(response.payload?.data?.message));
          dispatch(getBasicInfo(response.payload.data.id)).then((thenData) => {
            dispatch(setFurnaceBasicInfo(thenData.payload.data));
            handleTabClick(furnaceConfigTabs.electrodes);
          });
        }
      });
    } else {
      // alert('create api call');
      // dispatch(submitBasicInfo({ ...furnaceBasicInfo, plant_id: local_plant_id }));

      dispatch(submitBasicInfo({ ...furnaceBasicInfo, plant_id: local_plant_id })).then(
        (response) => {
          if (response?.payload?.data?.id) {
            notify('success', t(response.payload?.data?.message));
            dispatch(
              setFurnaceBasicInfo({
                ...furnaceBasicInfo,
                furnaceId: response.payload.data.id,
              })
            );
            handleTabClick(furnaceConfigTabs.electrodes);
          } else if (response.payload?.status === 400) {
            // 400 - bad request is received when api finds some validation issues
            _.forEach(response.payload.data, (value) => {
              if (_.isString(value)) {
                notify('info', value);
              }
            });
            // any exception case while adding furnace should be handled here
          } else {
            notify('error', 'unexpected error...');
          }
        }
      );
    }
  };

  const handleEditClickAction = () => {
    navigate('/system-admin/furnace-configuration/edit', {
      state: {
        action: crudType.edit,
        viewOrEditId: furnaceConfigId,
        title: furnaceNo,
      } as NavigateState,
    });
  };

  return (
    <div className='tab-container'>
      {/* DEV - purpose */}
      {/* <h1>Main state - global (furnaceBasicInfo)</h1>
      <pre>{JSON.stringify(furnaceBasicInfo, null, 2)} </pre> */}
      {/* {console.log("furnaceBasicInfo",furnaceBasicInfo)}  */}
      {/* <h1>Main Errors state - global (furnaceBasicInfoErrors)</h1>
      {JSON.stringify(furnaceBasicInfoErrors)}
      DEV - purpose */}

      {user.is_superuser && formAction === crudType.view && (
        <div className='d-flex justify-content-end'>
          <button
            className={`btn btn--h30 py-1 px-3 font-bold mb-4`}
            onClick={handleEditClickAction}
          >
            <img src={editIcon} alt='edit' className='mr-2' /> {`${t('sharedTexts.edit')}`}
          </button>
        </div>
      )}

      <BasicInfoNameSection />
      <hr className='line-break' />
      {formAction === crudType.view &&
      furnaceBasicInfo?.furnace_products &&
      furnaceBasicInfo?.furnace_products?.length > 0 ? (
        <>
          <ProductsSection />
          <hr className='line-break' />
        </>
      ) : (
        <>
          {!(formAction === crudType.view) && (
            <>
              <ProductsSection />
              <hr className='line-break' />
            </>
          )}
        </>
      )}
      <div style={{ marginBottom: '6rem' }}>
        <DefaultRecoveries />
      </div>
      {!(formAction === crudType.view) && (
        <Box position='fixed' bottom={0} left={0} right={0}>
          <PlantFooter
            disabled={submitButtonDisabled}
            currentTab={tabValue}
            onback={() => navigate(`${paths.furnaceConfig.list}`)}
            onClickOfPrimaryButton={() => handleBasicInfoTabPrimaryClick()}
          />
        </Box>
      )}
    </div>
  );
};

export default BasicInfo;
