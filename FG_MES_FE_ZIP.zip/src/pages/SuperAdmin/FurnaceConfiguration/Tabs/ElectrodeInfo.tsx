import { Box, Stack } from '@mui/material';
import Loading from 'components/common/Loading';
import PlantFooter from 'components/common/PlantFooter';
import ElectrodeAccordion from 'components/FurnaceConfigComponents/ElectrodeAccordion';
import ElectrodeHeaderForm from 'components/FurnaceConfigComponents/ElectrodeHeaderForm';
import AlertModal from 'components/Modal/AlertModal';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import { paths } from 'routes/paths';
import { useAppDispatch, useAppSelector } from 'store';
import {
  addOrEditElectrodeInfo,
  getFurnaceElectrodes,
  setFurnaceElectrodes,
} from 'store/slices/furnaceConfigurationSlice';
import { FurnaceElectrodeInfo } from 'types/furnaceConfig.model';
import { crudType, furnaceConfigTabs } from 'utils/constants';
import { notify } from 'utils/utils';

interface ElectrodeInfoProps {
  tabValue: number;
  handleTabClick: (tab: number) => void;
}

const ElectrodeInfo: React.FC<ElectrodeInfoProps> = ({ tabValue, handleTabClick }) => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const {
    furnaceElectrodes,
    loading: electrodesLoading,
    furnaceBasicInfo,
    formAction,
    furnaceConfigId,
    furnaceElectrodeNames,
  } = useAppSelector((state) => state.furnaceConfiguration);
  const [isErrorsExists, setIsErrorsExists] = useState<boolean>(false);
  const [showElectrodesUpdatePrompt, setShowElectrodesUpdatePrompt] = useState<boolean>(false);

  useEffect(() => {
    setIsErrorsExists(checkForErrors(furnaceElectrodes));
  }, [furnaceElectrodes]);

  useEffect(() => {
    if (furnaceConfigId) {
      dispatch(getFurnaceElectrodes(furnaceConfigId));
    }
  }, [dispatch, furnaceConfigId]);

  useEffect(() => {
    dispatch(
      setFurnaceElectrodes({
        ...furnaceElectrodes,
        furnace_config: furnaceConfigId,
      })
    );
  }, [dispatch, furnaceConfigId]);

  useEffect(() => {
    dispatch(
      setFurnaceElectrodes({
        ...furnaceElectrodes,
        furnace_config: furnaceBasicInfo.furnaceId ?? furnaceBasicInfo?.id,
      })
    );
  }, [dispatch, furnaceBasicInfo]);

  const checkForErrors = (furnaceElectrodes: FurnaceElectrodeInfo) => {
    const fieldErrors = furnaceElectrodes?.fieldErrors ?? {};
    return (
      Object.keys(fieldErrors).length > 0 ||
      !furnaceElectrodes.electrode_type_code ||
      !furnaceElectrodes.diameter ||
      !furnaceElectrodes.effective_date ||
      furnaceElectrodes.isAnyElectrodeFieldEmpty
    );
  };

  const handleElectrodesSubmit = () => {
    dispatch(addOrEditElectrodeInfo(furnaceElectrodes)).then(({ payload }) => {
      const electrodeOnSubmitResponse = payload.data;
      if (payload.status === 200) {
        if (electrodeOnSubmitResponse?.user_approval_needed) {
          setShowElectrodesUpdatePrompt(true);
        } else {
          notify('success', `${t(electrodeOnSubmitResponse.message)}`);
          // refetch of electrodes
          if (furnaceConfigId) dispatch(getFurnaceElectrodes(furnaceConfigId)); // - check
          handleTabClick(furnaceConfigTabs.parameters);
        }
      }
    });
  };

  const handleElectrodesCancel = () => {
    navigate(`${paths.furnaceConfig.list}`);
  };

  const handleElectrodePromptCancel = () => {
    setShowElectrodesUpdatePrompt(false);
    if (furnaceConfigId) dispatch(getFurnaceElectrodes(furnaceConfigId)); //  - check
  };

  const handleElectrodePromptConfirm = () => {
    dispatch(addOrEditElectrodeInfo({ ...furnaceElectrodes, is_user_approved: true })).then(
      ({ payload }) => {
        const electrodeOnSubmitResponse = payload.data;
        if (payload.status === 200) {
          if (electrodeOnSubmitResponse?.user_approval_needed) {
            notify('warning', 'something went wrong...');
          } else {
            notify('success', `${t(electrodeOnSubmitResponse.message)}`);
            // refetch of electrodes
            if (furnaceConfigId) dispatch(getFurnaceElectrodes(furnaceConfigId)); //  - check
            handleTabClick(furnaceConfigTabs.parameters);
          }
        }
      }
    );
  };

  if (electrodesLoading) {
    return <Loading />;
  }

  return (
    <div className='tab-container'>
      {/* <pre>{JSON.stringify(furnaceElectrodes,null, 2)}</pre> */}
      <Box display='flex' flexDirection='column' flex={1} position='relative' height='100%'>
        <Stack spacing={3} flexGrow={1} pb={12}>
          <Box>
            <ElectrodeHeaderForm />
          </Box>
          {furnaceElectrodeNames?.map((electrodeName) => {
            return (
              <Box key={electrodeName}>
                <ElectrodeAccordion electrodeName={electrodeName} />
              </Box>
            );
          })}
        </Stack>
      </Box>
      {formAction !== crudType.view && (
        <Box position='fixed' bottom={0} left={0} right={0}>
          <PlantFooter
            disabled={isErrorsExists}
            currentTab={tabValue}
            onback={handleElectrodesCancel}
            onClickOfPrimaryButton={handleElectrodesSubmit}
          />
        </Box>
      )}
      <AlertModal
        showModal={showElectrodesUpdatePrompt}
        title={'Confirm Electrode Changes?'}
        content={'Some parameters already exist in this date. Do you wish to overwrite them?'}
        confirmButtonText={t('sharedTexts.proceed')}
        onConfirmClick={() => handleElectrodePromptConfirm()}
        closeModal={() => handleElectrodePromptCancel()}
      />
    </div>
  );
};

export default ElectrodeInfo;
