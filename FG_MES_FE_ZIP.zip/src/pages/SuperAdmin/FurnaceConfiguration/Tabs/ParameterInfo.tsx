import React, { useEffect, useState } from 'react';
import { Box, Stack } from '@mui/material';
import ParameterForm from 'components/FurnaceConfigComponents/ParameterForm';
import PlantFooter from 'components/common/PlantFooter';
import { crudType, furnaceConfigTabs } from 'utils/constants';
import { paths } from 'routes/paths';
import { useNavigate } from 'react-router-dom';
import { FurnaceParameterInfo } from 'types/furnaceConfig.model';
import { useAppDispatch, useAppSelector } from 'store';
import {
  addOrEditParameterInfo,
  getFurnaceParameters,
  setFurnaceParameters,
} from 'store/slices/furnaceConfigurationSlice';
import Loading from 'components/common/Loading';
import { notify } from 'utils/utils';
import { useTranslation } from 'react-i18next';
import AlertModal from 'components/Modal/AlertModal';
import editIcon from 'assets/icons/edit-thick.svg';
import dayjs from 'dayjs';

interface ElectrodeInfoProps {
  tabValue: number;
  handleTabClick: (tab: number) => void;
}

const ParameterInfo: React.FC<ElectrodeInfoProps> = ({ tabValue, handleTabClick }) => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const [showParametersUpdatePrompt, setShowElectrodesUpdatePrompt] = useState<boolean>(false);
  const { t } = useTranslation();
  const {
    furnaceBasicInfo,
    furnaceParameters,
    loading: parametersLoading,
    formAction,
    furnaceConfigId,
    furnaceNo,
  } = useAppSelector((state) => state.furnaceConfiguration);
  const [isErrorsExists, setIsErrorsExists] = useState<boolean>(false);
  const handleParameterCancel = () => {
    navigate(`${paths.furnaceConfig.list}`);
  };
  const userDataString = useAppSelector((state) => state.userData.userData);
  const user: any = userDataString ? userDataString : null;

  const checkForErrors = (furnaceParameters: FurnaceParameterInfo) => {
    const fieldErrors = furnaceParameters?.fieldErrors ?? {};
    return (
      Object.keys(fieldErrors).length > 0 ||
      !furnaceParameters.effective_date ||
      furnaceParameters.isAnyParameterFieldEmpty
    );
  };

  useEffect(() => {
    setIsErrorsExists(checkForErrors(furnaceParameters));
  }, [furnaceParameters]);

  useEffect(() => {
    if (furnaceConfigId) {
      dispatch(getFurnaceParameters(furnaceConfigId));
    }
  }, [dispatch, furnaceConfigId]);

  useEffect(() => {
    dispatch(
      setFurnaceParameters({
        ...furnaceParameters,
        furnace_config: furnaceConfigId,
        effective_date: dayjs().format('YYYY-MM-DD'),
      })
    );
  }, [dispatch, furnaceConfigId]);

  useEffect(() => {
    dispatch(
      setFurnaceParameters({
        ...furnaceParameters,
        furnace_config: furnaceBasicInfo.furnaceId ?? furnaceBasicInfo?.furnace_no,
        effective_date: dayjs().format('YYYY-MM-DD'),
      })
    );
  }, [dispatch, furnaceBasicInfo]);

  const handleParametersSubmit = () => {
    dispatch(addOrEditParameterInfo(furnaceParameters)).then(({ payload }) => {
      const parameterOnSubmitResponse = payload.data;
      if (payload.status === 200) {
        if (parameterOnSubmitResponse?.user_approval_needed) {
          setShowElectrodesUpdatePrompt(true);
        } else {
          notify('success', `${t(parameterOnSubmitResponse.message)}`);
          if (furnaceConfigId) {
            dispatch(getFurnaceParameters(furnaceConfigId));
          }
          handleTabClick(furnaceConfigTabs.refiningSteps);
        }
      }
    });
  };

  const handleElectrodePromptCancel = () => {
    setShowElectrodesUpdatePrompt(false);
    if (furnaceConfigId) {
      dispatch(getFurnaceParameters(furnaceConfigId));
    }
  };

  const handleElectrodePromptConfirm = () => {
    dispatch(addOrEditParameterInfo({ ...furnaceParameters, is_user_approved: true })).then(
      ({ payload }) => {
        const parameterOnSubmitResponse = payload.data;
        if (payload.status === 200) {
          if (parameterOnSubmitResponse?.user_approval_needed) {
            notify('warning', 'something went wrong...');
          } else {
            notify('success', `${t(parameterOnSubmitResponse.message)}`);
            if (furnaceConfigId) {
              dispatch(getFurnaceParameters(furnaceConfigId));
            }

            handleTabClick(furnaceConfigTabs.refiningSteps);
          }
        }
      }
    );
  };

  if (parametersLoading) {
    return <Loading />;
  }

  const handleEditClickAction = () => {
    navigate('/system-admin/furnace-configuration/edit', {
      state: {
        action: crudType.edit,
        viewOrEditId: furnaceConfigId,
        title: furnaceNo,
      } as NavigateState,
    });
  };

  return (
    <div className='tab-container'>
      <Box display='flex' flexDirection='column' flex={1} position='relative' height='100%'>
        <Stack spacing={3} flexGrow={1} pb={8}>
          <Box>
            {user.is_superuser && formAction === crudType.view && (
              <div className='d-flex justify-content-end'>
                <button
                  className={`btn btn--h30 py-1 px-3 font-bold mb-4`}
                  onClick={handleEditClickAction}
                >
                  <img src={editIcon} alt='edit' className='mr-2' /> {`${t('sharedTexts.edit')}`}
                </button>
              </div>
            )}
            <ParameterForm />
          </Box>
        </Stack>
      </Box>
      {formAction !== crudType.view && (
        <Box position='fixed' bottom={0} left={0} right={0}>
          <PlantFooter
            disabled={isErrorsExists}
            currentTab={tabValue}
            onback={handleParameterCancel}
            onClickOfPrimaryButton={handleParametersSubmit}
          />
        </Box>
      )}

      <AlertModal
        showModal={showParametersUpdatePrompt}
        title={'Confirm Parameter Changes?'}
        content={'Some parameters already exist in this date. Do you wish to overwrite them?'}
        confirmButtonText={t('sharedTexts.proceed')}
        onConfirmClick={() => handleElectrodePromptConfirm()}
        closeModal={() => handleElectrodePromptCancel()}
      />
    </div>
  );
};

export default ParameterInfo;
