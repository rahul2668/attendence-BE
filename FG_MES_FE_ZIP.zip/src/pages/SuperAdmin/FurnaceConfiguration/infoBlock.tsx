import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useAppSelector } from 'store';

interface InfoBlockProps {
  label: any;
  value: string | number;
  flexBasis: string;
  marginBottom: any;
  type?: string; // Optional prop for defining the type
}

const commonLabelStyle = {
  fontWeight: 600,
  fontSize: '14px',
  color: '#5F6466',
};

const InfoBlock: React.FC<InfoBlockProps> = ({
  label,
  value,
  flexBasis,
  marginBottom,
  type,
}: any) => {
  const { t } = useTranslation();
  const [enabled, setEnabled] = useState(type === 'mandatory');
  const allUnits = useAppSelector((state: any) => state?.unit?.units);

  const translationKey: any = `systemAdmin.furnaceConfiguration.${label}`;
  const translatedString = t(translationKey);

  // If the translation exists, `translatedString` will be the translated value,
  // otherwise, it will be the same as `translationKey`
  const displayLabel = translatedString !== translationKey ? translatedString : label;

  useEffect(() => {
    setEnabled(type === 'mandatory');
  }, [type]);

  return (
    <div
      style={{
        flexBasis,
        marginBottom: `${marginBottom}px`,
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
      }}
    >
      <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
        <label style={commonLabelStyle}>{t(displayLabel)}</label>
        <span
          style={{
            height: '40px',
            fontSize: '13px',
            fontWeight: 600,
            paddingTop: '5px',
          }}
        >
          {`${value} ${allUnits?.filter((item: any) => item.name === label)[0]?.unit}`}
        </span>
      </div>
      <span
        style={{
          margin: '0 4px',
          fontSize: '14px',
          fontWeight: 600,
          color: '#989A9C',
          marginTop: '10px',
        }}
      >
        |
      </span>
      <p style={{ fontWeight: 600, fontSize: '14px', marginTop: '10px' }}>
        {enabled
          ? `${t('systemAdmin.furnaceConfiguration.mandatory')}`
          : `${t('systemAdmin.furnaceConfiguration.notMandatory')}`}
      </p>
    </div>
  );
};

export default InfoBlock;
