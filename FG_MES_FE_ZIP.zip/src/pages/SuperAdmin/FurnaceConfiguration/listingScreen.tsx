/* eslint-disable react-hooks/rules-of-hooks */
import { useEffect, useState } from 'react';
import Header from 'components/common/EmptyHeader';
import { useLocation, useNavigate } from 'react-router-dom';
import { paths } from 'routes/paths';
import Loader from 'components/Loader';
import AlertModal from 'components/Modal/AlertModal';
import httpClient from 'http/httpClient';
import { notify, validatePermissions } from 'utils/utils';
import Pagination from 'components/common/Pagination';
import { crudType, permissionsMapper } from 'utils/constants';
import { useTranslation } from 'react-i18next';
import _ from 'lodash';
import ReusableTable from 'components/common/ReusableTable/ReusableTable';
import { formatFurnace, furnaceConfigTableHeaders, toolTipsForFurnace } from './helper';
import { useAppDispatch, useAppSelector } from 'store';
import { setFurnaceNo } from 'store/slices/furnaceConfigurationSlice';

const ListingScreen = () => {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const { t } = useTranslation();
  const plantDataString = useAppSelector((state) => state.plantData.plantData);
  const plantData: any = plantDataString ?? null;
  const local_plant_id: any = plantData.plant_id;
  const [furnaceData, setFurnaceData] = useState<any>(null);
  const [furnaceDataList, setFurnaceDataList] = useState<any>([]);
  const [isLoading, setIsLoading] = useState(true);
  const itemsPerPage = 10;
  const [count, setCount] = useState(null);
  const [previous, setPrevious] = useState([]);
  const [next, setNext] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  // data which is passed the reusable table
  const [renderedFurnaceData, setRenderedFurnaceData] = useState([]);
  // delete modal control state
  const [showDeactivateOrActivateModal, setShowDeactivateOrActivateModal] =
    useState<boolean>(false);
  // since the activate and deactivate has confirm modals, the role is temporarily stored in a state
  const [selectedFurnace, setSelectedFurnace] = useState<any>();
  // Same modal is used for activate and deactivate. so the texts passes are stored in these states
  const [modalConfirmButtonText, setModalConfirmButtonText] = useState<string>('');
  const [modalTitle, setModalTitle] = useState<string>('');
  const [modalContent, setModalContent] = useState<string>('');

  //  ------------ permissions (reflected on icons)-------------
  const { pathname } = useLocation();
  const module = pathname?.split('/')[1];
  const subModule = pathname?.split('/')[2];

  const furnacePermissions = {
    hasEdit: validatePermissions(
      permissionsMapper[module],
      permissionsMapper[subModule],
      crudType.edit
    ),
    // delete permission decides the deactivation
    hasDeactivate: validatePermissions(
      permissionsMapper[module],
      permissionsMapper[subModule],
      crudType.delete
    ),
  };
  //  ------------ permissions end -------------

  // furnace list data fetching and pagination functions  ----------------------------
  const fetchData = async () => {
    try {
      setCurrentPage(1);
      const response = await httpClient.get(
        `/api/furnace-config/basic-info/?plant_id=${local_plant_id}`
      );
      const data: any = response.data;
      setIsLoading(false);
      setFurnaceDataList(data);
      setCount(data.length);
      setPrevious(data);
      setNext(data);
    } catch (error) {
      console.error('Error fetching data:', error);
      // Handle the error, e.g., set an error state or show a message to the user
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const onPageChange = (newPage: any) => {
    if (newPage !== 0) {
      setCurrentPage(newPage);
      const filterData = furnaceDataList.filter((val: any, index: any) => {
        if (index >= newPage * itemsPerPage - itemsPerPage && index < newPage * itemsPerPage) {
          return val;
        }
      });

      setFurnaceData({ furnace: filterData });
    }
  };

  useEffect(() => {
    const filterData = furnaceDataList.filter((val: any, index: any) => {
      if (index >= 1 * itemsPerPage - itemsPerPage && index < 1 * itemsPerPage) {
        return val;
      }
    });

    setFurnaceData({ furnace: filterData });
  }, [furnaceDataList]);
  // furnace list data fetching and pagination functions  ----------------------------

  // sort Logic with lodash
  const sortHandler = (columnName: string, sortOrder: 'ASC' | 'DESC') => {
    const sortOrderToPass: 'asc' | 'desc' = sortOrder === 'ASC' ? 'asc' : 'desc';

    const sortedFurnaceData = _.orderBy(furnaceDataList, [columnName], [sortOrderToPass]);
    setFurnaceData({ furnace: sortedFurnaceData });
  };

  // The data is Formatted to be used in reusable Table. The formatting is needed everywhere the reusable table is used
  useEffect(() => {
    if (furnaceData?.furnace) setRenderedFurnaceData(furnaceData?.furnace.map(formatFurnace));
  }, [furnaceData]);

  // ICONS ICON CALLBACKS PASSED TO THE CHILD (these fire on respective icon click) -----------------

  // gets called on view icon click
  const handleViewClickAction = (rowData: any) => {
    const { furnaceId, furnaceNo } = rowData;
    dispatch(setFurnaceNo(furnaceNo));
    navigate('/system-admin/furnace-configuration/view', {
      state: {
        action: crudType.view,
        viewOrEditId: furnaceId,
        title: furnaceNo,
      } as NavigateState,
    });
  };

  // gets called on edit icon click
  const handleEditClickAction = (rowData: any) => {
    const { furnaceId, furnaceNo } = rowData;
    dispatch(setFurnaceNo(furnaceNo));
    navigate('/system-admin/furnace-configuration/edit', {
      state: {
        action: crudType.edit,
        viewOrEditId: furnaceId,
        title: furnaceNo,
      } as NavigateState,
    });
  };

  const handleDeactivateAction = (rowData: any) => {
    //sets up the modal and stores the role data in a state temporarily
    setSelectedFurnace(rowData);
    setShowDeactivateOrActivateModal(true);
    setModalTitle(t('sharedTexts.alert'));
    setModalConfirmButtonText(t('sharedTexts.deactivate'));
    setModalContent(`Do you want to deactivate this Furnace?`); // change to language key
  };

  // called on activate icon onclick
  const handleActivateIconClick = (rowData: any) => {
    //sets up the modal and stores the role data in a state temporarily
    setSelectedFurnace(rowData);
    setShowDeactivateOrActivateModal(true);
    setModalTitle(t('sharedTexts.alert'));
    setModalConfirmButtonText(t('sharedTexts.proceed'));
    setModalContent(`Do you want to Activate this Furnace?`); // change to language key
  };

  // ICONS ICON CALLBACKS PASSED TO THE CHILD - END ------------------------------

  // ACTIVATE / DEACTIVATE FUNC - gets called after modal confirmation click
  // same function, same api call, same param. api logic toggles the active status of a furnace, just need to pass PK
  const handleDeactivateOrActivateConfirmClick = () => {
    changeStatusOfRole(selectedFurnace?.furnaceId);
  };

  // API which toggles the status of a furnace - used for both activate and deactivate
  const changeStatusOfRole = async (furnaceId: any) => {
    setShowDeactivateOrActivateModal(false);
    setIsLoading(true);
    httpClient
      .patch(`/api/furnace-config/basic-info/${furnaceId}/`)
      .then((response: any) => {
        if (response.status === 200) {
          if (response.data) {
            fetchData();
            setIsLoading(true);
            notify('success', t(response.data.message));
          }
        } else if (response.data?.error) {
          fetchData();
          setIsLoading(true);
        }
      })
      .catch(() => {
        fetchData();
        notify('error', `${t('userAccessControl.users.failedToChangeUserStatus')}`);
        setShowDeactivateOrActivateModal(false);
      });
  };

  return (
    <>
      <Header
        title={t('plantModulesAndFunctions.FUR_CFG')}
        buttonText={`${t('systemAdmin.furnaceConfiguration.addNewFurnace')}`}
        onButtonClick={() =>
          navigate(paths.furnaceConfig.create, {
            state: {
              action: crudType.create,
            },
          })
        }
      />

      <div>
        {isLoading ? (
          <Loader />
        ) : (
          <div className='container mt-3 mb-3' style={{ height: '85vh', overflow: 'auto' }}>
            {/* <div className='container card' style={{ height: '100%' x}}> */}
            {furnaceData?.furnace?.length > 0 ? (
              <ReusableTable
                columnsToDisplayAsPills={['status']}
                mainHeaders={furnaceConfigTableHeaders}
                renderData={renderedFurnaceData}
                showActionIconsInRow // if this is not provided then there wil be a gap in table columns - to fix it pass empty key in formatting function
                sortHandler={sortHandler}
                rowActionsPermission={furnacePermissions}
                callBackOnAddClick={handleEditClickAction}
                callBackOnEditClick={handleEditClickAction}
                callBackOnViewClick={handleViewClickAction}
                callBackOnDeactivationClick={handleDeactivateAction}
                callBackOnActivationClick={handleActivateIconClick}
                showOnlyAddButtonDependencyKey={'showOnlyAddButton'}
                showOnlyActivateAndAddButtonDependencyKey={'showOnlyActivateAndAddButton'}
                // IMP => MAKE SURE THE KEYS WHICH ARE NOT RENDERED IN THE TABLE IS PASSES IN THIS 'columnsToIgnoreInRendering'!!
                // ie, showActivateButton - these are dependency keys here. 'furnaceId' is not rendered, but needed in action callbacks
                columnsToIgnoreInRendering={[
                  'showOnlyAddButton',
                  'furnaceId',
                  'showOnlyActivateAndAddButton',
                ]}
                toolTips={toolTipsForFurnace}
              />
            ) : (
              <p className='d-flex justify-content-center mt-5'>
                {t('sharedTexts.noRecordsFound')}
              </p>
            )}

            <Pagination
              totalItems={count}
              itemsPerPage={itemsPerPage}
              onPageChange={onPageChange}
              currentPage={currentPage}
              previous={previous}
              next={next}
            />
            {/* </div> */}
          </div>
        )}

        {/* DEACTIVATE / activate CONFIRMATION MODAL  */}
        {showDeactivateOrActivateModal && (
          <AlertModal
            showModal={showDeactivateOrActivateModal}
            closeModal={() => {
              setShowDeactivateOrActivateModal(false);
            }}
            onConfirmClick={handleDeactivateOrActivateConfirmClick}
            title={modalTitle}
            content={modalContent}
            confirmButtonText={modalConfirmButtonText}
          />
        )}
      </div>
    </>
  );
};

export default ListingScreen;
