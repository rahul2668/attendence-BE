import 'assets/styles/scss/pages/furnace.scss';
import { useLocation, useNavigate } from 'react-router-dom';
import editIcon from 'assets/icons/edit-thick.svg';
import InfoBlock from './infoBlock';
import { useEffect, useState } from 'react';
import Loader from 'components/Loader';
import httpClient from 'http/httpClient';
import ChangehistoryModal from 'components/Modal/ChangehistoryModal';
import { validatePermissions } from 'utils/utils';
import { crudType, permissionsMapper } from 'utils/constants';
import { useAppSelector } from 'store';
import { useTranslation } from 'react-i18next';

interface InfoBlockProps {
  label: any;
  value: string | number;
  flexBasis: string;
  marginBottom: any;
  type?: string; // Optional prop for defining the type
  viewOnly?: boolean; // Optional prop for indicating view-only mode
  unit?: any;
}
const commonLabelStyle = {
  fontWeight: 600,
  fontSize: '14px',
  color: '##041724',
};

const AdditiveBlock: React.FC<InfoBlockProps> = ({
  label,
  value,
  flexBasis,
  marginBottom,
  unit,
}: any) => (
  <div
    style={{ flexBasis, marginBottom, display: 'flex', flexDirection: 'row', alignItems: 'center' }}
  >
    <label style={commonLabelStyle}>{label}</label>
    <span style={{ margin: '0 4px', fontSize: '14px', fontWeight: 600, color: '#989A9C' }}>|</span>
    <span style={{ marginLeft: '2px', fontSize: '14px', fontWeight: 600 }}>
      {value} <span style={{ fontSize: '13px' }}>{unit}</span>
    </span>
  </div>
);

const RefiningSteps = () => {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [stepData, setStepData] = useState<any>([]);
  const [stepDataMapping, setStepDataMapping] = useState<any>({});
  const [additiveData, setAdditiveData] = useState<any>({});
  const [masterData, setMasterData] = useState<any>([]);
  const [isLoading, setIsLoading] = useState<any>(true);
  const [showChangeHistoryModal, setShowChangeHistoryModal] = useState<boolean>(false);
  const [changeLogData, setChangeLogData] = useState<any>([]);
  const { furnaceConfigId, furnaceNo } = useAppSelector((state) => state.furnaceConfiguration);

  const { pathname } = useLocation();
  const module = pathname?.split('/')[1];
  const subModule = pathname?.split('/')[2];

  const hasEditPermission = validatePermissions(
    permissionsMapper[module],
    permissionsMapper[subModule],
    crudType.edit
  );
  const allUnits = useAppSelector((state: any) => state?.unit?.units);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await httpClient.get(
          `/api/furnace-config/refining-steps/${furnaceConfigId}/`
        );
        const responseData: any = response.data;
        setIsLoading(false);

        if (Array.isArray(responseData.data)) {
          const data = responseData.data;
          const stepDataMapping: any = {};
          const additiveData: any = {};

          const StepData = data.map((step: any) => {
            const parameters = step.control_parameters.map((param: any) => ({
              label: param.param,
              value: param.value,
              type: param.is_mandatory ? 'mandatory' : 'optional',
              record_status: param.record_status,
            }));

            stepDataMapping[step.step] = parameters;

            const additives = step.additives.map((additive: any) => ({
              label: additive.material,
              value: additive.quantity,
              record_status: additive.record_status,
            }));

            additiveData[step.step] = additives;

            return step.step; // Extract the 'step' value
          });

          setStepData(StepData);
          setStepDataMapping(stepDataMapping);
          setAdditiveData(additiveData);
        } else {
          console.error('Invalid data format:', responseData);
          // Handle the error, e.g., set an error state or show a message to the user
        }
      } catch (error) {
        console.error('Error fetching data:', error);
        // Handle the error, e.g., set an error state or show a message to the user
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    const fetchChangeLogData = async () => {
      try {
        const response = await httpClient.get(`/api/furnace-config/change-log/${furnaceConfigId}`);
        const data: any = response?.data;
        setIsLoading(false);
        setChangeLogData(data?.data);
      } catch (error) {
        console.error('Error fetching data:', error);
        // Handle the error, e.g., set an error state or show a message to the user
      }
    };

    fetchChangeLogData();
  }, []);

  const appmasterData = async () => {
    try {
      const masterResponse: any = await httpClient.get('/api/master/master/');

      const masterResponseList: any = masterResponse?.data;
      setMasterData(masterResponseList);
    } catch (error) {
      // Handle errors here
      console.error('Error fetching data:', error);
    }
  };

  useEffect(() => {
    appmasterData();
  }, []);

  const handleTranslate = (label: string) => {
    const translationKey: any = `systemAdmin.furnaceConfiguration.${label}`;
    const translatedString = t(translationKey);

    // If the translation exists, `translatedString` will be the translated value,
    // otherwise, it will be the same as `translationKey`
    const displayString = translatedString !== translationKey ? translatedString : label;

    return displayString;
  };

  const handleEditClickAction = () => {
    navigate('/system-admin/furnace-configuration/edit', {
      state: {
        action: crudType.edit,
        viewOrEditId: furnaceConfigId,
        title: furnaceNo,
      } as NavigateState,
    });
  };

  return (
    <>
      {isLoading ? (
        <Loader />
      ) : (
        <div className='tab-container'>
          {hasEditPermission && (
            <div className='d-flex justify-content-end'>
              {changeLogData.length > 0 && (
                <button
                  className={`btn btn--h30 py-1 px-2 font-bold mr-2 `}
                  style={{ backgroundColor: '#0d659e', color: 'white' }}
                  onClick={() => setShowChangeHistoryModal(true)}
                >
                  {t('sharedTexts.changeHistory')}
                </button>
              )}
              <button
                className={`btn btn--h30 py-1 px-3 font-bold mb-4`}
                onClick={handleEditClickAction}
              >
                <img src={editIcon} alt='edit' className='mr-2' /> {`${t('sharedTexts.edit')}`}
              </button>
            </div>
          )}
          <div className='container mb-3' style={{ display: 'flex', flexDirection: 'column' }}>
            <div
              className='child-container card'
              style={{ height: 'max-content', flex: 1, border: 0 }}
            >
              {/* <div style={{ display: 'flex' }}>
              <button
                type='button'
                style={{
                  display: 'flex',
                  width: '50%',
                  alignItems: 'center',
                  gap: '15px',
                  padding: '14px 31px 14px 31px',
                  backgroundColor: '#C1D3DF40',
                  cursor: 'pointer',
                  border: '#fff',
                }}
                onClick={() => setTab(1)}
              >
                <p
                  style={{
                    width: '32px',
                    height: '32px',
                    border: '1px solid #CDD0D1',
                    borderRadius: '50%',
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    backgroundColor: '#fff',
                  }}
                >
                  1
                </p>
                <p
                  style={{
                    fontSize: '14px',
                    fontWeight: 700,
                    color: '#757E85',
                  }}
                >
                  {`${t('systemAdmin.furnaceConfiguration.basicInformation')}`}
                </p>
              </button>
              <div
                style={{
                  display: 'flex',
                  width: '50%',
                  alignItems: 'center',
                  padding: '14px 31px 14px 31px',
                  gap: '15px',
                  borderTop: '2px solid #0D659E',
                  borderTopRightRadius: '4px',
                }}
              >
                <p
                  style={{
                    width: '32px',
                    height: '32px',
                    borderRadius: '50%',
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    backgroundColor: '#0D659E',
                    color: '#fff',
                  }}
                >
                  2
                </p>
                <p
                  style={{
                    fontSize: '14px',
                    fontWeight: 700,
                    color: '#0D659E',
                  }}
                >
                  {`${t('systemAdmin.furnaceConfiguration.refiningSteps')}`}
                </p>
              </div>
            </div> */}
              <div className='card-body card_body_container'>
                <div
                  className='box-container'
                  style={{
                    width: '100%',
                    borderRadius: '5px',

                    marginTop: '10px',
                    marginBottom: '20px',
                    margin: '10px 0',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '20px',
                  }}
                >
                  {stepData.map((step: any, index: any) => (
                    <div key={step} style={{ boxShadow: '0 0 20px rgba(0, 0, 0, 0.1)' }}>
                      <div
                        className='box-header'
                        style={{
                          width: '100%',
                          backgroundColor: '#F5F8FA',
                          padding: '10px',
                          textAlign: 'left',
                          borderRadius: index === 0 ? '5px 5px 0 0' : '0',
                          fontWeight: 600,
                        }}
                      >
                        {handleTranslate(
                          masterData.filter((val: any) => val.id == step)?.[0]?.value
                        )}
                      </div>
                      <p style={{ padding: '10px', color: '#04436B', fontWeight: 600 }}>
                        {stepDataMapping[step]?.length > 0
                          ? t('systemAdmin.furnaceConfiguration.parameters')
                          : ''}
                      </p>
                      <div
                        className='flex-row-container'
                        style={{
                          display: 'flex',
                          gap: '20px',
                          padding: '0px 10px 0px 10px',
                          textAlign: 'left',
                        }}
                      >
                        {(stepDataMapping[step] || [])?.map(
                          (item: any) =>
                            item.record_status && (
                              <InfoBlock
                                key={item.label}
                                label={
                                  masterData.filter((val: any) => val.id == item.label)?.[0]?.value
                                }
                                value={item.value}
                                flexBasis='25%'
                                marginBottom='5'
                                type={item.type}
                              />
                            )
                        )}
                      </div>

                      <p
                        style={{ padding: '0px 10px 0px 10px', color: '#04436B', fontWeight: 600 }}
                      >
                        {additiveData[step]?.filter((item: any) => item.record_status === true)
                          .length > 0
                          ? `${t('systemAdmin.furnaceConfiguration.additives')}`
                          : ''}
                      </p>
                      <div
                        className='flex-row-container'
                        style={{
                          display: 'flex',
                          gap: '35px',
                          padding: '0px 10px 0px 10px',
                          textAlign: 'left',
                        }}
                      >
                        {additiveData[step]?.map(
                          (item: any) =>
                            item.record_status && (
                              <AdditiveBlock
                                key={item.label}
                                label={
                                  masterData.filter((val: any) => val.id == item.label)?.[0]?.value
                                }
                                value={`Qty: ${item.value}`}
                                unit={
                                  allUnits.filter((item: any) => item.name === 'Quantity')[0][
                                    'unit'
                                  ]
                                }
                                marginBottom='10px'
                                flexBasis={''}
                              />
                            )
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <ChangehistoryModal
              title={`${t('sharedTexts.changeHistory')}`}
              showModal={showChangeHistoryModal}
              closeModal={() => {
                setShowChangeHistoryModal(false);
              }}
              changeLogData={changeLogData}
              excelTitle='FurnaceConfig'
            />
          </div>
        </div>
      )}
    </>
  );
};

export default RefiningSteps;
