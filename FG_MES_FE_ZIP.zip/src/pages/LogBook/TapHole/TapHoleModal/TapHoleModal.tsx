// BED LOG ADD/EDIT MODAL
import Loader from 'components/Loader';
import ReusableModal from 'components/common/Modal/ReusableModalLayout/ReusableModal';
import ObservationLogForm from 'components/common/ObservationLogForm/ObservationLogForm';
import { FC, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useAppDispatch, useAppSelector } from 'store';
import {
  createTapHole,
  getRadioTapHole,
  getTapHole,
  updateTapHole,
} from 'store/slices/tapHoleSlice';
import { notify } from 'utils/utils';

type SetShowModalFunction = React.Dispatch<React.SetStateAction<boolean>>;

interface TapHoleModalProps {
  isEdit?: boolean;
  // Pass state and state setter function as props
  showModal: boolean;
  setShowModal: SetShowModalFunction;
  tapHoleId: number;
  setIsLoading: (value: boolean) => void;
  getList: (value: any) => void;
}

const TapHoleModal: FC<TapHoleModalProps> = ({
  isEdit = false,
  showModal,
  setShowModal,
  tapHoleId,
  setIsLoading,
  getList,
}) => {
  const { t } = useTranslation();
  const coreFurnace = useAppSelector((state) => state.coreFurnace.coreFurnace);
  const dispatch = useAppDispatch();
  const [renderData, setRenderData] = useState({ radioData: [] });
  const [existingObservationData, setExistingObservationData] = useState<any>(null);
  const [observationId, setObservationId] = useState<string | number>('');

  const [saveClicked, setSaveClicked] = useState<boolean | null>(null);
  const [saveButtonDisabled, setSaveButtonDisabled] = useState(true);
  // acts as a toggle state.. on this state change, the on save will fire inside child
  const [fetchingRadioValues, setFetchingRadioValues] = useState(false); // loading tracker for radio values
  const [fetchingTapLogData, setFetchingTapLogData] = useState(false);
  // this function param is the payload we need to send
  const onSave = async (dataFromForm: any) => {
    setIsLoading(true);
    if (isEdit) {
      const editData: any = { body: dataFromForm, id: tapHoleId };
      const response = await dispatch(updateTapHole(editData));

      const data = response.payload.data;

      if (response.payload.status >= 200 && response.payload.status < 300) {
        notify('success', t(data.message));
      } else {
        notify('error', data.message);
      }
    } else {
      const response = await dispatch(createTapHole(dataFromForm));

      const data = response.payload.data;

      if (response.payload.status >= 200 && response.payload.status < 300) {
        notify('success', t(data.message));
      } else {
        notify('error', data.message);
      }
    }
    getList({ furnace: 0, page: 1 });
    setShowModal(false);
    setIsLoading(false);
  };

  useEffect(() => {
    const getRadioData = async () => {
      setFetchingRadioValues(true);
      const data = await dispatch(getRadioTapHole());
      setRenderData((prev) => ({ ...prev, radioData: data?.payload?.data?.data }));
      if (data?.payload?.data?.data) setFetchingRadioValues(false);
    };
    getRadioData();

    if (tapHoleId && isEdit) {
      const getTapHoleData = async (id: number) => {
        setFetchingTapLogData(true);
        const data = await dispatch(getTapHole(id));
        console.log('getTapHoleData', data);
        setObservationId(data?.payload?.data?.observation_id);
        // format the response and make like the state...
        const existingData = transformObject(data.payload.data);
        setExistingObservationData(existingData);
        setFetchingTapLogData(false);
      };
      getTapHoleData(tapHoleId);
    }
  }, [isEdit]);

  const toggleSaveClickedState = () => {
    if (saveClicked === null) {
      setSaveClicked(true);
    } else {
      setSaveClicked((prev) => !prev);
    }
  };

  const saveButtonClick = () => {
    toggleSaveClickedState();
    // maybe close or any additional things..
  };

  const closeButtonClick = () => {
    setShowModal(false);
    setSaveClicked(null);
    disableSaveButton();
  };

  const enableSaveButton = () => {
    setSaveButtonDisabled(false);
  };

  const disableSaveButton = () => {
    setSaveButtonDisabled(true);
  };

  function transformObject(obj: any) {
    const transformedObj = {
      furnace: obj.furnace.value ? parseInt(obj.furnace.value) : '',
      flame: obj.flame.id ? obj.flame.id : '',
      flame_colour: obj.flame_colour.id ? obj.flame_colour.id : '',
      tap_hole_bottom: obj.tap_hole_bottom.id ? obj.tap_hole_bottom.id : '',
      metal_output: obj.metal_output.id ? obj.metal_output.id : '',
      furnace_tapping: obj.furnace_tapping.id ? obj.furnace_tapping.id : '',
      slag: obj.slag.id ? obj.slag.id : '',
      flame_intensity: obj.flame_intensity.id ? obj.flame_intensity.id : '',
      observation_dt: obj?.observation_dt,
      comments: obj?.comments,
    };

    return transformedObj;
  }
  const canRender = () => {
    if (isEdit) return !fetchingRadioValues && !fetchingTapLogData;
    else return showModal && !fetchingRadioValues;
  };

  return (
    <ReusableModal
      title={
        !isEdit
          ? `${t('sharedTexts.add')} ${t('logBook.tapHoleLog.tapHoleObservation')}`
          : `${t('sharedTexts.edit')} ${t('logBook.tapHoleLog.tapHoleObservation')} - ${observationId}`
      }
      confirmButtonText={t('sharedTexts.save')}
      closeModal={() => closeButtonClick()}
      showModal={showModal}
      primaryButtonClick={() => saveButtonClick()}
      disabled={saveButtonDisabled}
    >
      {canRender() ? (
        <ObservationLogForm
          onSave={onSave}
          renderData={renderData}
          saveClicked={saveClicked}
          enableSaveButton={enableSaveButton}
          disableSaveButton={disableSaveButton}
          isEdit={isEdit}
          furnaces={coreFurnace}
          existingObservationData={existingObservationData}
          screen={'tapHole'}
        />
      ) : (
        <div style={{ marginTop: '13%' }}>
          <Loader />
        </div>
      )}

      {/* pass different header data, to load the fields in body  */}
    </ReusableModal>
  );
};

export default TapHoleModal;
