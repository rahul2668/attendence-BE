import ListingTable from 'components/common/ListingTable';
import Loading from 'components/common/Loading';
import Pagination from 'components/common/Pagination';
import { useEffect, useRef, useState } from 'react';
import DeleteIcon from '../../../assets/icons/DeleteIcon.svg';
import { deleteTapHole, getTapHole, getTapHoleList } from 'store/slices/tapHoleSlice';
import { useAppDispatch, useAppSelector } from 'store';
import { getCoreFurnaceList } from 'store/slices/coreFurnaceListSlice';
import TapHoleModal from './TapHoleModal/TapHoleModal';
import TapHoleViewModal from './TapHoleViewModal/TapHoleViewModal';
import { notify, validatePermissions } from 'utils/utils';
import AlertModal from 'components/Modal/AlertModal';
import { useTranslation } from 'react-i18next';
import ReusableHeader from 'components/common/Header';
import dayjs from 'dayjs';
import { useLocation } from 'react-router-dom';
import { crudType, permissionsMapper, uniqueCodesMapper } from 'utils/constants';
import { setFilterDataList } from 'store/slices/filterDataList';

interface CoreFurnace {
  furnace_no: string | number;
  id: string | number;
}
interface GetList {
  furnace: string | number;
  page: string | number;
  sort_by: string;
  filter_by_type: string;
  username: string;
  observation_dt: string;
}

const TapHoleList = () => {
  const dispatch = useAppDispatch();
  const { t } = useTranslation();

  const itemsPerPage = 10;
  const [isLoading, setIsLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [count, setCount] = useState(0);
  const [previous, setPrevious] = useState(false);
  const [next, setNext] = useState(false);
  const [list, setList] = useState([]);
  const [excelList, setExcelList] = useState([]);
  const coreFurnace = useAppSelector((state) => state.coreFurnace.coreFurnace);
  const [isEdit, setIsEdit] = useState(false); // passed to the modal
  const [showAddEditModal, setShowAddEditModal] = useState(false); // controls visibility of add/edit modal
  const [tapHoleId, setTapHoleId] = useState<number>(0);
  const [showViewModal, setShowViewModal] = useState(false); // controls visibility of add/edit modal
  const [tabViewData, setTabViewData] = useState({});
  const [deleteModal, setDeleteModal] = useState<boolean>(false);
  const [modalTitle, setModalTitle] = useState('');
  const [modalContent, setModalContent] = useState('');
  const [statusId, setStatusId] = useState<number>(0);
  const [reset, setReset] = useState<boolean>(false);
  const filterDataListState = useAppSelector((state) => state.filterDataList.filterDataList);
  const userListState = useAppSelector((state) => state.userList.userList);

  const csvLinkRef: any = useRef();

  const [inputData, setInputData] = useState<GetList>({
    furnace: 0,
    page: 1,
    sort_by: '',
    filter_by_type: '',
    username: '',
    observation_dt: '',
  });

  const handleStatusChange = () => {
    statusChangeAPI(statusId);
  };

  const handleCloseAlertModal = () => {
    setDeleteModal(false);
  };

  const statusChangeAPI = async (id: number) => {
    setIsLoading(true);
    const response = await dispatch(deleteTapHole(id));
    const data = response.payload.data;

    if (response.payload.status >= 200 && response.payload.status < 300) {
      notify('success', t(data.message));
      setDeleteModal(false);
    } else {
      notify('error', data.message);
      setDeleteModal(false);
    }
    getList({ furnace: 0, page: 1 });
  };

  const coreProcessTableHeader = [
    {
      header: t('logBook.sharedLogBookTexts.observationId'),
      key: 'observation_id',
      sortEnabled: true,
    },
    {
      header: t('systemAdmin.furnaceConfiguration.furnaceNo'),
      key: 'furnace_no',
      sortEnabled: true,
    },
    {
      header: t('logBook.sharedLogBookTexts.observationDateAndTime'),
      key: 'observation_dt',
      sortEnabled: true,
    },
    { header: t('sharedTexts.updatedBy'), key: 'username', sortEnabled: true },
  ];

  const getList = async (input: any) => {
    setIsLoading(true);
    setCurrentPage(1);
    const params = `furnace_id=${input.furnace ?? 0}&page=${input.page || 1}&sort_by_type=${
      input.sort_by_type || ''
    }&sort_by=${input.sort_by || ''}&username=${input.username ? `${input.username},` : ''}&observation_dt=${input.observation_dt || ''}`;
    const response = await dispatch(getTapHoleList(params));

    const data = response.payload.data;

    if (response.payload.status >= 200 && response.payload.status < 300) {
      setCount(data.count);
      setPrevious(!!data.previous);
      setNext(!!data.next);
      setList(data.results);
    }
    setIsLoading(false);
  };

  const handleExcelClick = async (input: any) => {
    setIsLoading(true);
    const params = `excel_download=1&furnace_id=${input.furnace ?? 0}&page=${input.page || 1}&sort_by_type=${
      input.sort_by_type || ''
    }&sort_by=${input.sort_by || ''}&username=${input.username ? `${input.username},` : ''}&observation_dt=${input.observation_dt || ''}`;
    const response = await dispatch(getTapHoleList(params));

    const data = response.payload.data;

    if (response.payload.status >= 200 && response.payload.status < 300) {
      setExcelList(data.results);
    }
    setIsLoading(false);
  };

  const getFurnace = async () => {
    await dispatch(getCoreFurnaceList());
  };

  useEffect(() => {
    getFurnace();
    getList({ furnace: 0, page: 1 });
  }, []);

  const onPageChange = (pageNumber: number) => {
    getList({ ...inputData, page: pageNumber });
    setCurrentPage(pageNumber);
    setInputData({ ...inputData, page: pageNumber });
  };

  const handleTranslate = (label: string | number) => {
    const translationKey: any = `logBook.tapHoleLog.${label}`;

    const translatedString = t(translationKey);

    // If the translation exists, `translatedString` will be the translated value,
    // otherwise, it will be the same as `translationKey`
    const displayString = translatedString !== translationKey ? translatedString : label;

    return displayString;
  };

  const dropDown = coreFurnace?.map((item: CoreFurnace) => {
    return { option: handleTranslate(item.furnace_no), value: item.id };
  });

  // modal code
  const handleAddButtonClick = () => {
    setShowAddEditModal(true);
    setIsEdit(false);
  };

  const handleEditButtonClick = (
    event: React.MouseEvent<HTMLAnchorElement, MouseEvent>,
    id: number
  ) => {
    event.stopPropagation();
    setShowAddEditModal(true);
    setIsEdit(true);
    setTapHoleId(id);
  };

  const handleOnchangeStatus = async (id: number, _role: string, observationId: string) => {
    setStatusId(id);
    setDeleteModal(true);
    setModalContent(
      `${t('logBook.tapHoleLog.doYouWantToDeleteTapHoleObservation')} - ${observationId}?`
    );
    setModalTitle(t('sharedTexts.message'));
  };

  const getTapHoleData = async (id: number) => {
    setIsLoading(true);
    const response = await dispatch(getTapHole(id));
    const data = response.payload.data;

    if (response.payload.status >= 200 && response.payload.status < 300) {
      setTabViewData(data);
    }
    setIsLoading(false);
  };

  const handleViewClick = (event: React.MouseEvent<HTMLAnchorElement, MouseEvent>, id: number) => {
    event.stopPropagation();
    setShowViewModal(true);
    getTapHoleData(id);
  };

  const onSortIconClick = (columnName: string, sortBy: string) => {
    const paramsToPass = {
      ...inputData,
      sort_by: sortBy,
      sort_by_type: columnName,
    };
    getList(paramsToPass);
    setInputData(paramsToPass);
  };

  const filterFieldList = [
    {
      type: 'selector',
      option: dropDown,
      name: 'Furnace No',
      label: t('systemAdmin.furnaceConfiguration.furnaceNo'),
    },
    { type: 'dateRange', name: 'Date Range' },
    {
      type: 'multiSelector',
      option: {
        placeholder: `${t('userAccessControl.users.username')}`,
        list: userListState.map((item) => item.username),
        name: 'Username',
        label: `${t('userAccessControl.users.username')}`,
      },
    },
  ];

  const excelHeader = [
    {
      label: t('logBook.sharedLogBookTexts.observationId'),
      key: 'observation_id',
    },
    {
      label: t('systemAdmin.furnaceConfiguration.furnaceNo'),
      key: 'furnace_no',
    },
    {
      label: t('logBook.sharedLogBookTexts.observationDateAndTime'),
      key: 'observation_dt',
    },
    { label: t('sharedTexts.updatedBy'), key: 'username' },
  ];

  useEffect(() => {
    if (excelList.length > 0) {
      csvLinkRef?.current?.link?.click();
    }
  }, [excelList]);

  const { pathname } = useLocation();
  const module = pathname?.split('/')[1];
  const subModule = pathname?.split('/')[2];

  const hasCreatePermission = validatePermissions(
    permissionsMapper[module],
    permissionsMapper[subModule],
    crudType.create
  );

  const triggeredReset = () => {
    setReset((prev) => !prev);
  };
  useEffect(() => {
    // Function to call when the component unmounts
    return () => {
      dispatch(setFilterDataList({})); // Call your function here
    };
  }, []);

  return (
    <>
      {isLoading && <Loading />}
      <ReusableHeader
        title={t(
          `plantModulesAndFunctions.${uniqueCodesMapper.tapHoleLogFunction}`,
          uniqueCodesMapper.tapHoleLogFunction
        )}
        excelDataList={{
          csvData: excelList,
          headersForCSV: excelHeader,
          title: t(
            `plantModulesAndFunctions.${uniqueCodesMapper.tapHoleLogFunction}`,
            uniqueCodesMapper.tapHoleLogFunction
          ),
        }}
        handleExcelClick={() => handleExcelClick(inputData)}
        csvLinkRef={csvLinkRef}
        filterFieldList={filterFieldList}
        isFilterSortAllowed
        hasCreatePermission={hasCreatePermission}
        isExcel
        triggeredReset={triggeredReset}
        onReset={() => {
          setReset(!reset);
          setInputData({
            furnace: 0,
            page: 1,
            sort_by: '',
            filter_by_type: '',
            username: '',
            observation_dt: '',
          });
          getList({
            furnace: 0,
            page: 1,
          });
        }}
        onFilter={() => {
          setInputData({
            ...inputData,
            furnace: filterDataListState?.['Furnace No']?.value
              ? filterDataListState?.['Furnace No']?.value
              : 0,
            username: filterDataListState?.Username ? filterDataListState?.Username.join() : '',
            observation_dt:
              filterDataListState?.['Date Range']?.[0] && filterDataListState?.['Date Range']?.[1]
                ? `${dayjs(filterDataListState?.['Date Range']?.[0]).format('YYYY-MM-DD')},${dayjs(filterDataListState?.['Date Range']?.[1]).format('YYYY-MM-DD')}`
                : '',
          });
          getList({
            ...inputData,
            furnace: filterDataListState?.['Furnace No']?.value
              ? filterDataListState?.['Furnace No']?.value
              : 0,
            username: filterDataListState?.Username ? filterDataListState?.Username.join() : '',
            observation_dt:
              filterDataListState?.['Date Range']?.[0] && filterDataListState?.['Date Range']?.[1]
                ? `${dayjs(filterDataListState?.['Date Range']?.[0]).format('YYYY-MM-DD')},${dayjs(filterDataListState?.['Date Range']?.[1]).format('YYYY-MM-DD')}`
                : '',
          });
        }}
        buttonText={t('logBook.sharedLogBookTexts.addObservation')}
        onButtonClick={handleAddButtonClick}
      />

      <div className='dashboard__main__body my-2' style={{ overflow: 'auto' }}>
        {list?.length > 0 ? (
          <ListingTable
            tableBody={list}
            handleOnchangeStatus={handleOnchangeStatus}
            tableHeader={coreProcessTableHeader}
            loading={isLoading}
            handleTableRowClick={() => {}}
            handleEditClick={handleEditButtonClick}
            handleViewClick={handleViewClick}
            handleCreateClick={() => {}}
            deleteIcon={DeleteIcon}
            code={'observation_id'}
            sortHandler={onSortIconClick}
            triggeredReset={reset}
          />
        ) : (
          <p className='d-flex justify-content-center mt-5'>{t('sharedTexts.noRecordsFound')}</p>
        )}
        <div className='px-4'>
          <Pagination
            totalItems={count}
            itemsPerPage={itemsPerPage}
            onPageChange={onPageChange}
            currentPage={currentPage}
            previous={previous}
            next={next}
          />
        </div>
      </div>
      {/* // modals  */}

      {/* edit and add  */}
      <TapHoleViewModal
        showModal={showViewModal}
        setShowModal={setShowViewModal}
        data={tabViewData}
      />

      <AlertModal
        showModal={deleteModal}
        title={modalTitle}
        content={modalContent}
        confirmButtonText={t('sharedTexts.proceed')}
        // onConfirmClick={handleDeleteRole}
        onConfirmClick={handleStatusChange}
        // closeModal={handleCloseDeleteModal}
        closeModal={handleCloseAlertModal}
      />
      {showAddEditModal && (
        <TapHoleModal
          showModal={showAddEditModal}
          setShowModal={setShowAddEditModal}
          isEdit={isEdit}
          tapHoleId={tapHoleId}
          setIsLoading={setIsLoading}
          getList={getList}
        />
      )}
    </>
  );
};

export default TapHoleList;
