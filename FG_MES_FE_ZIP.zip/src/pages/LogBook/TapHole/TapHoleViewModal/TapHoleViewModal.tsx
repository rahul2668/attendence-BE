// BED LOG ADD/EDIT MODAL
import ReusableModal from 'components/common/Modal/ReusableModalLayout/ReusableModal';
import ObservationView from 'components/common/ObservationView/ObservationView';
import { FC } from 'react';
import { useTranslation } from 'react-i18next';

type SetShowModalFunction = React.Dispatch<React.SetStateAction<boolean>>;

interface TapHoleModalProps {
  // Pass state and state setter function as props
  showModal: boolean;
  setShowModal: SetShowModalFunction;
  data: any;
}

const TapHoleViewModal: FC<TapHoleModalProps> = ({ showModal, setShowModal, data }) => {
  const { t } = useTranslation();
  const closeButtonClick = () => {
    setShowModal(false);
  };

  return (
    <ReusableModal
      title={`${t('sharedTexts.view')} ${t('logBook.tapHoleLog.tapHoleObservation')} - ${data.observation_id}`}
      confirmButtonText={t('sharedTexts.save')}
      closeModal={() => closeButtonClick()}
      showModal={showModal}
      hideButtons={true}
    >
      {showModal && <ObservationView observationData={data} screen={'tapHole'} />}
      {/* pass different header data, to load the fields in body  */}
    </ReusableModal>
  );
};

export default TapHoleViewModal;
