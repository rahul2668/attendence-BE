// BED LOG ADD/EDIT MODAL
import ReusableModal from 'components/common/Modal/ReusableModalLayout/ReusableModal';
import ObservationView from 'components/common/ObservationView/ObservationView';
import { FC } from 'react';
import { useTranslation } from 'react-i18next';

type SetShowModalFunction = React.Dispatch<React.SetStateAction<boolean>>;

interface BedLogModalProps {
  // Pass state and state setter function as props
  showModal: boolean;
  setShowModal: SetShowModalFunction;
  data: any;
}

const BedLogViewModal: FC<BedLogModalProps> = ({ showModal, setShowModal, data }) => {
  const { t } = useTranslation();
  const closeButtonClick = () => {
    setShowModal(false);
  };

  return (
    <ReusableModal
      title={`${t('sharedTexts.view')} ${t('logBook.furnaceBedLog.furnaceBedObservation')} - ${data.observation_id}`}
      confirmButtonText={t('sharedTexts.save')}
      closeModal={() => closeButtonClick()}
      showModal={showModal}
      hideButtons={true}
    >
      {showModal && <ObservationView observationData={data} screen={'furnaceBed'} />}
      {/* pass different header data, to load the fields in body  */}
    </ReusableModal>
  );
};

export default BedLogViewModal;
