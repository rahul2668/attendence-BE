// BED LOG ADD/EDIT MODAL
import Loader from 'components/Loader';
import ReusableModal from 'components/common/Modal/ReusableModalLayout/ReusableModal';
import ObservationLogForm from 'components/common/ObservationLogForm/ObservationLogForm';
import { FC, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useAppDispatch, useAppSelector } from 'store';
import {
  createFurnaceBed,
  getFurnaceBed,
  getRadioFurnaceBed,
  updateFurnaceBed,
} from 'store/slices/furnaceBedSlice';
import { notify } from 'utils/utils';

type SetShowModalFunction = React.Dispatch<React.SetStateAction<boolean>>;

interface BedLogModalProps {
  isEdit?: boolean;
  // Pass state and state setter function as props
  showModal: boolean;
  setShowModal: SetShowModalFunction;
  furnaceBedId: number;
  setIsLoading: (value: boolean) => void;
  getList: (value: any) => void;
}

const BedLogModal: FC<BedLogModalProps> = ({
  isEdit = false,
  showModal,
  setShowModal,
  furnaceBedId,
  setIsLoading,
  getList,
}) => {
  const { t } = useTranslation();
  const coreFurnace = useAppSelector((state) => state.coreFurnace.coreFurnace);
  const dispatch = useAppDispatch();

  const [renderData, setRenderData] = useState({ radioData: [] });
  const [existingObservationData, setExistingObservationData] = useState<any>(null);
  const [observationId, setObservationId] = useState<string | number>('');
  const [saveClicked, setSaveClicked] = useState<boolean | null>(null);
  const [saveButtonDisabled, setSaveButtonDisabled] = useState(true);
  // acts as a toggle state.. on this state change, the on save will fire inside child
  const [fetchingRadioValues, setFetchingRadioValues] = useState(false); // loading tracker for radio values
  const [fetchingBedLogData, setFetchingBedLogData] = useState(false); //
  const onSave = async (dataFromForm: any) => {
    setIsLoading(true);
    if (isEdit) {
      const editData: any = { body: dataFromForm, id: furnaceBedId };
      const response = await dispatch(updateFurnaceBed(editData));

      const data = response.payload.data;

      if (response.payload.status >= 200 && response.payload.status < 300) {
        notify('success', t(data.message));
      } else {
        notify('error', data.message);
      }
    } else {
      const response = await dispatch(createFurnaceBed(dataFromForm));

      const data = response.payload.data;

      if (response.payload.status >= 200 && response.payload.status < 300) {
        notify('success', t(data.message));
      } else {
        notify('error', data.message);
      }
    }
    getList({ furnace: 0, page: 1 });
    setShowModal(false);
    setIsLoading(false);
  };

  // seems to be a logical mistake here.. radio value fetching depended on isEdit?
  // its working fine though
  // isEdit has false value (in default prop destructuring). since isEdit is turned to true in edit flow, the useEffect fires
  // and hence the getRadio api is trigged...
  useEffect(() => {
    const getRadioData = async () => {
      setFetchingRadioValues(true);
      const data = await dispatch(getRadioFurnaceBed());
      setRenderData((prev) => ({ ...prev, radioData: data?.payload?.data?.data }));
      if (data?.payload?.data?.data) setFetchingRadioValues(false);
      console.log('getRadioFurnaceBed', data);
    };
    getRadioData();

    if (furnaceBedId && isEdit) {
      const getFurnaceBedData = async (id: number) => {
        setFetchingBedLogData(true);
        const data = await dispatch(getFurnaceBed(id));
        setObservationId(data?.payload?.data?.observation_id);
        // format the response and make like the state...
        const existingData = transformObject(data.payload.data);
        setExistingObservationData(existingData);
        setFetchingBedLogData(false);
      };
      getFurnaceBedData(furnaceBedId);
    }
  }, [isEdit]);

  const toggleSaveClickedState = () => {
    if (saveClicked === null) {
      setSaveClicked(true);
    } else {
      setSaveClicked((prev) => !prev);
    }
  };

  const saveButtonClick = () => {
    toggleSaveClickedState();
    // maybe close or any additional things..
  };

  const closeButtonClick = () => {
    setShowModal(false);
    setSaveClicked(null);
    disableSaveButton();
  };

  const enableSaveButton = () => {
    setSaveButtonDisabled(false);
  };

  const disableSaveButton = () => {
    setSaveButtonDisabled(true);
  };

  function transformObject(obj: any) {
    const transformedObj = {
      furnace: obj.furnace.value ? parseInt(obj.furnace.value) : '',
      auto_collapse: obj.auto_collapse.id ? obj.auto_collapse.id : '',
      electrode_auto_lining_wideness: obj.electrode_auto_lining_wideness.id
        ? obj.electrode_auto_lining_wideness.id
        : '',
      noise_when_collapsing: obj.noise_when_collapsing.id ? obj.noise_when_collapsing.id : '',
      electrode_blows_direction: obj.electrode_blows_direction.id
        ? obj.electrode_blows_direction.id
        : '',
      electrode_crust_formation: obj.electrode_crust_formation.id
        ? obj.electrode_crust_formation.id
        : '',
      bed_conditions: obj.bed_conditions.id ? obj.bed_conditions.id : '',
      activity_homogeneity: obj.activity_homogeneity.id ? obj.activity_homogeneity.id : '',
      observation_dt: obj?.observation_dt,
      comments: obj?.comments,
    };
    return transformedObj;
  }

  const canRender = () => {
    if (isEdit) return !fetchingBedLogData && !fetchingRadioValues;
    else return showModal && !fetchingRadioValues;
  };

  return (
    <ReusableModal
      title={
        !isEdit
          ? `${t('sharedTexts.add')} ${t('logBook.furnaceBedLog.furnaceBedObservation')}`
          : `${t('sharedTexts.edit')} ${t('logBook.furnaceBedLog.furnaceBedObservation')} - ${observationId}`
      }
      confirmButtonText={t('sharedTexts.save')}
      closeModal={() => closeButtonClick()}
      showModal={showModal}
      primaryButtonClick={() => saveButtonClick()}
      disabled={saveButtonDisabled}
    >
      {canRender() ? (
        <ObservationLogForm
          onSave={onSave}
          renderData={renderData}
          saveClicked={saveClicked}
          enableSaveButton={enableSaveButton}
          disableSaveButton={disableSaveButton}
          isEdit={isEdit}
          furnaces={coreFurnace}
          existingObservationData={existingObservationData}
          screen={'furnaceBed'}
        />
      ) : (
        <div style={{ marginTop: '13%' }}>
          <Loader />
        </div>
      )}
      {/* pass different header data, to load the fields in body  */}
    </ReusableModal>
  );
};

export default BedLogModal;
