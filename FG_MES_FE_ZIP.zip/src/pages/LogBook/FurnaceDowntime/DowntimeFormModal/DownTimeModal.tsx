// BED LOG ADD/EDIT MODAL
import Loader from 'components/Loader';
import ReusableModal from 'components/common/Modal/ReusableModalLayout/ReusableModal';
import { FC, useEffect, useState } from 'react';
import { useAppDispatch, useAppSelector } from 'store';
import { notify } from 'utils/utils';
import DownTimeLogForm from './DownTimeLogForm';
import {
  createFurnaceDownTimeEvent,
  createFurnaceDownTimeSplit,
  getFurnaceDownTimeEvent,
  getFurnaceDownTimeSplit,
  getRadioFurnaceDownTime,
  updateFurnaceDownTimeEvent,
  updateFurnaceDownTimeSplit,
} from 'store/slices/downTimeSlice';
import { DownTimeEventModalProps } from 'types/logBook.model';
import { useTranslation } from 'react-i18next';

const DownTimeEventModal: FC<DownTimeEventModalProps> = ({
  isEdit,
  showModal = true,
  setShowModal,
  downTimeId,
  setIsLoading,
  getList,
  isSplitUp,
  storeLastUpdatedEvent = () => {},
  passedFurnaceId,
}) => {
  const { t } = useTranslation();
  const coreFurnace = useAppSelector((state) => state.coreFurnace.coreFurnace);
  const dispatch = useAppDispatch();
  const [renderData, setRenderData] = useState({ radioData: [], equipments: [] });
  const [existingObservationData, setExistingObservationData] = useState<any>(null);
  const [eventData, setEventData] = useState<any>(null);
  const [observationId, setObservationId] = useState<string | number>('');

  const [saveClicked, setSaveClicked] = useState<boolean | null>(null);
  const [saveButtonDisabled, setSaveButtonDisabled] = useState(true);
  // acts as a toggle state.. on this state change, the on save will fire inside child
  const [fetchingRadioValues, setFetchingRadioValues] = useState(false); // loading tracker for radio values
  const [fetchingDownTimeData, setFetchingDownTimeData] = useState(false);
  // this function param is the payload we need to send
  const onSave = async (dataFromForm: any) => {
    setIsLoading(true);
    if (isEdit) {
      const editData: any = { body: dataFromForm, id: downTimeId };
      const newObj = { ...editData, furnace_down_time_event: downTimeId };
      const response = isSplitUp
        ? await dispatch(updateFurnaceDownTimeSplit(newObj))
        : await dispatch(updateFurnaceDownTimeEvent(editData));

      const data = response.payload.data;

      if (response.payload.status >= 200 && response.payload.status < 300) {
        notify('success', t(data.message));
        if (isSplitUp) storeLastUpdatedEvent(); // invoke in parent
      } else {
        notify('error', t(data.message));
      }
    } else {
      const newObj = { ...dataFromForm, furnace_down_time_event: downTimeId };
      const response = isSplitUp
        ? await dispatch(createFurnaceDownTimeSplit(newObj))
        : await dispatch(createFurnaceDownTimeEvent(dataFromForm));

      const data = response.payload.data;

      if (response.payload.status >= 200 && response.payload.status < 300) {
        notify('success', t(data.message));
        if (isSplitUp) storeLastUpdatedEvent(); // invoke in parent
      } else {
        notify('error', t(data.message));
      }
    }
    getList({ furnace: 0, page: 1 });
    setShowModal(false);
    setIsLoading(false);
    setSaveClicked(null);
  };

  useEffect(() => {
    const getMasterData = async () => {
      setFetchingRadioValues(true);
      const data = await dispatch(getRadioFurnaceDownTime());
      setRenderData((prev) => ({
        ...prev,
        down_time_type: data?.payload?.data?.data?.down_time_type,
      }));
      if (data?.payload?.data?.data) setFetchingRadioValues(false);
    };
    getMasterData();

    if (downTimeId) {
      // in split edit flow downTimeId -> has the split ID.downTimeId is the passed id from the parent
      const getDownTimeData = async (id: number) => {
        setFetchingDownTimeData(true);
        // console.log('isSplitUp', isSplitUp);
        if (isEdit) {
          const data = isSplitUp
            ? await dispatch(getFurnaceDownTimeSplit(id))
            : await dispatch(getFurnaceDownTimeEvent(id));
          setObservationId(data?.payload?.data?.id);
          // format the response and make like the state...
          const existingData = transformObject(data.payload.data);
          setExistingObservationData(existingData);

          setEventData({
            ...existingData,
            ...(data.payload.data?.event_end_date && {
              event_end_date: data.payload.data?.event_end_date,
            }),
            ...(data.payload.data?.event_start_date && {
              event_start_date: data.payload.data?.event_start_date,
            }),
            ...(data.payload.data.oldest_split_start_dt && {
              oldest_split_start_dt: data.payload.data.oldest_split_start_dt,
            }),
            ...(data.payload.data.latest_split_end_dt && {
              latest_split_end_dt: data.payload.data.latest_split_end_dt,
            }),
          });
        } else {
          const data = await dispatch(getFurnaceDownTimeEvent(id));
          setObservationId(data?.payload?.data?.id);
          // format the response and make like the state...
          const existingData = transformObject(data.payload.data);
          setEventData({
            ...existingData,
            event_end_date: data.payload.data?.observation_end_dt,
            event_start_date: data.payload.data?.observation_start_dt,
          });
        }
        // alert('make it false');
        setFetchingDownTimeData(false);
      };
      getDownTimeData(downTimeId);
    }
  }, [isEdit, downTimeId]);

  const toggleSaveClickedState = () => {
    if (saveClicked === null) {
      setSaveClicked(true);
    } else {
      setSaveClicked((prev) => !prev);
    }
  };

  const saveButtonClick = () => {
    toggleSaveClickedState();
    // maybe close or any additional things..
  };

  const closeButtonClick = () => {
    setShowModal(false);
    setSaveClicked(null);
    disableSaveButton();
  };

  const enableSaveButton = () => {
    setSaveButtonDisabled(false);
  };

  const disableSaveButton = () => {
    setSaveButtonDisabled(true);
  };

  // mod transform for both split and event
  function transformObject(obj: any) {
    const transformedObj = {
      ...(!isSplitUp
        ? { furnace: obj.furnace.value ? parseInt(obj.furnace.value) : '' }
        : { furnace: passedFurnaceId }),
      down_time_type: obj.down_time_type.id ? obj.down_time_type.id : '',
      equipment: obj.equipment.id ? obj.equipment.id : '',
      reason: obj.reason.id ? obj.reason.id : '',
      source: obj.source.id ? obj.source.id : '',
      observation_end_dt: obj?.observation_end_dt,
      observation_start_dt: obj?.observation_start_dt,
      comments: obj?.comments,
      event_status: obj?.event_status != 'Pending',
    };

    return transformedObj;
  }
  const canRender = () => {
    if (isEdit) return !fetchingRadioValues && !fetchingDownTimeData;
    else return showModal && !fetchingRadioValues;
  };

  return (
    <ReusableModal
      title={
        !isEdit
          ? `${t('logBook.furnaceDownTimeLog.downtime')}: ${isSplitUp ? t('logBook.furnaceDownTimeLog.addSplitUp') : t('logBook.furnaceDownTimeLog.addEvent')}`
          : `${t('logBook.furnaceDownTimeLog.downtime')}: ${isSplitUp ? `${t('logBook.furnaceDownTimeLog.editSpitUp')} - SP_` : `${t('logBook.furnaceDownTimeLog.editEvent')} - DT_`}${observationId}`
      }
      confirmButtonText={t('sharedTexts.save')}
      closeModal={() => closeButtonClick()}
      showModal={showModal}
      primaryButtonClick={() => saveButtonClick()}
      disabled={saveButtonDisabled}
    >
      {/* the passed id :{JSON.stringify(downTimeId)} */}
      {canRender() ? (
        <DownTimeLogForm
          onSave={onSave}
          renderData={renderData}
          saveClicked={saveClicked}
          enableSaveButton={enableSaveButton}
          disableSaveButton={disableSaveButton}
          isEdit={isEdit}
          furnaces={coreFurnace}
          existingObservationData={existingObservationData}
          isSplitUp={isSplitUp}
          eventData={eventData}
          passedFurnaceId={passedFurnaceId}
        />
      ) : (
        <div style={{ marginTop: '13%' }}>
          <Loader />
        </div>
      )}
      {/* pass different header data, to load the fields in body  */}
    </ReusableModal>
  );
};

export default DownTimeEventModal;
