// Observation log form - reusable component
import { FC, useEffect, useState } from 'react';
import { InputLabel, FormControl, MenuItem, Box } from '@mui/material';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DesktopDateTimePicker } from '@mui/x-date-pickers/DesktopDateTimePicker';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import dayjs, { Dayjs } from 'dayjs';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import ToggleButton from 'components/common/ToggleButton';
import { useAppDispatch, useAppSelector } from 'store';
import { getFurnaceDownEquipment, getFurnaceDownReason } from 'store/slices/downTimeSlice';
import { sourceDataList } from 'utils/constants';
import { DownTimeLog, DowntimeLogFormType } from 'types/logBook.model';
import { useTranslation } from 'react-i18next';
import { handleTimezone } from 'utils/utils';
import { UtilsMasterData } from 'types/plant.model';
import { DateTimeValidationError } from '@mui/x-date-pickers';

dayjs.extend(utc);
dayjs.extend(timezone);
dayjs.tz.guess();

const DownTimeLogForm: FC<DownTimeLog> = ({
  renderData,
  saveClicked = false,
  onSave,
  enableSaveButton,
  disableSaveButton,
  furnaces = [],
  existingObservationData = null,
  isEdit = false,
  isSplitUp = false,
  eventData,
  passedFurnaceId,
}) => {
  const { t } = useTranslation();
  const dispatch = useAppDispatch();
  const [formData, setFormData] = useState<DowntimeLogFormType>({
    furnace: isSplitUp && passedFurnaceId ? passedFurnaceId : '',
    comments: '',
    // observation_dt: dayjs(),
    observation_start_dt: dayjs().toDate(),
    observation_end_dt: null,
    equipment: '',
    event_status: false,
    reason: '',
  });

  const [isEndDateInvalid, setIsEndDateInvalid] = useState(false);
  const [markAsReadError, setMarkAsReadError] = useState(false);
  const [futureEndDateError, setFutureEndDateError] = useState(false);
  const [isEndDateError, setIsEndDateError] = useState(false);
  const [isStartDateError, setIsStartDateError] = useState(false);

  const [equipmentDataList, setEquipmentDataList] = useState([]);
  const [reasonDataList, setReasonDataList] = useState([]);
  const utilsMasterData = useAppSelector((state) => state.master);

  const utilsMasterList: Array<UtilsMasterData> = utilsMasterData?.results;

  const plantDataString = useAppSelector((state) => state.plantData.plantData);
  const plantData: any = plantDataString ?? null;
  const plant_time_zone_id: any = plantData.plant_time_zone_id;

  const timeZone = utilsMasterList?.filter((item: any) => item.id == plant_time_zone_id)?.[0]
    ?.description;

  const textareaStyles: any = {
    boxSizing: 'border-box',
    width: '100%',
    fontFamily: "'IBM Plex Sans', sans-serif",
    fontSize: '0.875rem',
    fontWeight: 400,
    lineHeight: 1.5,
    padding: '8px 12px',
    borderRadius: '8px',
    // color: '#9da8b7', // Grey 500
    border: '1px solid #bcbcbc', // Grey 200
    // boxShadow: '0px 2px 2px #dae2ed', // Grey 200
    resize: 'none',
    outline: 'none', // remove default focus outline
    transition: 'box-shadow 0.2s ease', // add transition for focus effect
  };

  const getReason = async (id: number | string) => {
    const data = await dispatch(getFurnaceDownReason(id));
    setReasonDataList(data?.payload?.data?.data);
  };

  const getEquipments = async (id: number | string) => {
    const data = await dispatch(getFurnaceDownEquipment(id));
    setEquipmentDataList(data?.payload?.data?.data);
  };

  const handleChange = async (event: SelectChangeEvent) => {
    setFormData((prev: DowntimeLogFormType) => ({
      ...prev,
      [event.target.name]: event.target.value,
    }));
    if (event.target.name == 'equipment') {
      setReasonDataList([]);
      setFormData((prev: DowntimeLogFormType) => {
        const { reason: removedReason, ...rest } = prev;
        return rest;
      });
      getReason(event.target.value);
    }
    if (event.target.name == 'down_time_type') {
      setEquipmentDataList([]);
      setReasonDataList([]);
      setFormData((prev: DowntimeLogFormType) => {
        const { reason: removedReason, equipment: removedEquipment, ...rest } = prev;
        return rest;
      });

      getEquipments(event.target.value);
    }
  };

  // not working for comments...
  const handleCommentChange = (event: any) => {
    setFormData((prev: DowntimeLogFormType) => ({
      ...prev,
      [event.target.name]: event.target.value,
    }));
    // setComment(event.target.value as string);
  };

  useEffect(() => {
    if (isSplitUp && eventData?.event_start_date && !isEdit) {
      setFormData((prev: DowntimeLogFormType) => ({
        ...prev,
        observation_start_dt: handleTimezone(eventData?.event_start_date, timeZone),
      }));
    }
  }, [isSplitUp, isEdit, eventData]);

  const handleEndDateTimeError = (newError: DateTimeValidationError) => {
    if (newError !== null) {
      setIsEndDateError(true);
    } else {
      setIsEndDateError(false);
    }
  };

  const handleStartDateTimeError = (newError: DateTimeValidationError) => {
    if (newError !== null) {
      setIsStartDateError(true);
    } else {
      setIsStartDateError(false);
    }
  };

  const handleStartDateAndTimeChange = (newDateAndTime: Dayjs | null) => {
    if (newDateAndTime) {
      const endDate = handleTimezone(formData?.observation_end_dt, timeZone);
      const startDate = handleTimezone(newDateAndTime, timeZone);
      if (endDate) {
        if (endDate.isAfter(startDate)) {
          setIsEndDateInvalid(false);
        } else if (formData?.observation_end_dt) {
          setIsEndDateInvalid(true);
        }
      }
      setFormData((prev: DowntimeLogFormType) => ({
        ...prev,
        observation_start_dt: startDate,
      }));
    }
    if (!newDateAndTime) {
      setFormData((prev: DowntimeLogFormType) => ({ ...prev, observation_end_dt: null }));
      setFormData((prev: DowntimeLogFormType) => ({ ...prev, event_status: false }));
    }
  };

  const handleEndDateAndTimeChange = (newDate: Dayjs | null) => {
    const currentDate = dayjs().tz(timeZone);
    if (newDate === null) {
      setFormData((prev) => ({
        ...prev,
        observation_end_dt: null,
        event_status: false,
      }));
    } else {
      const startDate = handleTimezone(formData?.observation_start_dt, timeZone);
      const endDate = handleTimezone(newDate, timeZone);
      const eventStartDate = handleTimezone(eventData?.event_start_date, timeZone);

      if (endDate.isSame(startDate) || endDate.isAfter(startDate)) {
        setIsEndDateInvalid(false);
      } else if (isSplitUp && !isEdit && endDate.isAfter(eventStartDate)) {
        setIsEndDateError(true);
      } else {
        setIsEndDateInvalid(true);
      }

      if (endDate.isAfter(currentDate)) {
        setFormData((prev: DowntimeLogFormType) => ({ ...prev, event_status: false }));
      }
      setFutureEndDateError(false);

      setFormData((prev) => ({
        ...prev,
        observation_end_dt: endDate,
      }));
    }
  };

  const handleEndDateMinimumValidation = (): Dayjs => {
    if (isEdit && eventData?.latest_split_end_dt) {
      return handleTimezone(eventData?.latest_split_end_dt, timeZone);
    } else if (isSplitUp && eventData?.event_start_date && !isEdit) {
      return handleTimezone(eventData?.event_start_date, timeZone);
    } else {
      return handleTimezone(formData?.observation_start_dt, timeZone);
    }
  };

  const handleEndDateMaximumValidation = (): Dayjs | undefined => {
    if (isSplitUp && eventData?.event_end_date) {
      return handleTimezone(eventData?.event_end_date, timeZone);
    } else {
      return undefined;
    }
  };

  const handleStartDateMinimumValidation = (): Dayjs | undefined => {
    if (isSplitUp) {
      return handleTimezone(eventData?.event_start_date, timeZone);
    } else {
      return undefined;
    }
  };

  const handleStartDateMaximumValidation = (): Dayjs | undefined => {
    if (isSplitUp && eventData?.event_end_date) {
      return handleTimezone(eventData?.event_end_date, timeZone);
    } else if (isEdit && !isSplitUp) {
      return handleTimezone(eventData?.oldest_split_start_dt, timeZone);
    } else {
      return undefined;
    }
  };

  const handleToggleChange = (value: any) => {
    const currentDate = dayjs().tz(timeZone);
    if (formData.observation_end_dt && !isEndDateInvalid) {
      setMarkAsReadError(false);
      setFormData((prev: DowntimeLogFormType) => ({ ...prev, event_status: value }));
    } else {
      setMarkAsReadError(true);
      setFormData((prev: DowntimeLogFormType) => ({ ...prev, event_status: false }));
    }
    if (handleTimezone(formData.observation_end_dt, timeZone).isAfter(currentDate)) {
      setFutureEndDateError(true);
      setFormData((prev: DowntimeLogFormType) => ({ ...prev, event_status: false }));
    }
  };

  // radio label
  const generateLabelStyles = () => {
    return {
      fontWeight: 600,
      color: '#606466',
      marginBottom: '10px',
      fontSize: '14px',
      position: 'relative',
      '&.Mui-focused': { color: '#0D659E' },
      '&.Mui-focused::after': {
        content: '""',
        position: 'absolute',
        left: 0,
        bottom: 0,
        width: 'fit-content',
        height: '2px',
        backgroundColor: '#0D659E',
        animation: 'underlineDraw 0.2s forwards',
        '@keyframes underlineDraw': {
          from: {
            width: 0,
          },
          to: {
            width: 'calc(var(--text-length) * 8.3px)',
          },
        },
      },
    };
  };

  useEffect(() => {
    if (saveClicked !== null) {
      // Check for null - initial value of state, ie, save button is not clicked yet!
      //   alert('Save Clicked');
      onSave(formData);
    }
  }, [saveClicked]);

  useEffect(() => {
    // Add 'furnace' and 'observation_dt' keys extra
    const allRequiredKeys: Array<keyof DowntimeLogFormType> = isSplitUp
      ? [
          // 'furnace',
          'equipment',
          'observation_start_dt',
          'observation_end_dt',
          'reason',
          'down_time_type',
        ]
      : ['furnace', 'equipment', 'observation_start_dt', 'reason', 'down_time_type'];
    // Check if all required fields have values
    const areAllRequiredFieldsFilled = allRequiredKeys.every((key) => !!formData[key]);

    if (areAllRequiredFieldsFilled && !isEndDateInvalid && !isEndDateError && !isStartDateError) {
      enableSaveButton();
    } else {
      disableSaveButton();
    }
  }, [formData, enableSaveButton, isEndDateInvalid, isEndDateError, isStartDateError]);

  useEffect(() => {
    if (existingObservationData) {
      getReason(existingObservationData.equipment);
      getEquipments(existingObservationData.down_time_type);
      setFormData(existingObservationData);
    }
  }, [existingObservationData]);

  return (
    <Box display={'flex'} flexDirection={'row'} sx={{ gap: '25px' }} flexWrap={'wrap'}>
      {/* Top section --- */}
      {/* Furnace Input --- */}
      <Box>
        <InputLabel
          id='fn'
          sx={{
            fontWeight: 600,
            color: '#606466',
            marginBottom: '5px',
            fontSize: '14px',
          }}
        >
          {t('systemAdmin.furnaceConfiguration.furnaceNo')}.*{' '}
        </InputLabel>

        <FormControl>
          <Select
            id='demo-simple-select'
            value={formData?.furnace ? formData.furnace.toString() : ''}
            name='furnace'
            //   notched={true}
            displayEmpty
            disabled={isEdit || isSplitUp}
            onChange={handleChange}
            inputProps={{ 'aria-label': 'Without label' }}
            sx={{
              height: '40px',
              width: '250px',
              backgroundColor: isEdit || isSplitUp ? '#e3e9ea' : '',
            }}
          >
            {/* excludes id 0  */}
            <MenuItem disabled value=''>
              <em style={{ fontStyle: 'normal' }}>{t('sharedTexts.select')}</em>
            </MenuItem>
            {furnaces
              .filter((furnace: any) => furnace.id !== 0)
              .map((furnace: any) => (
                <MenuItem key={furnace.id} value={furnace.furnace_no}>
                  {furnace.furnace_no}
                </MenuItem>
              ))}
          </Select>
        </FormControl>
      </Box>

      {isEdit && !isSplitUp && (
        <Box>
          <InputLabel
            id='fn'
            sx={{
              fontWeight: 600,
              color: '#606466',
              marginBottom: '5px',
              fontSize: '14px',
            }}
          >
            {t('logBook.furnaceDownTimeLog.source')}{' '}
          </InputLabel>

          <FormControl>
            <Select
              id='demo-simple-select'
              value={formData?.source ? formData.source.toString() : ''}
              name='source'
              //   notched={true}
              displayEmpty
              disabled={isEdit}
              onChange={handleChange}
              inputProps={{ 'aria-label': 'Without label' }}
              sx={{
                height: '40px',
                width: '250px',
                backgroundColor: isEdit ? '#e3e9ea' : '',
              }}
            >
              {/* excludes id 0  */}
              <MenuItem disabled value=''>
                <em style={{ fontStyle: 'normal' }}>{t('sharedTexts.select')}</em>
              </MenuItem>
              {sourceDataList
                .filter((source: any) => source.id !== 0)
                .map((source: any) => (
                  <MenuItem key={source.id} value={source.id}>
                    {source.value}
                  </MenuItem>
                ))}
            </Select>
          </FormControl>
        </Box>
      )}

      {/* Furnace Input end === */}

      <Box>
        <div style={{ display: 'flex', gap: '60px' }}>
          {/* date-time --- */}
          <Box>
            <InputLabel
              id='fn'
              sx={{
                fontWeight: 600,
                color: '#606466',
                fontSize: '14px',
                marginBottom: '5px',
              }}
            >
              {!isSplitUp
                ? `${t('logBook.furnaceDownTimeLog.eventStartDateAndTime')}*`
                : `${t('logBook.furnaceDownTimeLog.splitStartDateAndTime')}*`}
            </InputLabel>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DesktopDateTimePicker
                // defaultValue={dayjs()}
                disableFuture={!isSplitUp} // If it's not an event, disable future dates
                minDateTime={handleStartDateMinimumValidation()}
                maxDateTime={handleStartDateMaximumValidation()}
                format='DD/MM/YYYY hh:mm A'
                closeOnSelect={false}
                sx={{
                  '& .MuiInputBase-input': {
                    height: '40px',
                    padding: '0px 0px 0px 14px',
                    fontSize: '14px',
                    width: 'inherit',
                  },
                  '& .MuiInputBase-root': {
                    width: 'inherit',
                  },
                  flexDirection: 'row',
                  width: '250px!important', // this solved a UI bug in date
                }}
                value={
                  isSplitUp && eventData?.event_start_date && !isEdit
                    ? handleTimezone(eventData?.event_start_date, timeZone)
                    : handleTimezone(formData.observation_start_dt, timeZone)
                }
                timezone={timeZone}
                onChange={handleStartDateAndTimeChange}
                onError={(newError: DateTimeValidationError) => handleStartDateTimeError(newError)}
              />
            </LocalizationProvider>
          </Box>

          {/* date-time end === */}
        </div>
      </Box>

      <Box>
        <div style={{ display: 'flex', gap: '60px' }}>
          {/* date-time --- */}
          <Box>
            <InputLabel
              id='fn'
              sx={{
                fontWeight: 600,
                color: '#606466',
                fontSize: '14px',
                marginBottom: '5px',
              }}
            >
              {!isSplitUp
                ? `${t('logBook.furnaceDownTimeLog.eventEndDateAndTime')}`
                : `${t('logBook.furnaceDownTimeLog.splitEndDateAndTime')}*`}
            </InputLabel>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DesktopDateTimePicker
                minDateTime={handleEndDateMinimumValidation()}
                maxDateTime={handleEndDateMaximumValidation()}
                disabled={!formData?.observation_start_dt}
                format='DD/MM/YYYY hh:mm A'
                closeOnSelect={false}
                sx={{
                  '& .MuiInputBase-input': {
                    height: '40px',
                    padding: '0px 0px 0px 14px',
                    fontSize: '14px',
                  },
                  '& .MuiInputBase-root': {
                    width: 'inherit',
                  },
                  backgroundColor: !formData?.observation_start_dt ? '#e3e9ea' : '',
                  flexDirection: 'row',
                  width: '250px!important',
                }}
                value={
                  formData?.observation_end_dt
                    ? handleTimezone(formData?.observation_end_dt, timeZone)
                    : null
                }
                timezone={timeZone}
                onChange={handleEndDateAndTimeChange}
                onError={(newError: DateTimeValidationError) => handleEndDateTimeError(newError)}
              />
            </LocalizationProvider>

            {isEndDateInvalid && (
              <p style={{ fontSize: '12px', color: 'red' }}>
                {t('logBook.furnaceDownTimeLog.endDateMustBeGreaterThenStartDate')}
              </p>
            )}
          </Box>

          {/* date-time end === */}
        </div>
      </Box>
      {/* Top section  end === */}

      {/* DOWNTIME TYPE ---- */}
      <Box>
        <InputLabel
          id='fn'
          sx={{
            fontWeight: 600,
            color: '#606466',
            marginBottom: '5px',
            fontSize: '14px',
          }}
        >
          {t('logBook.furnaceDownTimeLog.downtimeType')}*
        </InputLabel>

        <FormControl>
          <Select
            id='demo-simple-select'
            value={formData?.down_time_type ? formData.down_time_type.toString() : ''}
            name='down_time_type'
            //   notched={true}
            displayEmpty
            onChange={handleChange}
            inputProps={{ 'aria-label': 'Without label' }}
            sx={{
              height: '40px',
              width: '250px',
            }}
          >
            {/* excludes id 0  */}
            <MenuItem disabled value=''>
              <em style={{ fontStyle: 'normal' }}>{t('sharedTexts.select')}</em>
            </MenuItem>
            {renderData?.down_time_type
              ?.filter((downTimeType: any) => downTimeType.id !== 0)
              .map((downTimeType: any) => (
                <MenuItem key={downTimeType.id} value={downTimeType.down_time_type_code}>
                  {t(
                    downTimeType.down_time_type_code &&
                      `logBook.furnaceDownTimeLog.${downTimeType.down_time_type_code}`
                  )}
                </MenuItem>
              ))}
          </Select>
        </FormControl>
      </Box>

      {/* DOWNTIME TYPE ==== */}

      {/* EQUIPMENT ---- */}
      <Box>
        <InputLabel
          id='fn'
          sx={{
            fontWeight: 600,
            color: '#606466',
            marginBottom: '5px',
            fontSize: '14px',
          }}
        >
          {t('logBook.furnaceDownTimeLog.equipment')}*
        </InputLabel>

        <FormControl>
          <Select
            id='demo-simple-select'
            value={formData?.equipment ? formData.equipment.toString() : ''}
            name='equipment'
            //   notched={true}
            disabled={!formData?.down_time_type}
            displayEmpty
            onChange={handleChange}
            inputProps={{ 'aria-label': 'Without label' }}
            sx={{
              height: '40px',
              width: '250px',
              backgroundColor: !formData?.down_time_type ? '#e3e9ea' : '',
            }}
          >
            {/* excludes id 0  */}
            <MenuItem disabled value=''>
              <em style={{ fontStyle: 'normal' }}>{t('sharedTexts.select')}</em>
            </MenuItem>
            {equipmentDataList
              ?.filter((equipment: any) => equipment.id !== 0)
              ?.map((equipment: any) => (
                <MenuItem key={equipment.id} value={equipment.id}>
                  {t(
                    equipment.equipment_master_code &&
                      `logBook.furnaceDownTimeLog.${equipment.equipment_master_code}`
                  )}
                </MenuItem>
              ))}
          </Select>
        </FormControl>
      </Box>
      {/* EQUIPMENT ==== */}

      {/* REASON TYPE ---- */}
      <Box>
        <InputLabel
          id='fn'
          sx={{
            fontWeight: 600,
            color: '#606466',
            marginBottom: '5px',
            fontSize: '14px',
          }}
        >
          {t('logBook.furnaceDownTimeLog.reason')}*
        </InputLabel>

        <FormControl>
          <Select
            id='demo-simple-select'
            value={formData?.reason ? formData.reason.toString() : ''}
            name='reason'
            //   notched={true}
            displayEmpty
            disabled={!formData?.equipment}
            onChange={handleChange}
            inputProps={{ 'aria-label': 'Without label' }}
            sx={{
              height: '40px',
              width: '250px',
              backgroundColor: !formData?.equipment ? '#e3e9ea' : '',
            }}
          >
            {/* excludes id 0  */}
            <MenuItem disabled value=''>
              <em style={{ fontStyle: 'normal' }}>{t('sharedTexts.select')}</em>
            </MenuItem>
            {reasonDataList
              .filter((reason: any) => reason.id !== 0)
              .map((reason: any) => (
                <MenuItem key={reason.id} value={reason.id}>
                  {t(reason.name && `logBook.furnaceDownTimeLog.${reason.reason_code}`)}
                </MenuItem>
              ))}
          </Select>
        </FormControl>
      </Box>
      {/* REASON TYPE ==== */}

      {/* comment  ---*/}
      <Box width={'100%'}>
        <InputLabel
          id='fn'
          sx={{
            fontWeight: 600,
            color: '#606466',
            fontSize: '14px',
          }}
        >
          {t('sharedTexts.comments')}
        </InputLabel>
        <textarea
          onChange={handleCommentChange}
          rows={4}
          cols={50}
          maxLength={500}
          name='comments'
          value={formData?.comments}
          placeholder={t('sharedTexts.enterComment')}
          style={textareaStyles}
          onFocus={(e) => {
            e.target.style.border = '2px solid #1976d2';
          }}
          onBlur={(e) => {
            e.target.style.border = '1px solid #bcbcbc';
          }}
        />
      </Box>
      {/* comment end === */}

      {!isSplitUp && (
        <Box>
          <InputLabel id='fn' sx={generateLabelStyles}>
            {t('logBook.furnaceDownTimeLog.markAsComplete')}
          </InputLabel>
          <ToggleButton
            onChange={(val: boolean) => handleToggleChange(val)}
            text={formData.event_status ? t('sharedTexts.yes') : t('sharedTexts.no')}
            isChecked={formData.event_status}
            style={{ color: '#757E85' }}
          />
          {markAsReadError && (
            <p style={{ fontSize: '12px', color: 'red' }}>
              {t('logBook.furnaceDownTimeLog.provideEndDate')}
            </p>
          )}
          {futureEndDateError && (
            <p style={{ fontSize: '12px', color: 'red' }}>
              {t('logBook.furnaceDownTimeLog.endDateIsInFuture')}
            </p>
          )}
        </Box>
      )}
    </Box>
  );
};

export default DownTimeLogForm;
