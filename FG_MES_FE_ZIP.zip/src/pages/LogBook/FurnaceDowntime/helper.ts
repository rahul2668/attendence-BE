import _ from 'lodash';

import { formatDateHelper } from 'utils/utils';

export const mainHeaders = [
  // extra column for arrow
  {
    label: '',
    alignment: '', // optional - heading alignment
    width: '', // optional
  },

  {
    label: 'logBook.furnaceDownTimeLog.eventId',
    alignment: '', // optional
    width: '', // optional
    enableSort: true,
    sortKey: 'event_id',
  },
  {
    label: `systemAdmin.furnaceConfiguration.furnaceNo`,
    alignment: '', // optional
    width: '', // optional
    enableSort: true,
    sortKey: 'furnace_no',
  },

  {
    label: 'logBook.furnaceDownTimeLog.startDateAndTime',
    alignment: '', // optional
    // width: '100px', // optional
    enableSort: true,
    sortKey: 'observation_start_dt',
  },

  {
    label: 'logBook.furnaceDownTimeLog.endDateAndTime',
    alignment: '', // optional
    // width: '100px', // optional
    enableSort: true,
    sortKey: 'observation_end_dt',
  },

  {
    label: 'logBook.furnaceDownTimeLog.Duration',
    alignment: '', // optional
    width: '', // optional
    enableSort: true,
    sortKey: 'duration',
  },

  {
    label: 'logBook.furnaceDownTimeLog.equipment',
    alignment: '', // optional
    width: '100px', // optional
    enableSort: true,
    sortKey: 'equipment_value',
  },

  {
    label: 'logBook.furnaceDownTimeLog.reason',
    alignment: 'left', // optional
    // width: '200px', // optional
    enableSort: true,
    sortKey: 'reason_value',
  },

  {
    label: 'sharedTexts.status',
    alignment: '', // optional
    width: '', // optional
    enableSort: true,
    sortKey: 'event_status',
  },

  // extra column for options icons
  {
    label: '',
    alignment: '', // optional
    width: '200px', // optional
  },
];

export const subHeaders = [
  // extra column for arrow
  {
    label: 'logBook.furnaceDownTimeLog.splitId',
    alignment: '', // optional - heading alignment
    width: '', // optional - px value
  },

  {
    label: 'logBook.furnaceDownTimeLog.startDateAndTime',
    alignment: '', // optional
    width: '', // optional
  },
  {
    label: 'logBook.furnaceDownTimeLog.endDateAndTime',
    alignment: '', // optional
    width: '', // optional
  },

  {
    label: 'logBook.furnaceDownTimeLog.duration',
    alignment: '', // optional
    width: '', // optional
  },

  {
    label: 'logBook.furnaceDownTimeLog.equipment',
    alignment: '', // optional
    width: '', // optional
  },

  {
    label: 'logBook.furnaceDownTimeLog.reason',
    alignment: '', // optional
    width: '', // optional
  },

  // extra column for options icons
  {
    label: '',
    alignment: '', // optional
    width: '200px', // optional
  },
];

export function formatDownTimeData(
  eventData: any, // maybe define a type?
  timeZone: string
) {
  const equipmentLanguageKey: any = `logBook.furnaceDownTimeLog.${eventData.equipment_value}`;
  const reasonLanguageKey: any = `logBook.furnaceDownTimeLog.${eventData.reason_value}`;
  const statusLanguageKey: any = `sharedTexts.pillLogicKeys.dynamic${eventData.event_status_value}`;
  return {
    eventId: eventData.event_id,
    furnaceNo: eventData.furnace_no,
    startDate: formatDateHelper(eventData.observation_start_dt, timeZone),
    endDate: formatDateHelper(eventData.observation_end_dt, timeZone),
    duration: eventData.duration ? eventData.duration : '--',
    equipment: equipmentLanguageKey,
    reason: reasonLanguageKey,
    status: statusLanguageKey,
    viewOnlyForSubData: eventData.event_status, // if status of event is completed, split data should be prevented from modification
    subTableData:
      eventData.furnace_down_time?.length > 0
        ? eventData.furnace_down_time.map((splitData: any) => ({
            splitID: splitData.split_id,
            startDate: formatDateHelper(splitData.observation_start_dt, timeZone),
            endDate: formatDateHelper(splitData.observation_end_dt, timeZone),
            duration: splitData.duration,
            equipment: `logBook.furnaceDownTimeLog.${splitData.equipment_value}`,
            reason: `logBook.furnaceDownTimeLog.${splitData.reason_value}`,
          }))
        : [],
  };
}

export const toolTipsForDownTime = {
  parentViewIconToolText: 'logBook.furnaceDownTimeLog.viewEvent',
  parentAddIconToolText: 'logBook.furnaceDownTimeLog.addSplit',
  parentEditIconToolText: 'logBook.furnaceDownTimeLog.editEvent',
  parentDeleteIconToolText: 'logBook.furnaceDownTimeLog.deleteEvent',
  childViewIconToolText: 'logBook.furnaceDownTimeLog.viewSplit',
  childEditIconToolText: 'logBook.furnaceDownTimeLog.editSplit',
  childDeleteIconToolText: 'logBook.furnaceDownTimeLog.deleteSplit',
};

export function findFurnaceNoByEventId(data: any, eventId: string) {
  const foundEvent = _.find(data, { eventId: eventId });
  return foundEvent ? foundEvent.furnaceNo : null;
}
export function findFurnaceNoBySplitId(data: any, splitId: string) {
  let foundFurnaceNo = null;
  _.forEach(data, (event) => {
    const foundSplit = _.find(event.subTableData, { splitID: splitId });
    if (foundSplit) {
      foundFurnaceNo = event.furnaceNo;
      return false; // Break the loop once found
    }
  });
  return foundFurnaceNo;
}

export function findFurnacePkByNo(data: any, furnace_no: string) {
  const foundEvent = _.find(data, { furnace_no: furnace_no });
  return foundEvent ? foundEvent.id : null;
}

export const timeLabelsInViewScreen = [
  'Event Start Date & Time',
  'Event End Date & Time',
  'Split Start Date & Time',
  'Split End Date & Time',
];

// types for headers
// have any type for row
// subTableData make the subData holder key as prop
