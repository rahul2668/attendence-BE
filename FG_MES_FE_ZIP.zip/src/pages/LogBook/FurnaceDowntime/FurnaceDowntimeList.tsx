import CollapsibleTable from 'components/common/CollapsibleTable/CollapsibleTable';
import Pagination from 'components/common/Pagination';
import { useEffect, useState, useRef } from 'react';
import {
  findFurnaceNoByEventId,
  findFurnaceNoBySplitId,
  formatDownTimeData,
  mainHeaders,
  subHeaders,
  toolTipsForDownTime,
} from './helper';
import { useAppDispatch, useAppSelector } from 'store';
import { getCoreFurnaceList } from 'store/slices/coreFurnaceListSlice'; // for furnace drop down
import {
  deleteFurnaceDownTimeEvent,
  deleteFurnaceDownTimeSplit,
  getFurnaceDownEquipment,
  getFurnaceDownReason,
  getFurnaceDownTimeEvent,
  getFurnaceDownTimeList,
  getFurnaceDownTimeSplit,
  getRadioFurnaceDownTime,
} from 'store/slices/downTimeSlice'; // main list api
import Loading from 'components/common/Loading';
import DownTimeLogViewModal from './DownTimeLogViewModal/DownTimeLogViewModal';
import DownTimeEventModal from './DowntimeFormModal/DownTimeModal';
import AlertModal from 'components/Modal/AlertModal';
import { useTranslation } from 'react-i18next';
import { notify, validatePermissions } from 'utils/utils';
import { crudType, uniqueCodesMapper } from 'utils/constants';
import { UtilsMasterData } from 'types/plant.model';
import ReusableHeader from 'components/common/Header';
import dayjs from 'dayjs';
import { setFilterDataList } from 'store/slices/filterDataList';
import { DowntimeExcelDownload } from 'types/downTime.model';

interface CoreFurnace {
  furnace_no: string | number;
  id: string | number;
}

interface ReasonList {
  id: number;
  reason_code?: string;
  equipment_master_code?: string;
  down_time_type_code?: string;
}

interface GetList {
  furnace: string | number;
  page: string | number;
  sort_by: string;
  sort_by_type: string;
  observation_start_dt: Date | null | string;
  observation_end_dt: Date | null | string;
  equipment_value: string;
  status: boolean | string;
  reason_value: string;
}

const FurnaceDowntimeList = () => {
  // API INT FOR LIST COMPONENT  =================================
  const dispatch = useAppDispatch();
  const { t } = useTranslation();

  const itemsPerPage = 10;
  const [isLoading, setIsLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [count, setCount] = useState(0);
  const [previous, setPrevious] = useState(false);
  const [next, setNext] = useState(false);
  const [list, setList] = useState([]);
  const filterDataListState = useAppSelector((state) => state.filterDataList.filterDataList);

  const [inputData, setInputData] = useState<GetList>({
    furnace: 0,
    page: 1,
    sort_by: '',
    sort_by_type: '',
    observation_start_dt: '',
    observation_end_dt: '',
    equipment_value: '',
    status: '',
    reason_value: '',
  });
  // const [furnaceNumberSelect, setFurnaceNumberSelect] = useState<string | number>('');
  const [showViewModal, setShowViewModal] = useState(false); // controls visibility for view modal - both split and event has same
  const [downTimeViewData, setDownTimeViewData] = useState({}); // data state passed to view modal
  const [isSplitUp, setIsSplitUp] = useState(true); // to know if its split or event
  const [showModal, setShowModal] = useState(false); // CONTROLS ADD/ EDIT MODAL
  const [isEdit, setIsEdit] = useState(false);
  const [passedId, setPassedId] = useState<number | null>(null); // this id will used as param for api call in edit flow
  const [showDeleteModal, setShowDeleteModal] = useState<boolean>(false);
  const [idToBeDeleted, setIdToBeDeleted] = useState<number | null>(null);
  const [tempStoredFurnaceNo, setTempStoredFurnaceNo] = useState<string>(''); // extracted furnace iD from render data for list. its then passed to add split modal to populate a field
  const [currentActiveEvent, setCurrentActiveEvent] = useState<string>(''); // on every action click. set this
  const [lastUpdatedEventId, setLastUpdatedEventId] = useState<string>(''); // this is used  to open up the sub table
  const [excelList, setExcelList] = useState([]);

  const [radioList, setRadioList] = useState({
    reason: [],
    equipments: [],
    downTimeTypes: [],
  });

  const utilsMasterData = useAppSelector((state) => state.master);

  const utilsMasterList: Array<UtilsMasterData> = utilsMasterData?.results;

  const plantDataString = useAppSelector((state) => state.plantData.plantData);
  const plantData: any = plantDataString ?? null;
  const plant_time_zone_id: any = plantData.plant_time_zone_id;

  const timeZone = utilsMasterList?.filter((item: any) => item.id == plant_time_zone_id)?.[0]
    ?.description;

  const coreFurnace = useAppSelector((state) => state.coreFurnace.coreFurnace);
  const csvLinkRef: any = useRef();
  // initiate furnace api
  const getFurnace = () => {
    dispatch(getCoreFurnaceList());
  };

  // main api
  const getList = async (input: any, skipPageReset?: boolean) => {
    setIsLoading(true);
    if (!skipPageReset) setCurrentPage(1);
    const params = `furnace_id=${input.furnace ?? 0}&page=${input.page || 1}&sort_by_type=${input.sort_by_type || ''}&sort_by=${input.sort_by || ''}&status=${typeof input.status === 'boolean' ? input.status : ''}&reason_value=${input.reason_value ? `${input.reason_value},` : ''}&equipment_value=${input.equipment_value ? `${input.equipment_value},` : ''}&observation_end_dt=${input.observation_end_dt || ''}&observation_start_dt=${input.observation_start_dt || ''}&down_time_type=${input.down_time_type_value ? `${input.down_time_type_value},` : ''}`;
    // params is passed into "id" in service method
    const response = await dispatch(getFurnaceDownTimeList(params));
    console.log('FD main list response :>', response);

    const data = response.payload.data;

    if (response.payload.status >= 200 && response.payload.status < 300) {
      setCount(data.count);
      setPrevious(!!data.previous);
      setNext(!!data.next);
      const formattedList = data?.results?.map((item: any) => formatDownTimeData(item, timeZone));

      setList(formattedList); // restructure this array and pass it to the component
    }
    setIsLoading(false);
  };
  const handleExcelClick = async (input: any) => {
    setIsLoading(true);
    setCurrentPage(1);
    const params = `excel_download=1&furnace_id=${input.furnace ?? 0}&page=${input.page || 1}&sort_by_type=${input.sort_by_type || ''}&sort_by=${input.sort_by || ''}&status=${input.status || ''}&reason_value=${input.reason_value ? `${input.reason_value},` : ''}&equipment_value=${input.equipment_value ? `${input.equipment_value},` : ''}&observation_end_dt=${input.observation_end_dt || ''}&observation_start_dt=${input.observation_start_dt || ''}&down_time_type=${input.down_time_type_value ? `${input.down_time_type_value},` : ''}`;

    const response = await dispatch(getFurnaceDownTimeList(params));

    const data = response.payload.data;

    if (response.payload.status >= 200 && response.payload.status < 300) {
      const updatedResults = data.results.map((item: DowntimeExcelDownload) => ({
        ...item,
        event_status_value:
          item.event_status_value &&
          t(`logBook.furnaceDownTimeLog.${item.event_status_value}`, item.event_status_value),
        reason_value:
          item.reason_value &&
          t(`logBook.furnaceDownTimeLog.${item.reason_value}`, item.reason_value),
        equipment_value:
          item.equipment_value &&
          t(`logBook.furnaceDownTimeLog.${item.equipment_value}`, item.equipment_value),
      }));

      setExcelList(updatedResults);
    }
    setIsLoading(false);
  };

  // MAIN USEEFFECT
  useEffect(() => {
    getFurnace();
    getList({ furnace: 0, page: 1 });
  }, []);

  // page number change
  const onPageChange = (pageNumber: number) => {
    getList({ ...inputData, page: pageNumber });
    setCurrentPage(pageNumber);
    setInputData({ ...inputData, page: pageNumber });
  };

  const handleTranslate = (label: string | number) => {
    const translationKey: any = `logBook.furnaceBedLog.${label}`;

    const translatedString = t(translationKey);

    // If the translation exists, `translatedString` will be the translated value,
    // otherwise, it will be the same as `translationKey`
    const displayString = translatedString !== translationKey ? translatedString : label;

    return displayString;
  };

  const dropDown = coreFurnace?.map((item: CoreFurnace) => {
    return { option: handleTranslate(item.furnace_no), value: item.id };
  });

  // API INT FOR LIST COMPONENT  =================================

  // DUMMY DATA --------------
  // DUMMY DATA --------------

  // need to derive this properly
  const hasPermissions = (subModule: string, crudType: string): boolean => {
    return validatePermissions(uniqueCodesMapper.logBookModule, subModule, crudType);
  };
  const eventPermissions = {
    hasEventCreate: hasPermissions(
      uniqueCodesMapper.furnaceDowntimeLogEventFunction,
      crudType.create
    ),
    hasEdit: hasPermissions(uniqueCodesMapper.furnaceDowntimeLogEventFunction, crudType.edit),
    hasCreate: hasPermissions(uniqueCodesMapper.furnaceDowntimeLogSplitFunction, crudType.create), //controls the split create
    hasDelete: hasPermissions(uniqueCodesMapper.furnaceDowntimeLogEventFunction, crudType.delete),
  };

  // need to derive this properly
  const splitPermissions = {
    hasEdit: hasPermissions(uniqueCodesMapper.furnaceDowntimeLogSplitFunction, crudType.edit),
    hasView: hasPermissions(uniqueCodesMapper.furnaceDowntimeLogSplitFunction, crudType.view),
    hasDelete: hasPermissions(uniqueCodesMapper.furnaceDowntimeLogSplitFunction, crudType.delete),
  };

  const getDownTimeData = async (id: number, isSplit: boolean) => {
    // setIsLoading(true);
    const response = isSplit
      ? await dispatch(getFurnaceDownTimeSplit(id))
      : await dispatch(getFurnaceDownTimeEvent(id));
    const data = response.payload.data;

    if (response.payload.status >= 200 && response.payload.status < 300) {
      setDownTimeViewData(data);
    }
    // setIsLoading(false);
  };

  const addEventClick = () => {
    setShowModal(true);
    setIsEdit(false);
    setIsSplitUp(false);
  };
  // functions of action events
  // modal opening and all should happen here, after fetching the ID from inside
  const viewClickAction = (valueInKey: any) => {
    // alert(`PARENT -> VIEW -> value: ${valueInKey} `);
    const [_, IdToSend] = valueInKey?.split('_');
    setCurrentActiveEvent(valueInKey);
    setShowViewModal(true);
    setIsSplitUp(false);
    getDownTimeData(parseInt(IdToSend), false);
  };

  const addClickAction = (valueInKey: any) => {
    setCurrentActiveEvent(valueInKey);
    const [_, IdToSend] = valueInKey?.split('_');
    // find furnace id from render data and pass it to add modal
    const furnaceId = findFurnaceNoByEventId(list, valueInKey); /// furnaceId this is not the pk of furnace
    // const furnacePrimaryKey = findFurnacePkByNo(coreFurnace, furnaceId);
    setTempStoredFurnaceNo(furnaceId);
    setPassedId(parseInt(IdToSend));
    setShowModal(true);
    setIsEdit(false);
    setIsSplitUp(true);
  };

  const editClickAction = (valueInKey: any) => {
    setCurrentActiveEvent(valueInKey);
    // alert(`PARENT -> EDIT -> value: ${valueInKey} `);
    const [_, IdToSend] = valueInKey?.split('_');
    setShowModal(true);
    setIsEdit(true);
    setIsSplitUp(false);
    setPassedId(parseInt(IdToSend));
  };

  const deleteClickAction = (valueInKey: any) => {
    setCurrentActiveEvent(valueInKey);
    // alert(`PARENT -> DELETE -> value: ${valueInKey} `);
    const [_, IdToSend] = valueInKey?.split('_');
    setIdToBeDeleted(parseInt(IdToSend));
    setShowDeleteModal(true);
    setIsSplitUp(false);
  };

  // sub table row action events
  const childViewClickAction = (valueInKey: any) => {
    const [_, IdToSend] = valueInKey?.split('_');
    setShowViewModal(true);
    setIsSplitUp(true);
    getDownTimeData(parseInt(IdToSend), true); // need to pass is split as param (state lags)
  };

  const childAddClickAction = (valueInKey: any) => {
    console.log(`CHILD -> ADD -> value: ${valueInKey} `);
  };
  const childEditClickAction = (valueInKey: any) => {
    const [_, IdToSend] = valueInKey?.split('_');
    const furnaceId = findFurnaceNoBySplitId(list, valueInKey); /// furnaceId this is not the pk of furnace
    if (furnaceId) {
      // const furnacePrimaryKey = findFurnacePkByNo(coreFurnace, furnaceId);
      setTempStoredFurnaceNo(furnaceId);
    }
    setPassedId(parseInt(IdToSend));
    setShowModal(true);
    setIsEdit(true);
    setIsSplitUp(true);
  };

  const childDeleteClickAction = (valueInKey: any) => {
    // alert(`CHILD -> DELETE -> value: ${valueInKey} `);
    const [_, IdToSend] = valueInKey?.split('_');
    setIdToBeDeleted(parseInt(IdToSend));
    setShowDeleteModal(true);
    setIsSplitUp(true);
  };

  // states of actions..

  const closeDeleteModal = () => {
    setIdToBeDeleted(null);
    setShowDeleteModal(false);
    setIsSplitUp(false);
  };

  const handleDeleteConfirm = async () => {
    // alert('go api call> delete id >> : ' + idToBeDeleted);

    setIsLoading(true);
    const response = isSplitUp
      ? await dispatch(deleteFurnaceDownTimeSplit(idToBeDeleted))
      : await dispatch(deleteFurnaceDownTimeEvent(idToBeDeleted));

    const data = response.payload.data;

    if (response.payload.status >= 200 && response.payload.status < 300) {
      notify('success', t(data.message));
      setShowDeleteModal(false);
    } else {
      notify('error', t(data.message));
      setShowDeleteModal(false);
    }
    getList({ furnace: 0, page: 1 });
    // close modal
    closeDeleteModal();
  };

  const clearModalStates = () => {
    setShowViewModal(false);
    setDownTimeViewData(false);
    setIsSplitUp(false);
    setShowModal(false);
    setIsEdit(false);
    setPassedId(null);
    setShowDeleteModal(false);
    setIdToBeDeleted(null);
  };

  const storeLastUpdatedEvent = () => {
    setLastUpdatedEventId(currentActiveEvent);
  };
  const clearLastUpdatedEvent = () => {
    setLastUpdatedEventId('');
  };

  const handleDeleteEvent = (id: number | null) => {
    const check = list.some((item: any) => {
      const IdToSend = item.eventId ? item.eventId.split('_')[1] : undefined;
      return IdToSend == id && item.subTableData.length > 0;
    });
    return check;
  };

  // sort function
  const onSortIconClick = (columnName: string, sortBy: string) => {
    const paramsToPass = {
      ...inputData,
      sort_by: sortBy,
      sort_by_type: columnName,
    };
    getList(paramsToPass, true);
    setInputData(paramsToPass);
  };

  useEffect(() => {
    const radioData = async () => {
      // const downTimeTypes = await
      const reasonData = await dispatch(getFurnaceDownReason(''));
      const downTimeTypes = await dispatch(getRadioFurnaceDownTime());
      const equipmentsData = await dispatch(getFurnaceDownEquipment(''));
      setRadioList({
        reason: reasonData?.payload?.data?.data,
        equipments: equipmentsData?.payload?.data?.data,
        downTimeTypes: downTimeTypes?.payload?.data?.data?.down_time_type,
      });
    };
    radioData();
  }, []);

  const filterFieldList = [
    {
      type: 'selector',
      option: dropDown,
      name: 'Furnace No',
      label: t('systemAdmin.furnaceConfiguration.furnaceNo'),
    },
    { type: 'dateRange', name: 'Date Range' },
    {
      type: 'multiSelector',
      option: {
        placeholder: `${t('logBook.furnaceDownTimeLog.Equipment')}`,
        list: radioList?.equipments?.map((item: ReasonList) => item.equipment_master_code),
        name: 'Equipment', // this is the key name in global state!!! - should not change!!
        label: `${t('logBook.furnaceDownTimeLog.Equipment')}`,
      },
    },
    {
      type: 'multiSelector',
      option: {
        placeholder: `${t('logBook.furnaceDownTimeLog.Reason')}`,
        list: radioList?.reason?.map((item: ReasonList) => item.reason_code),
        name: 'Reason',
        label: `${t('logBook.furnaceDownTimeLog.Reason')}`,
      },
    },
    {
      type: 'multiSelector',
      option: {
        placeholder: `${t('logBook.furnaceDownTimeLog.downtimeType')}`,
        list: radioList?.downTimeTypes?.map((item: ReasonList) => item.down_time_type_code),
        name: 'Downtime Type',
        label: `${t('logBook.furnaceDownTimeLog.downtimeType')}`,
      },
    },
    {
      type: 'selector',
      option: [
        { option: t('logBook.furnaceDownTimeLog.Pending'), value: false },
        { option: t('logBook.furnaceDownTimeLog.Completed'), value: true },
      ],
      name: 'Status',
      label: `${t('logBook.furnaceDownTimeLog.Status')}`,
    },
  ];

  useEffect(() => {
    // Function to call when the component unmounts
    return () => {
      dispatch(setFilterDataList({})); // Call your function here
    };
  }, []);
  useEffect(() => {
    if (excelList.length > 0) {
      csvLinkRef?.current?.link?.click();
    }
  }, [excelList]);
  const excelHeader = [
    {
      label: t('logBook.furnaceDownTimeLog.eventId'),
      key: 'event_id',
    },
    {
      label: t('logBook.furnaceDownTimeLog.splitId'),
      key: 'split_id',
    },
    {
      label: t('systemAdmin.furnaceConfiguration.furnaceNo'),
      key: 'furnace_no',
    },
    {
      label: t('logBook.sharedLogBookTexts.observationStartDateAndTime'),
      key: 'observation_start_dt',
    },
    {
      label: t('logBook.sharedLogBookTexts.observationEndDateAndTime'),
      key: 'observation_end_dt',
    },
    {
      label: t('logBook.sharedLogBookTexts.duration'),
      key: 'duration',
    },
    {
      label: t('logBook.sharedLogBookTexts.equipment'),
      key: 'equipment_value',
    },
    {
      label: t('logBook.sharedLogBookTexts.reason'),
      key: 'reason_value',
    },
    {
      label: t('logBook.sharedLogBookTexts.eventStatus'),
      key: 'event_status_value',
    },
  ];

  return (
    <main className='dashboard'>
      {/* width: '1px' - gave this to fix a bug.. its enabling a scrollbar if the table goes out in small screens */}
      <section className='dashboard__main' style={{ width: '1px' }}>
        {isLoading && <Loading />}
        <ReusableHeader
          title={t(
            `plantModulesAndFunctions.${uniqueCodesMapper.furnaceDowntimeLogFunction}`,
            uniqueCodesMapper.furnaceDowntimeLogFunction
          )}
          buttonText={t('logBook.furnaceDownTimeLog.addEvent')}
          isExcel
          csvLinkRef={csvLinkRef}
          handleExcelClick={() => handleExcelClick(inputData)}
          excelDataList={{
            csvData: excelList,
            headersForCSV: excelHeader,
            title: t(
              `plantModulesAndFunctions.${uniqueCodesMapper.furnaceDowntimeLogFunction}`,
              uniqueCodesMapper.furnaceDowntimeLogFunction
            ),
          }}
          onButtonClick={() => addEventClick()}
          filterFieldList={filterFieldList}
          isFilterSortAllowed
          hasCreatePermission={eventPermissions?.hasEventCreate}
          onReset={() => {
            setInputData({
              furnace: 0,
              page: 1,
              sort_by: '',
              sort_by_type: '',
              observation_start_dt: '',
              observation_end_dt: '',
              equipment_value: '',
              status: '',
              reason_value: '',
            });
            getList({
              furnace: 0,
              page: 1,
            });
          }}
          onFilter={() => {
            setInputData({
              ...inputData,
              furnace: filterDataListState?.['Furnace No']?.value
                ? filterDataListState?.['Furnace No']?.value
                : 0,
              observation_start_dt: filterDataListState?.['Date Range']?.[0]
                ? dayjs(filterDataListState?.['Date Range']?.[0]).format('YYYY-MM-DD')
                : '',
              observation_end_dt: filterDataListState?.['Date Range']?.[1]
                ? dayjs(filterDataListState?.['Date Range']?.[1]).format('YYYY-MM-DD')
                : '',
              equipment_value: filterDataListState?.['Equipment']
                ? filterDataListState?.['Equipment'].join()
                : '',
              reason_value: filterDataListState?.['Reason']
                ? filterDataListState?.['Reason'].join()
                : '',
              status: filterDataListState?.['Status'],
            });
            getList({
              ...inputData,
              furnace: filterDataListState?.['Furnace No']?.value
                ? filterDataListState?.['Furnace No']?.value
                : 0,
              observation_start_dt: filterDataListState?.['Date Range']?.[0]
                ? dayjs(filterDataListState?.['Date Range']?.[0]).format('YYYY-MM-DD')
                : '',
              observation_end_dt: filterDataListState?.['Date Range']?.[1]
                ? dayjs(filterDataListState?.['Date Range']?.[1]).format('YYYY-MM-DD')
                : '',
              equipment_value: filterDataListState?.['Equipment']
                ? filterDataListState?.['Equipment'].join()
                : '',
              down_time_type_value: filterDataListState?.['Downtime Type']
                ? filterDataListState?.['Downtime Type'].join()
                : '',
              reason_value: filterDataListState?.['Reason']
                ? filterDataListState?.['Reason'].join()
                : '',
              status: filterDataListState?.['Status']?.value,
            });
          }}
        />

        {/* ------------------ UNCOMMENT AT THE TIME OF DEVELOPMENT. HELPS TO UNDERSTAND LOGIC ------------------ */}
        {/* <h1> current active event: {currentActiveEvent} </h1> */}
        {/* <h1> last updated event (dependence): {lastUpdatedEventId} </h1> */}
        {/* NOTE : only set after success of split add and edit api calls. clear on click of toggle arrows in table */}
        {/* ------------------ UNCOMMENT AT THE TIME OF DEVELOPMENT. HELPS TO UNDERSTAND LOGIC ------------------ */}

        <div
          className='dashboard__main__body pt-6'
          style={{ padding: '16px 12px', overflow: 'auto' }}
        >
          {list?.length > 0 ? (
            <CollapsibleTable
              mainHeaders={mainHeaders}
              subHeaders={subHeaders}
              renderData={list}
              subDataKey={'subTableData'}
              // define icon functions in parent..
              showActionIconsInParentRow
              showActionIconsInChild
              parentRowActionsPermission={eventPermissions}
              childRowActionsPermission={splitPermissions}
              // callbacks for icons
              parentActionsValueKey={'eventId'} // THE KEY of ID
              childActionsValueKey={'splitID'}
              // childActionsValueKey={} // THE KEY of ID
              // parent call backs
              callBackOnViewClick={viewClickAction}
              callBackOnAddClick={addClickAction}
              callBackOnDeleteClick={deleteClickAction}
              callBackOnEditClick={editClickAction}
              // parent call backs end
              // child functions
              childCallBackOnViewClick={childViewClickAction}
              childCallBackOnAddClick={childAddClickAction}
              childCallBackOnDeleteClick={childDeleteClickAction}
              childCallBackOnEditClick={childEditClickAction}
              // child functions end

              toolTips={toolTipsForDownTime}
              lastUpdatedEventId={lastUpdatedEventId} // used to open up sub table
              clearLastUpdatedEvent={clearLastUpdatedEvent}
              columnsToDisplayAsPills={['status']} // keys in format function is passed
              columnsWithTranslations={['equipment', 'reason']}
              sortHandler={onSortIconClick}
            />
          ) : (
            <p className='d-flex justify-content-center mt-5'>{t('sharedTexts.noRecordsFound')}</p>
          )}

          <div className='px-4'>
            <Pagination
              totalItems={count}
              itemsPerPage={itemsPerPage}
              onPageChange={onPageChange}
              currentPage={currentPage}
              previous={previous}
              next={next}
            />
          </div>
        </div>
        {/* modals of action  */}

        {/* VIEW MODAL  */}
        {showViewModal && (
          <DownTimeLogViewModal
            showModal={showViewModal}
            setShowModal={setShowViewModal}
            data={downTimeViewData}
            isSplitUp={isSplitUp}
            onClose={clearModalStates}
          />
        )}

        {/* ADD /EDIT MODAL */}

        {showModal && (
          <DownTimeEventModal
            isEdit={isEdit}
            showModal={showModal}
            setShowModal={setShowModal}
            isSplitUp={isSplitUp}
            downTimeId={passedId}
            setIsLoading={() => {}}
            getList={getList}
            passedFurnaceId={tempStoredFurnaceNo} // only split will use this
            storeLastUpdatedEvent={storeLastUpdatedEvent} // to track which event got updated
          />
        )}
        {/* DELETE MODAL  */}
        <AlertModal
          showModal={showDeleteModal}
          title={
            isSplitUp
              ? `${t('logBook.furnaceDownTimeLog.deleteSplit')}?`
              : `${t('logBook.furnaceDownTimeLog.deleteEvent')}?`
          }
          content={
            !isSplitUp && handleDeleteEvent(idToBeDeleted)
              ? t('logBook.furnaceDownTimeLog.eventDeleteWarningMessage')
              : `${t('logBook.furnaceDownTimeLog.areYouSureYouWantToDeleteThis')} ${isSplitUp ? t('logBook.furnaceDownTimeLog.split') : t('logBook.furnaceDownTimeLog.event')}?`
          }
          confirmButtonText={t('sharedTexts.confirm')}
          onConfirmClick={handleDeleteConfirm}
          closeModal={closeDeleteModal}
        />
      </section>
    </main>
  );
};

export default FurnaceDowntimeList;
