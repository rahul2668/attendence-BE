// BED LOG ADD/EDIT MODAL
import ReusableModal from 'components/common/Modal/ReusableModalLayout/ReusableModal';
import { FC, useEffect, useState } from 'react';
import ViewForm from './DownTimeLogView';
import { DownTimeLogModalProps } from 'types/logBook.model';
import Loader from 'components/Loader';
import { useTranslation } from 'react-i18next';

const DownTimeLogViewModal: FC<DownTimeLogModalProps> = ({
  showModal,
  setShowModal,
  data,
  isSplitUp,
  onClose = () => {},
}) => {
  const { t } = useTranslation();
  const closeButtonClick = () => {
    setShowModal(false);
    onClose();
  };

  const [dataRenderedInView, setDataRenderedInView] = useState([]);

  useEffect(() => {
    let transformedObj: any = [];
    if (isSplitUp) {
      transformedObj = [
        { id: data?.furnace_no?.id, value: data?.furnace_no?.value, label: 'Furnace No' },
        { value: data?.duration, label: 'Duration' },
        // { value: data?.external_source_id, label: 'External ID' },
        { value: data?.observation_start_dt, label: 'Split Start Date & Time' },
        { value: data?.observation_end_dt, label: 'Split End Date & Time' },
        { id: data?.equipment?.id, value: data?.equipment?.value, label: 'Equipment' },
        { id: data?.reason?.id, value: data?.reason?.value, label: 'Reason' },
        {
          id: data?.down_time_type?.id,
          value: data?.down_time_type?.value,
          label: 'Downtime Type',
        },
        // { value: data?.split_status, label: 'Status' },
        { value: data?.comments, label: 'Comments' },
      ];
    } else {
      transformedObj = [
        { id: data?.furnace?.id, value: data?.furnace?.value, label: 'Furnace No' },
        { id: data?.source?.id, value: data?.source?.value, label: 'Source' },
        { value: data?.observation_start_dt, label: 'Event Start Date & Time' },
        { value: data?.observation_end_dt, label: 'Event End Date & Time' },
        { value: data?.duration, label: 'Duration' },
        { value: data?.updated_by, label: 'Updated By' },
        { id: data?.equipment?.id, value: data?.equipment?.value, label: 'Equipment' },
        { id: data?.reason?.id, value: data?.reason?.value, label: 'Reason' },
        {
          id: data?.down_time_type?.id,
          value: data?.down_time_type?.value,
          label: 'Downtime Type',
        },
        { value: data?.event_status, label: 'Status' },
        { value: data?.comments, label: 'Comments' },
      ];
    }
    setDataRenderedInView(transformedObj);
  }, [data]);

  const canRender = () => {
    return showModal && dataRenderedInView?.length > 0;
  };

  return (
    <ReusableModal
      title={`${t('logBook.furnaceDownTimeLog.viewFurnaceDowntime')} - ${isSplitUp ? `SP_${data?.id}` : `DT_${data?.id}`}`}
      confirmButtonText={t('sharedTexts.save')}
      closeModal={() => closeButtonClick()}
      showModal={showModal}
      hideButtons={true}
    >
      {/* {console.log('view data', dataRenderedInView.length === 0)} */}
      {canRender() ? (
        <ViewForm observationData={dataRenderedInView} />
      ) : (
        <div style={{ marginTop: '13%' }}>
          <Loader />
        </div>
      )}

      {/* {showModal && <ViewForm observationData={dataRenderedInView} />} */}
      {/* pass different header data, to load the fields in body  */}
    </ReusableModal>
  );
};

export default DownTimeLogViewModal;
