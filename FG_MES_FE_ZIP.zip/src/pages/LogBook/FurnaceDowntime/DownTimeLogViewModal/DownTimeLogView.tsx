// Observation log form - reusable component
import { FC } from 'react';
import { Box, Grid } from '@mui/material';
import dayjs from 'dayjs';
import { useTranslation } from 'react-i18next';
import { timeLabelsInViewScreen } from '../helper';

const ViewForm: FC<any> = ({ observationData }) => {
  const { t } = useTranslation();
  const handleDateFormat = (value: string) => {
    try {
      const date = dayjs(value);
      if (date.isValid()) {
        const formattedDate = date.format('DD-MMM-YYYY | hh:mm A');
        return formattedDate;
      } else {
        return '- -';
      }
    } catch (error) {
      console.error('Error parsing date:', error);
    }
  };
  const dataEntries = Object.keys(observationData)
    .filter((key) => typeof observationData[key] === 'object' && observationData[key] !== null)
    .map((key) => {
      if (
        typeof observationData[key] === 'object' &&
        observationData[key] !== null &&
        !timeLabelsInViewScreen.includes(observationData[key]?.label)
      ) {
        return { label: observationData[key].label, value: observationData[key].value || '- -' };
      } else if (timeLabelsInViewScreen.includes(observationData[key]?.label)) {
        // alert("going to format")
        return {
          label: observationData[key].label,
          value: handleDateFormat(observationData[key].value),
        };
      } else {
        return { label: key, value: observationData[key] || '- -' };
      }
    });

  return (
    <Box display={'flex'} flexDirection={'column'} sx={{ gap: '25px' }}>
      <Grid container spacing={2}>
        {dataEntries.map((item: any, index: number) => (
          <Grid item xs={6} sm={3} key={index}>
            <div style={{ fontWeight: 600, color: '#606466', fontSize: '14px' }}>
              {t(item.label && `logBook.furnaceDownTimeLog.${item.label}`)}
            </div>
            <div>
              <strong
                style={{
                  fontWeight: 600,
                  fontSize: '14px',
                  overflowWrap: 'break-word',
                  color:
                    item.label == 'Status' ? (item.value == 'Pending' ? '#f91313' : '#2D8E0E') : '',
                }}
              >
                {item.label == 'Reason' ||
                item.label == 'Source' ||
                item.label == 'Status' ||
                item.label == 'Downtime Type' ||
                item.label == 'Equipment'
                  ? t(item.value && `logBook.furnaceDownTimeLog.${item.value}`)
                  : item.value}
              </strong>
            </div>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default ViewForm;
