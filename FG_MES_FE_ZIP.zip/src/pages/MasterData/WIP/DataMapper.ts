import moment from 'moment';
import { isEmpty } from 'utils/utils';

interface Unit {
  id: number;
  name: string;
  unit: string;
}

export const SampleTypes = [
  { key: 'None', value: 0 },
  { key: 'Cup', value: 1 },
  { key: 'Probe', value: 2 },
  { key: 'Cast', value: 3 },
  { key: 'Grab', value: 4 },
  { key: 'Pile', value: 5 },
  { key: 'Bag', value: 6 },
  { key: 'Truck', value: 7 },
  { key: 'Car', value: 8 },
  { key: 'Barge', value: 9 },
  { key: 'Container', value: 10 },
];

export const AnalyticalDeviceTypes = [
  { key: 'None', value: 0 },
  { key: 'AA', value: 1 },
  { key: 'ICP', value: 2 },
  { key: 'LECO', value: 3 },
  { key: 'XRay', value: 4 },
  { key: 'Wet', value: 5 },
  { key: 'DCP', value: 6 },
  { key: 'OS Lab', value: 7 },
  { key: 'ICP MS', value: 8 },
];

export const OriginalSampleTypes = [
  { key: 'Original', value: 0 },
  { key: 'ReEnter', value: 1 },
  { key: 'Resample', value: 2 },
  { key: 'Reset', value: 3 },
  { key: 'Bad Sample', value: 4 },
];
export const updateSectionData = (
  additiveResponse: any,
  setAdditiveDetails: any,
  setOtherInformation: any,
  t: any,
  allUnits: any
) => {
  const material = [
    {
      type: 'text',
      editable: false,
      label: t('masterData.sharedMasterDataTexts.mesMaterialCode'),
      keyName: 'material_no',
      inputComponent: 'input',
      value: additiveResponse?.master_data?.mes_mat_code,
    },
    {
      type: 'text',
      editable: false,
      label: t('masterData.sharedMasterDataTexts.materialName'),
      inputComponent: 'input',
      keyName: 'material_name',
      value: additiveResponse?.master_data?.material_name,
    },
    {
      type: 'text',
      editable: false,
      label: t('masterData.sharedMasterDataTexts.erpCommercialMaterialCode'), // had a change of label
      inputComponent: 'input',
      keyName: 'erp_commercial_mat_code',
      value: additiveResponse?.master_data?.erp_commercial_mat_code,
    },
    {
      type: 'text',
      editable: false,
      label: t('masterData.sharedMasterDataTexts.erpCommercialMaterialName'), // had a change of label
      inputComponent: 'input',
      keyName: 'erp_commercial_mat_name',
      value: additiveResponse?.master_data?.erp_commercial_mat_name,
    },
    {
      type: 'text',
      editable: false,
      label: t('masterData.sharedMasterDataTexts.erpACCMaterialCode'),
      inputComponent: 'input',
      keyName: 'erp_acc_mat_code',
      value: additiveResponse?.master_data?.erp_acc_mat_code,
    },
    {
      type: 'text',
      editable: false,
      label: t('masterData.sharedMasterDataTexts.erpAccMaterialName'),
      inputComponent: 'input',
      keyName: 'erp_acc_mat_name',
      value: additiveResponse?.master_data?.erp_acc_mat_name,
    },
    {
      type: 'text',
      editable: false,
      label: t('masterData.sharedMasterDataTexts.opsTechnicalMaterialCode'),
      inputComponent: 'input',
      keyName: 'ops_tech_mat_code',
      value: additiveResponse?.master_data?.ops_tech_mat_code,
    },
    {
      type: 'text',
      editable: false,
      label: t('masterData.sharedMasterDataTexts.materialType'),
      inputComponent: 'input',
      keyName: 'material_type',
      value: additiveResponse?.master_data?.material_type,
    },
    {
      type: 'text',
      editable: false,
      label: t('sharedTexts.status'),
      keyName: 'is_active',
      inputComponent: 'input',
      value: additiveResponse?.master_data?.status ? 'Active' : 'Inactive',
    },
    {
      type: 'text',
      editable: false,
      label: t('sharedTexts.dateCreated'),
      keyName: 'created_at',
      inputComponent: 'input',
      value: moment(additiveResponse?.master_data?.created_at).format('MM/DD/YYYY'),
    },

    {
      type: 'text',
      editable: false,
      label: t('masterData.sharedMasterDataTexts.materialDescription'),
      keyName: 'material_description',
      inputComponent: 'input',
      value: additiveResponse?.master_data?.material_description,
    },
  ];
  const others = [
    {
      type: 'text',
      editable: true,
      label: 'Available*',
      keyName: 'is_available',
      inputComponent: 'select',
      options: [
        { key: t('sharedTexts.yes'), value: true },
        { key: t('sharedTexts.no'), value: false },
      ],
      value: additiveResponse?.is_available,
    },
    {
      type: 'text',
      editable: true,
      label: `${t('masterData.sharedMasterDataTexts.specReferences')}*`,
      keyName: 'spec_references',
      inputComponent: 'input',
      value: additiveResponse?.spec_references,
      unit: allUnits?.filter((item: Unit) => item.name == 'Text')[0]?.unit,
    },
    {
      type: 'number',
      editable: true,
      label: `${t('masterData.sharedMasterDataTexts.density')}*`,
      keyName: 'density',
      inputComponent: 'input',
      value: additiveResponse?.density,
      unit: allUnits?.filter((item: Unit) => item.name == 'Density')[0]?.unit,
    },
  ];

  setAdditiveDetails(material);
  setOtherInformation(others);
};

export const validateAdditiveData = (additiveData: any) => {
  return (
    // isEmpty(additiveData.record_no) ||
    // isEmpty(additiveData.lot_id) ||
    // isEmpty(additiveData?.unit_weight) ||
    // isEmpty(additiveData?.actual_cost) ||
    // isEmpty(additiveData?.addition_group) ||
    isEmpty(additiveData?.density) ||
    // isEmpty(additiveData?.standard_cost) ||
    // isEmpty(additiveData?.co_contributor) ||
    // isEmpty(additiveData?.kwh_melting) ||
    // isEmpty(additiveData?.carbon_needed)||
    isEmpty(additiveData?.is_available) ||
    isEmpty(additiveData?.spec_references)
  );
};
