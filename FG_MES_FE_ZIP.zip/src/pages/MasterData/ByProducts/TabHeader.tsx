import { FC, useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import DashboardAddtivieHeader from 'components/DashboardHeader';
import { paths } from 'routes/paths';
import { useAppDispatch } from 'store';
import {
  editByproductsSpecificationDetails,
  getByProductsSpecificationDetails,
} from 'store/slices/furnaceMaterialSlice';
import FurnaceMaterial from './ByProducts';
import MainTab from 'components/common/MainTab';
import MasterDataSpecification from 'components/common/MasterDataSpecification';
import Loading from 'components/common/Loading';
import { notify } from 'utils/utils';
import { useTranslation } from 'react-i18next';
type Tabs = {
  label: string;
  value: number;
};
const TabHeader: FC = () => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const { t } = useTranslation();
  const url = new URL(window.location.href);
  const queryParams = new URLSearchParams(url.search);
  const { id }: any = useParams();
  const isActive = queryParams.get('isActive');
  const tabs: Tabs[] = [
    { label: t('masterData.sharedMasterDataTexts.materialInformation'), value: 1 },
    { label: t('masterData.sharedMasterDataTexts.materialSpecification'), value: 2 },
  ];
  const [sizesChangeHistoryData, setSizesChangeHistoryData] = useState<any>([]);
  const [changeHistoryData, setChangeHistoryData] = useState<any>([]);
  const [changeLogData, setChangeLogData] = useState<any>([]);
  const [status, setStatus] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<number>(tabs[0].value);
  const [materialNo, setMaterialNo] = useState(0);
  const [loading, setLoading] = useState<boolean>(false);
  const editMode = false;
  const [isNextTabAllowed, setIsNextTabAllowed] = useState(true);
  const handleBackClick = () => {
    navigate(`${paths.byProducts.list}`);
  };
  const onSave = async () => {
    try {
      if (sizesChangeHistoryData.length > 1 && sizesChangeHistoryData[1].unit) {
        // Assign the value of the 'unit' property of the second element to the first element
        sizesChangeHistoryData[0].unit = sizesChangeHistoryData[1].unit;
      }

      // Check if data[4] exists and has the 'list' property and if the list has at least two elements
      if (data[4]?.list && data[4]?.list.length > 1 && data[4].list[1].unit) {
        // Assign the value of the 'unit' property of the second element to the first element
        if (data[4].list[0]) {
          data[4].list[0].unit = data[4].list[1].unit;
        }
      }

      setLoading(true);
      const merged = {
        change_logs_elements: changeHistoryData,
        change_logs_sizes: sizesChangeHistoryData[0],
      };
      !changeHistoryData?.length && delete merged.change_logs_elements;
      const payload: any = {
        chemistry_values: data[0]?.list || [],
        other_chemistry_values: data[1]?.list || [],
        physical_elements: data[2]?.list || [],
        sizes: data[4]?.list[0] || {},
        changeHistoryData: merged,
        auxillary: data[3]?.list || [],
      };
      console.log('payload', payload);

      if (!sizesChangeHistoryData[0] && !changeHistoryData?.length) {
        delete payload.changeHistoryData;
      }
      const response = await dispatch(
        editByproductsSpecificationDetails({ body: payload, id: id || null })
      );
      setChangeHistoryData([]);
      setSizesChangeHistoryData([]);

      if (response.payload.status >= 200 && response.payload.status < 300) {
        setLoading(false);
        notify('success', t(response?.payload?.data?.message));
        navigate(`${paths.byProducts.view}/${id}`);
      } else {
        setLoading(false);
      }
    } finally {
      setLoading(false);
    }
    fetchData();
  };

  const fetchData = async () => {
    setLoading(true);
    const resp = await dispatch(getByProductsSpecificationDetails(id));
    const changeHistoryData = resp.payload.data.data.changeHistoryData;
    setData((prevData: any) => {
      const updatedData = prevData.map((item: any) => {
        if (item.type === 'Chemistry Values') {
          return { ...item, list: resp?.payload?.data?.data?.chemistry_values };
        } else if (item.type === 'Other Chemistry Values') {
          return { ...item, list: resp?.payload?.data?.data?.other_chemistry_values };
        } else if (item.type === 'Physical Elements') {
          return { ...item, list: resp?.payload?.data?.data?.physical_elements };
        } else if (item.type === 'Auxiliary Elements') {
          return { ...item, list: resp?.payload?.data?.data?.auxillary };
        } else if (item.type === 'Sizes') {
          return {
            ...item,
            list: [resp?.payload?.data?.data?.sizes],
            title: t('masterData.sharedMasterDataTexts.sizeSpecifications'),
          };
        } else {
          return item;
        }
      });
      return updatedData;
    });

    setChangeLogData(changeHistoryData);
    setLoading(false);
  };
  useEffect(() => {
    activeTab === 2 && fetchData();
  }, [activeTab]);

  useEffect(() => {
    if (!status && activeTab === 2) {
      navigate(`${paths.byProducts.create}/${id}`);
    }
  }, [status, activeTab]);

  const [data, setData] = useState<any>([
    {
      title: t('masterData.sharedMasterDataTexts.chemistryValues'),
      list: [],
      type: 'Chemistry Values',
      accordion: false,
      showWarningToleranceOnTable: false, //UI table extra columns
    },
    {
      title: t('masterData.sharedMasterDataTexts.otherChemistryValues'),
      list: [],
      type: 'Other Chemistry Values',
      accordion: true,
      showWarningToleranceOnTable: false, //UI table extra columns
    },
    {
      title: t('masterData.sharedMasterDataTexts.physicalElements'),
      list: [],
      type: 'Physical Elements',
      accordion: false,
      showWarningToleranceOnTable: false, //UI table extra columns
    },
    {
      title: t('masterData.sharedMasterDataTexts.auxiliaryElements'),
      list: [],
      type: 'Auxiliary Elements',
      accordion: false,
      showWarningToleranceOnTable: false, //UI table extra columns
    },
    {
      title: t('masterData.sharedMasterDataTexts.sizeSpecifications'),
      list: [],
      type: 'Sizes',
      accordion: false,
      showWarningToleranceOnTable: false, //UI table extra columns
    },
  ]);

  return (
    <>
      <DashboardAddtivieHeader
        title={`${materialNo}`}
        onBackClick={handleBackClick}
        isActive={activeTab === 1 && isActive !== 'false'}
      />
      <div className='dashboard__main__body px-8 py-6'>
        <div className='card-box'>
          <div className={`${!editMode ? 'tab - wrapper' : ''}`}>
            <MainTab
              editMode={editMode}
              tabs={tabs}
              setActiveTab={setActiveTab}
              activeTab={activeTab}
              isNextTabAllowed={isNextTabAllowed}
            />
            {activeTab === 1 ? (
              <div>
                <FurnaceMaterial
                  getMaterailNum={(materailNum): any => {
                    setMaterialNo(materailNum);
                  }}
                  changeTab={setIsNextTabAllowed}
                  setStatus={setStatus}
                />
              </div>
            ) : (
              <div className=' px-6 pt-4 pb-16'>
                {!data[0]?.list?.length && !loading ? (
                  <div className='text-center p-4'>{t('sharedTexts.noDataFound')}</div>
                ) : (
                  ''
                )}
                {loading ? <Loading /> : ''}
                {!loading && data[0]?.list?.length ? (
                  <div className=' px-6 pt-4 pb-16'>
                    <MasterDataSpecification
                      sizesChangeHistoryData={sizesChangeHistoryData}
                      setSizesChangeHistoryData={setSizesChangeHistoryData}
                      apiData={data}
                      onSave={onSave}
                      setChangeHistoryData={setChangeHistoryData}
                      changeHistoryData={changeHistoryData}
                      changeHistoryInputData={changeLogData}
                      warningTolerance={false} //for component btn handling and Change History table extra column
                      setData={setData}
                      materialId={id}
                      excelTitle={t('masterData.byProducts.byProduct')}
                    />
                  </div>
                ) : (
                  ''
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
};
export default TabHeader;
