import { FC, useState, useEffect, FormEvent } from 'react';
import '../../../assets/styles/scss/pages/dashboard.scss';
import '../../../assets/styles/scss/components/table-general.scss';
import { useAppDispatch, useAppSelector } from 'store';
import InformationTab from 'components/common/InformationTab';
import InformationTabSection from 'components/common/InformationTabSection';
import Loading from 'components/common/Loading';
import { isEmpty, notify } from 'utils/utils';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import { paths } from 'routes/paths';
import { updateSectionData, validateAdditiveData } from './DataMapper';
import {
  createMaterail,
  getByProductDetails,
  getByProductMaterialExcel,
  setByProductMaterialExcelList,
} from 'store/slices/byProductSlice';
import { useTranslation } from 'react-i18next';
import dayjs, { Dayjs } from 'dayjs';
import AlertModal from 'components/Modal/AlertModal';

interface AddtiveProps {
  getMaterailNum: (e: any) => void;
  changeTab?: (e: any) => void;
  setStatus: (e: boolean) => void;
}
const FurnaceMaterial: FC<AddtiveProps> = ({ getMaterailNum, changeTab, setStatus }) => {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const location = useLocation();
  const { t } = useTranslation();
  const { byProductMaterialExcelList } = useAppSelector((state) => state.byProduct);

  const [byProductsData, setByProductsData] = useState<any>();
  const url = new URL(window.location.href);
  const queryParams = new URLSearchParams(url.search);
  const { id }: any = useParams();
  const editValue = queryParams.get('edit');
  const [isEdit, setIsEdit] = useState(editValue !== 'false');
  const [additiveDetails, setAdditiveDetails] = useState({});
  const [otherInformation, setOtherInformation] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const allUnits = useAppSelector((state: any) => state.unit.units);
  const [showUpdatePrompt, setShowUpdatePrompt] = useState<boolean>(false);
  const [additionalInfoId, setAdditionalInfoId] = useState<undefined | number>();

  const handleBackClick = () => {
    navigate(`${paths.byProducts.list}`);
  };

  const getByProducts = async () => {
    const response = await dispatch(getByProductDetails(id));
    setByProductsData(response.payload.data.data);
    getMaterailNum(
      `${response?.payload.data.data.master_data.mes_mat_code} | ${response?.payload.data.data.master_data.material_name}`
    );
    setStatus(response?.payload.data.data.master_data.status);
    const setByProductsResponse = response.payload.data.data;
    if (setByProductsResponse?.id) setAdditionalInfoId(setByProductsResponse?.id); // a separate state to hold the additinal info id
    updateSectionData(setByProductsResponse, setAdditiveDetails, setOtherInformation, t, allUnits);
  };
  const editHandler = () => {
    navigate(`${paths.byProducts.edit}/${id}`);
    setIsEdit(!isEdit);
  };
  const changeHandler = (value: string | number | boolean, keyName: string) => {
    const clonedData: any = JSON.parse(JSON.stringify(byProductsData));
    clonedData[keyName] = value;
    if (!('effective_date' in clonedData)) {
      clonedData['effective_date'] = dayjs().format('YYYY-MM-DD');
    }
    setByProductsData(clonedData);
  };

  const handleEffectiveDateChange = (newDateAndTime: Dayjs) => {
    // alert('parent fired');
    const clonedData = { ...byProductsData };
    clonedData['effective_date'] = newDateAndTime.format('YYYY-MM-DD');
    setByProductsData(clonedData);
  };

  useEffect(() => {
    getByProducts();
    if (location.pathname === `${paths.byProducts.view}/${id}`) {
      setIsEdit(false);
      changeTab && changeTab(true);
    } else if (location.pathname === `${paths.byProducts.edit}/${id}`) {
      setIsEdit(true);
      changeTab && changeTab(true);
    } else if (location.pathname === `${paths.byProducts.create}${id}`) {
      setIsEdit(true);
    }
  }, [id, location]);

  useEffect(() => {
    updateSectionData(byProductsData, setAdditiveDetails, setOtherInformation, t, allUnits);
    if (location.pathname === `${paths.byProducts.create}/${id}`) {
      if (byProductsData?.id) {
        changeTab && changeTab(true);
      } else {
        changeTab && changeTab(false);
      }
    }
  }, [byProductsData, allUnits]);

  const onSaveChanges = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const numericId: number = id !== null ? id : 0;
    // if (!byProductsData?.id) {
    onCreateMaterial(byProductsData, numericId);
    // } else {
    //   editMaterialDetails(byProductsData, numericId);
    // }
    setIsEdit(false);
  };
  // const editMaterialDetails = async (data: any, id: number) => {
  //   setIsLoading(true);
  //   const updatedData = {
  //     id: id,
  //     body: data,
  //   };
  //   const editResponse = await dispatch(editByProduct(updatedData));
  //   if (editResponse?.payload?.data?.user_approval_needed) {
  //     setIsLoading(false);
  //     setShowUpdatePrompt(true);
  //   } else {
  //     if (editResponse.payload.status >= 200 && editResponse.payload.status < 300) {
  //       notify('success', t(editResponse?.payload?.data?.message));
  //       navigate(`${paths.byProducts.view}/${id}`);
  //     }
  //   }

  //   setIsLoading(false);
  // };
  const onCreateMaterial = async (data: any, id: number) => {
    setIsLoading(true);

    // Create a shallow copy of the data object
    const dataCopy = {
      ...data,
      // additionalInfoId - will only be there if the main api response has a key 'id'
      ...(additionalInfoId ? { additional_info_id: additionalInfoId } : {}), // first save call action's payload
    };
    delete dataCopy.master_data;
    delete dataCopy.id;

    const createResponse = await dispatch(
      createMaterail({ ...dataCopy, id: data?.master_data?.mes_mat_code })
    );

    setIsLoading(false);

    if (createResponse?.payload?.data?.user_approval_needed) {
      setShowUpdatePrompt(true);
      return;
    }

    if (createResponse.payload.status >= 200 && createResponse.payload.status < 300) {
      notify('success', t(createResponse?.payload?.data?.message));
      navigate(`${paths.byProducts.view}/${id}`);
    }
  };

  const hasErrors = () => {
    return validateAdditiveData(byProductsData);
  };

  const handlePromptCancel = () => {
    setShowUpdatePrompt(false);
  };

  const handlePromptConfirm = async () => {
    setIsLoading(true);
    // const numericId: number = id !== null ? parseInt(id) : 0;

    const dataCopy = { ...byProductsData };
    delete dataCopy.master_data;

    delete dataCopy.master_data;
    const createResponse = await dispatch(
      createMaterail({
        ...dataCopy,
        id: byProductsData?.master_data?.mes_mat_code,
        is_user_approved: true,
        // additionalInfoId - will only be there if the main api response has a key 'id'
        ...(additionalInfoId ? { additional_info_id: additionalInfoId } : {}),  // proceed action's payload
      })
    );
    setIsLoading(false);

    if (createResponse?.payload?.data?.user_approval_needed) {
      setIsLoading(false);
      setShowUpdatePrompt(true);
    }
    if (createResponse.payload.status >= 200 && createResponse.payload.status < 300) {
      notify('success', t(createResponse?.payload?.data?.message));
      navigate(`${paths.byProducts.view}/${id}`);
      setShowUpdatePrompt(false);
    }
  };

  const excelHeader: any[] = [
    {
      label: t('sharedTexts.effectiveDate'),
      key: 'effective_date',
    },
    {
      label: t('masterData.sharedMasterDataTexts.materialType'),
      key: 'master_data.material_type',
    },
    {
      label: t('masterData.sharedMasterDataTexts.mesMaterialCode'),
      key: 'master_data.mes_mat_code',
    },
    {
      label: t('masterData.sharedMasterDataTexts.materialName'),
      key: 'master_data.material_name',
    },
    {
      label: t('masterData.sharedMasterDataTexts.materialDescription'),
      key: 'master_data.material_description',
    },
    {
      label: t('systemAdmin.plantConfiguration.createdAt'),
      key: 'master_data.created',
    },
    {
      label: t('logBook.furnaceDownTimeLog.Status'),
      key: 'master_data.status',
    },
    {
      label: t('masterData.sharedMasterDataTexts.erpCommercialMaterialCode'),
      key: 'master_data.erp_commercial_mat_code',
    },
    {
      label: t('masterData.sharedMasterDataTexts.erpCommercialMaterialName'),
      key: 'master_data.erp_commercial_mat_name',
    },
    {
      label: t('masterData.sharedMasterDataTexts.erpACCMaterialCode'),
      key: 'master_data.erp_acc_mat_code',
    },
    {
      label: t('masterData.sharedMasterDataTexts.erpAccMaterialName'),
      key: 'master_data.erp_acc_mat_name',
    },
    {
      label: t('masterData.sharedMasterDataTexts.opsTechnicalMaterialCode'),
      key: 'master_data.ops_tech_mat_code',
    },
    {
      label: t('masterData.sharedMasterDataTexts.unitWeight'),
      key: 'unit_weight',
    },
    {
      label: t('masterData.sharedMasterDataTexts.density'),
      key: 'density',
    },
    {
      label: t('systemAdmin.plantConfiguration.createdBy'),
      key: 'created_name',
    },
    {
      label: t('systemAdmin.plantConfiguration.modifiedBy'),
      key: 'modified_name',
    },
    {
      label: t('systemAdmin.plantConfiguration.createdAt'),
      key: 'created_date',
    },
    {
      label: t('systemAdmin.plantConfiguration.modifiedAt'),
      key: 'modified_date',
    },
  ];

  const handleExcelClick = async (e: any) => {
    e.preventDefault();
    if (id) {
      const response = await dispatch(getByProductMaterialExcel(id));
      const data = response.payload.data;

      if (response.payload.status >= 200 && response.payload.status < 300) {
        dispatch(setByProductMaterialExcelList(data.data));
      }
    }
  };

  const clearExcelState = () => {
    dispatch(setByProductMaterialExcelList([]));
  };

  return !isLoading && !isEmpty(byProductsData) ? (
    <>
      <form onSubmit={onSaveChanges}>
        <InformationTab
          isEdit={isEdit}
          hasErrors={hasErrors}
          editHandler={editHandler}
          handleBackClick={handleBackClick}
        >
          <>
            <InformationTabSection
              gridSize={2}
              isEdit={isEdit}
              onChange={changeHandler}
              sectionData={additiveDetails}
              noTitle={true}
            />
            <InformationTabSection
              excelHeader={excelHeader}
              handleExcelClick={handleExcelClick}
              materialExcelList={byProductMaterialExcelList}
              clearExcelState={clearExcelState}
              gridSize={2}
              isEdit={isEdit}
              onChange={changeHandler}
              title={t('masterData.sharedMasterDataTexts.additionalInformation')}
              sectionData={otherInformation}
              handleEffectiveDateChange={handleEffectiveDateChange}
              dateState={byProductsData?.effective_date}
              excelTitle='ByProducts'
            />
          </>
        </InformationTab>
      </form>
      <AlertModal
        showModal={showUpdatePrompt}
        title={t('masterData.sharedMasterDataTexts.confirmPlantChanges')}
        content={t('masterData.sharedMasterDataTexts.MaterialInfoExistsOverridePrompt')}
        confirmButtonText={t('sharedTexts.proceed')}
        onConfirmClick={() => handlePromptConfirm()}
        closeModal={() => handlePromptCancel()}
      />
    </>
  ) : (
    <Loading />
  );
};

export default FurnaceMaterial;
