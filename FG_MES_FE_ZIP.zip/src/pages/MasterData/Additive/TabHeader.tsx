import { FC, useEffect, useState } from 'react';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import DashboardAddtivieHeader from 'components/DashboardHeader';
import AdditiveMaintenance from './AdditiveMaintence';
import { paths } from 'routes/paths';
import { useAppDispatch } from 'store';
import MainTab from 'components/common/MainTab';
import MasterDataSpecification from 'components/common/MasterDataSpecification';
import {
  editAdditiveSpecificationDetails,
  getAdditiveSpecificationDetails,
} from 'store/slices/furnaceMaterialSlice';
import { notify } from 'utils/utils';
import Loading from 'components/common/Loading';
import { useTranslation } from 'react-i18next';
type Tabs = {
  label: string;
  value: number;
};
const TabHeader: FC = () => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const location = useLocation();
  const { t } = useTranslation();
  const url = new URL(window.location.href);
  const queryParams = new URLSearchParams(url.search);
  const editValue = queryParams.get('edit');
  const { id }: any = useParams();
  const viewOnly = queryParams.get('view');
  const isActive = queryParams.get('isActive');
  const [changeLogData, setChangeLogData] = useState<any>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const tabs: Tabs[] = [
    { label: t('masterData.sharedMasterDataTexts.materialInformation'), value: 1 },
    { label: t('masterData.sharedMasterDataTexts.materialSpecification'), value: 2 },
  ];
  const [status, setStatus] = useState<boolean>(false);
  const [changeHistoryData, setChangeHistoryData] = useState<any>([]);
  const [sizesChangeHistoryData, setSizesChangeHistoryData] = useState<any>([]);
  const [activeTab, setActiveTab] = useState<number>(tabs[0].value);
  const [materialNo, setMaterialNo] = useState(0);
  const editMode = editValue == 'true' && viewOnly == 'false';
  const [isNextTabAllowed, setIsNextTabAllowed] = useState(true);

  const handleBackClick = () => {
    navigate(`${paths.additiveMaintenance.list}`);
  };

  useEffect(() => {
    if (location.pathname === paths.additiveMaintenance.analysisValue && activeTab !== 2) {
      navigate(`${paths.additiveMaintenance.list}`);
    }
  }, [location]);

  const [data, setData] = useState<any>([
    {
      title: t('masterData.sharedMasterDataTexts.chemistryValues'),
      list: [],
      type: 'Chemistry Values',
      accordion: false,
      showWarningToleranceOnTable: false, //UI table extra columns
    },
    {
      title: t('masterData.sharedMasterDataTexts.physicalElements'),
      list: [],
      type: 'Physical Values',
      accordion: false,
      showWarningToleranceOnTable: false, //UI table extra columns
    },
  ]);

  const fetchData = async () => {
    setLoading(true);
    const resp = await dispatch(getAdditiveSpecificationDetails(id));
    const changeHistoryData = resp.payload.data.data.changeHistoryData;
    setData((prevData: any) => {
      const updatedData = prevData.map((item: any) => {
        if (item.type === 'Chemistry Values') {
          return { ...item, list: resp?.payload?.data?.data?.chemistry_values };
        } else if (item.type === 'Physical Values') {
          return { ...item, list: resp?.payload?.data?.data?.physical_elements };
        } else {
          return item;
        }
      });
      return updatedData;
    });
    // setSelectedUnit(resp.data.sizes.unit)
    setChangeLogData(changeHistoryData);
    setLoading(false);
  };

  useEffect(() => {
    activeTab === 2 && fetchData();
  }, [activeTab]);

  useEffect(() => {
    if (!status && activeTab === 2) {
      navigate(`${paths.additiveMaintenance.create}/${id}`);
    }
  }, [status, activeTab]);

  const onSave = async () => {
    try {
      setLoading(true);
      const merged = {
        change_logs_elements: changeHistoryData,
        change_logs_sizes: sizesChangeHistoryData[0],
      };
      !changeHistoryData?.length && delete merged.change_logs_elements;
      const payload: any = {
        chemistry_values: data[0]?.list || [],
        physical_elements: data[1]?.list || [],
        changeHistoryData: merged,
      };
      if (!sizesChangeHistoryData[0] && !changeHistoryData?.length) {
        delete payload.changeHistoryData;
      }

      const response = await dispatch(
        editAdditiveSpecificationDetails({ body: payload, id: id || null })
      );
      setChangeHistoryData([]);
      setSizesChangeHistoryData([]);

      if (response.payload.status >= 200 && response.payload.status < 300) {
        setLoading(false);
        notify('success', t(response?.payload?.data?.message));
        navigate(`${paths.additiveMaintenance.view}/${id}`);
      } else {
        setLoading(false);
      }
    } finally {
      setLoading(false);
    }
    fetchData();
  };

  return (
    <>
      <DashboardAddtivieHeader
        title={`${materialNo}`}
        onBackClick={handleBackClick}
        isActive={!(activeTab === 1 && isActive === 'false')}
      />

      <div className='dashboard__main__body px-8 py-6'>
        <div className='card-box'>
          <div className={`${!editMode ? 'tab - wrapper' : ''}`}>
            <MainTab
              editMode={editMode}
              tabs={tabs}
              setActiveTab={setActiveTab}
              activeTab={activeTab}
              isNextTabAllowed={isNextTabAllowed}
            />
            {activeTab === 1 ? (
              <div>
                <AdditiveMaintenance
                  getMaterailNum={(materailNum): any => {
                    setMaterialNo(materailNum);
                  }}
                  changeTab={setIsNextTabAllowed}
                  setStatus={setStatus}
                />
              </div>
            ) : (
              <div className=' px-6 pt-4 pb-16'>
                {!data[0]?.list?.length && !loading ? (
                  <div className='text-center p-4'>{t('sharedTexts.noDataFound')}</div>
                ) : (
                  ''
                )}
                {loading ? <Loading /> : ''}
                {!loading && data[0]?.list?.length ? (
                  <div className=' px-6 pt-4 pb-16'>
                    <MasterDataSpecification
                      sizesChangeHistoryData={sizesChangeHistoryData}
                      setSizesChangeHistoryData={setSizesChangeHistoryData}
                      apiData={data}
                      onSave={onSave}
                      setChangeHistoryData={setChangeHistoryData}
                      changeHistoryData={changeHistoryData}
                      changeHistoryInputData={changeLogData}
                      warningTolerance={false} //for component btn handling and Change History table extra column
                      setData={setData}
                      materialId={id}
                      excelTitle={t('masterData.additives.additive')}
                    />
                  </div>
                ) : (
                  ''
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
};
export default TabHeader;
