import { FC, useEffect, useState } from 'react';
import '../../../assets/styles/scss/pages/dashboard.scss';
import '../../../assets/styles/scss/components/table-general.scss';
import { useAppDispatch } from 'store';
import Header from '../../../components/common/MainHeader';
import Loading from 'components/common/Loading';
import ListingTable from 'components/common/ListingTable';
import Pagination from 'components/common/PaginationAPI';
import httpClient from 'http/httpClient';
import { useNavigate } from 'react-router-dom';
import { paths } from 'routes/paths';
import AlertModal from 'components/Modal/AlertModal';
import { notify } from 'utils/utils';
import { getAdditiveList } from 'store/slices/additiveSlice';
import _ from 'lodash';
import { getMaterialTypes } from 'store/slices/furnaceMaterialSlice';
import { useTranslation } from 'react-i18next';

interface GetList {
  page_size: number;
  material_no: string;
  page: number;
  status: boolean | string;
  material_name: string;
  sort_by_type: string;
  sort_by: string;
  filter_by_type: number[];
}

interface Sort {
  search: string;
  material_name: string;
  is_active: boolean;
  ordering: string;
  page: number;
  sort_type: string;
}

const AdditiveMaintenance: FC = () => {
  //Constants
  const dispatch = useAppDispatch();
  const { t } = useTranslation();
  //States
  const navigate = useNavigate();
  const [currentPage, setCurrentPage] = useState(1);
  const [searchValue, setSearchValue] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const itemsPerPage = 10;
  const [count, setCount] = useState(5);
  const [previous, setPrevious] = useState(false);
  const [next, setNext] = useState(false);
  const [reset, setReset] = useState<boolean>(false);
  const [deleteModal, setDeleteModal] = useState<boolean>(false);
  const [modalTitle, setModalTitle] = useState('');
  const [modalContent, setModalContent] = useState('');
  const [list, setList] = useState([]);
  const [statusId, setStatusId] = useState<number>(0);

  const [selectedTypesInFilter, setSelectedTypesInFilter] = useState<any[]>([]);
  const [materialTypes, setMaterialTypes] = useState<any[]>([]);

  //methods

  const [inputData, setInputData] = useState<GetList>({
    page_size: itemsPerPage,
    material_no: searchValue,
    page: 1,
    status: '',
    material_name: '',
    sort_by_type: '',
    sort_by: '',
    filter_by_type: [],
  });

  const updateStates = (response: any) => {
    setList(response);
    setLoading(false);
  };

  const onSort_Filter = async (input: Sort) => {
    getList({
      ...inputData,
      status: input.is_active,
      material_name: input.material_name,
      page: 1,
      sort_by: input.sort_type == 'Descending' ? 'DESC' : 'ASC',
      sort_by_type: input.ordering,
      material_no: input.search,
      filter_by_type: selectedTypesInFilter.map((type) => type.id),
    });
    setInputData({
      ...inputData,
      status: input.is_active,
      material_name: input.material_name,
      page: 1,
      sort_by: input.sort_type == 'Descending' ? 'DESC' : 'ASC',
      sort_by_type: input.ordering,
      material_no: input.search,
      filter_by_type: selectedTypesInFilter.map((type) => type.id),
    });
  };

  const handleEditClick = (event: React.MouseEvent<HTMLAnchorElement, MouseEvent>, id: number) => {
    event.stopPropagation();

    const url = `${paths.additiveMaintenance.edit}/${id}`;

    navigate(url);
  };

  const handleViewClick = (event: React.MouseEvent<HTMLAnchorElement, MouseEvent>, id: number) => {
    event.stopPropagation();
    const url = `${paths.additiveMaintenance.view}/${id}`;
    navigate(url);
  };

  const handleCreateClick = (id: number) => {
    const url = `${paths.additiveMaintenance.create}/${id}`;
    navigate(url);
  };

  const handleOnchangeStatus = (id: number, role: string, materialNo: string) => {
    setStatusId(id);
    setDeleteModal(true);
    if (role == 'Activate') {
      setModalContent(`${t('masterData.additives.doYouWantToActivateTheAdditive')} ${materialNo}?`);
      setModalTitle(t('sharedTexts.message'));
    } else {
      setModalContent(
        `${t('masterData.additives.doYouWantToDeactivateTheAdditive')} ${materialNo}?`
      );
      setModalTitle(t('sharedTexts.message'));
    }
  };

  const statusChangeAPI = (id: number) => {
    setLoading(true);
    httpClient
      .patch(`/api/materials/${id}/`)
      .then((response: any) => {
        if (response.status === 200) {
          if (response.data) {
            setLoading(false);
            notify('success', t(response.data.message));
            setDeleteModal(false);
          }
        } else if (response.data?.error) {
          setLoading(false);
          setDeleteModal(false);
        }
        getList({ ...inputData, page: 1 });
        setInputData({ ...inputData, page: 1 });
      })
      .catch(() => {
        notify('error', t('masterData.additives.failedToChangeAdditiveStatus'));
        setDeleteModal(false);
      });
  };

  const handleStatusChange = () => {
    statusChangeAPI(statusId);
  };

  const handleCloseAlertModal = () => {
    setDeleteModal(false);
  };

  const onPageChange = (pageNumber: number) => {
    getList({ ...inputData, page: pageNumber });
    setInputData({ ...inputData, page: pageNumber });
    setCurrentPage(pageNumber);
  };

  const getList = async (input: GetList, skipPageReset?: boolean) => {
    const serializedTypeIds = input.filter_by_type.join(',');
    setLoading(true);
    if (!skipPageReset) setCurrentPage(1);
    const params = `category=Additives&material_no=${input.material_no || ''}&page=${
      input.page || ''
    }&status=${input.status}&material_name=${input.material_name || ''}&sort_by_type=${
      input.sort_by_type || ''
    }&sort_by=${input.sort_by || ''}&filter_by_type=${serializedTypeIds}`;

    const response = await dispatch(getAdditiveList(params));

    const data = response.payload.data;

    if (response.payload.status == 200) {
      setCount(data.count);
      setPrevious(!!data.previous);
      setNext(!!data.next);
      updateStates(data.results);
    }

    setLoading(false);
  };

  useEffect(() => {
    getList({ ...inputData, material_no: searchValue, page: 1 });
    setInputData({ ...inputData, material_no: searchValue, page: 1 });
    setCurrentPage(1);
    fetchMaterialTypes();
  }, [searchValue, reset]);

  const tableHeader = [
    {
      key: 'mes_mat_code',
      header: t('masterData.sharedMasterDataTexts.mesMaterialCode'),
      sortEnabled: true,
    },
    {
      key: 'material_name',
      header: t('masterData.sharedMasterDataTexts.materialName'),
      sortEnabled: true,
    },
    { key: 'created_at', header: t('sharedTexts.dateCreated'), sortEnabled: true },
    { key: 'record_status', header: t('sharedTexts.status'), sortEnabled: true },
  ];

  // type code

  const handleTypeCheckboxChange = (typeObject: any) => {
    const index = _.findIndex(selectedTypesInFilter, (obj) => obj.id === typeObject.id);

    if (index === -1) {
      // Object doesn't exist in the array, so add it
      setSelectedTypesInFilter([...selectedTypesInFilter, typeObject]);
    } else {
      // Object exists in the array, so remove it
      setSelectedTypesInFilter(_.filter(selectedTypesInFilter, (obj) => obj.id !== typeObject.id));
    }
  };

  const isCheckedOfTypeFilter = (typeObject: any) => {
    return _.some(selectedTypesInFilter, (obj) => obj.id === typeObject.id);
  };
  const hasTypesSelected = (): boolean => selectedTypesInFilter.length > 0;

  const fetchMaterialTypes = async () => {
    try {
      // Dispatch the thunk action to fetch material types
      const response = await dispatch(getMaterialTypes({ category: 'Additives' }));
      const { data: typesData = [] } = response.payload;
      setMaterialTypes(typesData);
    } catch (error) {
      // Handle any errors that occur during the dispatch
      console.error('Error fetching material types:', error);
    }
  };
  // type code end

  const onSortIconClick = (columnName: string, sortBy: string) => {
    const paramsToPass = {
      ...inputData,
      sort_by: sortBy,
      sort_by_type: columnName,
    };
    getList(paramsToPass, true); // second param skips the page reset
    setInputData(paramsToPass);
  };

  return (
    <>
      {loading && <Loading />}
      <Header
        title={t('plantModulesAndFunctions.ADD_MNT')}
        onSearchChange={(value) => {
          setSearchValue(value || '');
        }}
        placeholder={t('masterData.furnaceMaterials.searchByMesCode')}
        hasTypesSelected={hasTypesSelected}
        handleTypeCheckboxChange={handleTypeCheckboxChange}
        isCheckedOfTypeFilter={isCheckedOfTypeFilter}
        showTypeFilter
        typesData={materialTypes}
        sort_filter_click={(inputValue: any) => onSort_Filter(inputValue)}
        onReset={() => {
          setInputData({
            ...inputData,
            page_size: itemsPerPage,
            material_no: '',
            page: 1,
            status: '',
            material_name: '',
            sort_by_type: '',
            sort_by: '',
            filter_by_type: [],
          });
          setReset(!reset);
        }}
      />
      <div className='dashboard__main__body pb-3' style={{ overflow: 'auto' }}>
        {list?.length > 0 ? (
          <ListingTable
            tableBody={list}
            handleOnchangeStatus={handleOnchangeStatus}
            tableHeader={tableHeader}
            loading={loading}
            handleTableRowClick={() => {}}
            handleEditClick={handleEditClick}
            handleViewClick={handleViewClick}
            handleCreateClick={handleCreateClick}
            sortHandler={onSortIconClick}
            triggeredReset={reset}
          />
        ) : (
          <div style={{ textAlign: 'center', padding: '50px 20px' }}>
            {t('sharedTexts.noRecordsFound')}
          </div>
        )}

        <div className='px-4'>
          <Pagination
            totalItems={count}
            itemsPerPage={itemsPerPage}
            onPageChange={onPageChange}
            currentPage={currentPage}
            previous={previous}
            next={next}
          />
        </div>
      </div>

      <AlertModal
        showModal={deleteModal}
        title={modalTitle}
        content={modalContent}
        confirmButtonText={t('sharedTexts.proceed')}
        // onConfirmClick={handleDeleteRole}
        onConfirmClick={handleStatusChange}
        // closeModal={handleCloseDeleteModal}
        closeModal={handleCloseAlertModal}
      />
    </>
  );
};

export default AdditiveMaintenance;
