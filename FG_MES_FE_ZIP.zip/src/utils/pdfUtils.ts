import jsPDF from 'jspdf';
import * as htmlToImage from 'html-to-image';

const fontSize: number = 10;

export async function exportMultipleChartsToPdf(
  className: string,
  filterCriteria: any,
  actionType: any,
  t: any
): Promise<any> {
  const doc = new jsPDF('p', 'px'); // (1)

  const elements = document.getElementsByClassName(className); // (2)

  buildFieldData(filterCriteria, doc);
  await creatPdf({ doc, elements }); // (3-5)

  if ('exportPDF' === actionType) {
    const fileName = getFileNamePrefix(className, t);
    const currentDate = new Date();
    let timestamp =
      currentDate.getDate() +
      '-' +
      (currentDate.getMonth() + 1) +
      '-' +
      currentDate.getFullYear() +
      '_' +
      currentDate.getHours() +
      ':' +
      currentDate.getMinutes() +
      ':' +
      currentDate.getSeconds();

    doc.save(`${fileName}_${timestamp}.pdf`);
  } else {
    window.open(doc.output('bloburl'));
  }

  return true;
}
function getFileNamePrefix(className: string, t: any): string {
  return 'analysis-graph' === className
    ? t('reports.analysisReport')
    : t('reports.consumptionReport');
}
function buildFieldData(filterCriteria: any, doc: jsPDF) {
  doc.setFontSize(fontSize).text(`Material Category: ${filterCriteria.materialCategory}`, 12, 25);
  if (filterCriteria.materialType) {
    doc.setFontSize(fontSize).text(`Material Type: ${filterCriteria.materialType}`, 180, 25);
    doc.setFontSize(fontSize).text(`Granularity: ${filterCriteria.granularity}`, 300, 25);
  } else {
    doc.setFontSize(fontSize).text(`Granularity: ${filterCriteria.granularity}`, 180, 25);
  }
  doc.setFontSize(fontSize).text(`Start Date: ${filterCriteria.startDate}`, 12, 40);
  doc.setFontSize(fontSize).text(`End Date: ${filterCriteria.endDate}`, 180, 40);
}
async function creatPdf({ doc, elements }: { doc: jsPDF; elements: HTMLCollectionOf<Element> }) {
  let top = 40;
  let padding = 10;

  for (let i = 0; i < elements.length; i++) {
    const el = elements.item(i) as HTMLElement;
    const imgData = await htmlToImage.toPng(el);

    let elHeight = el.offsetHeight;
    let elWidth = el.offsetWidth;
    let heightLeft = elHeight;
    const pageWidth = doc.internal.pageSize.getWidth();

    if (elWidth > pageWidth) {
      const ratio = pageWidth / elWidth;
      elHeight = elHeight * ratio - padding;
      elWidth = elWidth * ratio - padding;
    }

    const pageHeight = doc.internal.pageSize.getHeight();
    top += elHeight;

    heightLeft -= pageHeight;

    while (heightLeft >= 0) {
      padding = heightLeft - elHeight;
      if (elHeight > padding) {
        doc.addImage(imgData, 'PNG', 10, padding, elWidth, elHeight + 15);
        doc.addPage();
      }
      heightLeft -= pageHeight;
    }
  }
}
