type PermissionsMapper = {
  'user-access-control': string;
  users: string;
  roles: string;
  [key: string]: string;
};

export const uniqueCodesMapper = {
  userAccessControlModule: 'USRCTRL',
  masterDataModule: 'MSTRDATA',
  coreProcessModule: 'COREPROC',
  labAnalysisModule: 'LABANLYS',
  reportsModule: 'REPORTS',
  systemAdminModule: 'SYSADMN',
  logBookModule: 'LOGBOOK',
  usersFunction: 'USERS',
  rolesFunction: 'ROLES',
  plantConfigFunction: 'PLT_CFG',
  furnaceConfigFunction: 'FUR_CFG',
  furnaceRawMaterialFunction: 'FUR_MNT',
  additivesFunction: 'ADD_MNT',
  byProductsFunction: 'BY_PROD',
  wipFunction: 'WIP_MNT',
  materialAnalysisReportFunction: 'MAT_ANA',
  materialConsumptionReportFunction: 'MAT_CON',
  materialSizeReportFunction: 'MAT_SZE',
  furnaceBedLogFunction: 'FUR_BED',
  tapHoleLogFunction: 'TAP_LOG',
  furnaceDowntimeLogFunction: 'DWN_LOG',
  furnaceDowntimeLogEventFunction: 'DWN_EVT',
  furnaceDowntimeLogSplitFunction: 'DWN_SPLT',
  compositeElectrode: 'COMP_EL',
  preBakedElectrode: 'BAKE_EL',
  soderbergElectrode: 'SODER_EL',
  dcFurnaceElectrode: 'DCFUR_EL',
};

export const subModuleConfigs = {
  MSTRDATA: {
    'Material Maintenance': ['ADD_MNT', 'BY_PROD', 'FUR_MNT', 'WIP_MNT'],
  },
};

export const permissionsMapper: PermissionsMapper = {
  //user-access-control
  'user-access-control': uniqueCodesMapper.userAccessControlModule,
  users: uniqueCodesMapper.usersFunction,
  roles: uniqueCodesMapper.rolesFunction,

  //master-data
  'master-data': uniqueCodesMapper.masterDataModule,
  // 'dashboard-material-maintenance': 'Material Maintenance',
  'material-maintenance': 'Material Maintenance',
  'additive-maintenance': uniqueCodesMapper.additivesFunction,
  'standard-bom': 'Standard BOM',
  'customer-specification': 'Customer Specifications',
  'active-furnace': 'Active Furnace List',
  'furnace-material-maintenance': uniqueCodesMapper.furnaceRawMaterialFunction,
  'wip-maintenance': uniqueCodesMapper.wipFunction,
  'by-products': uniqueCodesMapper.byProductsFunction,

  //core-process
  'core-process': uniqueCodesMapper.coreProcessModule,
  'log-book': uniqueCodesMapper.logBookModule,
  'production-schedule': 'Production Schedule',
  'silicon-grade-material-maintenance': 'Silicon Grade Material Maintenance',
  'bin-contents': 'Bin Contents',
  'furnace-bed-log': uniqueCodesMapper.furnaceBedLogFunction,
  'tap-hole-log': uniqueCodesMapper.tapHoleLogFunction,
  'furnace-downtime-log': uniqueCodesMapper.furnaceDowntimeLogFunction,

  //system Admin
  'system-admin': uniqueCodesMapper.systemAdminModule,
  'plant-configuration': uniqueCodesMapper.plantConfigFunction,
  'furnace-configuration': uniqueCodesMapper.furnaceConfigFunction,
};

export enum crudType {
  view = 'view',
  create = 'create',
  edit = 'edit',
  delete = 'delete',
}

export const plantConfigFunctions = {
  plantConfigFunction: uniqueCodesMapper.plantConfigFunction,
  furnaceConfigFunction: uniqueCodesMapper.furnaceConfigFunction,
  roles: uniqueCodesMapper.rolesFunction,
  users: uniqueCodesMapper.usersFunction,
};

export const plantConfigModules = {
  systemAdmin: uniqueCodesMapper.systemAdminModule,
  userAccessControl: uniqueCodesMapper.userAccessControlModule,
};

// radio options - furnace bed log
export const furnaceBedRadioOptions = [
  {
    fieldLabel: 'Auto Collapse',
    radioOptions: ['Yes', 'No'],
    payloadKey: 'auto_collapse',
    required: false,
  },
  {
    fieldLabel: 'Electrode - Auto lining Wideness*',
    radioOptions: ['Wide', 'Narrow'],
    payloadKey: 'electrode_auto_lining_wideness',
    required: true,
  },
  {
    fieldLabel: 'Noise When Collapsing*',
    radioOptions: ['Roaring', 'No Noise'],
    payloadKey: 'noise_when_collapsing',
    required: true,
  },
  {
    fieldLabel: 'Electrode blows Direction*',
    radioOptions: ['Verticle', 'Angle'],
    payloadKey: 'electrode_blows_direction',
    required: true,
  },
  {
    fieldLabel: 'Electrode Crust Formation*',
    radioOptions: ['Yes', 'No'],
    payloadKey: 'electrode_crust_formation',
    required: true,
  },
  {
    fieldLabel: 'Bed Conditions*',
    radioOptions: ['Soft', 'Gummy', 'Hard'],
    payloadKey: 'bed_conditions',
    required: true,
  },
  {
    fieldLabel: 'Activity HomoGeneity',
    radioOptions: ['Even', 'Centre', 'Electrode 1', 'Electrode 2', 'Electrode 3'],
    payloadKey: 'activity_homogeneity',
    required: false,
  },
];

export const tapHoleRadioOptions = [
  {
    fieldLabel: 'Flame*',
    radioOptions: ['Yes', 'No'],
    payloadKey: 'flame',
    required: true,
  },
  {
    fieldLabel: 'Flame Color*',
    radioOptions: ['White', 'Red'],
    payloadKey: 'flame_color',
    required: true,
  },
  {
    fieldLabel: 'Tap Hole Bottom*',
    radioOptions: ['Hard', 'Soft'],
    payloadKey: 'tap_hole_bottom',
    required: true,
  },
  {
    fieldLabel: 'Metal Output*',
    radioOptions: ['Bottom', 'Top'],
    payloadKey: 'metal_output',
    required: true,
  },
  {
    fieldLabel: 'Furnace Tapping*',
    radioOptions: ['Easy', 'Intermediate', 'Difficult'],
    payloadKey: 'furnace_tapping',
    required: true,
  },
  {
    fieldLabel: 'Slag*',
    radioOptions: ['Sticky', 'Normal', 'Lumpy'],
    payloadKey: 'slag',
    required: true,
  },
  {
    fieldLabel: 'Flame intensity*',
    radioOptions: ['None', 'Light', 'Medium', 'Heavy'],
    payloadKey: 'activity_homogeneity',
    required: true,
  },
];

export const coreProcessSelect = { option: 'Select Furnace No', value: 'Select' };

export const sourceDataList = [
  {
    id: '1',
    value: 'Manual',
  },
  {
    id: '2',
    value: 'Automatic',
  },
];
export const Languages = [
  { label: 'English', code: 'en' },
  { label: 'French', code: 'fr' },
  { label: 'Spanish', code: 'es' },
];

export const logBook = {
  furnaceBed: 'furnaceBed',
  tapHole: 'tapHole',
};

// fields with translations in filter tiles are defined here
export const filterFieldTranslationKeyPrefix = {
  Equipment: 'logBook.furnaceDownTimeLog.',
  // Status: 'sharedTexts.',
  'Downtime Type': 'logBook.furnaceDownTimeLog.',
  Reason: 'logBook.furnaceDownTimeLog.',
};
export type FilterFieldKeys = keyof typeof filterFieldTranslationKeyPrefix;

export const masterCategories = {
  electrodeCategory: 'ELECTRODES',
  coreCategory: 'CORE',
  casingCategory: 'CASING',
  pasteCategory: 'PASTE',
};

export const furnaceElectrodeNames = ['E1', 'E2', 'E3'];
export const dcFurnaceElectrodeNames = ['E1'];

export const fieldNames = {
  electrodeDiameter: 'Electrode diameter',
  coreMassPerLength: 'Core Mass/Length',
  casingMassPerLength: 'Casing Mass/Length',
  pasteMassPerLength: 'Paste Mass/Length',
  energyLosses: 'Energy Losses',
  jouleLossesCoefficient: 'Joule Losses Coefficient',
  defaultEpiIndex: 'Default EPI Index',
  correctedReactanceCoefficient: 'Corrected Reactance Coefficient',
  designMW: 'Design MW',
  fixedCost: 'Fixed Cost',
  targetEnergyEfficiency: 'Target Energy Efficiency',
  targetCostBudget: 'Target Cost Budget',
  targetAvailability: 'Target Availability',
  targetFurnaceLoad: 'Target Furnace Load',
  crucibleDiameter: 'Crucible Diameter',
  crucibleDepth: 'Crucible Depth',
  pcdTheoretical: 'PCD Theoretical',
  pcdActual: 'PCD Actual',
  defaultMoisture: 'Default Moisture',
};

export const furnaceElectrodeFieldRefs = {
  electrodeDiameter: 'diameter',
};

export const furnaceConfigTabs = {
  basicInfo: 1,
  electrodes: 2,
  parameters: 3,
  refiningSteps: 4,
};

export const globalString = {
  currency: 'currency',
};

export const elementNames = {
  fixedCarbon: 'Fixed Carbon (%)',
  yieldUsefulCarbon: 'C yield UC/FC (%)',
  usefulCarbon: 'Useful Carbon (%)',
};

export const usefulCarbonDependencyFields = [
  elementNames.fixedCarbon,
  elementNames.yieldUsefulCarbon,
];

export const autoCalculatedFields = [elementNames.usefulCarbon];
