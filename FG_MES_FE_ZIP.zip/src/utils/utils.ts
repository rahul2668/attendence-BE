import { Theme, ToastOptions, toast } from 'react-toastify';
import { crudType, permissionsMapper } from './constants';
import moment, { Moment } from 'moment';
import dayjs, { Dayjs } from 'dayjs';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import { jwtDecode } from 'jwt-decode';
import { CustomJwtPayload } from 'types/auth.model';
import { UtilsMasterData } from 'types/plant.model';

dayjs.extend(utc);
dayjs.extend(timezone);

export const isEmpty = (val: any) => {
  /*
  test results
  --------------
  []        true, empty array
  {}        true, empty object
  null      true
  undefined true
  ""        true, empty string
  ''        true, empty string
  0         false, number
  true      false, boolean
  false     false, boolean
  Date      false
  function  false
  */
  if (val === undefined) return true;

  if (
    typeof val === 'function' ||
    typeof val === 'number' ||
    typeof val === 'boolean' ||
    Object.prototype.toString.call(val) === '[object Date]'
  )
    return false;

  if (val == null || val.length === 0)
    // null or 0 length array
    return true;

  if (typeof val == 'object') if (Object.keys(val).length === 0) return true;

  if (typeof val === 'string') if (val.trim() === '') return true;

  return false;
};

export const getNameInitial = (text: string | null | undefined, singleChar: boolean) => {
  const name = text === '' || text === null || !text ? 'NA' : text.split(' ');
  if (isEmpty(text)) {
    return 'NA';
  }
  const [firstName, lastName] = name;
  if (isEmpty(firstName) && isEmpty(lastName)) {
    return 'NA';
  }
  if (isEmpty(firstName) && !isEmpty(lastName)) {
    return `${lastName[0].toUpperCase()}`;
  }
  if (firstName && lastName) {
    const name = `${firstName[0].toUpperCase()}${lastName[0].toUpperCase()}`;
    if (singleChar) return `${firstName[0].toUpperCase()}`;
    return name;
  } else {
    return `${firstName[0].toUpperCase()}`;
  }
};

export const setLocalStorage = (key: string, value: string) => {
  window.localStorage.setItem(key, JSON.stringify(value));
};

export const getLocalStorage = (key: string) => {
  const value: any = window.localStorage.getItem(key);
  return !isEmpty(value) ? JSON.parse(value) : null;
};

export const clearLocalStorage = (key: Array<string>) => {
  key.forEach((item) => window.localStorage.removeItem(item));
};

export const setSessionStorage = (key: string, value: string) => {
  window.sessionStorage.setItem(key, JSON.stringify(value));
};

export const getSessionStorage = (key: string) => {
  const value: any = window.sessionStorage.getItem(key);
  return !isEmpty(value) ? JSON.parse(value) : null;
};

export const clearSessionStorage = (key: Array<string>) => {
  key.forEach((item) => window.sessionStorage.removeItem(item));
};

export const notify = (type: 'success' | 'warning' | 'info' | 'error', message: string) => {
  const options: ToastOptions<Theme> = {
    position: 'top-right',
    autoClose: 10000,
    theme: 'colored',
  };

  if (type === 'success') {
    toast.success(message, options);
  } else if (type === 'warning') {
    toast.warning(message, options);
  } else if (type === 'info') {
    toast.info(message, options);
  } else if (type === 'error') {
    toast.error(message, options);
  }
  // } else {
  //   toast.error(message, options);
  // }
};

export const preventArrowBehavior = (e: any, data: any) => {
  if (
    e.keyCode === 40 ||
    e.keyCode === 38 ||
    (data.type === 'number' &&
      (e.key === 'e' || e.key === 'E' || e.key === '-' || e.key === '+')) ||
    (data === 'number' && (e.key === 'e' || e.key === 'E' || e.key === '-' || e.key === '+'))
  ) {
    e.preventDefault();
    return;
  }
};

export const debounce = (cb: any, d: any) => {
  let timer: any;
  return function (...args: any) {
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => {
      cb(...args);
    }, d);
  };
};

export const validatePermissionList = (permissions: any) => {
  for (const category in permissions) {
    const functions = permissions[category];
    for (const func in functions) {
      if (functions[func].view) {
        return true;
      }
    }
  }
  return false;
};

export const validatePermissions = (module: string, subModule: string, type: string) => {
  const token: any = sessionStorage.getItem('accessToken');
  const decoded: CustomJwtPayload | null = token ? jwtDecode(token) : null;
  const userInfo: any = decoded?.user_data;
  if (userInfo) {
    const { permission_list: permissions } = userInfo;
    try {
      return permissions[module][subModule][type];
    } catch (error) {
      return false;
    }
  }
};

export const hasPermission = (path: string) => {
  const module = path?.split('/')[1];
  const subModule = path?.split('/')[2];
  if (module && subModule)
    return validatePermissions(
      permissionsMapper[module],
      permissionsMapper[subModule],
      crudType.view
    );
};

export const validateElementValues = (elementList: Array<any>) => {
  const errors = elementList.reduce((errorRows, element) => {
    const elementName = element.element;

    if (
      Number(element.low) > Number(element.high) ||
      Number(element.low) > Number(element.aim) ||
      Number(element.high) < Number(element.low) ||
      Number(element.high) < Number(element.aim) ||
      Number(element.aim) < Number(element.low) ||
      Number(element.aim) > Number(element.high)
    ) {
      errorRows.push(elementName);
    }
    return errorRows;
  }, [] as string[]);
  return errors;
};

const numberConversion = (dropdownList: any, elementData: any, type: string) => {
  const value = Number(
    dropdownList?.filter((item: any) => item.value == elementData[type])[0]?.option.split(' ')[0]
  );

  return Number.isNaN(value) ? 0 : value;
};

export const validateSizeElementValues = (elementList: Array<any>, dropdownList: any) => {
  const errors = elementList.reduce((errorRows, element) => {
    const elementName = 'Sizes';
    if (dropdownList.length > 0) {
      if (
        numberConversion(dropdownList, element, 'low_size') >
          numberConversion(dropdownList, element, 'high_size') ||
        numberConversion(dropdownList, element, 'high_size') <
          numberConversion(dropdownList, element, 'low_size')
      ) {
        errorRows.push(elementName);
      }
    }
    return errorRows;
  }, [] as string[]);
  return errors;
};

export const getCommaSeparatedRoles = (rolesArr: any) => {
  const roleNames = rolesArr?.map((role: any) => role.role_name);
  const roles: string = roleNames?.join(', ');

  return roles;
};

export const validateLowAimHigh = (
  property: string,
  value: number,
  elementData: any,
  elementName: string,
  t: any,
  type?: string
) => {
  let error = '';

  if (type === 'Sizes') {
    if (property === 'low') {
      if (value > elementData.high)
        error = `${elementName} : ${t('masterData.sharedMasterDataTexts.lowShouldBeLessThanHigh')}`;
    } else if (property === 'high') {
      if (value < elementData.low)
        error = `${elementName} : ${t('masterData.sharedMasterDataTexts.highShouldBeGreaterThanLow')}`;
    }
    return error;
  }
  if (property === 'low') {
    if (!(value < elementData.high && value <= elementData.aim))
      error = `${elementName} : ${t('masterData.sharedMasterDataTexts.low')} <= ${t('masterData.sharedMasterDataTexts.aim')} <= ${t('masterData.sharedMasterDataTexts.high')}`;
  } else if (property === 'high') {
    if (!(value >= elementData.low && value >= elementData.aim))
      error = `${elementName} : ${t('masterData.sharedMasterDataTexts.low')} <= ${t('masterData.sharedMasterDataTexts.aim')} <= ${t('masterData.sharedMasterDataTexts.high')}`;
  } else if (property === 'aim') {
    if (!(value >= elementData.low && value <= elementData.high))
      error = `${elementName} : ${t('masterData.sharedMasterDataTexts.low')} <= ${t('masterData.sharedMasterDataTexts.aim')} <= ${t('masterData.sharedMasterDataTexts.high')}`;
  }
  return error;
};

export const validateSizeLowAimHigh = (
  property: string,
  value: number,
  elementData: any,
  elementName: string,
  t: any,
  dropdownList: any,
  type?: string
) => {
  let error = '';

  if (type === 'Sizes') {
    if (property === 'low_size') {
      if (value > numberConversion(dropdownList, elementData, 'high_size')) {
        error = `${elementName} : ${t('masterData.sharedMasterDataTexts.lowShouldBeLessThanHigh')}`;
      }
    } else if (property === 'high_size') {
      if (value < numberConversion(dropdownList, elementData, 'low_size')) {
        error = `${elementName} : ${t('masterData.sharedMasterDataTexts.highShouldBeGreaterThanLow')}`;
      }
    }
    return error;
  }

  return error;
};

export const isUserFormFilled = (formData: any) => {
  for (const key in formData) {
    if (formData.hasOwnProperty(key)) {
      if (Array.isArray(formData[key]) && formData[key].length === 0) {
        return false;
      } else if (formData[key] === '') {
        return false;
      }
    }
  }
  return true;
};

export const isNumber = (value: number) => !isNaN(Number(value));

export const deepClone = (data: any) => JSON.parse(JSON.stringify(data));

export const getStatusId = (status: Array<string>) => {
  const statusInfo = [
    { id: '1', name: 'Scheduled' },
    { id: '2', name: 'Begin' },
    { id: '3', name: 'Hold' },
    { id: '4', name: 'Completed' },
  ];
  const result = statusInfo.filter((o1) => status.some((o2) => o1.name === o2));
  return result.map((res) => res.id);
};

export const hasErrors = (errorObject: any) => {
  return Object.values(errorObject).some((error) => error !== '');
};

export const checkData = (data: any) => {
  const allEmpty = data.every((item: Object) => {
    // Check if the value is an array and is empty
    if (Array.isArray(Object.values(item)[0])) {
      return Object.values(item)[0].length === 0;
    }

    // Check if the value is an object and is empty
    if (typeof Object.values(item)[0] === 'object' && Object.values(item)[0] !== null) {
      return Object.keys(Object.values(item)[0]).length === 0;
    }

    // Default case: return false for non-array and non-object values
    return false;
  });
  return allEmpty;
};

export const getFormattedDate = (date: any) => {
  const year = date.getFullYear();

  let month = (1 + date.getMonth()).toString();
  month = month.length > 1 ? month : '0' + month;

  let day = date.getDate().toString();
  day = day.length > 1 ? day : '0' + day;

  return month + day + year;
};

export const isValidArray = (jsonArray: any) => {
  for (const obj of jsonArray) {
    if (typeof obj !== 'object' || obj === null) {
      return false;
    }

    for (const key of ['low', 'aim', 'high']) {
      if (!(key in obj) || obj[key] === null) {
        return false;
      }
    }
  }

  return true;
};

/**
 * @description Retrieves permissions for a given path.
 * @param path - The path for which permissions are requested.
 * @returns Object containing create, delete, edit, and view permissions.
 */
export const getPermissions = (path: string) => {
  // Split the path using '/' as the delimiter
  const pathParts = path.split('/');

  // Extract the modules & subModules based on their positions
  const module = pathParts[1];
  const subModule = pathParts[2];

  // check different permissions
  const canCreate =
    validatePermissions(permissionsMapper[module], permissionsMapper[subModule], crudType.create) ||
    false;
  const canDelete =
    validatePermissions(permissionsMapper[module], permissionsMapper[subModule], crudType.delete) ||
    false;
  const canEdit =
    validatePermissions(permissionsMapper[module], permissionsMapper[subModule], crudType.edit) ||
    false;
  const canView =
    validatePermissions(permissionsMapper[module], permissionsMapper[subModule], crudType.view) ||
    false;

  // return the permissions
  return { canCreate, canDelete, canEdit, canView };
};

/**
 * @description Formats a number with a dynamic number of decimal places.
 * @param value - The number to be formatted.
 * @param decimalPlaces - The desired number of decimal places.
 * @returns The formatted number as string to maintain trailing zeroes.
 */
export const formatValueOfElements = (value: number, decimalPlaces: number): string => {
  // Round the value to the specified number of decimal places
  const roundedValue = Number(value.toFixed(decimalPlaces));

  // Convert to string to add trailing zeros if necessary
  const formattedString = roundedValue.toFixed(decimalPlaces);

  return formattedString;
};
export const preventExponentialInputInNumber = (evt: any) => {
  ['e', 'E', '+', '-', '.'].includes(evt.key) && evt.preventDefault();
  if (evt.keyCode === 40 || evt.keyCode === 38) {
    evt.preventDefault();
  }
};

export function trimAndEllipsis(str: string, maxLength: number) {
  return str && str.length > maxLength ? `${str.substring(0, maxLength)}...` : str;
}

export function compareDates(date: { startDate?: Moment; endDate?: Moment }): string[] {
  let dateRange: string[] = [];
  let compareStartDate = moment(date?.startDate).format('YYYY-MM-DD');
  dateRange?.push(compareStartDate);
  let compareEndDate = moment(date?.endDate).format('YYYY-MM-DD');
  dateRange?.push(compareEndDate);
  return dateRange;
}

export const buildDropdownOptions = (data: any, category_id: any, category_name: any) => {
  let opitionvaluearray: { option: string; value: string }[] = [];
  if (category_id === 'material_id') {
    let options = {
      option: 'All',
      value: 'All',
    };
    opitionvaluearray.push(options);
  }
  data.forEach((element: any) => {
    const initial = {
      option: '',
      value: '',
    };

    initial.value = element[category_id];
    initial.option = element[category_name];
    opitionvaluearray.push(initial);
  });

  return opitionvaluearray;
};

export const buildMaterialIdCompareDropdown = (data: any, category_id: any, category_name: any) => {
  let opitionvaluearray: { option: string; value: string }[] = [];

  data.forEach((element: any) => {
    const initial = {
      option: '',
      value: '',
    };
    initial.value = element[category_id];
    initial.option = element[category_name];
    opitionvaluearray.push(initial);
  });
  return opitionvaluearray;
};

export const handleTimezone = (dateTime: string | Date | Dayjs | null, timeZone: string) => {
  return dayjs.utc(dateTime).tz(timeZone);
};

export const formatDateHelper = (dateTime: string, timeZone: string) => {
  const timeZonedDate = handleTimezone(dateTime, timeZone);
  const formattedDate = timeZonedDate.format('DD-MM-YYYY | hh:mm A');
  return dayjs(dateTime).isValid() ? formattedDate : '- -';
};

export const createOptionsByCategory = (masterData: any, category: any) => {
  return [...(masterData?.filter((val: any) => val?.category === category) || [])];
};

export const getMasterCodeById = (masterData: UtilsMasterData[], masterId: number) => {
  const masterInfo = masterData
    .filter((master) => {
      return master.id === masterId;
    })
    .map((masterInfo) => {
      return masterInfo.master_code;
    });
  return masterInfo[0];
};

export const getMasterValueByCode = (masterData: UtilsMasterData[], masterCode: string) => {
  const masterInfo = masterData
    .filter((master) => {
      return master.master_code === masterCode;
    })
    .map((masterInfo) => {
      return masterInfo.value;
    });
  return masterInfo[0];
};

export const getUnitByFieldName = (unitsData: Unit[], field: string) => {
  const unitInfo = unitsData.filter((item: Unit) => item.name == field)[0]?.unit;
  return unitInfo;
};

export const getLoggedInUser = () => {
  let localUserData: any;
  const token: any = getSessionStorage('accessToken');
  const decoded: CustomJwtPayload | null = token ? jwtDecode(token) : null;
  const userData = decoded?.user_data;

  if (userData !== null) {
    localUserData = userData;
  } else {
    localUserData = {};
  }
  return localUserData;
};
