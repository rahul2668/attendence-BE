import _ from 'lodash';
import { subModuleConfigs } from './constants';

type SubModuleConfigs = typeof subModuleConfigs;

// a comparison object to render the menu
// 'Master Data' - the module, 'Material Maintenance' - submodule name & inside the category key , the possible screens should be given as an array

export function findSubModule(outerKey: string, value: string): string | null {
  const categories = subModuleConfigs[outerKey as keyof SubModuleConfigs]; // Type assertion to keyof SubModuleConfigs
  if (!categories) return null; // Handle cases where outerKey is not found
  const category = _.findKey(
    categories,
    (subCategories: string[]) => subCategories && subCategories.includes(value)
  );
  return category || null;
}
