export interface HeadersForCSV {
  label: string;
  key: string;
}

export interface ExcelDataList {
  csvData: Array<any>;
  headersForCSV?: Array<HeadersForCSV>;
  title: string;
}
