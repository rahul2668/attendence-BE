export interface LazyLoadedFurnaceProduct {
  id: number;
  material_code: string;
}

export interface LazyLoadedFurnaceProductResponse {
  count: number;
  next: string | null;
  previous: string | null;
  results: LazyLoadedFurnaceProduct[];
}

export interface LazyLoadService {
  getProductCodes: (
    searchKey?: string,
    otherParams?: any
  ) => HttpPromise<LazyLoadedFurnaceProductResponse>;
}
