import { Dayjs } from 'dayjs';

// global state of basic info tab
export type FurnaceBasicInfo = {
  plant_id: number;
  furnaceId?: number;
  furnace_no?: number;
  furnace_description?: string;
  workshop?: number;
  power_delivery?: number;
  cost_center?: number;
  silica_fume_default_material?: number;
  slag: number;
  skull: number;
  furnace_products?: FurnaceProduct[];
  [key: string]: any; // check
};

export interface FurnaceProduct {
  product_type: number | string;
  product_name: string;
  products: FurnaceProductItem[];
}

export interface FurnaceProductItem {
  id?: number;
  furnace_config?: number;
  material_master?: number;
  material_master_value?: string;
  record_status?: boolean;
}
// global state for basic info error
export type FurnaceBasicInfoErrors = {
  furnace_no?: string;
  furnace_description?: string;
  workshop?: string;
  power_delivery?: string;
  cost_center?: string;
};

export type FurnaceElectrodeInfo = {
  furnace_config: number;
  electrode_type_id: number;
  diameter: number;
  effective_date: Dayjs;
  electrode_type_code: string;
  electrodes: Electrode[];
  fieldErrors?: { [key: string]: string };
  isAnyElectrodeFieldEmpty: boolean;
  user_approval_needed?: boolean;
  is_user_approved?: boolean;
};

export interface Electrode {
  [key: string]: number | string;
}

export interface FurnaceConfigService {
  getFurnaceElectrodeInfo: (furnaceId: number) => HttpPromise<FurnaceElectrodeInfo>;
  createOrUpdateFurnaceElectrode: (request: FurnaceElectrodeInfo) => HttpPromise<APIResponse>;
  submitBasicInfo: (request: FurnaceBasicInfo) => HttpPromise<APIResponse>;
  updateBasicInfo: (request: FurnaceBasicInfo) => HttpPromise<APIResponse>;
  getBasicInfo: (furnaceId: number) => HttpPromise<APIResponse>;
  getFurnaceParameterInfo: (furnaceId: number) => HttpPromise<APIResponse>;
  createOrUpdateFurnaceParameter: (request: FurnaceParameterInfo) => HttpPromise<APIResponse>;
  getFurnaceElectrodesExcel: (furnaceId: number) => HttpPromise<FurnaceElectrodeExcelInfo[]>;
  getFurnaceParametersExcel: (furnaceId: number) => HttpPromise<any[]>;
}

export interface FurnaceParameterInfo {
  furnace_config: number;
  effective_date: Dayjs;
  fieldErrors?: { [key: string]: string };
  isAnyParameterFieldEmpty: boolean;
  energy_losses: number;
  joule_losses_coefficient: number;
  default_epi_index: number;
  corrected_reactance_coefficient: number;
  design_mv: number;
  fixed_cost: number;
  target_energy_efficiency: number;
  target_cost_budget: number;
  target_availability: number;
  target_furnace_load: number;
  crucible_diameter: number;
  crucible_depth: number;
  pcd_theoretical: number;
  pcd_actual: number;
  default_moisture: boolean;
  is_user_approved?: boolean;
}

export type FurnaceElectrodeExcelInfo = {
  id: number;
  core_value: string;
  paste_value: string;
  casing_value: string;
  electrode_type_id: number;
  electrode_name: string;
  core_mass_length: string;
  paste_mass_length: string;
  casing_mass_length: string;
  core: number;
  paste: number;
  casing: number;
};
