export interface GetAllFurnaceDownTimeResponse {
  id: number;
  material_no: string | number;
  material_name: string | number;
  material_description: string;
  record_no: number | string;
  lot_id: number | string;
  unit_weight: number | string;
  thermal_effect: number | string;
  feed_rate: number | string;
  lot_mass: number | string;
  actual_cost: number | string;
  priority: number | string;
  additional_sequence: number | string;
  additional_group: number | string;
  density: number | string;
  standard_cost: number | string;
  primary_elment: number | string;
  distribution: number | string;
  inventory_prot_factor: number | string;
  batching_system_bin: number | string;
  is_active: boolean;
  analyst_no: number | string;
  sample_type: string;
  analytical_device: string;
  original_sample: string;
  created_at: string | number;
  available: boolean;
  body: any;
  // specs: object
}

export interface DowntimeExcelDownload {
  duration: string;
  equipment_value: string;
  event_id: string;
  event_status_value: string;
  furnace_no: number;
  observation_end_dt: string;
  observation_start_dt: string;
  reason_value: string;
}

export interface FurnaceDownTimeService {
  getFurnaceDownTimeDetailsList: (id: string | null) => HttpPromise<GetAllFurnaceDownTimeResponse>;
  getFurnaceDownTimeEventDetails: (
    id: string | number | null
  ) => HttpPromise<GetAllFurnaceDownTimeResponse>;
  getFurnaceDownTimeSplitDetails: (
    id: string | number | null
  ) => HttpPromise<GetAllFurnaceDownTimeResponse>;
  createFurnaceDownTimeEventDetails: (
    request: GetAllFurnaceDownTimeResponse
  ) => HttpPromise<GetAllFurnaceDownTimeResponse>;
  createFurnaceDownTimeSplitDetails: (
    request: GetAllFurnaceDownTimeResponse
  ) => HttpPromise<GetAllFurnaceDownTimeResponse>;
  updateFurnaceDownTimeEventDetails: (
    request: GetAllFurnaceDownTimeResponse
  ) => HttpPromise<GetAllFurnaceDownTimeResponse>;
  updateFurnaceDownTimeSplitDetails: (
    request: GetAllFurnaceDownTimeResponse
  ) => HttpPromise<GetAllFurnaceDownTimeResponse>;
  getRadioFurnaceDownTimeDetails: () => HttpPromise<GetAllFurnaceDownTimeResponse>;
  deleteFurnaceDownTimeEvent: (
    id: string | number | null
  ) => HttpPromise<GetAllFurnaceDownTimeResponse>;
  deleteFurnaceDownTimeSplit: (
    id: string | number | null
  ) => HttpPromise<GetAllFurnaceDownTimeResponse>;
  getFurnaceDownTimeEquipment: (
    id: string | number | null
  ) => HttpPromise<GetAllFurnaceDownTimeResponse>;
  getFurnaceDownTimeReason: (
    id: string | number | null
  ) => HttpPromise<GetAllFurnaceDownTimeResponse>;
}
