export interface FieldUnit {
  id: number;
  name: string;
  unit: string;
}
