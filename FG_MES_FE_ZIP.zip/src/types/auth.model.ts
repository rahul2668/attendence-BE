import { JwtPayload } from 'jwt-decode';
import { PlantData } from './plant.model';

export interface Login {
  username: string;
  password: string;
}
export interface SsoLogin {
  email: string | undefined;
}
export interface CreateUser {
  first_name: string;
  last_name: string;
  username: string;
  password: string;
}
export interface ChangePassword {
  username: string;
  current_password: string | number;
  new_password: string | number;
}
export interface AuthService {
  userLogin: (request: Login) => HttpPromise<any>;
  userLoginSSO: (request: SsoLogin) => HttpPromise<any>;
  userLogout: () => HttpPromise<any>;
  refreshToken: () => HttpPromise<any>;
  getSSOLoginCredentials: () => HttpPromise<any>;
  createUser: (request: CreateUser) => HttpPromise<any>;
  getAuthToken: (request: Login) => HttpPromise<any>;
  changePassword: (request: ChangePassword) => HttpPromise<any>;
  getPlantLanguage: () => HttpPromise<any>;
}

export interface UserData {
  id: number;
  first_name: string;
  last_name: string;
  url: string;
  username: string;
  roles: Array<any>;
  phone: string;
  email: string | null;
  is_delete: boolean;
  permission_list: PermissionItem;
  is_superuser: boolean;
  login_type: string;
  plant: PlantData;
}

export interface CustomJwtPayload extends JwtPayload {
  user_data: UserData;
  plant_data: PlantData;
}
