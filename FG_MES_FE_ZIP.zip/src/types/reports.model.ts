export interface Reports {
  getMaterialCategories: () => HttpPromise<any>;
  getMaterialTypes: (materialCategoryId: number) => HttpPromise<any>;
  getVariantDetailsById: (variantsId: number) => HttpPromise<any>;
  getMaterialIds: (materialTypeId: number) => HttpPromise<any>;
  getVariants: () => HttpPromise<any>;
  variantSaveService: (payload: any) => HttpPromise<any>;
  reportOptionsService: (
    materialCategory: number,
    materialType: number,
    materialId: any
  ) => HttpPromise<any>;
  getReport: (payload: any) => HttpPromise<any>;
  deleteVariantById: (variantId: number, variantName: string, userName: string) => HttpPromise<any>;
}
