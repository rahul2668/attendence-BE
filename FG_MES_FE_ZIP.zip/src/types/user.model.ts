import { Role } from 'types/role.model';

export interface User {
  id: number;
  first_name: string;
  last_name: string;
  url: string;
  username: string;
  roles: Role[];
  email: string;
  phone: string;
}
export interface GetAllUsersResponse {
  count: number;
  next: string;
  previous: string;
  results: User[];
}
export interface GetUsersListInput {
  page_size: number;
}

export interface AddUserInput {
  first_name: string;
  last_name: string;
  username: string;
  password: string;
  roles: number[];
  email: string;
  phone: string;
}

export interface AddUserResponse {
  id: number;
  first_name: string;
  last_name: string;
  username: string;
  password: string;
  roles: number[];
  email: string;
  phone: string;
}
export interface UserService {
  getUsersList: (request: GetUsersListInput) => HttpPromise<GetAllUsersResponse>;
  addUser: (request: AddUserInput) => HttpPromise<AddUserResponse>;
}
