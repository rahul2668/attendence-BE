import { Dayjs } from 'dayjs';

// type for ObservationLogForm for taphole and furnace
export interface ObservationLogFormType {
  furnace: number | string;
  comments?: string;
  observation_dt: string | Date;
  flame?: number;
  flame_colour?: number;
  tap_hole_bottom?: number;
  metal_output?: number;
  furnace_tapping?: number;
  slag?: number;
  flame_intensity?: number;
  auto_collapse?: string;
  electrode_auto_lining_wideness?: string;
  noise_when_collapsing?: string;
  electrode_blows_direction?: string;
  electrode_crust_formation?: string;
  bed_conditions?: string;
  activity_homogeneity?: string;
}

export interface DowntimeLogFormType {
  furnace: number | string;
  comments?: string;
  observation_start_dt: string | Date | Dayjs;
  observation_end_dt: string | Date | Dayjs | null;
  equipment?: number | string;
  downtime?: number | string;
  event_status?: boolean;
  reason?: number | string;
  down_time_type?: number | string;
  source?: number | string;
}

export interface DownTimeLog {
  renderData: any;
  saveClicked: boolean | null;
  onSave: (value: any) => void;
  enableSaveButton: () => void;
  disableSaveButton: () => void;
  furnaces: Array<any>;
  existingObservationData: any;
  isEdit: boolean;
  isSplitUp: boolean;
  eventData: any;
  passedFurnaceId?: string;
}

type SetShowModalFunction = React.Dispatch<React.SetStateAction<boolean>>;
export interface DownTimeEventModalProps {
  isEdit: boolean;
  // Pass state and state setter function as props
  showModal: boolean;
  setShowModal: SetShowModalFunction;
  downTimeId: number | null;
  setIsLoading: (value: boolean) => void;
  getList: (value: any) => void;
  isSplitUp: boolean;
  passedFurnaceId?: string;
  storeLastUpdatedEvent?: () => void;
}

export interface DownTimeLogModalProps {
  // Pass state and state setter function as props
  showModal: boolean;
  setShowModal: SetShowModalFunction;
  data: any;
  isSplitUp?: boolean;
  onClose?: () => void;
}
