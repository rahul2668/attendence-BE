export interface Role {
  role_name: string;
  url: string;
  id: number;
}

export interface RoleDetails {
  role_name: string;
  id: string | number;
}
export interface GetRolesList {
  id: number | string;
  page_size: number;
}
export interface GetRolesResponse {
  roles: Role[];
}
export interface GetRoleDetailsResponse {
  role_name: string;
  url: string;
}
export interface DeleteRole {
  id: number | null;
}
export interface EditRole {
  id: number;
}
export interface RolesInitialData {
  [category: string]: {
    [key: string]: {
      [action: string]: boolean;
    };
  };
}

export interface GetRoleDetailsRequest {
  role_id: string | number | null;
  is_clone: boolean;
}
export interface RoleServiceModel {
  getRoles: () => HttpPromise<GetRolesResponse>;
  getRoleDetails: (request: GetRoleDetailsRequest) => HttpPromise<GetRoleDetailsResponse>;
  editRole: (request: any) => HttpPromise<EditRole>;
  deleteRole: (request: any) => HttpPromise<DeleteRole>;
  createRole: (request: any) => HttpPromise<any>;
}
