export interface ConsumptionReport {
  furnanceList: () => HttpPromise<any>;
  variantList: () => HttpPromise<any>;
  fetchVariantDetailsById: (variantId: any) => HttpPromise<any>;
  consumptionvariantsave: (payload: any) => HttpPromise<any>;
  fetchConsumptionReport: (payload: any) => HttpPromise<any>;
  getMaterialCategories: () => HttpPromise<any>;
  getMaterialTypes: (materialCategoryId: number) => HttpPromise<any>;
  getMaterialIds: (materialTypeId: number) => HttpPromise<any>;
  deleteVariantById: (variantId: number, variantName: string, userName: string) => HttpPromise<any>;
}
