type HttpPromise<T = any> = AxiosPromise<T>;

interface PermissionItem {
  [key: string]: {
    [key: string]: {
      view: boolean;
      create: boolean;
      edit: boolean;
      delete: boolean;
      isEligibleForMenu: boolean;
    };
  };
}

type Tabs = {
  label: string;
  value: number;
};

interface SelectOption {
  value: string | number;
  option: string;
}

type Unit = {
  id: number;
  name: string;
  unit: string;
};

interface NavigateState {
  action: crudType;
  viewOrEditId?: number;
  title?: string | number;
}

interface APIResponse {
  message: string;
  id?: number;
}

interface ReusableInputField {
  id: number;
  label: string;
  name: string;
  inputType: 'number' | 'select' | 'boolean';
  unit?: string;
  option?: any[];
  selectedValueState?: string | number;
  valueState?: string | number;
  placeholder?: string;
  isRequired: boolean;
  fieldName?: string;
}
