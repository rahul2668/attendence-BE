import englishTranslation from '../locales/english/en.json';
import resources from './i18nResources';

declare module 'i18next' {
  interface CustomTypeOptions {
    defaultNS: 'en';
    resources: typeof resources;
  }
}
