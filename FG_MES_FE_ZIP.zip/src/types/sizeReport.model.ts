export interface SizeReports {
  getSizeMaterialCategories: () => HttpPromise<any>;
  getSizeMaterialTypes: (materialCategoryId: number) => HttpPromise<any>;
  getSizeVariantDetailsById: (variantsId: number) => HttpPromise<any>;
  getSizeMaterialIds: (materialTypeId: number) => HttpPromise<any>;
  getSizeVariants: () => HttpPromise<any>;
  sizeVariantSaveService: (payload: any) => HttpPromise<any>;
  sizeReportOptionsService: (
    materialCategory: number,
    materialType: number,
    materialId: any
  ) => HttpPromise<any>;
  getSizeReport: (payload: any) => HttpPromise<any>;
  deleteSizeVariantById: (
    variantId: number,
    variantName: string,
    userName: string
  ) => HttpPromise<any>;
}
