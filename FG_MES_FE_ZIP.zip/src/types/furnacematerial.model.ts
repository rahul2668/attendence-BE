export interface GetAllFurnaceMaterialResponse {
  id?: number;
  material_no: string | number;
  material_name: string | number;
  material_description: string;
  record_no: number | string;
  lot_id: number | string;
  unit_weight: number | string;
  thermal_effect: number | string;
  feed_rate: number | string;
  lot_mass: number | string;
  actual_cost: number | string;
  priority: number | string;
  additional_sequence: number | string;
  additional_group: number | string;
  density: number | string;
  standard_cost: number | string;
  primary_elment: number | string;
  distribution: number | string;
  inventory_prot_factor: number | string;
  batching_system_bin: number | string;
  is_active: boolean;
  analyst_no: number | string;
  sample_type: string;
  analytical_device: string;
  original_sample: string;
  created_at: string | number;
  available: boolean;
  // specs: object
}
export interface IgetFurnaceMaterialList {
  material_no: number | string;
  page_size: number;
  page: number;
}
export interface EditFurnaceMaterial {
  id: number | null;
  body: GetAllFurnaceMaterialResponse;
}
export interface DeleteFurnaceMaterial {
  is_delete: boolean;
  id: number | null;
}
export interface StatusFurnaceMaterial {
  is_active: boolean;
  id: number | null;
}

export interface FurnaceFeatures {
  material_name?: string | number;
  is_active?: boolean | string;
  ordering?: string;
  search?: number;
  page?: number;
}
export interface SearchMaterialName {
  material_name?: string;
}
export interface CloneMaterial {
  id: number | null | undefined;
  object_to_copy_id: number | null | undefined;
}
export interface MaterialTypeParams {
  category?: string;
}
export interface FurnaceMaterialService {
  getFurnaceMaterialDetails: (id: string | null) => HttpPromise<GetAllFurnaceMaterialResponse>;
  getFurnaceMaterialSpecificationDetails: (
    id: string | null
  ) => HttpPromise<GetAllFurnaceMaterialResponse>;
  getWipMaterialSpecificationDetails: (
    id: string | null
  ) => HttpPromise<GetAllFurnaceMaterialResponse>;
  getByProductsSpecificationDetails: (
    id: string | null
  ) => HttpPromise<GetAllFurnaceMaterialResponse>;
  getAdditiveSpecificationDetails: (
    id: string | null
  ) => HttpPromise<GetAllFurnaceMaterialResponse>;
  getFurnaceMaterialList: (request: string) => HttpPromise<GetAllFurnaceMaterialResponse>;
  editFurnaceMaterial: (request: EditFurnaceMaterial) => HttpPromise<any>;
  editFurnaceMaterialSpecificationDetails: (request: EditFurnaceMaterial) => HttpPromise<any>;
  editWipMaterialSpecificationDetails: (request: EditFurnaceMaterial) => HttpPromise<any>;
  editAdditiveSpecificationDetails: (request: EditFurnaceMaterial) => HttpPromise<any>;
  editByProductsSpecificationDetails: (request: EditFurnaceMaterial) => HttpPromise<any>;
  deleteFurnaceMaterial: (request: DeleteFurnaceMaterial) => HttpPromise<any>;
  statusFurnaceMaterial: (request: StatusFurnaceMaterial) => HttpPromise<any>;
  getListData: () => HttpPromise<GetAllFurnaceMaterialResponse>;
  getSort_FilteredFurnacedList: (
    request: FurnaceFeatures
  ) => HttpPromise<GetAllFurnaceMaterialResponse>;
  getSearchedFilter: (request: SearchMaterialName) => HttpPromise<GetAllFurnaceMaterialResponse>;
  getCloneMaterial: (request: CloneMaterial) => HttpPromise<GetAllFurnaceMaterialResponse>;
  createClonedMaterial: (
    request: GetAllFurnaceMaterialResponse
  ) => HttpPromise<GetAllFurnaceMaterialResponse>;
  getMaterialTypes: (materialTypeParams: MaterialTypeParams) => HttpPromise<any>;
  getSizeDropdown: () => HttpPromise<any>;
  getFurnaceMaterialExcel: (id: string | null) => HttpPromise<GetAllFurnaceMaterialResponse>;
}
