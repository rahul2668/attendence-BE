export interface GetAllTapHoleResponse {
  id: number;
  material_no: string | number;
  material_name: string | number;
  material_description: string;
  record_no: number | string;
  lot_id: number | string;
  unit_weight: number | string;
  thermal_effect: number | string;
  feed_rate: number | string;
  lot_mass: number | string;
  actual_cost: number | string;
  priority: number | string;
  additional_sequence: number | string;
  additional_group: number | string;
  density: number | string;
  standard_cost: number | string;
  primary_elment: number | string;
  distribution: number | string;
  inventory_prot_factor: number | string;
  batching_system_bin: number | string;
  is_active: boolean;
  analyst_no: number | string;
  sample_type: string;
  analytical_device: string;
  original_sample: string;
  created_at: string | number;
  available: boolean;
  body: any;
  // specs: object
}

export interface TapHoleService {
  getTapHoleDetailsList: (id: string | null) => HttpPromise<GetAllTapHoleResponse>;
  getTapHoleDetails: (id: string | number | null) => HttpPromise<GetAllTapHoleResponse>;
  createTapHoleDetails: (request: GetAllTapHoleResponse) => HttpPromise<GetAllTapHoleResponse>;
  updateTapHoleDetails: (request: GetAllTapHoleResponse) => HttpPromise<GetAllTapHoleResponse>;
  getRadioTapHoleDetails: () => HttpPromise<GetAllTapHoleResponse>;
  deleteTapHoleDetails: (id: string | number | null) => HttpPromise<GetAllTapHoleResponse>;
}
