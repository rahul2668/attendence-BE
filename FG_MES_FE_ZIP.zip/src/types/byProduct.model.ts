export interface GetAllAdditiveResponse {
  id: number;
  available: boolean;
  material_no: string | number;
  material_name: string | number;
  unit_weight: number | string;
  record_no: number | string;
  lot_id: number | string;
  thermal_effect: number | string;
  feed_rate: number | string;
  lot_mass: number | string;
  actual_cost: number | string;
  priority: number | string;
  additional_sequence: number | string;
  additional_group: number | string;
  density: number | string;
  standard_cost: number | string;
  primary_elment: number | string;
  distribution: number | string;
  inventory_prot_factor: number | string;
  batching_system_bin: number | string;
  created_at: string | number;
  analyst_no: number | string;
  sample_type: string;
  analytical_device: string;
  original_sample: string;
  material_description: string;
  // specs: object
}
export interface GetByProductList {
  material_no: number | string;
  page_size: number;
  page: number;
}
export interface EditAdditives {
  id: number | null;
  body: GetAllAdditiveResponse;
}
export interface DeleteByProduct {
  is_delete: boolean;
  id: number | null;
}
export interface StatusAdditive {
  is_active: boolean;
  id: number | null;
}
export interface AdditiveFeatures {
  material_name?: string | number;
  is_active?: boolean | string;
  ordering?: string;
  search?: string | number;
  page?: number;
  page_size?: number;
}
export interface SearchMaterialName {
  material_name?: string;
}
export interface CloneMaterial {
  id: number | null | undefined;
  object_to_copy_id: number | null | undefined;
}
export interface ByProductService {
  getByProductDetails: (id: string | null) => HttpPromise<GetAllAdditiveResponse>;
  getByProductList: (request: string) => HttpPromise<GetAllAdditiveResponse>;
  editByProduct: (request: EditAdditives) => HttpPromise<any>;
  deleteByProduct: (request: DeleteByProduct) => HttpPromise<any>;
  statusAdditive: (request: StatusAdditive) => HttpPromise<any>;
  getListData: () => HttpPromise<GetAllAdditiveResponse>;
  getSort_FilteredByProductList: (request: AdditiveFeatures) => HttpPromise<GetAllAdditiveResponse>;
  getSearchedFilter: (request: SearchMaterialName) => HttpPromise<GetAllAdditiveResponse>;
  getCloneMaterial: (request: CloneMaterial) => HttpPromise<GetAllAdditiveResponse>;
  createClonedMaterial: (request: GetAllAdditiveResponse) => HttpPromise<GetAllAdditiveResponse>;
  getByProductMaterialExcel: (id: string | null) => HttpPromise<GetAllAdditiveResponse>;
}
