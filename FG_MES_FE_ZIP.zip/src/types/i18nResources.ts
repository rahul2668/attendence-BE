import en from '../locales/english/en.json';

const resources = {
  en,
} as const;

export default resources;
