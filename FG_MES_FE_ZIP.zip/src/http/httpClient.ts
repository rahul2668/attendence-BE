import axios, {
  AxiosInstance,
  AxiosResponse,
  AxiosError,
  Method,
  InternalAxiosRequestConfig,
  AxiosPromise,
} from 'axios';
import { t } from 'i18next';
import { paths } from 'routes/paths';
import { getSessionStorage, notify } from 'utils/utils';

export interface Request {
  headers?: Record<string, string>;
  data?: any;
  params?: any;
}

export class HttpClient {
  private httpClient: AxiosInstance;

  constructor() {
    this.httpClient = axios.create({
      // baseURL: '',
      baseURL: 'http://127.0.0.1:8000',
      // baseURL: 'http://72.181.13.50:3234',
      responseType: 'json',
      timeout: 60000,
    });
    // this.httpClient.interceptors.request.use(this.handleRequestUse)
    this.httpClient.interceptors.request.use(this.handleRequestAuth);
    this.httpClient.interceptors.response.use(
      // this.handleResponseUse,
      this.handleResponseAuth,
      this.handleError
    );
  }

  private handleRequestAuth(config: InternalAxiosRequestConfig) {
    let authToken = getSessionStorage('accessToken');
    authToken = authToken ?? null;
    if (authToken) config.headers.Authorization = `Bearer ${authToken}`;
    return config;
  }
  private handleResponseAuth(response: AxiosResponse) {
    return response;
  }

  // private handleResponseUse(response: AxiosResponse) {
  //   return response
  // }

  private handleError(error: AxiosError) {
    const errorMessage: any = error.response?.data;
    if (errorMessage.message) {
      notify('error', t(errorMessage.message));
    }
    // handle 400 locally in the components
    // if (error.response?.status === 400) {
    //   notify('error', t('sharedTexts.badRequest'));
    // }
    if (error.response?.status === 500) {
      notify('error', t('sharedTexts.internalServerError'));
    }
    // unAuthorized requests
    if (error.response?.status === 401 || error.response?.status === 403) {
      sessionStorage.clear();
      setTimeout(() => {
        window.location?.assign(`${paths.login}`);
      }, 3000); // giving time to read the message in notification
    }
    return error?.response;
  }

  private async handleRequest(
    url: string,
    method: Method,
    config: Request = {}
  ): Promise<AxiosResponse<any>> {
    const { headers, data, params } = config;
    try {
      const response = await this.httpClient.request({
        url,
        method,
        data,
        params,
        headers,
      });
      return response;
    } catch (e: any) {
      return e.error;
    }
  }

  public get<T>(url: string, config: Request = {}): AxiosPromise<T> {
    return this.handleRequest(url, 'get', config);
  }

  public post<T>(url: string, config: Request = {}): AxiosPromise<T> {
    return this.handleRequest(url, 'post', config);
  }

  public put<T>(url: string, config: Request = {}): AxiosPromise<T> {
    return this.handleRequest(url, 'put', config);
  }

  public delete<T>(url: string, config: Request = {}): AxiosPromise<T> {
    return this.handleRequest(url, 'delete', config);
  }

  public patch<T>(url: string, config: Request = {}): AxiosPromise<T> {
    return this.handleRequest(url, 'patch', config);
  }
}

export default new HttpClient();
