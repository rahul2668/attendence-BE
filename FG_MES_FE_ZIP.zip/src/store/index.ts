import { configureStore } from '@reduxjs/toolkit';
import { useDispatch, useSelector, TypedUseSelectorHook } from 'react-redux';

import postReducer from 'store/slices/postSlice';
import plantSlice from './slices/plantsSlice';
import additiveSlice from './slices/additiveSlice';
import userSlice from './slices/userSlice';
import MaterialSlice from './slices/MaterialSlice';
import AuthSlice from './slices/authSlice';
import furnaceMaterialSlice from './slices/furnaceMaterialSlice';
import plantConfigSlice from './slices/plantGetData';
import furnaceListSlice from './slices/furnaceListSlice';
import unitSlice from './slices/unitSlice';
import ConsumptionReducer from './reducers/ConsumptionReducer';
import ReportReducer from './reducers/ReportReducer';
import materialSpecificattionSlice from './slices/materialSpecificattionSlice';
import coreFurnaceListSlice from './slices/coreFurnaceListSlice';
import sizeReportAnalysisSlice from './slices/sizeReportAnalysisSlice';
import MasterSlice from './slices/masterSlice';
import UserDataSlice from './slices/userDataSlice';
import PlantDataSlice from './slices/plantDataSlice';
import FilterDataListSlice from './slices/filterDataList';
import UserListSlice from './slices/userListSlice';
import FurnaceConfigurationSlice from './slices/furnaceConfigurationSlice';
import byProductSlice from './slices/byProductSlice';
import wipSlice from './slices/wipSlice';

const store = configureStore({
  reducer: {
    post: postReducer,
    plant: plantSlice,
    additive: additiveSlice,
    byProduct: byProductSlice,
    wip: wipSlice,
    user: userSlice,
    material: MaterialSlice,
    login: AuthSlice,
    furnace: furnaceMaterialSlice,
    plant_config: plantConfigSlice,
    furnace_config: furnaceListSlice,
    unit: unitSlice,
    consumption: ConsumptionReducer,
    reportReducer: ReportReducer,
    materialSpecificationUnit: materialSpecificattionSlice,
    coreFurnace: coreFurnaceListSlice,
    sizeReportAnalysis: sizeReportAnalysisSlice,
    master: MasterSlice,
    userData: UserDataSlice,
    plantData: PlantDataSlice,
    filterDataList: FilterDataListSlice,
    userList: UserListSlice,
    furnaceConfiguration: FurnaceConfigurationSlice,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;

export const useAppSelector: TypedUseSelectorHook<RootState> = useSelector;
export const useAppDispatch: () => AppDispatch = useDispatch;

export default store;
