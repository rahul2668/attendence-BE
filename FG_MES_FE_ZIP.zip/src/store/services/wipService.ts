import httpClient from 'http/httpClient';
import {
  GetAllAdditiveResponse,
  EditAdditives,
  WipService as IAdditiveService,
  DeleteWip,
  StatusAdditive,
  AdditiveFeatures,
  SearchMaterialName,
  CloneMaterial,
} from 'types/wip.model';
import { isEmpty } from 'utils/utils';

const WipService = (): IAdditiveService => {
  return {
    getWipDetails: (id: string | null): HttpPromise<GetAllAdditiveResponse> => {
      return httpClient.get(`/api/master/wip-additional-information/${id}/`);
    },
    getWipList: (request: string): HttpPromise<GetAllAdditiveResponse> => {
      return httpClient.get(`/api/materials/?${request}`);
    },
    getSort_FilteredAdditiveList: (
      request: AdditiveFeatures
    ): HttpPromise<GetAllAdditiveResponse> => {
      let url = `/api/additive/?page_size=10&page=${request.page}`;
      if (!isEmpty(request.ordering)) {
        url = url + `&ordering=${request.ordering}`;
      }
      if (!isEmpty(request.search)) {
        url = url + `&search=${request.search}`;
      }
      if (!isEmpty(request.is_active)) {
        url = url + `&is_active=${request.is_active}`;
      }
      if (!isEmpty(request.material_name)) {
        url = url + `&id__in=${request.material_name}`;
      }
      return httpClient.get(url);
    },
    getListData: (): HttpPromise<any> => {
      return httpClient.get('/api/additive/');
    },
    getCloneMaterial: (request: CloneMaterial): HttpPromise<any> => {
      return httpClient.post(`/api/additive/${request.id}/clone/`, {
        data: request,
      });
    },
    createClonedMaterial: (
      request: GetAllAdditiveResponse
    ): HttpPromise<GetAllAdditiveResponse> => {
      return httpClient.post(`/api/master/wip-additional-information/${request.id}/`, {
        data: request,
      });
    },
    editWip: (request: EditAdditives): HttpPromise<any> => {
      return httpClient.put(`/api/master/wip-additional-information/${request.id}/`, {
        data: request.body,
      });
    },
    deleteWip: (request: DeleteWip): HttpPromise<any> => {
      return httpClient.patch(`/api/additive/${request.id}/`, {
        data: request,
      });
    },
    statusAdditive: (request: StatusAdditive): HttpPromise<any> => {
      return httpClient.get(`api/additive/${request.id}/change_status/`);
    },
    getSearchedFilter: (request: SearchMaterialName): HttpPromise<GetAllAdditiveResponse> => {
      return httpClient.get(
        `/api/additive/get-material-name-list/?search=${request.material_name}`
      );
    },
    getWipMaterialExcel: (id: string | null): HttpPromise<GetAllAdditiveResponse> => {
      return httpClient.get(`/api/master/wip-additional-information/${id}/?excel_download=true`);
    },
  };
};

export default WipService();
