import httpClient from 'http/httpClient';
import {
  FurnaceElectrodeInfo,
  FurnaceBasicInfo,
  FurnaceParameterInfo,
  FurnaceConfigService as IFurnaceConfigService,
} from 'types/furnaceConfig.model';

const FurnaceConfigService = (): IFurnaceConfigService => {
  return {
    getFurnaceElectrodeInfo(furnaceId: number): HttpPromise<FurnaceElectrodeInfo> {
      return httpClient.get(`/api/furnace-config/electrodes/${furnaceId}`);
    },
    createOrUpdateFurnaceElectrode(request: FurnaceElectrodeInfo): HttpPromise<APIResponse> {
      return httpClient.post('/api/furnace-config/electrodes/', {
        data: request,
      });
    },
    submitBasicInfo(request: FurnaceBasicInfo): HttpPromise<APIResponse> {
      return httpClient.post('/api/furnace-config/basic-info/', {
        data: request,
      });
    },
    getBasicInfo(furnaceId: number): HttpPromise<APIResponse> {
      return httpClient.get(`/api/furnace-config/basic-info/${furnaceId}`);
    },
    updateBasicInfo(request: FurnaceBasicInfo): HttpPromise<APIResponse> {
      return httpClient.put(`/api/furnace-config/basic-info/${request.id}`, {
        // NEED TO CHANGE THIS ID TO FUNRACE ID
        data: request,
      });
    },
    getFurnaceParameterInfo(furnaceId: number): HttpPromise<FurnaceParameterInfo> {
      return httpClient.get(`/api/furnace-config/parameters/${furnaceId}`);
    },
    createOrUpdateFurnaceParameter(request: FurnaceParameterInfo): HttpPromise<APIResponse> {
      return httpClient.post('/api/furnace-config/parameters/', {
        data: request,
      });
    },
    getFurnaceElectrodesExcel(furnaceId: number): HttpPromise<APIResponse> {
      return httpClient.get(`/api/furnace-config/electrodes/${furnaceId}/?excel_download=true`);
    },
    getFurnaceParametersExcel(furnaceId: number): HttpPromise<APIResponse> {
      return httpClient.get(`/api/furnace-config/parameters/${furnaceId}/?excel_download=true`);
    },
  };
};

export default FurnaceConfigService();
