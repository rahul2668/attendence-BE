import httpClient from 'http/httpClient';
import { GetAllTapHoleResponse, TapHoleService as ITapHoleService } from 'types/tapHole.model';

const TapHoleService = (): ITapHoleService => {
  return {
    getTapHoleDetailsList: (id: string | null): HttpPromise<GetAllTapHoleResponse> => {
      return httpClient.get(`/api/log/taphole/?${id}`);
    },
    getTapHoleDetails: (id: string | number | null): HttpPromise<GetAllTapHoleResponse> => {
      return httpClient.get(`/api/log/taphole/${id}/`);
    },
    deleteTapHoleDetails: (id: string | number | null): HttpPromise<GetAllTapHoleResponse> => {
      return httpClient.patch(`/api/log/taphole/${id}/`);
    },
    getRadioTapHoleDetails: (): HttpPromise<GetAllTapHoleResponse> => {
      return httpClient.get(`/api/log/taphole-radios/`);
    },
    createTapHoleDetails: (request: GetAllTapHoleResponse): HttpPromise<GetAllTapHoleResponse> => {
      return httpClient.post(`/api/log/taphole/`, {
        data: request,
      });
    },
    updateTapHoleDetails: (request: GetAllTapHoleResponse): HttpPromise<GetAllTapHoleResponse> => {
      return httpClient.put(`/api/log/taphole/${request.id}`, {
        data: request.body,
      });
    },
  };
};

export default TapHoleService();
