import httpClient from 'http/httpClient';
import {
  GetAllAdditiveResponse,
  EditAdditives,
  ByProductService as IAdditiveService,
  DeleteByProduct,
  StatusAdditive,
  AdditiveFeatures,
  SearchMaterialName,
  CloneMaterial,
} from 'types/byProduct.model';
import { isEmpty } from 'utils/utils';

const ByProductService = (): IAdditiveService => {
  return {
    getByProductDetails: (id: string | null): HttpPromise<GetAllAdditiveResponse> => {
      return httpClient.get(`/api/master/by-product-additional-information/${id}/`);
    },
    getByProductList: (request: string): HttpPromise<GetAllAdditiveResponse> => {
      return httpClient.get(`/api/materials/?${request}`);
    },
    getSort_FilteredByProductList: (
      request: AdditiveFeatures
    ): HttpPromise<GetAllAdditiveResponse> => {
      let url = `/api/additive/?page_size=10&page=${request.page}`;
      if (!isEmpty(request.ordering)) {
        url = url + `&ordering=${request.ordering}`;
      }
      if (!isEmpty(request.search)) {
        url = url + `&search=${request.search}`;
      }
      if (!isEmpty(request.is_active)) {
        url = url + `&is_active=${request.is_active}`;
      }
      if (!isEmpty(request.material_name)) {
        url = url + `&id__in=${request.material_name}`;
      }
      return httpClient.get(url);
    },
    getListData: (): HttpPromise<any> => {
      return httpClient.get('/api/additive/');
    },
    getCloneMaterial: (request: CloneMaterial): HttpPromise<any> => {
      return httpClient.post(`/api/additive/${request.id}/clone/`, {
        data: request,
      });
    },
    createClonedMaterial: (
      request: GetAllAdditiveResponse
    ): HttpPromise<GetAllAdditiveResponse> => {
      return httpClient.post(`/api/master/by-product-additional-information/${request.id}/`, {
        data: request,
      });
    },
    editByProduct: (request: EditAdditives): HttpPromise<any> => {
      return httpClient.put(`/api/master/by-product-additional-information/${request.id}/`, {
        data: request.body,
      });
    },
    deleteByProduct: (request: DeleteByProduct): HttpPromise<any> => {
      return httpClient.patch(`/api/additive/${request.id}/`, {
        data: request,
      });
    },
    statusAdditive: (request: StatusAdditive): HttpPromise<any> => {
      return httpClient.get(`api/additive/${request.id}/change_status/`);
    },
    getSearchedFilter: (request: SearchMaterialName): HttpPromise<GetAllAdditiveResponse> => {
      return httpClient.get(
        `/api/additive/get-material-name-list/?search=${request.material_name}`
      );
    },
    getByProductMaterialExcel: (id: string | null): HttpPromise<GetAllAdditiveResponse> => {
      return httpClient.get(
        `/api/master/by-product-additional-information/${id}/?excel_download=true`
      );
    },
  };
};

export default ByProductService();
