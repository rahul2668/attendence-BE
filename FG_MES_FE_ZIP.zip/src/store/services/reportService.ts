import httpClient from 'http/httpClient';
import { jwtDecode } from 'jwt-decode';
import { CustomJwtPayload } from 'types/auth.model';
import { Reports } from 'types/reports.model';
import { getSessionStorage } from 'utils/utils';

const ReportsService = (): Reports => {
  let localUserData: any;
  const token: any = getSessionStorage('accessToken');
  const decoded: CustomJwtPayload | null = token ? jwtDecode(token) : null;
  const userData = decoded?.user_data;

  if (userData !== null) {
    localUserData = userData;
  } else {
    localUserData = {};
  }
  return {
    getMaterialCategories: (): HttpPromise<any> => {
      return httpClient.get('/api/dashboard/lab_analysis/material_category_list/');
    },
    getMaterialTypes(materialCategoryId: any): HttpPromise<any> {
      return httpClient.post('/api/dashboard/lab_analysis/material_type_list/', {
        data: {
          category_id: materialCategoryId,
        },
      });
    },
    deleteVariantById(variantId, variantName, userName): HttpPromise<any> {
      return httpClient.put('/api/dashboard/lab_analysis/variant_delete/', {
        data: {
          variant_id: variantId,
          variant_name: variantName,
          user_name: userName,
        },
      });
    },
    getVariantDetailsById(variantsId): HttpPromise<any> {
      return httpClient.post('/api/dashboard/lab_analysis/variant_get/', {
        data: { variant_id: variantsId },
      });
    },

    getMaterialIds(materialTypeId): HttpPromise<any> {
      return httpClient.post('/api/dashboard/lab_analysis/material_master_list/', {
        data: { type_id: materialTypeId },
      });
    },
    getVariants(): HttpPromise<any> {
      return httpClient.post('/api/dashboard/lab_analysis/variant_list/', {
        data: { user_name: localUserData?.username },
      });
    },
    variantSaveService(payload): HttpPromise<any> {
      return httpClient.post('/api/dashboard/lab_analysis/variant_save/', { data: payload });
    },
    reportOptionsService(materialCategory, materialType, materialId): HttpPromise<any> {
      return httpClient.post('/api/dashboard/lab_analysis/report_option/', {
        data: {
          category_id: materialCategory,
          type_id: materialType,
          material_id: materialId,
        },
      });
    },

    getReport(payload: any): HttpPromise<any> {
      return httpClient.post('/api/dashboard/lab_analysis/report_generate/', { data: payload });
    },
  };
};

export default ReportsService();
