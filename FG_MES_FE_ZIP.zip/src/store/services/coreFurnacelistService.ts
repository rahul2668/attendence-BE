import httpClient from 'http/httpClient';
import {
  GetAllCoreFurnaceListResponse,
  CoreFurnaceListService as IFurnaceBedService,
} from 'types/coreFurnaceList.model';

const CoreFurnaceListService = (): IFurnaceBedService => {
  return {
    getCoreFurnaceListDetails: (): HttpPromise<GetAllCoreFurnaceListResponse> => {
      return httpClient.get(`/api/log/get-all-furnace/`);
    },
  };
};

export default CoreFurnaceListService();
