import httpClient from 'http/httpClient';
import {
  GetAllFurnaceBedResponse,
  FurnaceBedService as IFurnaceBedService,
} from 'types/furnaceBed.model';

const FurnaceBedService = (): IFurnaceBedService => {
  return {
    getFurnaceBedDetailsList: (id: string | null): HttpPromise<GetAllFurnaceBedResponse> => {
      return httpClient.get(`/api/log/furnacebed/?${id}`);
    },
    getFurnaceBedDetails: (id: string | number | null): HttpPromise<GetAllFurnaceBedResponse> => {
      return httpClient.get(`/api/log/furnacebed/${id}/`);
    },
    deleteFurnaceBedDetails: (
      id: string | number | null
    ): HttpPromise<GetAllFurnaceBedResponse> => {
      return httpClient.patch(`/api/log/furnacebed/${id}/`);
    },
    getRadioFurnaceBedDetails: (): HttpPromise<GetAllFurnaceBedResponse> => {
      return httpClient.get(`/api/log/furnacebed-radios/`);
    },
    createFurnaceBedDetails: (
      request: GetAllFurnaceBedResponse
    ): HttpPromise<GetAllFurnaceBedResponse> => {
      return httpClient.post(`/api/log/furnacebed/`, {
        data: request,
      });
    },
    updateFurnaceBedDetails: (
      request: GetAllFurnaceBedResponse
    ): HttpPromise<GetAllFurnaceBedResponse> => {
      return httpClient.put(`/api/log/furnacebed/${request.id}`, {
        data: request.body,
      });
    },
  };
};

export default FurnaceBedService();
