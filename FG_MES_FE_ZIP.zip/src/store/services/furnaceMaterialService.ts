import httpClient from 'http/httpClient';
import {
  GetAllFurnaceMaterialResponse,
  FurnaceMaterialService as IFurnaceMaterialService,
  CloneMaterial,
  DeleteFurnaceMaterial,
  EditFurnaceMaterial,
  FurnaceFeatures,
  SearchMaterialName,
  StatusFurnaceMaterial,
  MaterialTypeParams,
} from 'types/furnacematerial.model';
import { isEmpty } from 'utils/utils';

const FurnaceMaterialService = (): IFurnaceMaterialService => {
  return {
    getFurnaceMaterialDetails: (id: string | null): HttpPromise<GetAllFurnaceMaterialResponse> => {
      return httpClient.get(`/api/master/furnace-additional-information/${id}/`);
    },
    getFurnaceMaterialSpecificationDetails: (
      id: string | null
    ): HttpPromise<GetAllFurnaceMaterialResponse> => {
      return httpClient.get(`/api/master/furnace-material-specification-step2/${id}/`);
    },
    getWipMaterialSpecificationDetails: (
      id: string | null
    ): HttpPromise<GetAllFurnaceMaterialResponse> => {
      return httpClient.get(`/api/master/wip-material-specification-step2/${id}/`);
    },
    getByProductsSpecificationDetails: (
      id: string | null
    ): HttpPromise<GetAllFurnaceMaterialResponse> => {
      return httpClient.get(`/api/master/by-product-material-specification-step2/${id}/`);
    },
    getAdditiveSpecificationDetails: (
      id: string | null
    ): HttpPromise<GetAllFurnaceMaterialResponse> => {
      return httpClient.get(`/api/master/additive-material-specification-step2/${id}/`);
    },
    getFurnaceMaterialList: (request: string): HttpPromise<GetAllFurnaceMaterialResponse> => {
      return httpClient.get(`/api/materials/?${request}`);
    },
    getFurnaceMaterialExcel: (id: string | null): HttpPromise<GetAllFurnaceMaterialResponse> => {
      return httpClient.get(
        `/api/master/furnace-additional-information/${id}/?excel_download=true`
      );
    },
    getSort_FilteredFurnacedList: (
      request: FurnaceFeatures
    ): HttpPromise<GetAllFurnaceMaterialResponse> => {
      let url = `/api/furnacematerial/?page_size=10&page=${request.page}`;
      if (!isEmpty(request.ordering)) {
        url = url + `&ordering=${request.ordering}`;
      }
      if (!isEmpty(request.search)) {
        url = url + `&search=${request.search}`;
      }
      if (!isEmpty(request.is_active)) {
        url = url + `&is_active=${request.is_active}`;
      }
      if (!isEmpty(request.material_name)) {
        url = url + `&id__in=${request.material_name}`;
      }
      return httpClient.get(url);
    },
    editFurnaceMaterial: (request: EditFurnaceMaterial): HttpPromise<any> => {
      return httpClient.post(`/api/master/furnace-additional-information/${request.id}/`, {
        data: request.body,
      });
    },
    editFurnaceMaterialSpecificationDetails: (request: EditFurnaceMaterial): HttpPromise<any> => {
      return httpClient.put(`/api/master/furnace-material-specification-step2/${request.id}/`, {
        data: request.body,
      });
    },
    editWipMaterialSpecificationDetails: (request: EditFurnaceMaterial): HttpPromise<any> => {
      return httpClient.put(`/api/master/wip-material-specification-step2/${request.id}/`, {
        data: request.body,
      });
    },
    editAdditiveSpecificationDetails: (request: EditFurnaceMaterial): HttpPromise<any> => {
      return httpClient.put(`/api/master/additive-material-specification-step2/${request.id}/`, {
        data: request.body,
      });
    },
    editByProductsSpecificationDetails: (request: EditFurnaceMaterial): HttpPromise<any> => {
      return httpClient.put(`/api/master/by-product-material-specification-step2/${request.id}/`, {
        data: request.body,
      });
    },
    getSearchedFilter: (
      request: SearchMaterialName
    ): HttpPromise<GetAllFurnaceMaterialResponse> => {
      return httpClient.get(
        `/api/furnacematerial/get-material-name-list/?search=${request.material_name}`
      );
    },
    deleteFurnaceMaterial: (request: DeleteFurnaceMaterial): HttpPromise<any> => {
      return httpClient.patch(`/api/furnacematerial/${request.id}/`, {
        data: request,
      });
    },
    statusFurnaceMaterial: (request: StatusFurnaceMaterial): HttpPromise<any> => {
      return httpClient.get(`/api/furnacematerial/${request.id}/change_status/`);
    },
    getListData: (): HttpPromise<any> => {
      return httpClient.get('/api/furnacematerial/');
    },
    getCloneMaterial: (request: CloneMaterial): HttpPromise<any> => {
      return httpClient.post(`/api/furnacematerial/${request.id}/clone/`, {
        data: request,
      });
    },
    createClonedMaterial: (
      request: GetAllFurnaceMaterialResponse
    ): HttpPromise<GetAllFurnaceMaterialResponse> => {
      let material_master_id = request.id;
      delete request.id;
      return httpClient.post(`/api/master/furnace-additional-information/${material_master_id}/`, {
        data: request,
      });
    },
    getMaterialTypes: (materialTypeParams: MaterialTypeParams): HttpPromise<any> => {
      return httpClient.get('/api/material-type/', {
        params: { ...materialTypeParams },
      });
    },
    getSizeDropdown: (): HttpPromise<GetAllFurnaceMaterialResponse> => {
      return httpClient.get(`/api/material/size-dropdown/`);
    },
  };
};

export default FurnaceMaterialService();
