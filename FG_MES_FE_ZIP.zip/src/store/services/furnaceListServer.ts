import httpClient from 'http/httpClient';

const GetFurnaceListData = () => {
  return {
    getFurnaceConfigList: (): HttpPromise => {
      return httpClient.get(`/api/furnace-config/furnace-no-list/`);
    },
  };
};

export default GetFurnaceListData();
