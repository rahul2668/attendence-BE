import httpClient from 'http/httpClient';
import {
  Login,
  CreateUser,
  AuthService as IAuthService,
  ChangePassword,
  SsoLogin,
} from 'types/auth.model';

const AuthService = (): IAuthService => {
  return {
    userLogin: (request: Login): HttpPromise<any> => {
      return httpClient.post('/api/account/simple-login/', {
        data: request,
      });
    },
    userLoginSSO: (request: SsoLogin): HttpPromise<any> => {
      return httpClient.post('/api/account/sso-login/', {
        data: request,
      });
    },
    userLogout: (): HttpPromise<any> => {
      return httpClient.post('/api/account/logout/', {});
    },
    refreshToken: (): HttpPromise<any> => {
      return httpClient.post('/api/account/refresh-token/', {});
    },
    getSSOLoginCredentials: (): HttpPromise<any> => {
      return httpClient.get('/api/account/sso-login-credentials/');
    },
    createUser: (request: CreateUser): HttpPromise<any> => {
      return httpClient.post('/api/users/', {
        data: request,
      });
    },
    getAuthToken: (request: Login): HttpPromise<any> => {
      return (
        httpClient.post('/api/auth-token/'),
        {
          data: request,
        }
      );
    },
    changePassword: (request: ChangePassword): HttpPromise<any> => {
      return httpClient.post('/api/account/change-password/', {
        data: request,
      });
    },
    getPlantLanguage: (): HttpPromise<any> => {
      return httpClient.get('/api/account/get-plant-language/');
    },
  };
};
export default AuthService();
