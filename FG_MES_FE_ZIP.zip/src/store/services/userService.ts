import httpClient from 'http/httpClient';
import {
  GetAllUsersResponse,
  UserService as IUserService,
  GetUsersListInput,
  AddUserInput,
  AddUserResponse,
} from 'types/user.model';

const UserService = (): IUserService => {
  return {
    getUsersList: (request: GetUsersListInput): HttpPromise<GetAllUsersResponse> => {
      return httpClient.get(`/api/users/?page_size=${request.page_size}`);
    },
    addUser: (request: AddUserInput): HttpPromise<AddUserResponse> => {
      return httpClient.post(`/api/users/`, {
        data: request,
      });
    },
  };
};

export default UserService();
