import httpClient from 'http/httpClient';
import {
  GetRolesResponse,
  RoleServiceModel,
  GetRoleDetailsResponse,
  GetRoleDetailsRequest,
} from 'types/role.model';

const RoleService = (): RoleServiceModel => {
  return {
    getRoles: (): HttpPromise<GetRolesResponse> => {
      return httpClient.get('/api/roles/');
    },
    getRoleDetails: (request: GetRoleDetailsRequest): HttpPromise<GetRoleDetailsResponse> => {
      // return httpClient.post(`/api/users/get_permission_data/`, { data: request });
      return httpClient.post(`/api/account/get_permission_data/`, { data: request });
    },
    editRole: (request: any): HttpPromise<any> => {
      // return httpClient.post(`/api/users/edit_role/`, {
      //   data: request,
      // });
      return httpClient.post(`/api/account/edit_role/`, { data: request });
    },
    deleteRole: (request: any): HttpPromise<any> => {
      return httpClient.patch(`/api/material/${request.id}`, {
        data: request,
      });
    },
    createRole: (request: any): HttpPromise<any> => {
      // return httpClient.post('/api/users/create_role/', { data: request });
      return httpClient.post('/api/account/create_role/', { data: request });
    },
  };
};

export default RoleService();
