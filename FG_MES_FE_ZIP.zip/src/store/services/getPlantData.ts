import httpClient from 'http/httpClient';
import { jwtDecode } from 'jwt-decode';
import { CustomJwtPayload } from 'types/auth.model';
import { getSessionStorage } from 'utils/utils';

const GetPlantConfigData = () => {
  const token: string | null = getSessionStorage('accessToken');
  const decoded: CustomJwtPayload | null = token ? jwtDecode(token) : null;
  const plantDataString = decoded?.plant_data;
  const plant: any = plantDataString ?? null;

  const plant_id: any = plant?.plant_id;

  return {
    getPlantConfig: (): HttpPromise => {
      return httpClient.get(`/api/plant/plant-config/${plant_id}/`);
    },
    getPlantExcel(): HttpPromise<APIResponse> {
      return httpClient.get(`/api/plant/parameter-excel-download/${plant_id}/`);
    },
  };
};

export default GetPlantConfigData();
