import httpClient from 'http/httpClient';
import { jwtDecode } from 'jwt-decode';
import { CustomJwtPayload } from 'types/auth.model';
import { SizeReports } from 'types/sizeReport.model';
import { getSessionStorage } from 'utils/utils';

let localUserData: any;
const token: any = getSessionStorage('accessToken');
const decoded: CustomJwtPayload | null = token ? jwtDecode(token) : null;
const userData = decoded?.user_data;

if (userData !== null) {
  localUserData = userData;
} else {
  localUserData = {};
}

const SizeReportsService = (): SizeReports => {
  return {
    getSizeMaterialCategories: (): HttpPromise<any> => {
      return httpClient.get('/api/dashboard/size_lab_analysis/material_category_list/');
    },
    getSizeMaterialTypes(materialCategoryId: any): HttpPromise<any> {
      return httpClient.post('/api/dashboard/size_lab_analysis/material_type_list/', {
        data: {
          category_id: materialCategoryId,
        },
      });
    },
    deleteSizeVariantById(variantId: any, variantName: any, userName: any): HttpPromise<any> {
      return httpClient.put('/api/dashboard/size_lab_analysis/variant_delete/', {
        data: {
          variant_id: variantId,
          variant_name: variantName,
          user_name: userName,
        },
      });
    },
    getSizeVariantDetailsById(variantsId: any): HttpPromise<any> {
      return httpClient.post('/api/dashboard/size_lab_analysis/variant_get/', {
        data: { variant_id: variantsId },
      });
    },
    getSizeMaterialIds(materialTypeId: any): HttpPromise<any> {
      return httpClient.post('/api/dashboard/size_lab_analysis/material_master_list/', {
        data: { type_id: materialTypeId },
      });
    },
    getSizeVariants(): HttpPromise<any> {
      return httpClient.post('/api/dashboard/size_lab_analysis/variant_list/', {
        data: { user_name: localUserData?.username },
      });
    },
    sizeVariantSaveService(payload: any): HttpPromise<any> {
      return httpClient.post('/api/dashboard/size_lab_analysis/variant_save/', { data: payload });
    },
    sizeReportOptionsService(
      materialCategory: any,
      materialType: any,
      materialId: any
    ): HttpPromise<any> {
      return httpClient.post('/api/dashboard/size_lab_analysis/report_option/', {
        data: {
          category_id: materialCategory,
          type_id: materialType,
          material_id: materialId,
        },
      });
    },
    getSizeReport(payload: any): HttpPromise<any> {
      return httpClient.post('/api/dashboard/size_lab_analysis/report_generate/', {
        data: payload,
      });
    },
  };
};

export default SizeReportsService();
