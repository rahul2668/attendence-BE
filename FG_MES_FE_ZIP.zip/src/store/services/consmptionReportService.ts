import httpClient from 'http/httpClient';
import { jwtDecode } from 'jwt-decode';
import { CustomJwtPayload } from 'types/auth.model';
import { ConsumptionReport } from 'types/consumptionReport.model';
import { getSessionStorage } from 'utils/utils';

const ConsumptionReportService = (): ConsumptionReport => {
  let localUserData: any;
  const token: string | null = getSessionStorage('accessToken');
  const decoded: CustomJwtPayload | null = token ? jwtDecode(token) : null;
  const userData = decoded?.user_data;

  if (userData !== null) {
    localUserData = userData;
  } else {
    localUserData = {};
  }
  return {
    furnanceList(): HttpPromise<any> {
      return httpClient.get('/api/dashboard/consumption/furnace_list/');
    },
    variantList(): HttpPromise<any> {
      return httpClient.post('/api/dashboard/consumption/variant_list/', {
        data: { user_name: localUserData?.username },
      });
    },
    deleteVariantById(variantId, variantName, userName): HttpPromise<any> {
      return httpClient.put('/api/dashboard/consumption/variant_delete/', {
        data: {
          variant_id: variantId,
          variant_name: variantName,
          user_name: userName,
        },
      });
    },
    fetchVariantDetailsById(variantId): HttpPromise<any> {
      return httpClient.post('/api/dashboard/consumption/variant_get/', {
        data: { variant_id: variantId },
      });
    },
    consumptionvariantsave(payload): HttpPromise<any> {
      return httpClient.post('/api/dashboard/consumption/variant_save/', { data: payload });
    },
    getMaterialTypes(materialCategoryId: any): HttpPromise<any> {
      return httpClient.post('/api/dashboard/consumption/material_type_list/', {
        data: {
          category_id: materialCategoryId,
        },
      });
    },
    getMaterialIds(materialTypeId): HttpPromise<any> {
      return httpClient.post('/api/dashboard/consumption/material_master_list/', {
        data: { type_id: materialTypeId },
      });
    },
    fetchConsumptionReport(payload): HttpPromise<any> {
      return httpClient.post('/api/dashboard/consumption/report_generate/', {
        data: payload,
      });
    },
    getMaterialCategories: (): HttpPromise<any> => {
      return httpClient.get('/api/dashboard/consumption/material_category_list/');
    },
  };
};

export default ConsumptionReportService();
