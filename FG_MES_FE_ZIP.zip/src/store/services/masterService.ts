import httpClient from 'http/httpClient';

const GetMasterData = () => {
  return {
    getMaster: (): HttpPromise => {
      return httpClient.get(`/api/master/master/`);
    },
  };
};

export default GetMasterData();
