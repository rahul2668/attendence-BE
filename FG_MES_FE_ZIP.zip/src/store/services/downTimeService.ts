import httpClient from 'http/httpClient';
import {
  GetAllFurnaceDownTimeResponse,
  FurnaceDownTimeService as IFurnaceDownTimeService,
} from 'types/downTime.model';

const FurnaceDownTimeService = (): IFurnaceDownTimeService => {
  return {
    getFurnaceDownTimeDetailsList: (
      id: string | null
    ): HttpPromise<GetAllFurnaceDownTimeResponse> => {
      return httpClient.get(`/api/log/furnace-downtime/?${id}`);
    },
    getFurnaceDownTimeEventDetails: (
      id: string | number | null
    ): HttpPromise<GetAllFurnaceDownTimeResponse> => {
      return httpClient.get(`/api/log/furnace-downtime/${id}/`);
    },
    getFurnaceDownTimeSplitDetails: (
      id: string | number | null
    ): HttpPromise<GetAllFurnaceDownTimeResponse> => {
      return httpClient.get(`/api/log/furnace-downtime-split/${id}/`);
    },
    deleteFurnaceDownTimeEvent: (
      id: string | number | null
    ): HttpPromise<GetAllFurnaceDownTimeResponse> => {
      return httpClient.patch(`/api/log/furnace-downtime/${id}/`);
    },
    deleteFurnaceDownTimeSplit: (
      id: string | number | null
    ): HttpPromise<GetAllFurnaceDownTimeResponse> => {
      return httpClient.patch(`/api/log/furnace-downtime-split/${id}/`);
    },
    getRadioFurnaceDownTimeDetails: (): HttpPromise<GetAllFurnaceDownTimeResponse> => {
      return httpClient.get(`/api/log/furnace-downtime-type-master/`);
    },
    createFurnaceDownTimeEventDetails: (
      request: GetAllFurnaceDownTimeResponse
    ): HttpPromise<GetAllFurnaceDownTimeResponse> => {
      return httpClient.post(`/api/log/furnace-downtime/`, {
        data: request,
      });
    },
    createFurnaceDownTimeSplitDetails: (
      request: GetAllFurnaceDownTimeResponse
    ): HttpPromise<GetAllFurnaceDownTimeResponse> => {
      return httpClient.post(`/api/log/furnace-downtime-split/`, {
        data: request,
      });
    },
    updateFurnaceDownTimeEventDetails: (
      request: GetAllFurnaceDownTimeResponse
    ): HttpPromise<GetAllFurnaceDownTimeResponse> => {
      return httpClient.put(`/api/log/furnace-downtime/${request.id}`, {
        data: request.body,
      });
    },
    updateFurnaceDownTimeSplitDetails: (
      request: GetAllFurnaceDownTimeResponse
    ): HttpPromise<GetAllFurnaceDownTimeResponse> => {
      return httpClient.put(`/api/log/furnace-downtime-split/${request.id}`, {
        data: request.body,
      });
    },
    getFurnaceDownTimeEquipment: (
      id: string | number | null
    ): HttpPromise<GetAllFurnaceDownTimeResponse> => {
      return httpClient.get(`/api/log/furnace-downtime-equipment-master/${id}/`);
    },
    getFurnaceDownTimeReason: (
      id: string | number | null
    ): HttpPromise<GetAllFurnaceDownTimeResponse> => {
      return httpClient.get(`/api/log/furnace-downtime-reasons/${id}/`);
    },
  };
};

export default FurnaceDownTimeService();
