import httpClient from 'http/httpClient';
import { LazyLoadService, LazyLoadedFurnaceProductResponse } from 'types/lazyLoad.modal';

const GetLazyLoadData = (): LazyLoadService => {
  return {
    getProductCodes: (
      searchKey?: string,
      otherParams?: any
    ): HttpPromise<LazyLoadedFurnaceProductResponse> => {
      return httpClient.get('/api/furnace-config/product-code/', {
        params: { search_key: searchKey, ...(otherParams ? otherParams : {}) },
      });
    },
  };
};

export default GetLazyLoadData();
