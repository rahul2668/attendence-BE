import { buildDropdownOptions, buildMaterialIdCompareDropdown } from 'utils/utils';

interface State {
  furnanceList: any[];
  variantList: any[];
  variantdetailsById: string;
  matGraphs: any;
  materialCategories: any;
  materialTypes: any;
  materialIds: any;
  materialIdsForSelection: any;
  materialTypesCompare: any;
  timezone: string;
}

const initialState: State = {
  furnanceList: [],
  variantList: [],
  variantdetailsById: '',
  matGraphs: [],
  materialCategories: [],
  materialTypes: [],
  materialIds: [],
  materialIdsForSelection: [],
  materialTypesCompare: [],
  timezone: '',
};

const ConsumptionReducer = (state: State = initialState, action: any) => {
  switch (action.type) {
    case 'FURNANCE_FETCH_SUCCESS': {
      return {
        ...state,
        furnanceList: buildDropdownOptions(action.payload, 'furnace_no', 'furnace_description'),
      };
    }
    case 'VARIANT_FETCH_SUCCESS': {
      return {
        ...state,
        variantList: buildDropdownOptions(action.payload, 'variant_id', 'variant_name'),
      };
    }
    case 'VARIANT_FETCH_BY_ID_SUCCESS': {
      return {
        ...state,
        variantdetailsById: action.payload,
      };
    }
    case 'SET_CONSUMPTION_MAT_GRAPH': {
      return {
        ...state,
        matGraphs: action.payload,
      };
    }
    case 'MATERIAL_CONSUMPTION_CATEGORY_FETCH_SUCCESS': {
      return {
        ...state,
        materialCategories: buildDropdownOptions(action.payload, 'category_code', 'category_name'),
      };
    }
    case 'MATERIAL_CONSUMPTION_TYPE_FETCH_SUCCESS': {
      return {
        ...state,
        materialTypes: buildDropdownOptions(action.payload, 'type_code', 'type_name'),
      };
    }
    case 'MATERIAL_CONSUMPTION_ID_FETCH_SUCCESS': {
      return {
        ...state,
        materialIds: buildDropdownOptions(action.payload, 'material_id', 'material_code_name'),
        materialIdsForSelection: state.materialIdsForSelection.concat(
          buildDropdownOptions(action.payload, 'material_id', 'material_code_name')
        ),
      };
    }
    case 'MATERIAL_CONSUMPTION_ID_COMPARE_FETCH_SUCCESS': {
      return {
        ...state,
        materialTypesCompare: buildMaterialIdCompareDropdown(
          action.payload,
          'material_id',
          'material_code_name'
        ),
      };
    }
    case 'SET_TIMEZONE': {
      return {
        ...state,
        timeZone: action.payload,
      };
    }
    default: {
      return {
        ...state,
      };
    }
  }
};

export default ConsumptionReducer;
