import { buildDropdownOptions, buildMaterialIdCompareDropdown } from 'utils/utils';

interface State {
  materialCategories: any[];
  materialIds: any[];
  materialTypes: any[];
  reportOptions: any[];
  VariantsList: any[];
  variantDetails: string;
  Error: string;
  variant: string;
  loader: boolean;
  matGraphs: any[];
  materialTypesCompare: any[];
  reportOptionsHeadings: any[];
  materialIdsForSelection: any[];
}
const initialState: State = {
  materialCategories: [],
  materialIds: [],
  materialIdsForSelection: [],
  materialTypes: [],
  reportOptions: [],
  VariantsList: [],
  variantDetails: '',
  Error: '',
  variant: '',
  loader: false,
  matGraphs: [],
  materialTypesCompare: [],
  reportOptionsHeadings: [],
};

const ReportReducer = (state = initialState, action: any) => {
  switch (action.type) {
    case 'MATERIAL_CATEGORY_FETCH_SUCCESS': {
      return {
        ...state,
        materialCategories: buildDropdownOptions(action.payload, 'category_code', 'category_name'),
      };
    }

    case 'MATERIAL_CATEGORY_FETCH_FAILURE': {
      return {
        ...state,
        error: action.payload,
      };
    }
    case 'MATERIAL_TYPE_FETCH_SUCCESS': {
      return {
        ...state,
        materialTypes: buildDropdownOptions(action.payload, 'type_code', 'type_name'),
      };
    }
    case 'MATERIAL_TYPE_FETCH_FAILURE': {
      return {
        ...state,
        error: action.payload,
      };
    }
    case 'MATERIAL_ID_FETCH_SUCCESS': {
      return {
        ...state,
        materialIds: buildDropdownOptions(action.payload, 'mes_mat_code', 'material_code_name'),
        materialIdsForSelection: state.materialIdsForSelection.concat(
          buildDropdownOptions(action.payload, 'mes_mat_code', 'material_code_name')
        ),
      };
    }
    case 'VARIANT_SAVE_SUCCESS': {
      return {
        ...state,
        variant: action.payload,
      };
    }
    case 'VARIANTS_FETCH_SUCCESS': {
      return {
        ...state,
        VariantsList: buildDropdownOptions(action.payload, 'variant_id', 'variant_name'),
      };
    }
    case 'VARIANT_DETAILS_FETCH_SUCCESS': {
      return {
        ...state,
        variantDetails: action.payload,
      };
    }
    case 'MATERIAL_ID_COMPARE_FETCH_SUCCESS': {
      return {
        ...state,
        materialTypesCompare: buildMaterialIdCompareDropdown(
          action.payload,
          'mes_mat_code',
          'material_code_name'
        ),
      };
    }

    case 'VARIANT_SAVE_FAILURE': {
      return {
        ...state,
        Error: action.payload,
      };
    }
    case 'REPORT_FETCH_SUCCESS': {
      let data = reportDataOptions(action.payload);
      return {
        ...state,
        reportOptions: data.reportOptions,
        reportOptionsHeadings: data.reportOptionsHeadings,
      };
    }
    case 'SET_MAT_GRAPH': {
      return {
        ...state,
        matGraphs: action.payload,
      };
    }
    default: {
      return { ...state };
    }
  }
};

export default ReportReducer;

function reportDataOptions(data: any): any {
  let reportOptions: any[] = [];
  let reportOptionHeadings: any[] = [];

  data.forEach((group: any) => {
    let heading = {
      option: group.group_name,
      value: group.group_id,
    };
    reportOptionHeadings.push(heading.option);
    reportOptions.push(heading);

    group.elements.forEach((element: any) => {
      let options = {
        option: element.element_name,
        value: element.element_id,
      };
      reportOptions.push(options);
    });
  });
  return { reportOptions: reportOptions, reportOptionsHeadings: reportOptionHeadings };
}

/*function reportDataOptions(data:any):any{
    let reportOptions: any[]=[];
    let reportOptionHeadings: any[]=[]
   let keyValues = Object.entries(data);
   
   keyValues.forEach((elementMain: any[]) => {
    console.log(elementMain);
    for (let index = 0; index < elementMain.length; index++) {
        if(index===0){
            let options={
                option:elementMain[index],
                value:elementMain[index]
            }
            reportOptionHeadings.push(elementMain[index]);
        reportOptions.push(options);
        }
        else{
            elementMain[index].forEach((element: any) => {
                let options={
                    option:element,
                    value:element
                }
            reportOptions.push(options);
            });
        }
    }
    
  });

  return reportOptions;
  }*/
