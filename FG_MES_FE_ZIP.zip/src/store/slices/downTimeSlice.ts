import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import furnaceDownTimeService from 'store/services/downTimeService';

export interface DownTimeSlice {
  loading: boolean;
  error: any;
  results: [];
  furnaceDownTime: any;
}
const initState: DownTimeSlice = {
  loading: false,
  error: null,
  results: [],
  furnaceDownTime: {},
};
export const getFurnaceDownTimeList = createAsyncThunk(
  'furnaceDownTime/getFurnaceDownTimeList',
  furnaceDownTimeService.getFurnaceDownTimeDetailsList
);

export const createFurnaceDownTimeEvent = createAsyncThunk(
  'furnaceDownTime/createFurnaceDownTimeEvent',
  furnaceDownTimeService.createFurnaceDownTimeEventDetails
);
export const createFurnaceDownTimeSplit = createAsyncThunk(
  'furnaceDownTime/createFurnaceDownTimeSplit',
  furnaceDownTimeService.createFurnaceDownTimeSplitDetails
);
export const updateFurnaceDownTimeEvent = createAsyncThunk(
  'furnaceDownTime/updateFurnaceDownTimeEvent',
  furnaceDownTimeService.updateFurnaceDownTimeEventDetails
);
export const updateFurnaceDownTimeSplit = createAsyncThunk(
  'furnaceDownTime/updateFurnaceDownTimeSplit',
  furnaceDownTimeService.updateFurnaceDownTimeSplitDetails
);
export const getRadioFurnaceDownTime = createAsyncThunk(
  'furnaceDownTime/getRadioFurnaceDownTime',
  furnaceDownTimeService.getRadioFurnaceDownTimeDetails
);
export const getFurnaceDownTimeEvent = createAsyncThunk(
  'furnaceDownTime/getFurnaceDownTimeEvent',
  furnaceDownTimeService.getFurnaceDownTimeEventDetails
);
export const getFurnaceDownTimeSplit = createAsyncThunk(
  'furnaceDownTime/getFurnaceDownTimeSplit',
  furnaceDownTimeService.getFurnaceDownTimeSplitDetails
);
export const deleteFurnaceDownTimeEvent = createAsyncThunk(
  'furnaceDownTime/deleteFurnaceDownTimeEvent',
  furnaceDownTimeService.deleteFurnaceDownTimeEvent
);
export const deleteFurnaceDownTimeSplit = createAsyncThunk(
  'furnaceDownTime/deleteFurnaceDownTimeSplit',
  furnaceDownTimeService.deleteFurnaceDownTimeSplit
);
export const getFurnaceDownReason = createAsyncThunk(
  'furnaceDownTime/getFurnaceDownReason',
  furnaceDownTimeService.getFurnaceDownTimeReason
);
export const getFurnaceDownEquipment = createAsyncThunk(
  'furnaceDownTime/getFurnaceDownEquipment',
  furnaceDownTimeService.getFurnaceDownTimeEquipment
);

const FurnaceBedSlice = createSlice({
  name: 'furnaceDownTime',
  initialState: initState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getFurnaceDownTimeList.pending, (state) => {
        state.loading = true;
      })
      .addCase(getFurnaceDownTimeList.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.results = action.payload.data;
      })
      .addCase(getFurnaceDownTimeList.rejected, (state, action) => {
        state.loading = false;
        state.results = [];
        state.error = action.payload;
      });
    builder
      .addCase(createFurnaceDownTimeEvent.pending, (state) => {
        state.loading = true;
      })
      .addCase(createFurnaceDownTimeEvent.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.results = action.payload.data;
      })
      .addCase(createFurnaceDownTimeEvent.rejected, (state, action) => {
        state.loading = false;
        state.results = [];
        state.error = action.payload;
      });
    builder
      .addCase(createFurnaceDownTimeSplit.pending, (state) => {
        state.loading = true;
      })
      .addCase(createFurnaceDownTimeSplit.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.results = action.payload.data;
      })
      .addCase(createFurnaceDownTimeSplit.rejected, (state, action) => {
        state.loading = false;
        state.results = [];
        state.error = action.payload;
      });
    builder
      .addCase(updateFurnaceDownTimeEvent.pending, (state) => {
        state.loading = true;
      })
      .addCase(updateFurnaceDownTimeEvent.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.results = action.payload.data;
      })
      .addCase(updateFurnaceDownTimeEvent.rejected, (state, action) => {
        state.loading = false;
        state.results = [];
        state.error = action.payload;
      });
    builder
      .addCase(updateFurnaceDownTimeSplit.pending, (state) => {
        state.loading = true;
      })
      .addCase(updateFurnaceDownTimeSplit.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.results = action.payload.data;
      })
      .addCase(updateFurnaceDownTimeSplit.rejected, (state, action) => {
        state.loading = false;
        state.results = [];
        state.error = action.payload;
      });
    builder
      .addCase(getRadioFurnaceDownTime.pending, (state) => {
        state.loading = true;
      })
      .addCase(getRadioFurnaceDownTime.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.results = action.payload.data;
      })
      .addCase(getRadioFurnaceDownTime.rejected, (state, action) => {
        state.loading = false;
        state.results = [];
        state.error = action.payload;
      });
    builder
      .addCase(getFurnaceDownTimeEvent.pending, (state) => {
        state.loading = true;
      })
      .addCase(getFurnaceDownTimeEvent.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.results = action.payload.data;
      })
      .addCase(getFurnaceDownTimeEvent.rejected, (state, action) => {
        state.loading = false;
        state.results = [];
        state.error = action.payload;
      });
    builder
      .addCase(getFurnaceDownTimeSplit.pending, (state) => {
        state.loading = true;
      })
      .addCase(getFurnaceDownTimeSplit.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.results = action.payload.data;
      })
      .addCase(getFurnaceDownTimeSplit.rejected, (state, action) => {
        state.loading = false;
        state.results = [];
        state.error = action.payload;
      });
    builder
      .addCase(deleteFurnaceDownTimeEvent.pending, (state) => {
        state.loading = true;
      })
      .addCase(deleteFurnaceDownTimeEvent.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.results = action.payload.data;
      })
      .addCase(deleteFurnaceDownTimeEvent.rejected, (state, action) => {
        state.loading = false;
        state.results = [];
        state.error = action.payload;
      });

    builder
      .addCase(deleteFurnaceDownTimeEvent.pending, (state) => {
        state.loading = true;
      })
      .addCase(deleteFurnaceDownTimeEvent.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.results = action.payload.data;
      })
      .addCase(deleteFurnaceDownTimeEvent.rejected, (state, action) => {
        state.loading = false;
        state.results = [];
        state.error = action.payload;
      });
    builder
      .addCase(getFurnaceDownReason.pending, (state) => {
        state.loading = true;
      })
      .addCase(getFurnaceDownReason.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.results = action.payload.data;
      })
      .addCase(getFurnaceDownReason.rejected, (state, action) => {
        state.loading = false;
        state.results = [];
        state.error = action.payload;
      });
  },
});

export default FurnaceBedSlice.reducer;
