import { Dispatch } from '@reduxjs/toolkit';
import reportService from 'store/services/reportService';
import { compareDates } from 'utils/utils';
export const MaterialCategoryAction = (): any => async (dispatch: Dispatch) => {
  return reportService.getMaterialCategories().then(
    (response: any) => {
      dispatch({
        type: 'MATERIAL_CATEGORY_FETCH_SUCCESS',
        payload: response.data,
      });

      return Promise.resolve(response.data);
    },
    (error: any) => {
      console.log(error);
      const message =
        (error.response && error.response.data && error.response.data.message) ||
        error.message ||
        error.toString();

      return Promise.reject(message);
    }
  );
};

export const variantsList = (): any => async (dispatch: Dispatch) => {
  return reportService.getVariants().then(
    (response: any) => {
      dispatch({
        type: 'VARIANTS_FETCH_SUCCESS',
        payload: response.data,
      });
      return Promise.resolve(response.data);
    },
    (error: any) => {
      console.log(error);
      const message =
        (error.response && error.response.data && error.response.data.message) ||
        error.message ||
        error.toString();

      return Promise.reject(message);
    }
  );
};

export const fetchReportAction =
  (payload: any): any =>
  async (dispatch: Dispatch) => {
    return reportService.getReport(payload).then(
      (response: any) => {
        //console.log(response);
        dispatch({
          type: 'SET_MAT_GRAPH',
          payload: response.data,
        });
        return Promise.resolve(response);
      },
      (error: any) => {
        const message =
          (error.response && error.response.data && error.response.data.message) ||
          error.message ||
          error.toString();
        dispatch({
          type: 'MATERIAL_TYPE_FETCH_FAILURE',
          payload: message,
        });
        return Promise.reject(message);
      }
    );
  };
export const materialTypeAction =
  (materialCategoryId: any): any =>
  async (dispatch: Dispatch) => {
    return reportService.getMaterialTypes(materialCategoryId).then(
      (response: any) => {
        dispatch({
          type: 'MATERIAL_TYPE_FETCH_SUCCESS',
          payload: response.data,
        });
        return Promise.resolve(response);
      },
      (error: any) => {
        const message =
          (error.response && error.response.data && error.response.data.message) ||
          error.message ||
          error.toString();
        dispatch({
          type: 'MATERIAL_TYPE_FETCH_FAILURE',
          payload: message,
        });
        return Promise.reject(message);
      }
    );
  };

export const materialIdAction =
  (materialTypeId: any): any =>
  async (dispatch: Dispatch) => {
    return reportService.getMaterialIds(materialTypeId).then(
      (response: any) => {
        dispatch({
          type: 'MATERIAL_ID_FETCH_SUCCESS',
          payload: response.data,
        });
        dispatch({
          type: 'MATERIAL_ID_COMPARE_FETCH_SUCCESS',
          payload: response.data,
        });
        return Promise.resolve(response);
      },
      (error: any) => {
        const message =
          (error.response && error.response.data && error.response.data.message) ||
          error.message ||
          error.toString();
        dispatch({
          type: 'MATERIAL_ID_FETCH_FAILURE',
          payload: message,
        });
        return Promise.reject(message);
      }
    );
  };

export const VariantSaveAction =
  (payload: any): any =>
  async (dispatch: Dispatch) => {
    return reportService.variantSaveService(payload).then(
      (response: any) => {
        dispatch({
          type: 'VARIANT_SAVE_SUCCESS',
          payload: response.data,
        });
        return Promise.resolve(response);
      },
      (error: any) => {
        const message =
          (error.response && error.response.data && error.response.data.message) ||
          error.message ||
          error.toString();
        dispatch({
          type: 'VARIANT_SAVE_FAILURE',
          payload: message,
        });
        return Promise.reject(message);
      }
    );
  };

export const VariantCloneAction =
  (variantData: any, compareRadio: any, checkToggle: any, privateVariant?: any): any =>
  async (dispatch: Dispatch) => {
    return reportService
      .variantSaveService(
        buildVariantClonepayload(variantData, compareRadio, checkToggle, privateVariant)
      )
      .then(
        (response: any) => {
          dispatch({
            type: 'VARIANT_CLONE_SUCCESS',
            payload: response.data,
          });
          return Promise.resolve(response);
        },
        (error: any) => {
          const message =
            (error.response && error.response.data && error.response.data.message) ||
            error.message ||
            error.toString();
          dispatch({
            type: 'VARIANT_CLONE_FAILURE',
            payload: message,
          });
          return Promise.reject(message);
        }
      );
  };

export const reportOptionsAction =
  (materialCategory: any, materialType: any, materialId: any): any =>
  async (dispatch: Dispatch) => {
    return reportService.reportOptionsService(materialCategory, materialType, materialId).then(
      (response: any) => {
        dispatch({
          type: 'REPORT_FETCH_SUCCESS',
          payload: response.data,
        });

        return Promise.resolve(response);
      },
      (error: any) => {
        const message =
          (error.response && error.response.data && error.response.data.message) ||
          error.message ||
          error.toString();
        dispatch({
          type: 'REPORT_FETCH_FAILURE',
          payload: message,
        });
        return Promise.reject(message);
      }
    );
  };

export const variantDeleteIdAction =
  (variantId: any, variantName: any, userName: any): any =>
  async (dispatch: Dispatch) => {
    return reportService.deleteVariantById(variantId, variantName, userName).then(
      (response: any) => {
        return Promise.resolve(response);
      },
      (error: any) => {
        const message =
          (error.response && error.response.data && error.response.data.message) ||
          error.message ||
          error.toString();
        dispatch({
          type: 'VARIANT_DELETE_FAILURE',
          payload: message,
        });
        return Promise.reject(message);
      }
    );
  };
export const variantFetchByIdAction =
  (variantId: any): any =>
  async (dispatch: Dispatch) => {
    return reportService.getVariantDetailsById(variantId).then(
      (response: any) => {
        // dispatch({
        //     type: 'VARIANT_DETAILS_FETCH_SUCCESS',
        //     payload: response.data
        // });

        return Promise.resolve(response);
      },
      (error: any) => {
        const message =
          (error.response && error.response.data && error.response.data.message) ||
          error.message ||
          error.toString();
        dispatch({
          type: 'VARIANT_DETAILS_FETCH_FAILURE',
          payload: message,
        });
        return Promise.reject(message);
      }
    );
  };

/*function buildVariantSavepayload(variantData: any, compareRadio: any, checkToggle: any, privateVariant: any) {
    let timeFlag = 'TimePeriod' === compareRadio?.compareDate;
    let materialFlag = 'Material' === compareRadio?.compareDate;
    let payload =
    {
        "variant_name": variantData?.VariantNameModalInput,
        "variant_id": variantData?.update_flag == true ? variantData?.variantId : '',
        "plant": "Beverly",
        "user_id": 1,
        "clone_flag": false,
        "report_save": {
            "update_flag": variantData.update_flag,
            "private": privateVariant,
            "material_category_id": variantData?.MaterialCategory,
            "material_type_id": variantData?.MaterialType,
            "material_number_id": variantData?.MaterialID,
            "supplier": variantData?.Supplier,
            "layout": variantData?.Layout,
            "granularity": "week",
            "date_range": variantData?.DateRange,
            "compare": checkToggle,
            "comapare_time_flag": timeFlag,
            "compare_time_period": variantData?.CompareDateRange,
            "compare_material_flag": materialFlag,
            "report_options": variantData?.reportSequence
        }
    };
    return payload;
}*/

const buildVariantClonepayload = (
  variantData: any,
  compareRadio: any,
  checkToggle: any,
  privateVarint: any
) => {
  let timeFlag = 'TimePeriod' === compareRadio?.compareDate;
  let materialFlag = 'Material' === compareRadio?.compareDate;
  console.log(compareDates(variantData?.DateRange?.selection2));
  let payload = {
    variant_name: variantData?.VariantNameModalInput,
    variant_id: '',
    plant: 'Beverly',
    user_id: 1,
    clone_flag: true,
    report_save: {
      update_flag: false,
      private: privateVarint,
      material_category_id: variantData?.MaterialCategory,
      material_type_id: variantData?.MaterialType,
      material_number_id: variantData?.MaterialID,
      supplier: variantData?.Supplier,
      layout: variantData?.Layout,
      granularity: variantData?.Granularity,
      date_range: compareDates(variantData?.DateRange?.selection2),
      compare: checkToggle,
      comapare_time_flag: timeFlag,
      compare_time_period: compareDates(variantData?.CompareDateRange?.selection1),
      compare_material_flag: materialFlag,
      report_options: variantData?.reportSequence,
    },
  };
  return payload;
};
