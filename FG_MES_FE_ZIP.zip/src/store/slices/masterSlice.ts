import GetMasterData from 'store/services/masterService';
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { UtilsMasterData } from 'types/plant.model';

export interface PlantSlice {
  loading: boolean;
  error: any;
  results: UtilsMasterData[];
  count: number;
}

const initState: PlantSlice = {
  loading: false,
  error: null,
  results: [],
  count: 0,
};

export const getMaster = createAsyncThunk('master/getMaster', GetMasterData.getMaster);

const MasterSlice = createSlice({
  name: 'master',
  initialState: initState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getMaster.pending, (state) => {
        state.loading = true;
      })
      .addCase(getMaster.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.results = action.payload.data;
      })
      .addCase(getMaster.rejected, (state, action) => {
        state.loading = false;
        state.results = [];
        state.error = action.payload;
      });
  },
});

export default MasterSlice.reducer;
