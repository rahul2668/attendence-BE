import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import byProductService from 'store/services/byProductService';

export interface byProductSlice {
  loading: boolean;
  error: any;
  additive: object;
  results: [];
  count: number;
  clonedMaterialData: object;
  byProductMaterialExcelList: [];
}
const initState: byProductSlice = {
  loading: false,
  error: null,
  additive: {},
  results: [],
  count: 0,
  clonedMaterialData: {},
  byProductMaterialExcelList: [],
};

export const getByProductDetails = createAsyncThunk(
  'byProduct/byProductDetails',
  async (id: string | null, { rejectWithValue }) => {
    try {
      const response = await byProductService.getByProductDetails(id);
      if (response.status === 200) {
        return response;
      } else {
        const errorResponse = await response.json();
        rejectWithValue(errorResponse);
        return response;
      }
    } catch (error: any) {
      rejectWithValue({ message: error.message });
      throw error;
    }
  }
);

export const getByProductList = createAsyncThunk(
  'byProduct/getByProductList',
  async (request: any, { rejectWithValue }) => {
    try {
      const response = await byProductService.getByProductList(request);
      if (response.status === 200) {
        return response;
      } else {
        const errorResponse = await response.json();
        rejectWithValue(errorResponse);
        return response;
      }
    } catch (error: any) {
      rejectWithValue({ message: error.message });
      throw error;
    }
  }
);

export const editByProduct = createAsyncThunk(
  'byProduct/editByProduct',
  byProductService.editByProduct
);
export const deleteByProduct = createAsyncThunk(
  'byProduct/deleteByProduct',
  async (request: any, { rejectWithValue }) => {
    try {
      const response = await byProductService.deleteByProduct(request);
      if (response.status === 200) {
        return response;
      } else {
        const errorResponse = await response.json();
        rejectWithValue(errorResponse);
        return response;
      }
    } catch (error: any) {
      rejectWithValue({ message: error.message });
      throw error;
    }
  }
);
export const getByProductMaterialExcel = createAsyncThunk(
  'additive/getByProductMaterialExcel',
  byProductService.getByProductMaterialExcel
);
export const statusAdditive = createAsyncThunk(
  'additive/statusAdditive',
  byProductService.statusAdditive
);
export const listFeatures = createAsyncThunk(
  'byProduct/byProductlistFeatures',
  byProductService.getSort_FilteredByProductList
);
export const cloneMaterial = createAsyncThunk(
  'additive/cloneMaterial',
  byProductService.getCloneMaterial
);
export const createMaterail = createAsyncThunk(
  'material/createMaterail',
  byProductService.createClonedMaterial
);
export const filterSearch = createAsyncThunk(
  'additive/filterSearch',
  byProductService.getSearchedFilter
);
const additiveSlice = createSlice({
  name: 'additive',
  initialState: initState,
  reducers: {
    clearCloneData: (state) => {
      state.clonedMaterialData = {};
    },
    setByProductMaterialExcelList(state, action) {
      state.byProductMaterialExcelList = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getByProductDetails.pending, (state) => {
        state.loading = true;
      })
      .addCase(getByProductDetails.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.additive = action.payload.data;
      })
      .addCase(getByProductDetails.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
    builder
      .addCase(getByProductList.pending, (state) => {
        state.loading = true;
      })
      .addCase(getByProductList.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.additive = action.payload.data;
      })
      .addCase(getByProductList.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(filterSearch.pending, (state) => {
        state.loading = true;
      })
      .addCase(filterSearch.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.additive = action.payload.data;
      })
      .addCase(filterSearch.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
    builder
      .addCase(cloneMaterial.pending, (state) => {
        state.loading = true;
      })
      .addCase(cloneMaterial.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.clonedMaterialData = action.payload.data;
      })
      .addCase(cloneMaterial.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
    builder
      .addCase(createMaterail.pending, (state) => {
        state.loading = true;
      })
      .addCase(createMaterail.fulfilled, (state) => {
        state.loading = false;
        state.error = null;
      })
      .addCase(createMaterail.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
    builder
      .addCase(editByProduct.pending, (state) => {
        state.loading = true;
      })
      .addCase(editByProduct.fulfilled, (state) => {
        state.loading = false;
        state.error = null;
      })
      .addCase(editByProduct.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
    builder
      .addCase(deleteByProduct.pending, (state) => {
        state.loading = true;
      })
      .addCase(deleteByProduct.fulfilled, (state) => {
        state.loading = false;
        state.error = null;
      })
      .addCase(deleteByProduct.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
    builder
      .addCase(statusAdditive.pending, (state) => {
        state.loading = true;
      })
      .addCase(statusAdditive.fulfilled, (state) => {
        state.loading = false;
        state.error = null;
      })
      .addCase(statusAdditive.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});
export const { clearCloneData, setByProductMaterialExcelList } = additiveSlice.actions;

export default additiveSlice.reducer;
