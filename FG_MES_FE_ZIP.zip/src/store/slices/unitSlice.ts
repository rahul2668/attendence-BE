import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import httpClient from 'http/httpClient';

export interface UnitSlice {
  units: any[];
  error: any;
  status: string;
}

const initState: UnitSlice = {
  units: [],
  error: null,
  status: 'idle',
};

export const getAllUnits = createAsyncThunk('units/getAllUnits', async () => {
  const response: any = await httpClient.get(`/api/units/`);
  return response.data;
});

const unitSlice = createSlice({
  name: 'units',
  initialState: initState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getAllUnits.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(getAllUnits.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.units = action?.payload;
      })
      .addCase(getAllUnits.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message;
      });
  },
});

export default unitSlice.reducer;
