import { createSlice } from '@reduxjs/toolkit';
import { UserData } from 'types/auth.model';

const UserDataSlice = createSlice({
  name: 'userData',
  initialState: {
    userData: {} as UserData,
  },
  reducers: {
    setUserData(state, action) {
      state.userData = action.payload;
    },
  },
});

// Extract the action creators object and the reducer
const { actions, reducer } = UserDataSlice;

// Extract and export each action creator by name
export const { setUserData } = actions;

// Export the reducer, either as a default or named export
export default reducer;
