import { Dispatch } from '@reduxjs/toolkit';
import ConsumptionReportService from 'store/services/consmptionReportService';

export const fetchVariantList = (): any => async (dispatch: any) => {
  return await ConsumptionReportService.variantList().then(
    (response: any) => {
      variantListDispatch(dispatch, response);
      return Promise.resolve(response);
    },
    (error: any) => {
      console.log(error);
      const message =
        (error.response && error.response.data && error.response.data.message) ||
        error.message ||
        error.toString();

      return Promise.reject(message);
    }
  );
};
export const variantDeleteIdAction =
  (variantId: any, variantName: any, userName: any): any =>
  async (dispatch: Dispatch) => {
    return ConsumptionReportService.deleteVariantById(variantId, variantName, userName).then(
      (response: any) => {
        return Promise.resolve(response);
      },
      (error: any) => {
        const message =
          (error.response && error.response.data && error.response.data.message) ||
          error.message ||
          error.toString();
        dispatch({
          type: 'VARIANT_CONS_DELETE_FAILURE',
          payload: message,
        });
        return Promise.reject(message);
      }
    );
  };
export const fetchvariantDetails =
  (variantId: string): any =>
  async (dispatch: Dispatch) => {
    return ConsumptionReportService.fetchVariantDetailsById(variantId).then(
      (response: any) => {
        variantDetailsByIdDispatch(dispatch, response);
        return Promise.resolve(response);
      },
      (error: any) => {
        console.log(error);
        const message =
          (error.response && error.response.data && error.response.data.message) ||
          error.message ||
          error.toString();

        return Promise.reject(message);
      }
    );
  };
export const materialIdAction =
  (materialTypeId: any): any =>
  async (dispatch: Dispatch) => {
    return ConsumptionReportService.getMaterialIds(materialTypeId).then(
      (response: any) => {
        dispatch({
          type: 'MATERIAL_CONSUMPTION_ID_FETCH_SUCCESS',
          payload: response.data,
        });
        dispatch({
          type: 'MATERIAL_CONSUMPTION_ID_COMPARE_FETCH_SUCCESS',
          payload: response.data,
        });
        return Promise.resolve(response);
      },
      (error: any) => {
        const message =
          (error.response && error.response.data && error.response.data.message) ||
          error.message ||
          error.toString();
        dispatch({
          type: 'MATERIAL_ID_FETCH_FAILURE',
          payload: message,
        });
        return Promise.reject(message);
      }
    );
  };
export const materialTypeAction =
  (materialCategoryId: any): any =>
  async (dispatch: Dispatch) => {
    return ConsumptionReportService.getMaterialTypes(materialCategoryId).then(
      (response: any) => {
        dispatch({
          type: 'MATERIAL_CONSUMPTION_TYPE_FETCH_SUCCESS',
          payload: response.data,
        });
        return Promise.resolve(response);
      },
      (error: any) => {
        const message =
          (error.response && error.response.data && error.response.data.message) ||
          error.message ||
          error.toString();
        dispatch({
          type: 'MATERIAL_TYPE_FETCH_FAILURE',
          payload: message,
        });
        return Promise.reject(message);
      }
    );
  };

export const MaterialCategoryAction = (): any => async (dispatch: Dispatch) => {
  return ConsumptionReportService.getMaterialCategories().then(
    (response: any) => {
      dispatch({
        type: 'MATERIAL_CONSUMPTION_CATEGORY_FETCH_SUCCESS',
        payload: response.data,
      });

      return Promise.resolve(response.data);
    },
    (error: any) => {
      console.log(error);
      const message =
        (error.response && error.response.data && error.response.data.message) ||
        error.message ||
        error.toString();

      return Promise.reject(message);
    }
  );
};
export const fetchConsumptionReportAction =
  (payload: any): any =>
  async (dispatch: Dispatch) => {
    return ConsumptionReportService.fetchConsumptionReport(payload).then(
      (response: any) => {
        dispatch({
          type: 'SET_CONSUMPTION_MAT_GRAPH',
          payload: response.data,
        });
        return Promise.resolve(response);
      },
      (error: any) => {
        const message =
          (error.response && error.response.data && error.response.data.message) ||
          error.message ||
          error.toString();
        dispatch({
          type: 'MATERIAL_TYPE_FETCH_FAILURE',
          payload: message,
        });
        return Promise.reject(message);
      }
    );
  };
export const consumptionvariantsaveAction =
  (payload: any): any =>
  async (dispatch: Dispatch) => {
    return ConsumptionReportService.consumptionvariantsave(payload).then(
      (response: any) => {
        variantDetailsByIdDispatch(dispatch, response);
        return Promise.resolve(response);
      },
      (error: any) => {
        console.log(error);
        const message =
          (error.response && error.response.data && error.response.data.message) ||
          error.message ||
          error.toString();

        return Promise.reject(message);
      }
    );
  };

export const furnanceListget = (): any => async (dispatch: any) => {
  try {
    const response = await ConsumptionReportService.furnanceList();
    furnanceListDispatch(dispatch, response);
    return response;
  } catch (error) {
    console.error('Error fetching furnance list:', error);
    throw error;
  }
};

const furnanceListDispatch = (dispatch: Dispatch, response: any) => {
  dispatch({
    type: 'FURNANCE_FETCH_SUCCESS',
    payload: response.data,
  });
};

const variantListDispatch = (dispatch: Dispatch, response: any) => {
  dispatch({
    type: 'VARIANT_FETCH_SUCCESS',
    payload: response.data,
  });
};

const variantDetailsByIdDispatch = (dispatch: Dispatch, response: any) => {
  dispatch({
    type: 'VARIANT_CONSUMPTION_FETCH_BY_ID_SUCCESS',
    payload: response.data,
  });
};
