import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import tapHoleService from 'store/services/tapHoleService';

export interface HoleSlice {
  loading: boolean;
  error: any;
  results: [];
  taphole: any;
  clonedMaterialData: object;
}
const initState: HoleSlice = {
  loading: false,
  error: null,
  results: [],
  taphole: {},
  clonedMaterialData: {},
};
export const getTapHoleList = createAsyncThunk(
  'taphole/getTapHoleList',
  tapHoleService.getTapHoleDetailsList
);
export const createTapHole = createAsyncThunk(
  'taphole/createTapHole',
  tapHoleService.createTapHoleDetails
);
export const updateTapHole = createAsyncThunk(
  'taphole/updateTapHole',
  tapHoleService.updateTapHoleDetails
);
export const getRadioTapHole = createAsyncThunk(
  'taphole/getRadioTapHole',
  tapHoleService.getRadioTapHoleDetails
);
export const getTapHole = createAsyncThunk('taphole/getTapHole', tapHoleService.getTapHoleDetails);
export const deleteTapHole = createAsyncThunk(
  'taphole/deleteTapHole',
  tapHoleService.deleteTapHoleDetails
);

const TapHoleSlice = createSlice({
  name: 'taphole',
  initialState: initState,
  reducers: {
    clearCloneData: (state) => {
      state.clonedMaterialData = {};
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getTapHoleList.pending, (state) => {
        state.loading = true;
      })
      .addCase(getTapHoleList.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.results = action.payload.data;
      })
      .addCase(getTapHoleList.rejected, (state, action) => {
        state.loading = false;
        state.results = [];
        state.error = action.payload;
      });
    builder
      .addCase(createTapHole.pending, (state) => {
        state.loading = true;
      })
      .addCase(createTapHole.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.results = action.payload.data;
      })
      .addCase(createTapHole.rejected, (state, action) => {
        state.loading = false;
        state.results = [];
        state.error = action.payload;
      });
    builder
      .addCase(updateTapHole.pending, (state) => {
        state.loading = true;
      })
      .addCase(updateTapHole.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.results = action.payload.data;
      })
      .addCase(updateTapHole.rejected, (state, action) => {
        state.loading = false;
        state.results = [];
        state.error = action.payload;
      });
    builder
      .addCase(getRadioTapHole.pending, (state) => {
        state.loading = true;
      })
      .addCase(getRadioTapHole.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.results = action.payload.data;
      })
      .addCase(getRadioTapHole.rejected, (state, action) => {
        state.loading = false;
        state.results = [];
        state.error = action.payload;
      });
    builder
      .addCase(getTapHole.pending, (state) => {
        state.loading = true;
      })
      .addCase(getTapHole.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.results = action.payload.data;
      })
      .addCase(getTapHole.rejected, (state, action) => {
        state.loading = false;
        state.results = [];
        state.error = action.payload;
      });
    builder
      .addCase(deleteTapHole.pending, (state) => {
        state.loading = true;
      })
      .addCase(deleteTapHole.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.results = action.payload.data;
      })
      .addCase(deleteTapHole.rejected, (state, action) => {
        state.loading = false;
        state.results = [];
        state.error = action.payload;
      });
  },
});

export const { clearCloneData } = TapHoleSlice.actions;

export default TapHoleSlice.reducer;
