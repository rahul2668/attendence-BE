import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import httpClient from 'http/httpClient';

export interface UnitSlice {
  userList: any[];
  error: any;
  status: string;
}

const initState: UnitSlice = {
  userList: [],
  error: null,
  status: 'idle',
};

export const getUserList = createAsyncThunk('user/getUserList', async () => {
  const response: any = await httpClient.get(`/api/account/get-all-users/`);
  return response.data;
});

const UserListSlice = createSlice({
  name: 'userList',
  initialState: initState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getUserList.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(getUserList.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.userList = action?.payload?.data;
      })
      .addCase(getUserList.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message;
      });
  },
});

export default UserListSlice.reducer;
