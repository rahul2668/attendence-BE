import { createSlice } from '@reduxjs/toolkit';
import { PlantData } from 'types/plant.model';

const PlantDataSlice = createSlice({
  name: 'plantData',
  initialState: {
    plantData: {} as PlantData,
  },
  reducers: {
    setPlantData(state, action) {
      state.plantData = action.payload;
    },
  },
});

// Extract the action creators object and the reducer
const { actions, reducer } = PlantDataSlice;

// Extract and export each action creator by name
export const { setPlantData } = actions;

// Export the reducer, either as a default or named export
export default reducer;
