import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import FurnaceConfigService from 'store/services/furnaceConfigService';
import {
  FurnaceBasicInfo,
  FurnaceBasicInfoErrors,
  FurnaceElectrodeExcelInfo,
  FurnaceElectrodeInfo,
  FurnaceParameterInfo,
} from 'types/furnaceConfig.model';

interface InitialFurnaceConfigState {
  furnaceBasicInfo: FurnaceBasicInfo;
  furnaceElectrodes: FurnaceElectrodeInfo;
  furnaceBasicInfoErrors: FurnaceBasicInfoErrors;
  furnaceParameters: FurnaceParameterInfo;
  loading: boolean;
  error: string | null;
  formAction: string;
  furnaceConfigId?: number;
  furnaceElectrodeExcelList?: FurnaceElectrodeExcelInfo[];
  furnaceParametersExcelList?: any[];
  furnaceNo?: string | number;
  furnaceElectrodeNames?: string[];
}

const initialState: InitialFurnaceConfigState = {
  furnaceBasicInfo: {} as FurnaceBasicInfo,
  furnaceBasicInfoErrors: {} as FurnaceBasicInfoErrors,
  furnaceElectrodes: {} as FurnaceElectrodeInfo,
  furnaceParameters: {} as FurnaceParameterInfo,
  loading: false,
  error: null,
  formAction: '',
  furnaceElectrodeExcelList: [],
  furnaceParametersExcelList: [],
  furnaceElectrodeNames: [],
};

export const getFurnaceElectrodes = createAsyncThunk(
  'furnaceConfig/getFurnaceElectrodes',
  FurnaceConfigService.getFurnaceElectrodeInfo
);

export const addOrEditElectrodeInfo = createAsyncThunk(
  'furnaceConfig/addOrEditElectrodeInfo',
  FurnaceConfigService.createOrUpdateFurnaceElectrode
);

export const submitBasicInfo = createAsyncThunk(
  'furnaceConfig/submitBasicInfo',
  FurnaceConfigService.submitBasicInfo
);

export const getBasicInfo = createAsyncThunk(
  'furnaceConfig/getBasicInfo',
  FurnaceConfigService.getBasicInfo
);

export const updateBasicInfo = createAsyncThunk(
  'furnaceConfig/updateBasicInfo',
  FurnaceConfigService.updateBasicInfo
);

export const getFurnaceParameters = createAsyncThunk(
  'furnaceConfig/getFurnaceParameters',
  FurnaceConfigService.getFurnaceParameterInfo
);

export const addOrEditParameterInfo = createAsyncThunk(
  'furnaceConfig/addOrEditParameterInfo',
  FurnaceConfigService.createOrUpdateFurnaceParameter
);

export const getFurnaceElectrodesExcel = createAsyncThunk(
  'furnaceConfig/getFurnaceElectrodesExcel',
  FurnaceConfigService.getFurnaceElectrodesExcel
);

export const getFurnaceParametersExcel = createAsyncThunk(
  'furnaceConfig/getFurnaceParametersExcel',
  FurnaceConfigService.getFurnaceParametersExcel
);

const FurnaceConfigurationSlice = createSlice({
  name: 'furnaceConfig',
  initialState,
  reducers: {
    setFurnaceConfigId(state, action) {
      state.furnaceConfigId = action.payload;
    },
    setFurnaceNo(state, action) {
      state.furnaceNo = action.payload;
    },
    setFurnaceBasicInfo(state, action) {
      state.furnaceBasicInfo = action.payload;
    },
    setFurnaceElectrodes(state, action) {
      state.furnaceElectrodes = {
        ...state.furnaceElectrodes,
        ...action.payload,
      };
    },
    setFurnaceBasicInfoErrors(state, action) {
      state.furnaceBasicInfoErrors = action.payload;
    },
    clearAllStatesToInitialValue() {
      return initialState; // Reset the state to initial values
    },
    setFormAction(state, action) {
      state.formAction = action.payload;
    },
    setFurnaceParameters(state, action) {
      state.furnaceParameters = {
        ...state.furnaceParameters,
        ...action.payload,
      };
    },
    setFurnaceElectrodeExcelList(state, action) {
      state.furnaceElectrodeExcelList = action.payload;
    },
    setFurnaceParametersExcelList(state, action) {
      state.furnaceParametersExcelList = action.payload;
    },
    setFurnaceElectrodeNames(state, action) {
      state.furnaceElectrodeNames = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getFurnaceElectrodes.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getFurnaceElectrodes.fulfilled, (state, action) => {
        state.loading = false;
        state.furnaceElectrodes = {
          ...state.furnaceElectrodes,
          ...action.payload.data,
        };
      })
      .addCase(getFurnaceElectrodes.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message ?? 'Failed to fetch furnace electrodes';
      })
      .addCase(addOrEditElectrodeInfo.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(addOrEditElectrodeInfo.fulfilled, (state) => {
        state.loading = false;
        // Handle successful update or addition here
      })
      .addCase(addOrEditElectrodeInfo.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message ?? 'Failed to add or edit electrode info';
      })
      // basic info submit
      .addCase(submitBasicInfo.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(submitBasicInfo.fulfilled, (state) => {
        state.loading = false;
        // imp => need to handle a few cases by checking the status code...
        // notify('success', t(action.payload.data.message));
        // state.furnaceBasicInfo = initialState.furnaceBasicInfo; /// dont clear state
        // upsert the furnace id after successful resp
        // and load the next tab..  we might need to move the tab state to redux
      })
      .addCase(submitBasicInfo.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message ?? 'Failed to add or edit basic info';
      })
      // basic info get data -----
      .addCase(getBasicInfo.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getBasicInfo.fulfilled, (state) => {
        state.loading = false;
      })
      .addCase(getBasicInfo.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message ?? 'Failed to fetch basic info';
      })
      // basic info get data -----
      .addCase(updateBasicInfo.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateBasicInfo.fulfilled, (state) => {
        state.loading = false;
      })
      .addCase(updateBasicInfo.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message ?? 'Failed to add or edit basic info';
      })
      // getFurnaceElectrodesExcel get data -----
      .addCase(getFurnaceElectrodesExcel.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getFurnaceElectrodesExcel.fulfilled, (state) => {
        state.loading = false;
      })
      .addCase(getFurnaceElectrodesExcel.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message ?? 'Failed to add or edit basic info';
      })
      // parameters fetch and submit
      .addCase(getFurnaceParameters.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getFurnaceParameters.fulfilled, (state, action) => {
        state.loading = false;
        state.furnaceParameters = {
          ...state.furnaceParameters,
          ...action.payload.data.data,
        };
      })
      .addCase(getFurnaceParameters.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message ?? 'Failed to fetch furnace parameters';
      })
      .addCase(addOrEditParameterInfo.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(addOrEditParameterInfo.fulfilled, (state) => {
        state.loading = false;
        // Handle successful update or addition here
      })
      .addCase(addOrEditParameterInfo.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message ?? 'Failed to add or edit parameter info';
      })

      // getFurnaceParametersExcel get data -----
      .addCase(getFurnaceParametersExcel.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getFurnaceParametersExcel.fulfilled, (state) => {
        state.loading = false;
      })
      .addCase(getFurnaceParametersExcel.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message ?? 'Failed to add or edit basic info';
      });
  },
});

const { actions, reducer } = FurnaceConfigurationSlice;

export const {
  setFurnaceBasicInfo,
  setFurnaceElectrodes,
  setFurnaceBasicInfoErrors,
  clearAllStatesToInitialValue,
  setFormAction,
  setFurnaceParameters,
  setFurnaceConfigId,
  setFurnaceElectrodeExcelList,
  setFurnaceParametersExcelList,
  setFurnaceNo,
  setFurnaceElectrodeNames,
} = actions;

export default reducer;
