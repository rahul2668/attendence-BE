import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  selectedUnit: '',
};

const materialSpecificationSlice = createSlice({
  name: 'materialSpecificationSLice',
  initialState: initialState,
  reducers: {
    setSelectedUnit: (state, action) => {
      state.selectedUnit = action.payload;
    },
  },
});

export const { setSelectedUnit } = materialSpecificationSlice.actions;
export const selectSelectedValue = (state: any) => state.materialSpecificationSLice.selectedUnit;
export default materialSpecificationSlice.reducer;
