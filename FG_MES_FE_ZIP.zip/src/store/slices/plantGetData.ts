import GetPlantConfigData from 'store/services/getPlantData';
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';

export interface PlantSlice {
  loading: boolean;
  error: any;
  results: [];
  count: number;
  plantExcelList: [];
}

const initState: PlantSlice = {
  loading: false,
  error: null,
  results: [],
  count: 0,
  plantExcelList: [],
};

export const getPlant = createAsyncThunk('plant/getAllPlant', GetPlantConfigData?.getPlantConfig);
export const getPlantExcel = createAsyncThunk(
  'plant/getPlantExcel',
  GetPlantConfigData?.getPlantExcel
);

const plantConfigSlice = createSlice({
  name: 'plant',
  initialState: initState,
  reducers: {
    setPlantExcelList(state, action) {
      state.plantExcelList = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getPlant.pending, (state) => {
        state.loading = true;
      })
      .addCase(getPlant.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.results = action.payload.data;
      })
      .addCase(getPlant.rejected, (state, action) => {
        state.loading = false;
        state.results = [];
        state.error = action.payload;
      })
      //excel download
      .addCase(getPlantExcel.pending, (state) => {
        state.loading = true;
      })
      .addCase(getPlantExcel.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.results = action.payload.data;
      })
      .addCase(getPlantExcel.rejected, (state, action) => {
        state.loading = false;
        state.results = [];
        state.error = action.payload;
      });
  },
});

const { actions, reducer } = plantConfigSlice;

export const { setPlantExcelList } = actions;

export default reducer;
