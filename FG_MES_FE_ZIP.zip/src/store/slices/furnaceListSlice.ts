import GetFurnaceListData from '../services/furnaceListServer';
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';

export interface PlantSlice {
  loading: boolean;
  error: any;
  results: [];
  count: number;
}

const initState: PlantSlice = {
  loading: false,
  error: null,
  results: [],
  count: 0,
};

export const getFurnaceList = createAsyncThunk(
  'furnace/getAllFurnace',
  GetFurnaceListData?.getFurnaceConfigList
);

const furnaceConfigSlice = createSlice({
  name: 'furnace',
  initialState: initState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getFurnaceList.pending, (state) => {
        state.loading = true;
      })
      .addCase(getFurnaceList.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.results = action.payload.data;
      })
      .addCase(getFurnaceList.rejected, (state, action) => {
        state.loading = false;
        state.results = [];
        state.error = action.payload;
      });
  },
});

export default furnaceConfigSlice.reducer;
