import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import wipService from 'store/services/wipService';

export interface WipService {
  loading: boolean;
  error: any;
  additive: object;
  results: [];
  count: number;
  clonedMaterialData: object;
  wipMaterialExcelList: [];
}
const initState: WipService = {
  loading: false,
  error: null,
  additive: {},
  results: [],
  count: 0,
  clonedMaterialData: {},
  wipMaterialExcelList: [],
};

export const getWipDetails = createAsyncThunk(
  'wip/wipDetails',
  async (id: string | null, { rejectWithValue }) => {
    try {
      const response = await wipService.getWipDetails(id);
      if (response.status === 200) {
        return response;
      } else {
        const errorResponse = await response.json();
        rejectWithValue(errorResponse);
        return response;
      }
    } catch (error: any) {
      rejectWithValue({ message: error.message });
      throw error;
    }
  }
);

export const getWipList = createAsyncThunk(
  'wip/getWipList',
  async (request: any, { rejectWithValue }) => {
    try {
      const response = await wipService.getWipList(request);
      if (response.status === 200) {
        return response;
      } else {
        const errorResponse = await response.json();
        rejectWithValue(errorResponse);
        return response;
      }
    } catch (error: any) {
      rejectWithValue({ message: error.message });
      throw error;
    }
  }
);

export const editWip = createAsyncThunk('wip/editWip', wipService.editWip);
export const deleteWip = createAsyncThunk(
  'wip/deleteWip',
  async (request: any, { rejectWithValue }) => {
    try {
      const response = await wipService.deleteWip(request);
      if (response.status === 200) {
        return response;
      } else {
        const errorResponse = await response.json();
        rejectWithValue(errorResponse);
        return response;
      }
    } catch (error: any) {
      rejectWithValue({ message: error.message });
      throw error;
    }
  }
);
export const getWipMaterialExcel = createAsyncThunk(
  'additive/getWipMaterialExcel',
  wipService.getWipMaterialExcel
);
export const statusAdditive = createAsyncThunk(
  'additive/statusAdditive',
  wipService.statusAdditive
);
export const listFeatures = createAsyncThunk(
  'additive/additivelistFeatures',
  wipService.getSort_FilteredAdditiveList
);
export const cloneMaterial = createAsyncThunk(
  'additive/cloneMaterial',
  wipService.getCloneMaterial
);
export const createMaterail = createAsyncThunk(
  'material/createMaterail',
  wipService.createClonedMaterial
);
export const filterSearch = createAsyncThunk('additive/filterSearch', wipService.getSearchedFilter);
const additiveSlice = createSlice({
  name: 'additive',
  initialState: initState,
  reducers: {
    clearCloneData: (state) => {
      state.clonedMaterialData = {};
    },
    setWipMaterialExcelList(state, action) {
      state.wipMaterialExcelList = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getWipDetails.pending, (state) => {
        state.loading = true;
      })
      .addCase(getWipDetails.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.additive = action.payload.data;
      })
      .addCase(getWipDetails.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
    builder
      .addCase(getWipList.pending, (state) => {
        state.loading = true;
      })
      .addCase(getWipList.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.additive = action.payload.data;
      })
      .addCase(getWipList.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(filterSearch.pending, (state) => {
        state.loading = true;
      })
      .addCase(filterSearch.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.additive = action.payload.data;
      })
      .addCase(filterSearch.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
    builder
      .addCase(cloneMaterial.pending, (state) => {
        state.loading = true;
      })
      .addCase(cloneMaterial.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.clonedMaterialData = action.payload.data;
      })
      .addCase(cloneMaterial.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
    builder
      .addCase(createMaterail.pending, (state) => {
        state.loading = true;
      })
      .addCase(createMaterail.fulfilled, (state) => {
        state.loading = false;
        state.error = null;
      })
      .addCase(createMaterail.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
    builder
      .addCase(editWip.pending, (state) => {
        state.loading = true;
      })
      .addCase(editWip.fulfilled, (state) => {
        state.loading = false;
        state.error = null;
      })
      .addCase(editWip.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
    builder
      .addCase(deleteWip.pending, (state) => {
        state.loading = true;
      })
      .addCase(deleteWip.fulfilled, (state) => {
        state.loading = false;
        state.error = null;
      })
      .addCase(deleteWip.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
    builder
      .addCase(statusAdditive.pending, (state) => {
        state.loading = true;
      })
      .addCase(statusAdditive.fulfilled, (state) => {
        state.loading = false;
        state.error = null;
      })
      .addCase(statusAdditive.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});
export const { clearCloneData, setWipMaterialExcelList } = additiveSlice.actions;

export default additiveSlice.reducer;
