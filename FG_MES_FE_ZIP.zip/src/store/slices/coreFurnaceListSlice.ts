import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import coreFurnaceListService from 'store/services/coreFurnacelistService';

export interface CoreSlice {
  status: string;
  error: any;
  coreFurnace: [];
}
const initState: CoreSlice = {
  status: '',
  error: null,
  coreFurnace: [],
};
export const getCoreFurnaceList = createAsyncThunk(
  'core/getCoreFurnaceList',
  coreFurnaceListService.getCoreFurnaceListDetails
);

const CoreFurnaceListSlice = createSlice({
  name: 'coreFurnace',
  initialState: initState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getCoreFurnaceList.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(getCoreFurnaceList.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.coreFurnace = action?.payload?.data?.data;
      })
      .addCase(getCoreFurnaceList.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action?.error?.message;
      });
  },
});

export default CoreFurnaceListSlice.reducer;
