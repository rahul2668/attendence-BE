import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import AuthService from 'store/services/authService';

export interface AuthSlice {
  loading: boolean;
  error: any;
  loginData: object;
  ssoLoginKeys?: {
    clientId: string;
    authority: string;
    redirectUri: string;
    acceptedDomain: string;
  };
  plantLanguage?: string;
}
const initState: AuthSlice = {
  loading: false,
  error: null,
  loginData: {},
};

export const userLogin = createAsyncThunk('auth/userLogin', AuthService.userLogin);
export const userLoginSSO = createAsyncThunk('auth/userLoginSSO', AuthService.userLoginSSO);
export const ssoLoginCredentials = createAsyncThunk(
  'auth/ssoLoginCredentials',
  AuthService.getSSOLoginCredentials
);
export const userLogout: any = createAsyncThunk('auth/userLogout', AuthService.userLogout);
export const refreshToken = createAsyncThunk('auth/refreshToken', AuthService.refreshToken);
export const chnagePassword = createAsyncThunk('auth/chnagePassword', AuthService.changePassword);
export const createUser = createAsyncThunk('auth/createUser', AuthService.createUser);
export const getAuthToken = createAsyncThunk('auth/getToken', AuthService.getAuthToken);
export const getPlantLanguage = createAsyncThunk(
  'auth/getPlantLanguage',
  AuthService.getPlantLanguage
);
const AuthSlice = createSlice({
  name: 'login',
  initialState: initState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(userLogin.pending, (state) => {
        state.loading = true;
      })
      .addCase(userLogin.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.loginData = action.payload.data;
      })
      .addCase(userLogin.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
    builder
      .addCase(userLoginSSO.pending, (state) => {
        state.loading = true;
      })
      .addCase(userLoginSSO.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.loginData = action.payload.data;
      })
      .addCase(userLoginSSO.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
    builder
      .addCase(ssoLoginCredentials.pending, (state) => {
        state.loading = true;
      })
      .addCase(ssoLoginCredentials.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.ssoLoginKeys = action.payload.data;
      })
      .addCase(ssoLoginCredentials.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
    builder
      .addCase(chnagePassword.pending, (state) => {
        state.loading = true;
      })
      .addCase(chnagePassword.fulfilled, (state) => {
        state.loading = false;
        state.error = null;
      })
      .addCase(chnagePassword.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
    builder
      .addCase(createUser.pending, (state) => {
        state.loading = true;
      })
      .addCase(createUser.fulfilled, (state) => {
        state.loading = false;
        state.error = null;
      })
      .addCase(createUser.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
    builder
      .addCase(getAuthToken.pending, (state) => {
        state.loading = true;
      })
      .addCase(getAuthToken.fulfilled, (state) => {
        state.loading = false;
        state.error = null;
      })
      .addCase(getAuthToken.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
    builder
      .addCase(getPlantLanguage.pending, (state) => {
        state.loading = true;
      })
      .addCase(getPlantLanguage.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.plantLanguage = action.payload.data.language;
      })
      .addCase(getPlantLanguage.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
    builder
      .addCase(userLogout.pending, (state) => {
        state.loading = true;
      })
      .addCase(userLogout.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.plantLanguage = action.payload.data.language;
      })
      .addCase(userLogout.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
    builder
      .addCase(refreshToken.pending, (state) => {
        state.loading = true;
      })
      .addCase(refreshToken.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.plantLanguage = action.payload.data.language;
      })
      .addCase(refreshToken.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export default AuthSlice.reducer;
