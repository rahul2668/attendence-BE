import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import furnaceBedService from 'store/services/furnaceBedService';

export interface BedSlice {
  loading: boolean;
  error: any;
  results: [];
  furnaceBed: any;
  clonedMaterialData: object;
}
const initState: BedSlice = {
  loading: false,
  error: null,
  results: [],
  furnaceBed: {},
  clonedMaterialData: {},
};
export const getFurnaceBedList = createAsyncThunk(
  'furnacebed/getFurnaceBedList',
  furnaceBedService.getFurnaceBedDetailsList
);
export const createFurnaceBed = createAsyncThunk(
  'furnacebed/createFurnaceBed',
  furnaceBedService.createFurnaceBedDetails
);
export const updateFurnaceBed = createAsyncThunk(
  'furnacebed/updateFurnaceBed',
  furnaceBedService.updateFurnaceBedDetails
);
export const getRadioFurnaceBed = createAsyncThunk(
  'furnacebed/getRadioFurnaceBed',
  furnaceBedService.getRadioFurnaceBedDetails
);
export const getFurnaceBed = createAsyncThunk(
  'furnacebed/getFurnaceBed',
  furnaceBedService.getFurnaceBedDetails
);
export const deleteFurnaceBed = createAsyncThunk(
  'furnacebed/deleteFurnaceBed',
  furnaceBedService.deleteFurnaceBedDetails
);

const FurnaceBedSlice = createSlice({
  name: 'furnacebed',
  initialState: initState,
  reducers: {
    clearCloneData: (state) => {
      state.clonedMaterialData = {};
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getFurnaceBedList.pending, (state) => {
        state.loading = true;
      })
      .addCase(getFurnaceBedList.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.results = action.payload.data;
      })
      .addCase(getFurnaceBedList.rejected, (state, action) => {
        state.loading = false;
        state.results = [];
        state.error = action.payload;
      });
    builder
      .addCase(createFurnaceBed.pending, (state) => {
        state.loading = true;
      })
      .addCase(createFurnaceBed.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.results = action.payload.data;
      })
      .addCase(createFurnaceBed.rejected, (state, action) => {
        state.loading = false;
        state.results = [];
        state.error = action.payload;
      });
    builder
      .addCase(updateFurnaceBed.pending, (state) => {
        state.loading = true;
      })
      .addCase(updateFurnaceBed.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.results = action.payload.data;
      })
      .addCase(updateFurnaceBed.rejected, (state, action) => {
        state.loading = false;
        state.results = [];
        state.error = action.payload;
      });
    builder
      .addCase(getRadioFurnaceBed.pending, (state) => {
        state.loading = true;
      })
      .addCase(getRadioFurnaceBed.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.results = action.payload.data;
      })
      .addCase(getRadioFurnaceBed.rejected, (state, action) => {
        state.loading = false;
        state.results = [];
        state.error = action.payload;
      });
    builder
      .addCase(getFurnaceBed.pending, (state) => {
        state.loading = true;
      })
      .addCase(getFurnaceBed.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.results = action.payload.data;
      })
      .addCase(getFurnaceBed.rejected, (state, action) => {
        state.loading = false;
        state.results = [];
        state.error = action.payload;
      });
    builder
      .addCase(deleteFurnaceBed.pending, (state) => {
        state.loading = true;
      })
      .addCase(deleteFurnaceBed.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.results = action.payload.data;
      })
      .addCase(deleteFurnaceBed.rejected, (state, action) => {
        state.loading = false;
        state.results = [];
        state.error = action.payload;
      });
  },
});

export const { clearCloneData } = FurnaceBedSlice.actions;

export default FurnaceBedSlice.reducer;
