import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import furnaceMaterialService from 'store/services/furnaceMaterialService';

export interface MaterialSlice {
  loading: boolean;
  error: any;
  results: [];
  furnacematerial: any;
  clonedMaterialData: object;
  furnaceMaterialExcelList: [];
}
const initState: MaterialSlice = {
  loading: false,
  error: null,
  results: [],
  furnacematerial: {},
  clonedMaterialData: {},
  furnaceMaterialExcelList: [],
};
export const getFurnaceMaterialList = createAsyncThunk(
  'furnace/getFurnaceMaterialList',
  furnaceMaterialService.getFurnaceMaterialList
);
export const getFurnaceMaterialExcel = createAsyncThunk(
  'furnace/getFurnaceMaterialExcel',
  furnaceMaterialService.getFurnaceMaterialExcel
);
export const getFurnaceMaterialDetails = createAsyncThunk(
  'furnace/FurnaceMaterialDetails',
  furnaceMaterialService.getFurnaceMaterialDetails
);
export const getFurnaceMaterialSpecificationDetails = createAsyncThunk(
  'furnace/FurnaceMaterialSpecificationDetails',
  furnaceMaterialService.getFurnaceMaterialSpecificationDetails
);
export const getWipMaterialSpecificationDetails = createAsyncThunk(
  'furnace/getWipMaterialSpecificationDetails',
  furnaceMaterialService.getWipMaterialSpecificationDetails
);
export const getByProductsSpecificationDetails = createAsyncThunk(
  'furnace/getByProductsSpecificationDetails',
  furnaceMaterialService.getByProductsSpecificationDetails
);
export const getAdditiveSpecificationDetails = createAsyncThunk(
  'furnace/getAdditiveSpecificationDetails',
  furnaceMaterialService.getAdditiveSpecificationDetails
);
export const editFurnaceMaterialSpecificationDetails = createAsyncThunk(
  'furnace/editMaterialSpecificationDetails',
  furnaceMaterialService.editFurnaceMaterialSpecificationDetails
);
export const editWipMaterialSpecificationDetails = createAsyncThunk(
  'furnace/editWipMaterialSpecificationDetails',
  furnaceMaterialService.editWipMaterialSpecificationDetails
);
export const editAdditiveSpecificationDetails = createAsyncThunk(
  'furnace/editAdditiveSpecificationDetails',
  furnaceMaterialService.editAdditiveSpecificationDetails
);
export const editByproductsSpecificationDetails = createAsyncThunk(
  'furnace/editByproductsSpecificationDetails',
  furnaceMaterialService.editByProductsSpecificationDetails
);

export const editFurnaceMaterial = createAsyncThunk(
  'furnace/editFurnaceMaterial',
  furnaceMaterialService.editFurnaceMaterial
);
export const deleteFurnaceMaterial = createAsyncThunk(
  'furnace/deleteFurnaceMaterial',
  furnaceMaterialService.deleteFurnaceMaterial
);
export const createMaterail = createAsyncThunk(
  'furnace/createMaterail',
  furnaceMaterialService.createClonedMaterial
);
export const cloneMaterial = createAsyncThunk(
  'furnace/cloneMaterial',
  furnaceMaterialService.getCloneMaterial
);
export const statusFurnaceMaterial = createAsyncThunk(
  'furnace/statusFurnaceMaterial',
  furnaceMaterialService.statusFurnaceMaterial
);
export const getListData = createAsyncThunk(
  'furnace/getListData',
  furnaceMaterialService.getListData
);

export const listFeatures = createAsyncThunk(
  'furnace/materialListFeatures',
  furnaceMaterialService.getSort_FilteredFurnacedList
);
export const filterSearch = createAsyncThunk(
  'furnace/filterSearch',
  furnaceMaterialService.getSearchedFilter
);
export const getMaterialTypes = createAsyncThunk(
  'furnace/getMaterialTypes',
  furnaceMaterialService.getMaterialTypes
);
export const getSizeDropdown = createAsyncThunk(
  'furnace/getSizeDropdown',
  furnaceMaterialService.getSizeDropdown
);
const FurnaceMaterialSlice = createSlice({
  name: 'furnacematerial',
  initialState: initState,
  reducers: {
    clearCloneData: (state) => {
      state.clonedMaterialData = {};
    },
    setFurnaceMaterialExcelList(state, action) {
      state.furnaceMaterialExcelList = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getFurnaceMaterialList.pending, (state) => {
        state.loading = true;
      })
      .addCase(getFurnaceMaterialList.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.results = action.payload.data;
      })
      .addCase(getFurnaceMaterialList.rejected, (state, action) => {
        state.loading = false;
        state.results = [];
        state.error = action.payload;
      });
    builder
      .addCase(cloneMaterial.pending, (state) => {
        state.loading = true;
      })
      .addCase(cloneMaterial.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.clonedMaterialData = action.payload.data;
      })
      .addCase(cloneMaterial.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
    builder
      .addCase(createMaterail.pending, (state) => {
        state.loading = true;
      })
      .addCase(createMaterail.fulfilled, (state) => {
        state.loading = false;
        state.error = null;
      })
      .addCase(createMaterail.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
    builder
      .addCase(getListData.pending, (state) => {
        state.loading = true;
      })
      .addCase(getListData.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.results = action.payload.data;
      })
      .addCase(getListData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
    builder
      .addCase(filterSearch.pending, (state) => {
        state.loading = true;
      })
      .addCase(filterSearch.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.furnacematerial = action.payload.data;
      })
      .addCase(filterSearch.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
    builder
      .addCase(getFurnaceMaterialDetails.pending, (state) => {
        state.loading = true;
      })
      .addCase(getFurnaceMaterialDetails.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.furnacematerial = action.payload.data;
      })
      .addCase(getFurnaceMaterialDetails.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
    builder
      .addCase(editFurnaceMaterial.pending, (state) => {
        state.loading = true;
      })
      .addCase(editFurnaceMaterial.fulfilled, (state) => {
        state.loading = false;
        state.error = null;
      })
      .addCase(editFurnaceMaterial.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
    builder
      .addCase(deleteFurnaceMaterial.pending, (state) => {
        state.loading = true;
      })
      .addCase(deleteFurnaceMaterial.fulfilled, (state) => {
        state.loading = false;
        state.error = null;
      })
      .addCase(deleteFurnaceMaterial.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
    builder
      .addCase(statusFurnaceMaterial.pending, (state) => {
        state.loading = true;
      })
      .addCase(statusFurnaceMaterial.fulfilled, (state) => {
        state.loading = false;
        state.error = null;
      })
      .addCase(statusFurnaceMaterial.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
    builder
      .addCase(getMaterialTypes.pending, (state) => {
        state.loading = true;
      })
      .addCase(getMaterialTypes.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.results = action.payload.data;
      })
      .addCase(getMaterialTypes.rejected, (state, action) => {
        state.loading = false;
        state.results = [];
        state.error = action.payload;
      });
    builder
      .addCase(getSizeDropdown.pending, (state) => {
        state.loading = true;
      })
      .addCase(getSizeDropdown.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.results = action.payload.data;
      })
      .addCase(getSizeDropdown.rejected, (state, action) => {
        state.loading = false;
        state.results = [];
        state.error = action.payload;
      });
    builder
      .addCase(getFurnaceMaterialExcel.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getFurnaceMaterialExcel.fulfilled, (state) => {
        state.loading = false;
      })
      .addCase(getFurnaceMaterialExcel.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message ?? 'Failed to add or edit basic info';
      });
  },
});
export const { clearCloneData, setFurnaceMaterialExcelList } = FurnaceMaterialSlice.actions;

export default FurnaceMaterialSlice.reducer;
