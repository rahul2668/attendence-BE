import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import SizeReportsService from 'store/services/sizeReportService';
import { buildDropdownOptions, buildMaterialIdCompareDropdown } from 'utils/utils';

interface SizeReportState {
  materialCategories: any[];
  materialIds: any[];
  materialTypesCompare: any[];
  VariantsList: any[];
  variant: string;
  materialTypes: any[];
  matGraphs: any[];
  variantDetails: string;
  loading: boolean;
  error: string | null;
  clonedMaterialData: object;
}

const initialState: SizeReportState = {
  materialCategories: [],
  materialIds: [],
  materialTypesCompare: [],
  VariantsList: [],
  variant: '',
  materialTypes: [],
  matGraphs: [],
  variantDetails: '',
  loading: false,
  error: null,
  clonedMaterialData: {},
};

interface DeleteSizeVariantParams {
  variantId: any;
  variantName: string;
  userName: string;
}

export const fetchSizeMaterialCategories = createAsyncThunk(
  'sizeReports/fetchSizeMaterialCategories',
  SizeReportsService.getSizeMaterialCategories
);
export const fetchSizeVariantsList = createAsyncThunk(
  'sizeReports/fetchSizeVariantsList',
  SizeReportsService.getSizeVariants
);
export const fetchSizeMaterialTypes = createAsyncThunk(
  'sizeReports/fetchSizeMaterialTypes',
  SizeReportsService.getSizeMaterialTypes
);
export const fetchSizeMaterialIds = createAsyncThunk(
  'sizeReports/fetchSizeMaterialIds',
  SizeReportsService.getSizeMaterialIds
);

export const saveVariants = createAsyncThunk(
  'sizeReports/saveVariants',
  SizeReportsService.sizeVariantSaveService
);
export const fetchReport = createAsyncThunk(
  'sizeReports/fetchReport',
  SizeReportsService.getSizeReport
);
export const deleteSizeVariant = createAsyncThunk(
  'sizeReports/deleteSizeVariantById',
  async ({ variantId, variantName, userName }: DeleteSizeVariantParams, thunkAPI) => {
    try {
      const response = await SizeReportsService.deleteSizeVariantById(
        variantId,
        variantName,
        userName
      );
      return response.data;
    } catch (error: any) {
      return thunkAPI.rejectWithValue(error.response.data);
    }
  }
);
export const getSizeVariantDetailsById = createAsyncThunk(
  'sizeReports/getSizeVariantDetailsById',
  SizeReportsService.getSizeVariantDetailsById
);

// Add more async thunks as needed

const SizeReportSlice = createSlice({
  name: 'sizeReports',
  initialState,
  reducers: {
    clearCloneData: (state) => {
      state.clonedMaterialData = {};
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchSizeMaterialCategories.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchSizeMaterialCategories.fulfilled, (state, action) => {
        state.loading = false;
        state.materialCategories = buildDropdownOptions(
          action.payload.data,
          'category_code',
          'category_name'
        );
      })
      .addCase(fetchSizeMaterialCategories.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || action.error.toString();
      })
      .addCase(fetchSizeVariantsList.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchSizeVariantsList.fulfilled, (state, action) => {
        state.loading = false;
        state.VariantsList = buildDropdownOptions(
          action.payload.data,
          'variant_id',
          'variant_name'
        );
      })
      .addCase(fetchSizeVariantsList.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || action.error.toString();
      })
      .addCase(fetchSizeMaterialTypes.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchSizeMaterialTypes.fulfilled, (state, action) => {
        state.loading = false;
        state.materialTypes = buildDropdownOptions(action.payload.data, 'type_code', 'type_name');
      })
      .addCase(fetchSizeMaterialTypes.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || action.error.toString();
      })
      .addCase(fetchSizeMaterialIds.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchSizeMaterialIds.fulfilled, (state, action) => {
        state.loading = false;
        state.materialTypesCompare = buildMaterialIdCompareDropdown(
          action.payload.data,
          'material_id',
          'material_code_name'
        );
      })
      .addCase(fetchSizeMaterialIds.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || action.error.toString();
      })
      .addCase(saveVariants.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(saveVariants.fulfilled, (state, action) => {
        state.loading = false;
        state.variant = action.payload.data;
      })
      .addCase(saveVariants.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || action.error.toString();
      })
      .addCase(fetchReport.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchReport.fulfilled, (state, action) => {
        state.loading = false;
        console.log(action);
        state.matGraphs = action.payload.data;
      })
      .addCase(fetchReport.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || action.error.toString();
      })
      .addCase(getSizeVariantDetailsById.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getSizeVariantDetailsById.fulfilled, (state, action) => {
        state.loading = false;
        state.variantDetails = action.payload.data;
      })
      .addCase(getSizeVariantDetailsById.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || action.error.toString();
      })
      .addCase(deleteSizeVariant.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteSizeVariant.fulfilled, (state) => {
        state.loading = false;
        state.error = null;
      })
      .addCase(deleteSizeVariant.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || action.error.toString();
      });
    // Add more cases for other async thunks
  },
});

export const { clearCloneData } = SizeReportSlice.actions;

export default SizeReportSlice.reducer;
