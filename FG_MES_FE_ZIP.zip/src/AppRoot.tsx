import './index.scss';
import { useEffect, useState } from 'react';
import { AppRouter } from 'routes/Router';
import 'react-toastify/dist/ReactToastify.css';
import { ToastContainer } from 'react-toastify';
import { RouterProvider } from 'react-router-dom';
import { paths } from 'routes/paths';
import { useAppDispatch, useAppSelector } from 'store';
import { getAllUnits } from 'store/slices/unitSlice';
import { MsalProvider } from '@azure/msal-react';
import { IPublicClientApplication, PublicClientApplication } from '@azure/msal-browser';
import { msalConfig } from 'helpers/ssoAuthConfig';
import { getSessionStorage } from 'utils/utils';
import i18n from 'i18n';
import { getMaster } from 'store/slices/masterSlice';
import { jwtDecode } from 'jwt-decode';
import { setUserData } from 'store/slices/userDataSlice';
import { CustomJwtPayload } from 'types/auth.model';
import { setPlantData } from 'store/slices/plantDataSlice';
import { getUserList } from 'store/slices/userListSlice';
import dayjs from 'dayjs';
import weekday from 'dayjs/plugin/weekday';
import localeData from 'dayjs/plugin/localeData';

dayjs.extend(weekday);
dayjs.extend(localeData);

const AppRoot = () => {
  const [msalInstance, setMsalInstance] = useState<PublicClientApplication | null>(null);
  const [isMsalInitialized, setIsMsalInitialized] = useState(false);

  const checkToken = () => {
    const token = getSessionStorage('accessToken');

    if (!token && window.location.pathname !== paths.login) {
      window.location.href = paths.login;
    }
  };
  const dispatch = useAppDispatch();
  const allUnits = useAppSelector((state) => state.unit.units);
  const ssoKeys = useAppSelector((state) => state.login.ssoLoginKeys);
  const userData = useAppSelector((state) => state.userData.userData);

  useEffect(() => {
    const token: string | null = getSessionStorage('accessToken');
    if (token && Object.keys(userData).length === 0 && userData.constructor === Object) {
      const decoded: CustomJwtPayload = jwtDecode(token);
      dispatch(setUserData(decoded?.user_data));
      dispatch(setPlantData(decoded?.plant_data));
      dispatch(getUserList());
    }
    if (allUnits.length === 0) {
      dispatch(getAllUnits());
      dispatch(getMaster());
    }
  }, [dispatch, allUnits]);

  useEffect(() => {
    if (ssoKeys) {
      msalConfig.auth.clientId = atob(ssoKeys.clientId);
      msalConfig.auth.authority = `https://login.microsoftonline.com/${atob(ssoKeys.authority)}`;
      msalConfig.auth.redirectUri = ssoKeys.redirectUri;

      const instance = new PublicClientApplication(msalConfig);
      setMsalInstance(instance);
      setIsMsalInitialized(true);
    }
  }, [ssoKeys]);

  useEffect(() => {
    checkToken();

    const handleStorageChange = () => {
      checkToken();
    };

    window.addEventListener('storage', handleStorageChange);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);

  useEffect(() => {
    const selectedLanguage = getSessionStorage('selectedLanguage');
    i18n.changeLanguage(selectedLanguage);
  }, []);

  return (
    <>
      {isMsalInitialized && ssoKeys ? (
        <MsalProvider instance={msalInstance as IPublicClientApplication}>
          <RouterProvider router={AppRouter} />
        </MsalProvider>
      ) : (
        <RouterProvider router={AppRouter} />
      )}
      <ToastContainer
        position='top-right'
        autoClose={2000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme='light'
      />
    </>
  );
};

export default AppRoot;
