export const GET_ALL_PLANTS = `${import.meta.env.VITE_API_URL}/api/plant`;
export const USER_LOGIN = `${import.meta.env.VITE_API_URL}/users/login/`;
