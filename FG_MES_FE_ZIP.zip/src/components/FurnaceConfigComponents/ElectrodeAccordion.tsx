import React, { useEffect, useMemo, useState } from 'react';
import Accordion from 'components/common/Accordion';
import ReusableDropDown from 'components/common/ReusableDropDown/ReusableDropDown';
import ReusableInput from 'components/common/ReusableInput/ReusableInput';
import { Grid, useMediaQuery } from '@mui/material';
import { Electrode } from 'types/furnaceConfig.model';
import { setFurnaceElectrodes } from 'store/slices/furnaceConfigurationSlice';
import { useAppDispatch, useAppSelector } from 'store';
import { crudType, fieldNames, masterCategories, uniqueCodesMapper } from 'utils/constants';
import { createOptionsByCategory, getUnitByFieldName } from 'utils/utils';
import _ from 'lodash';
import { useTranslation } from 'react-i18next';
interface ElectrodeAccordionProps {
  electrodeName: string;
}

const ElectrodeAccordion: React.FC<ElectrodeAccordionProps> = ({ electrodeName }) => {
  const dispatch = useAppDispatch();
  const { t } = useTranslation();
  // -- dynamic width code
  const [inputWidth, setInputWidth] = useState<string>('');
  const isSmallScreen = useMediaQuery('(min-width:601px) and (max-width:1000px)');
  const isMediumScreen = useMediaQuery('(min-width:1000px) and (max-width:1250px)');
  const isLargeScreen = useMediaQuery('(min-width:1250px) and (max-width:1500px)');
  const isXLScreen = useMediaQuery('(min-width:1500px)');
  // -- dynamic width code  end
  const { furnaceElectrodes, formAction } = useAppSelector((state) => state.furnaceConfiguration);
  const [selectedElectrodeFields, setSelectedElectrodeFields] = useState<ReusableInputField[]>([]);
  const utilsMasterData = useAppSelector((state) => state.master);
  const [selectValueStates, setSelectValueStates] = useState<{ [key: string]: string | number }>(
    {}
  );
  const [valueStates, setValueStates] = useState<{ [key: string]: string | number }>({});
  const allUnits = useAppSelector((state) => state.unit.units);
  const [fieldErrors, setFieldErrors] = useState<{ [key: string]: string }>({});

  const validateInteger = (value: any) => {
    const numberRegex = /^\d{0,8}(\.\d{0,2})?$/;
    return numberRegex.test(value);
  };

  useEffect(() => {
    if (isSmallScreen) {
      setInputWidth('150px');
    } else if (isMediumScreen) {
      setInputWidth('200px');
    } else if (isLargeScreen) {
      setInputWidth('300px');
    } else if (isXLScreen) {
      setInputWidth('370px');
    }
  }, [isSmallScreen, isMediumScreen, isLargeScreen]);

  useEffect(() => {
    const electrodeMasterCode = furnaceElectrodes.electrode_type_code;
    if (electrodeMasterCode === uniqueCodesMapper.compositeElectrode) {
      setSelectedElectrodeFields(compositeElectrodeFields);
    }
    if (electrodeMasterCode === uniqueCodesMapper.preBakedElectrode) {
      setSelectedElectrodeFields(preBakedElectrodeFields);
    }
    if (electrodeMasterCode === uniqueCodesMapper.soderbergElectrode) {
      setSelectedElectrodeFields(soderbergElectrodesFields);
    }
    if (electrodeMasterCode === uniqueCodesMapper.dcFurnaceElectrode) {
      setSelectedElectrodeFields(dcFurnaceElectrodeFields);
    }
  }, [furnaceElectrodes.electrode_type_code]);

  useEffect(() => {
    if (furnaceElectrodes.electrode_type_code === uniqueCodesMapper.compositeElectrode) {
      setSelectedElectrodeFields(compositeElectrodeFields);
    }
    if (furnaceElectrodes.electrode_type_code === uniqueCodesMapper.preBakedElectrode) {
      setSelectedElectrodeFields(preBakedElectrodeFields);
    }
    if (furnaceElectrodes.electrode_type_code === uniqueCodesMapper.soderbergElectrode) {
      setSelectedElectrodeFields(soderbergElectrodesFields);
    }
    if (furnaceElectrodes.electrode_type_code === uniqueCodesMapper.dcFurnaceElectrode) {
      setSelectedElectrodeFields(dcFurnaceElectrodeFields);
    }
    setSelectValueStates({});
    setValueStates({});
    setFieldErrors({});
    dispatch(
      setFurnaceElectrodes({
        ...furnaceElectrodes,
        electrodes: [],
        fieldErrors: {},
      })
    );
  }, [dispatch, furnaceElectrodes.electrode_type_code]);

  useEffect(() => {
    if (furnaceElectrodes.electrodes && selectedElectrodeFields.length > 0) {
      const existingElectrode = furnaceElectrodes.electrodes?.find(
        (e) => e.electrode_name === electrodeName
      );
      if (!existingElectrode) {
        dispatch(
          setFurnaceElectrodes({
            ...furnaceElectrodes,
            electrodes: [...furnaceElectrodes.electrodes, { electrode_name: electrodeName }],
          })
        );
      } else {
        const newSelectValueStates: { [key: string]: string | number } = {};
        const newValueStates: { [key: string]: string | number } = {};

        selectedElectrodeFields.forEach((field) => {
          const value = existingElectrode[field.name];
          if (value !== undefined) {
            if (field.inputType === 'select') {
              newSelectValueStates[field.name] = value;
            } else if (field.inputType === 'number') {
              newValueStates[field.name] = value;
            }
          }
        });
        setSelectValueStates(newSelectValueStates);
        setValueStates(newValueStates);
      }
    }
  }, [furnaceElectrodes, selectedElectrodeFields]);

  useEffect(() => {
    dispatch(
      setFurnaceElectrodes({
        ...furnaceElectrodes,
        isAnyElectrodeFieldEmpty: !areAllFieldsPresentForAllElectrodes(),
      })
    );
  }, [dispatch, furnaceElectrodes.electrodes]);

  const coreFields: ReusableInputField[] = useMemo(() => {
    return [
      {
        id: 1,
        label: 'systemAdmin.furnaceConfiguration.core',
        name: 'core',
        option: createOptionsByCategory(utilsMasterData.results, masterCategories.coreCategory),
        inputType: 'select',
        isRequired: true,
      },
      {
        id: 2,
        label: 'systemAdmin.furnaceConfiguration.coreMassOrLength',
        name: 'core_mass_length',
        inputType: 'number',
        unit: getUnitByFieldName(allUnits, fieldNames.coreMassPerLength),
        isRequired: true,
        fieldName: fieldNames.coreMassPerLength,
      },
    ];
  }, [utilsMasterData, allUnits]);

  const casingFields: ReusableInputField[] = useMemo(() => {
    return [
      {
        id: 3,
        label: 'systemAdmin.furnaceConfiguration.casing',
        name: 'casing',
        option: createOptionsByCategory(utilsMasterData.results, masterCategories.casingCategory),
        inputType: 'select',
        isRequired: true,
      },
      {
        id: 4,
        label: 'systemAdmin.furnaceConfiguration.casingMassOrLength',
        name: 'casing_mass_length',
        inputType: 'number',
        unit: getUnitByFieldName(allUnits, fieldNames.casingMassPerLength),
        isRequired: true,
        fieldName: fieldNames.casingMassPerLength,
      },
    ];
  }, [utilsMasterData, allUnits]);

  const pasteFields: ReusableInputField[] = useMemo(() => {
    return [
      {
        id: 5,
        label: 'systemAdmin.furnaceConfiguration.paste',
        name: 'paste',
        option: createOptionsByCategory(utilsMasterData.results, masterCategories.pasteCategory),
        inputType: 'select',
        isRequired: true,
      },
      {
        id: 6,
        label: 'systemAdmin.furnaceConfiguration.pasteMassOrLength',
        name: 'paste_mass_length',
        inputType: 'number',
        unit: getUnitByFieldName(allUnits, fieldNames.pasteMassPerLength),
        isRequired: true,
        fieldName: fieldNames.pasteMassPerLength,
      },
    ];
  }, [utilsMasterData, allUnits]);

  const compositeElectrodeFields: ReusableInputField[] = useMemo(() => {
    return [...coreFields, ...casingFields, ...pasteFields];
  }, [coreFields, casingFields, pasteFields]);

  const preBakedElectrodeFields: ReusableInputField[] = useMemo(() => {
    return [...coreFields];
  }, [coreFields]);

  const soderbergElectrodesFields: ReusableInputField[] = useMemo(() => {
    return [...pasteFields, ...casingFields];
  }, [pasteFields, casingFields]);

  const dcFurnaceElectrodeFields: ReusableInputField[] = useMemo(() => {
    return [...coreFields];
  }, [coreFields]);

  const handleDropDownOnChange = (name: string, value: string) => {
    setSelectValueStates({ ...selectValueStates, [name]: value });
    handleOnChange(name, value);
  };

  const handleInputOnChange = (
    name: string,
    value: string,
    fieldName: string | undefined = undefined
  ) => {
    if (validateInteger(value) || value === '') {
      setValueStates({ ...valueStates, [name]: value });
      handleOnChange(name, value, fieldName);
    }
  };

  const handleOnChange = (
    name: string,
    value: string | number,
    fieldName: string | undefined = undefined
  ) => {
    const updatedElectrodes = furnaceElectrodes.electrodes.map((electrode) => {
      if (electrode.electrode_name === electrodeName) {
        return { ...electrode, [name]: value };
      }
      return electrode;
    });

    const updatedErrors = { ...fieldErrors };
    if (typeof value === 'string' && value.trim() === '') {
      const fieldNameKey = _.findKey(fieldNames, (value) => value === fieldName);
      updatedErrors[name] = fieldName
        ? `systemAdmin.furnaceConfiguration.${fieldNameKey}IsRequired` // give keys here and call t () in prop
        : 'This field is required';
    } else {
      delete updatedErrors[name];
    }

    setFieldErrors(updatedErrors);

    dispatch(
      setFurnaceElectrodes({
        ...furnaceElectrodes,
        electrodes: updatedElectrodes,
        fieldErrors: updatedErrors,
      })
    );
  };

  const areAllFieldsPresentForEachElectrode = (
    fields: ReusableInputField[],
    electrodes: Electrode[]
  ) => {
    // A set of required field names is created for faster lookup
    const requiredFieldNames = new Set(
      fields.filter((field) => field.isRequired).map((field) => field.name)
    );
    // Iterating each electrode
    for (const electrode of electrodes) {
      // Iterating each required field name
      for (const fieldName of requiredFieldNames) {
        const fieldValue = electrode[fieldName];
        // Checking if the required field is present and valid
        if (
          fieldValue === undefined ||
          fieldValue === null ||
          (typeof fieldValue === 'string' && fieldValue.trim() === '')
        ) {
          return false;
        }
      }
    }
    // If all required fields are present for all electrodes, return true
    return true;
  };

  const areAllFieldsPresentForAllElectrodes = () => {
    let isAllFieldsPresent = true;

    if (furnaceElectrodes.electrode_type_code === uniqueCodesMapper.compositeElectrode) {
      isAllFieldsPresent = areAllFieldsPresentForEachElectrode(
        compositeElectrodeFields,
        furnaceElectrodes.electrodes
      );
    }
    if (furnaceElectrodes.electrode_type_code === uniqueCodesMapper.preBakedElectrode) {
      isAllFieldsPresent = areAllFieldsPresentForEachElectrode(
        preBakedElectrodeFields,
        furnaceElectrodes.electrodes
      );
    }
    if (furnaceElectrodes.electrode_type_code === uniqueCodesMapper.soderbergElectrode) {
      isAllFieldsPresent = areAllFieldsPresentForEachElectrode(
        soderbergElectrodesFields,
        furnaceElectrodes.electrodes
      );
    }
    if (furnaceElectrodes.electrode_type_code === uniqueCodesMapper.dcFurnaceElectrode) {
      isAllFieldsPresent = areAllFieldsPresentForEachElectrode(
        dcFurnaceElectrodeFields,
        furnaceElectrodes.electrodes
      );
    }

    return isAllFieldsPresent;
  };

  return (
    <>
      {selectedElectrodeFields.length > 0 && (
        <Accordion title={electrodeName}>
          <Grid container spacing={{ xs: 2, md: 3 }}>
            {selectedElectrodeFields.map((field) => (
              <React.Fragment key={field.id}>
                {field.inputType === 'select' && (
                  <Grid item>
                    <ReusableDropDown
                      label={field.label}
                      selectedValueState={selectValueStates[field.name] || ''}
                      name={field.name}
                      dropDownItemsData={field.option || []}
                      handleDropDownOnChange={(event) =>
                        handleDropDownOnChange(field.name, event.target.value)
                      }
                      idAccessKey='master_code'
                      codeOrValueAccessKey='value'
                      requiredField={field.isRequired}
                      viewMode={formAction === crudType.view}
                      customWidth={inputWidth}
                    />
                  </Grid>
                )}
                {field.inputType === 'number' && (
                  <Grid item>
                    <ReusableInput
                      label={field.label}
                      name={field.name}
                      handleOnChange={(event) =>
                        handleInputOnChange(field.name, event.target.value, field.fieldName)
                      }
                      valueState={valueStates[field.name] || ''}
                      placeholder={'Enter value'}
                      type={field.inputType}
                      unit={field.unit}
                      requiredField={field.isRequired}
                      fieldError={t(fieldErrors[field.name], fieldErrors[field.name])}
                      viewMode={formAction === crudType.view}
                      customWidth={inputWidth}
                    />
                  </Grid>
                )}
              </React.Fragment>
            ))}
          </Grid>
        </Accordion>
      )}
    </>
  );
};

export default ElectrodeAccordion;
