import React, { useEffect, useRef, useState } from 'react';
import { Box, Grid, InputLabel } from '@mui/material';
import { DesktopDatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { useTranslation } from 'react-i18next';
import { useAppDispatch, useAppSelector } from 'store';
import { UtilsMasterData } from 'types/plant.model';
import { crudType, fieldNames, globalString } from 'utils/constants';
import { getUnitByFieldName, handleTimezone } from 'utils/utils';
import ReusableInput from 'components/common/ReusableInput/ReusableInput';
import dayjs, { Dayjs } from 'dayjs';
import ToggleButton from 'components/common/ToggleButton';
import {
  getFurnaceParametersExcel,
  setFurnaceParameters,
  setFurnaceParametersExcelList,
} from 'store/slices/furnaceConfigurationSlice';
import { FurnaceParameterInfo } from 'types/furnaceConfig.model';
import ToggleTextComponent from 'components/common/ToggleTextComponent';
import MUIToolTip from 'components/common/ToolTip/MUIToolTip';
import DownloadExcel from 'components/common/ExcelDownload';
import _ from 'lodash';

const ParameterForm = () => {
  const dispatch = useAppDispatch();
  const { t } = useTranslation();
  const [valueStates, setValueStates] = useState<{ [key: string]: string }>({});
  const [fieldErrors, setFieldErrors] = useState<{ [key: string]: string }>({});

  const {
    // furnaceElectrodes,
    formAction,
    furnaceParameters,
    furnaceParametersExcelList,
    furnaceConfigId,
  } = useAppSelector((state) => state.furnaceConfiguration);
  const utilsMasterData = useAppSelector((state) => state.master);
  const utilsMasterList: Array<UtilsMasterData> = utilsMasterData?.results;
  const plantDataString = useAppSelector((state) => state.plantData.plantData);
  const plantData: any = plantDataString ?? null;
  const plant_time_zone_id: any = plantData.plant_time_zone_id;
  const timeZone = utilsMasterList?.filter((item: any) => item.id == plant_time_zone_id)?.[0]
    ?.description;
  const allUnits = useAppSelector((state) => state.unit.units);
  const csvLinkRef: any = useRef();

  //Static data for the fields.
  const parameterFields: ReusableInputField[] = [
    {
      id: 1,
      label: 'systemAdmin.furnaceConfiguration.energyLosses',
      name: 'energy_losses',
      fieldName: fieldNames.energyLosses,
      inputType: 'number',
      unit: getUnitByFieldName(allUnits, fieldNames.energyLosses),
      isRequired: true,
    },
    {
      id: 2,
      label: 'systemAdmin.furnaceConfiguration.jouleLossesCoefficient',
      name: 'joule_losses_coefficient',
      fieldName: fieldNames.jouleLossesCoefficient,
      inputType: 'number',
      unit: getUnitByFieldName(allUnits, fieldNames.jouleLossesCoefficient),
      isRequired: true,
    },
    {
      id: 3,
      label: 'systemAdmin.furnaceConfiguration.defaultEpiIndex',
      name: 'default_epi_index',
      fieldName: fieldNames.defaultEpiIndex,
      inputType: 'number',
      unit: getUnitByFieldName(allUnits, fieldNames.defaultEpiIndex),
      isRequired: true,
    },
    {
      id: 4,
      label: 'systemAdmin.furnaceConfiguration.correctedReactanceCoefficient',
      name: 'corrected_reactance_coefficient',
      fieldName: fieldNames.correctedReactanceCoefficient,
      inputType: 'number',
      unit: getUnitByFieldName(allUnits, fieldNames.correctedReactanceCoefficient),
      isRequired: true,
    },
    {
      id: 5,
      label: 'systemAdmin.furnaceConfiguration.designMW',
      name: 'design_mv',
      fieldName: fieldNames.designMW,
      inputType: 'number',
      unit: getUnitByFieldName(allUnits, fieldNames.designMW),
      isRequired: true,
    },
    {
      id: 6,
      label: 'systemAdmin.furnaceConfiguration.fixedCost',
      name: 'fixed_cost',
      fieldName: fieldNames.fixedCost,
      inputType: 'number',
      unit: getUnitByFieldName(allUnits, globalString.currency),
      isRequired: true,
    },
    {
      id: 7,
      label: 'systemAdmin.furnaceConfiguration.targetEnergyEfficiency',
      name: 'target_energy_efficiency',
      fieldName: fieldNames.targetEnergyEfficiency,
      inputType: 'number',
      unit: getUnitByFieldName(allUnits, fieldNames.targetEnergyEfficiency),
      isRequired: true,
    },
    {
      id: 8,
      label: 'systemAdmin.furnaceConfiguration.targetCostBudget',
      name: 'target_cost_budget',
      fieldName: fieldNames.targetCostBudget,
      inputType: 'number',
      unit: getUnitByFieldName(allUnits, fieldNames.targetCostBudget),
      isRequired: true,
    },
    {
      id: 9,
      label: 'systemAdmin.furnaceConfiguration.targetAvailability',
      name: 'target_availability',
      fieldName: fieldNames.targetAvailability,
      inputType: 'number',
      unit: getUnitByFieldName(allUnits, fieldNames.targetAvailability),
      isRequired: true,
    },
    {
      id: 10,
      label: 'systemAdmin.furnaceConfiguration.targetFurnaceLoad',
      name: 'target_furnace_load',
      fieldName: fieldNames.targetFurnaceLoad,
      inputType: 'number',
      unit: getUnitByFieldName(allUnits, fieldNames.targetFurnaceLoad),
      isRequired: true,
    },
    {
      id: 11,
      label: 'systemAdmin.furnaceConfiguration.crucibleDiameter',
      name: 'crucible_diameter',
      fieldName: fieldNames.crucibleDiameter,
      inputType: 'number',
      unit: getUnitByFieldName(allUnits, fieldNames.crucibleDiameter),
      isRequired: true,
    },
    {
      id: 12,
      label: 'systemAdmin.furnaceConfiguration.crucibleDepth',
      name: 'crucible_depth',
      fieldName: fieldNames.crucibleDepth,
      inputType: 'number',
      unit: getUnitByFieldName(allUnits, fieldNames.crucibleDepth),
      isRequired: true,
    },
    {
      id: 13,
      label: 'systemAdmin.furnaceConfiguration.pcdTheoretical',
      name: 'pcd_theoretical',
      fieldName: fieldNames.pcdTheoretical,
      inputType: 'number',
      unit: getUnitByFieldName(allUnits, fieldNames.pcdTheoretical),
      isRequired: true,
    },
    {
      id: 14,
      label: 'systemAdmin.furnaceConfiguration.pcdActual',
      name: 'pcd_actual',
      fieldName: fieldNames.pcdActual,
      inputType: 'number',
      unit: getUnitByFieldName(allUnits, fieldNames.pcdActual),
      isRequired: true,
    },
  ];

  const toggleValues: ReusableInputField[] = [
    {
      id: 15,
      label: 'systemAdmin.furnaceConfiguration.defaultMoisture',
      name: 'default_moisture',
      fieldName: fieldNames.defaultMoisture,
      inputType: 'boolean',
      unit: '',
      isRequired: false,
    },
  ];

  const excelHeader = [
    {
      label: t('sharedTexts.effectiveDate'),
      key: 'effective_date',
    },
    {
      label: t('systemAdmin.furnaceConfiguration.furnaceNo'),
      key: 'furnace_no',
    },
    {
      label: t('systemAdmin.furnaceConfiguration.energyLosses'),
      key: 'energy_losses',
    },
    {
      label: t('systemAdmin.furnaceConfiguration.jouleLossesCoefficient'),
      key: 'joule_losses_coefficient',
    },
    {
      label: t('systemAdmin.furnaceConfiguration.defaultEpiIndex'),
      key: 'default_epi_index',
    },
    {
      label: t('systemAdmin.furnaceConfiguration.correctedReactanceCoefficient'),
      key: 'corrected_reactance_coefficient',
    },
    {
      label: t('systemAdmin.furnaceConfiguration.designMW'),
      key: 'design_mv',
    },
    {
      label: t('systemAdmin.furnaceConfiguration.fixedCost'),
      key: 'fixed_cost',
    },
    {
      label: t('systemAdmin.furnaceConfiguration.targetEnergyEfficiency'),
      key: 'target_energy_efficiency',
    },
    {
      label: t('systemAdmin.furnaceConfiguration.targetCostBudget'),
      key: 'target_cost_budget',
    },
    {
      label: t('systemAdmin.furnaceConfiguration.targetAvailability'),
      key: 'target_availability',
    },
    {
      label: t('systemAdmin.furnaceConfiguration.targetFurnaceLoad'),
      key: 'target_furnace_load',
    },
    {
      label: t('systemAdmin.furnaceConfiguration.crucibleDiameter'),
      key: 'crucible_diameter',
    },
    {
      label: t('systemAdmin.furnaceConfiguration.crucibleDepth'),
      key: 'crucible_depth',
    },
    {
      label: t('systemAdmin.furnaceConfiguration.pcdTheoretical'),
      key: 'pcd_theoretical',
    },
    {
      label: t('systemAdmin.furnaceConfiguration.pcdActual'),
      key: 'pcd_actual',
    },
    {
      label: t('systemAdmin.furnaceConfiguration.defaultMoisture'),
      key: 'default_moisture',
    },
    {
      label: t('systemAdmin.plantConfiguration.createdBy'),
      key: 'created_name',
    },
    {
      label: t('systemAdmin.plantConfiguration.modifiedBy'),
      key: 'modified_name',
    },
    {
      label: t('systemAdmin.plantConfiguration.createdAt'),
      key: 'created_date',
    },
    {
      label: t('systemAdmin.plantConfiguration.modifiedAt'),
      key: 'modified_date',
    },
  ];

  const validateInteger = (value: any) => {
    const numberRegex = /^\d{0,8}(\.\d{0,2})?$/;
    return numberRegex.test(value);
  };

  useEffect(() => {
    const isAnyParameterFieldEmpty = !areAllRequiredFieldsPresent(furnaceParameters);
    if (furnaceParameters.isAnyParameterFieldEmpty !== isAnyParameterFieldEmpty) {
      dispatch(
        setFurnaceParameters({
          ...furnaceParameters,
          isAnyParameterFieldEmpty,
        })
      );
    }
    const transformedParameters: { [key: string]: string } = {};
    Object.keys(furnaceParameters).forEach((key) => {
      transformedParameters[key] = String(furnaceParameters[key as keyof FurnaceParameterInfo]);
    });
    setValueStates(transformedParameters);
  }, [furnaceParameters, dispatch]);

  useEffect(() => {
    if (formAction === crudType.create && !furnaceParameters.effective_date) {
      dispatch(
        setFurnaceParameters({
          ...furnaceParameters,
          effective_date: dayjs().format('YYYY-MM-DD'),
          default_moisture: false,
        })
      );
    }
  }, [furnaceParameters, dispatch, formAction]);

  const areAllRequiredFieldsPresent = (furnaceParameters: FurnaceParameterInfo) => {
    const requiredFieldNames = new Set(
      parameterFields.filter((field) => field.isRequired).map((field) => field.name)
    );

    for (const fieldName of requiredFieldNames) {
      if (!(fieldName in furnaceParameters)) {
        return false;
      }
    }

    return true;
  };

  const handleInputOnChange = (
    name: string,
    value: string,
    fieldName: string | undefined = undefined
  ) => {
    if (validateInteger(value) || value === '') {
      setValueStates({ ...valueStates, [name]: value });
      handleOnChange(name, value, fieldName);
    }
  };

  const handleOnChange = (
    name: string,
    value: string | number,
    fieldName: string | undefined = undefined
  ) => {
    const updatedErrors = { ...fieldErrors };
    if (typeof value === 'string' && value.trim() === '') {
      const fieldNameKey = _.findKey(fieldNames, (value) => value === fieldName);
      updatedErrors[name] = fieldName
        ? `systemAdmin.furnaceConfiguration.${fieldNameKey}IsRequired` // give keys here and call t () in prop
        : 'This field is required';
    } else {
      delete updatedErrors[name];
    }

    setFieldErrors(updatedErrors);

    dispatch(
      setFurnaceParameters({
        ...furnaceParameters,
        [name]: value,
        fieldErrors: updatedErrors,
      })
    );
  };

  const handleParameterEffectiveDateChange = (newDateAndTime: Dayjs | null) => {
    const updatedErrors = { ...furnaceParameters.fieldErrors };

    if (newDateAndTime) {
      delete updatedErrors['effective_date'];
    } else {
      updatedErrors['effective_date'] = 'Effective Date is required';
      setFieldErrors(updatedErrors);
    }
    dispatch(
      setFurnaceParameters({
        ...furnaceParameters,
        effective_date: newDateAndTime ? newDateAndTime.format('YYYY-MM-DD') : null,
        fieldErrors: updatedErrors,
      })
    );
  };

  const handleToggleChange = (checked: boolean) => {
    dispatch(
      setFurnaceParameters({
        ...furnaceParameters,
        default_moisture: checked,
      })
    );
  };

  const handleExcelClick = async () => {
    if (furnaceConfigId) {
      const response = await dispatch(getFurnaceParametersExcel(furnaceConfigId));
      const data = response.payload.data;

      if (response.payload.status >= 200 && response.payload.status < 300) {
        dispatch(setFurnaceParametersExcelList(data.data));
      }
    }
  };

  useEffect(() => {
    if (furnaceParametersExcelList && furnaceParametersExcelList.length > 0) {
      csvLinkRef?.current?.link?.click();
      dispatch(setFurnaceParametersExcelList([]));
    }
  }, [furnaceParametersExcelList]);

  return (
    <div>
      {formAction === crudType.view ? (
        <div style={{ display: 'flex', alignItems: 'center', padding: '10px 0' }}>
          <span className='furnaceConfigHeader'>
            Effective Date: {dayjs(furnaceParameters.effective_date).format('DD.MM.YY')}
          </span>
          <MUIToolTip text={t(`sharedTexts.downloadExcel`)}>
            <DownloadExcel
              csvData={furnaceParametersExcelList}
              headersForCSV={excelHeader}
              excelTitle='Furnace_Parameters'
              handleClick={handleExcelClick}
              csvLinkRef={csvLinkRef}
            />
          </MUIToolTip>
        </div>
      ) : (
        <Grid item xs={2} sm={4} md={4}>
          <InputLabel
            id='fn'
            sx={{
              fontWeight: 600,
              color: '#606466',
              fontSize: '14px',
              marginBottom: '5px',
            }}
          >
            {t('sharedTexts.effectiveDate')}*
          </InputLabel>
          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DesktopDatePicker
              closeOnSelect={false}
              format='DD/MM/YYYY'
              sx={{
                '& .MuiInputBase-input': {
                  height: '40px',
                  padding: '0px 0px 0px 14px',
                  fontSize: '14px',
                },
                width: '250px!important', // this solved a UI bug in date
              }}
              onChange={handleParameterEffectiveDateChange}
              value={handleTimezone(furnaceParameters.effective_date, timeZone)}
            />
          </LocalizationProvider>
        </Grid>
      )}
      {parameterFields.length > 0 && (
        <Grid container spacing={{ xs: 2, md: 3 }} pt={4} pb={5}>
          {parameterFields.map((field) => (
            <React.Fragment key={field.id}>
              {field.inputType === 'number' && (
                <Grid item>
                  <ReusableInput
                    label={field.label}
                    name={field.name}
                    handleOnChange={(event) =>
                      handleInputOnChange(field.name, event.target.value, field.fieldName)
                    }
                    valueState={valueStates[field.name] || ''}
                    placeholder={'Enter value'}
                    type={field.inputType}
                    unit={field.unit}
                    requiredField={field.isRequired}
                    fieldError={t(fieldErrors[field.name], fieldErrors[field.name])}
                    viewMode={formAction === crudType.view}
                  />
                </Grid>
              )}
            </React.Fragment>
          ))}

          <Box pt={3} pl={3}>
            <InputLabel
              id='fn'
              sx={{
                fontWeight: 600,
                color: '#606466',
                marginBottom: '5px',
                fontSize: '14px',
              }}
            >
              {/* pass translated label - use t() in prop  */}
              {toggleValues[0].isRequired
                ? `${t(toggleValues[0].label, toggleValues[0].label)}*`
                : t(toggleValues[0].label, toggleValues[0].label)}
            </InputLabel>
            {formAction !== crudType.view ? (
              <ToggleButton
                isChecked={furnaceParameters.default_moisture ?? false}
                text={`${furnaceParameters.default_moisture ? t('sharedTexts.enabled') : t('sharedTexts.disabled')}`}
                onChange={handleToggleChange}
              />
            ) : (
              <ToggleTextComponent
                value={
                  furnaceParameters.default_moisture
                    ? t('sharedTexts.enabled')
                    : t('sharedTexts.disabled')
                }
                color={furnaceParameters.default_moisture ? '#238903' : 'red'}
              />
            )}
          </Box>
        </Grid>
      )}
    </div>
  );
};

export default ParameterForm;
