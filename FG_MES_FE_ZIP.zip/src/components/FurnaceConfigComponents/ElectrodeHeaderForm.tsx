import { ChangeEvent, useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useAppDispatch, useAppSelector } from 'store';
import { UtilsMasterData } from 'types/plant.model';
import { useMediaQuery } from '@mui/material';
import {
  getFurnaceElectrodesExcel,
  setFurnaceElectrodeExcelList,
  setFurnaceElectrodeNames,
  setFurnaceElectrodes,
} from 'store/slices/furnaceConfigurationSlice';
import ReusableDropDown from 'components/common/ReusableDropDown/ReusableDropDown';
import { Grid, InputLabel, SelectChangeEvent } from '@mui/material';
import {
  createOptionsByCategory,
  getMasterValueByCode,
  getUnitByFieldName,
  handleTimezone,
} from 'utils/utils';
import ReusableInput from 'components/common/ReusableInput/ReusableInput';
import { DesktopDatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import dayjs, { Dayjs } from 'dayjs';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import {
  crudType,
  dcFurnaceElectrodeNames,
  fieldNames,
  furnaceElectrodeFieldRefs,
  furnaceElectrodeNames,
  masterCategories,
  uniqueCodesMapper,
} from 'utils/constants';
import MUIToolTip from 'components/common/ToolTip/MUIToolTip';
import DownloadExcel from 'components/common/ExcelDownload';
import { useNavigate } from 'react-router-dom';
import editIcon from 'assets/icons/edit-thick.svg';

const ElectrodeHeaderForm = () => {
  const { t } = useTranslation();
  const dispatch = useAppDispatch();

  // -- dynamic width code
  const [inputWidth, setInputWidth] = useState<string>('');
  const isSmallScreen = useMediaQuery('(min-width:601px) and (max-width:1000px)');
  const isMediumScreen = useMediaQuery('(min-width:1000px) and (max-width:1250px)');
  const isLargeScreen = useMediaQuery('(min-width:1250px)');
  // -- dynamic width code  end

  const [electrodeTypes, setElectrodeTypes] = useState<UtilsMasterData[]>([]);
  const utilsMasterData = useAppSelector((state) => state.master);
  const { furnaceElectrodes, formAction, furnaceConfigId, furnaceElectrodeExcelList, furnaceNo } =
    useAppSelector((state) => state.furnaceConfiguration);
  const utilsMasterList: Array<UtilsMasterData> = utilsMasterData?.results;
  const plantDataString = useAppSelector((state) => state.plantData.plantData);
  const plantData: any = plantDataString ?? null;
  const plant_time_zone_id: any = plantData.plant_time_zone_id;
  const timeZone = utilsMasterList?.filter((item: any) => item.id == plant_time_zone_id)?.[0]
    ?.description;
  const allUnits = useAppSelector((state) => state.unit.units);
  const [fieldErrors, setFieldErrors] = useState<{ [key: string]: string }>({});
  const [valueStates, setValueStates] = useState<{ [key: string]: string | number }>({});
  const userDataString = useAppSelector((state) => state.userData.userData);
  const user: any = userDataString ? userDataString : null;
  const navigate = useNavigate();
  const csvLinkRef: any = useRef();

  const excelHeader = [
    {
      label: t('sharedTexts.effectiveDate'),
      key: 'effective_date',
    },
    {
      label: t('systemAdmin.furnaceConfiguration.furnaceNo'),
      key: 'furnace_no',
    },
    {
      label: t('systemAdmin.furnaceConfiguration.electrodeType'),
      key: 'electrode_type_name',
    },
    {
      label: t('systemAdmin.furnaceConfiguration.electrodeName'),
      key: 'electrode_name',
    },
    {
      label: t('systemAdmin.furnaceConfiguration.electrodeDiameter'),
      key: 'diameter',
    },
    {
      label: t('systemAdmin.furnaceConfiguration.casing'),
      key: 'casing_value',
    },
    {
      label: t('systemAdmin.furnaceConfiguration.casingMassOrLength'),
      key: 'casing_mass_length',
    },
    {
      label: t('systemAdmin.furnaceConfiguration.core'),
      key: 'core_value',
    },
    {
      label: t('systemAdmin.furnaceConfiguration.coreMassOrLength'),
      key: 'core_mass_length',
    },
    {
      label: t('systemAdmin.furnaceConfiguration.paste'),
      key: 'paste_value',
    },
    {
      label: t('systemAdmin.furnaceConfiguration.pasteMassOrLength'),
      key: 'paste_mass_length',
    },
    {
      label: t('systemAdmin.plantConfiguration.createdBy'),
      key: 'created_name',
    },
    {
      label: t('systemAdmin.plantConfiguration.modifiedBy'),
      key: 'modified_name',
    },
    {
      label: t('systemAdmin.plantConfiguration.createdAt'),
      key: 'created_date',
    },
    {
      label: t('systemAdmin.plantConfiguration.modifiedAt'),
      key: 'modified_date',
    },
  ];

  useEffect(() => {
    setValueStates({
      ...valueStates,
      [furnaceElectrodeFieldRefs.electrodeDiameter]: furnaceElectrodes.diameter,
    });
  }, [furnaceElectrodes]);

  useEffect(() => {
    if (utilsMasterData) {
      setElectrodeTypes(
        createOptionsByCategory(utilsMasterData.results, masterCategories.electrodeCategory)
      );
    }
  }, [utilsMasterData]);

  useEffect(() => {
    const electrodeMasterCode = furnaceElectrodes.electrode_type_code;
    setFieldErrors({});
    setValueStates({});
    dispatch(
      setFurnaceElectrodes({
        ...furnaceElectrodes,
        electrode_type_code: electrodeMasterCode,
        diameter: null,
        fieldErrors: {},
        effective_date: dayjs().format('YYYY-MM-DD'),
      })
    );
    if (electrodeMasterCode === uniqueCodesMapper.dcFurnaceElectrode) {
      dispatch(setFurnaceElectrodeNames(dcFurnaceElectrodeNames));
    } else {
      dispatch(setFurnaceElectrodeNames(furnaceElectrodeNames));
    }
  }, [dispatch, furnaceElectrodes.electrode_type_code]);

  const handleElectrodeTypeChange = (event: SelectChangeEvent<string>) => {
    dispatch(
      setFurnaceElectrodes({
        ...furnaceElectrodes,
        [event.target.name]: event.target.value,
      })
    );
  };

  const validateInteger = (value: any) => {
    const numberRegex = /^\d{0,5}?$/;
    return numberRegex.test(value);
  };

  const handleDiameterChange = (event: ChangeEvent<HTMLInputElement>) => {
    const diameterValue = event.target.value;
    const fieldName = event.target.name;
    const updatedErrors = { ...fieldErrors };
    if (typeof diameterValue === 'string' && diameterValue.trim() === '') {
      updatedErrors[event.target.name] =
        'systemAdmin.furnaceConfiguration.electrodeDiameterIsRequired'; // change to actual error
    } else {
      delete updatedErrors[event.target.name];
    }

    setFieldErrors(updatedErrors);

    if (validateInteger(diameterValue) || diameterValue === '') {
      setValueStates({ ...valueStates, [fieldName]: diameterValue });
      dispatch(
        setFurnaceElectrodes({
          ...furnaceElectrodes,
          [event.target.name]: diameterValue,
          fieldErrors: updatedErrors,
        })
      );
    }
  };

  const handleElectrodeEffectiveDateChange = (newDateAndTime: Dayjs | null) => {
    const updatedErrors = { ...furnaceElectrodes.fieldErrors };

    if (newDateAndTime) {
      delete updatedErrors['effective_date'];
    } else {
      updatedErrors['effective_date'] = 'Effective Date is required';
      setFieldErrors(updatedErrors);
    }
    dispatch(
      setFurnaceElectrodes({
        ...furnaceElectrodes,
        effective_date: newDateAndTime ? newDateAndTime.format('YYYY-MM-DD') : null,
        fieldErrors: updatedErrors,
      })
    );
  };

  const handleEditClickAction = () => {
    navigate('/system-admin/furnace-configuration/edit', {
      state: {
        action: crudType.edit,
        viewOrEditId: furnaceConfigId,
        title: furnaceNo,
      } as NavigateState,
    });
  };

  const handleExcelClick = async () => {
    if (furnaceConfigId) {
      const response = await dispatch(getFurnaceElectrodesExcel(furnaceConfigId));
      const data = response.payload.data;

      if (response.payload.status >= 200 && response.payload.status < 300) {
        dispatch(setFurnaceElectrodeExcelList(data.data));
      }
    }
  };

  useEffect(() => {
    if (furnaceElectrodeExcelList && furnaceElectrodeExcelList.length > 0) {
      csvLinkRef?.current?.link?.click();
      dispatch(setFurnaceElectrodeExcelList([]));
    }
  }, [furnaceElectrodeExcelList]);

  useEffect(() => {
    if (isSmallScreen) {
      setInputWidth('200px');
    } else if (isMediumScreen) {
      setInputWidth('200px');
    } else if (isLargeScreen) {
      setInputWidth('300px');
    }
  }, [isSmallScreen, isMediumScreen, isLargeScreen]);

  return (
    <>
      {formAction === crudType.view ? (
        <>
          {user.is_superuser && (
            <div className='d-flex justify-content-end'>
              <button
                className={`btn btn--h30 py-1 px-3 font-bold mb-4`}
                onClick={handleEditClickAction}
              >
                <img src={editIcon} alt='edit' className='mr-2' /> {`${t('sharedTexts.edit')}`}
              </button>
            </div>
          )}
          <div style={{ display: 'flex', alignItems: 'center', padding: '10px 0' }}>
            {furnaceElectrodes.electrode_type_code &&
              furnaceElectrodes.electrode_type_code !== '' && (
                <>
                  <span className='furnaceConfigHeader'>{`${getMasterValueByCode(utilsMasterList, furnaceElectrodes.electrode_type_code)} Electrode`}</span>
                  <span className='furnaceConfigHeader'>|</span>
                </>
              )}
            {furnaceElectrodes.diameter > 0 && (
              <>
                <span className='furnaceConfigHeader'>
                  Diameter:{' '}
                  {`${furnaceElectrodes.diameter} ${getUnitByFieldName(allUnits, fieldNames.electrodeDiameter)}`}
                </span>
                <span className='furnaceConfigHeader'>|</span>
              </>
            )}
            {furnaceElectrodes.effective_date && (
              <span className='furnaceConfigHeader'>
                Effective Date: {dayjs(furnaceElectrodes.effective_date).format('DD.MM.YY')}
              </span>
            )}
            <MUIToolTip text={t(`sharedTexts.downloadExcel`)}>
              <DownloadExcel
                csvData={furnaceElectrodeExcelList}
                headersForCSV={excelHeader}
                excelTitle='Furnace Electrodes'
                handleClick={handleExcelClick}
                csvLinkRef={csvLinkRef}
              />
            </MUIToolTip>
          </div>
        </>
      ) : (
        <Grid container spacing={{ xs: 2, md: 3 }} columns={{ xs: 4, sm: 8, md: 12 }}>
          <Grid item>
            <ReusableDropDown
              label={`${t('systemAdmin.furnaceConfiguration.electrodeType')}*`}
              selectedValueState={furnaceElectrodes.electrode_type_code}
              name='electrode_type_code'
              dropDownItemsData={electrodeTypes}
              handleDropDownOnChange={handleElectrodeTypeChange}
              idAccessKey={'master_code'}
              codeOrValueAccessKey={'value'}
              viewMode={formAction === crudType.view}
              fieldDisabled={!(formAction === crudType.create)}
              customWidth={inputWidth}
            />
          </Grid>
          <Grid item>
            <ReusableInput
              label={`${t('systemAdmin.furnaceConfiguration.electrodeDiameter')}`}
              name='diameter'
              handleOnChange={handleDiameterChange}
              valueState={valueStates['diameter'] || ''}
              placeholder='Enter value'
              type='number'
              unit={getUnitByFieldName(allUnits, fieldNames.electrodeDiameter)}
              fieldError={t(fieldErrors['diameter'], fieldErrors['diameter'])}
              viewMode={formAction === crudType.view}
              requiredField={true}
              customWidth={inputWidth}
            />
          </Grid>
          <Grid item>
            <InputLabel
              id='fn'
              sx={{
                fontWeight: 600,
                color: '#606466',
                fontSize: '14px',
                marginBottom: '5px',
              }}
            >
              {t('sharedTexts.effectiveDate')}*
            </InputLabel>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DesktopDatePicker
                closeOnSelect={false}
                format='DD/MM/YYYY'
                sx={{
                  '& .MuiInputBase-input': {
                    height: '40px',
                    padding: '0px 0px 0px 14px',
                    fontSize: '14px',
                  },
                  width: inputWidth,
                  // width: '250px!important', // this solved a UI bug in date
                }}
                onChange={handleElectrodeEffectiveDateChange}
                value={handleTimezone(furnaceElectrodes.effective_date, timeZone)}
              />
            </LocalizationProvider>
          </Grid>
        </Grid>
      )}
    </>
  );
};

export default ElectrodeHeaderForm;
