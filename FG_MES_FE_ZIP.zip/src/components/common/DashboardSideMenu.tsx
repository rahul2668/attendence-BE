import { FC, useEffect, useState } from 'react';
import '../../assets/styles/scss/components/dashboard-side-menu.scss';
import logo from '../../assets/img/blue_FG_logo.png';
import locationIcon from '../../assets/icons/location-outline.svg';
import arrowDown from '../../assets/icons/chevron-down-thick.svg';
import ModalChangePassword from 'components/Modal/ChangePassword';
import { useLocation, useNavigate } from 'react-router-dom';
import globeIcon from '../../assets/icons/blue_globe.svg';
import { paths } from 'routes/paths';
import {
  getCommaSeparatedRoles,
  getNameInitial,
  notify,
  validatePermissions,
  isEmpty,
  clearSessionStorage,
} from 'utils/utils';
import { arrowDownSvg, getPath, getSvg } from './DashboardSideMenuSVGs';
import { crudType, permissionsMapper, uniqueCodesMapper } from 'utils/constants';
import OutsideClickHandler from 'react-outside-click-handler';
import { useAppDispatch, useAppSelector } from 'store';
import { chnagePassword } from 'store/slices/authSlice';
import { useGetPlantData } from 'hooks/useGetPlantData';
import { findSubModule } from 'utils/sideBar';
import Loading from './Loading';
import { useTranslation } from 'react-i18next';
import ReusableModal from './Modal/ReusableModalLayout/ReusableModal';
import LanguageSelect from './LanguageSelect';

const DashboardSideMenu: FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  const [firstName, setFirstName] = useState<any>('');
  const [lastName, setLastName] = useState<any>('');
  const [openModel, setOpenModel] = useState(false);
  const [showLanguageChangeModal, setShowLanguageChangeModal] = useState(false);
  const closeModel = () => setOpenModel(false);
  const [roles, setRoles] = useState<string>('');
  const [permissions, setPermissions] = useState<PermissionItem>({});
  const [plantName, setPlantName] = useState('');
  const [loginType, setLoginType] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const plant: any = useGetPlantData();
  const { t } = useTranslation();

  const UserInfo = useAppSelector((state) => state.userData.userData);
  useEffect(() => {
    if (!isEmpty(UserInfo)) {
      setFirstName(UserInfo?.first_name);
      setLastName(UserInfo?.last_name);
      setLoginType(UserInfo?.login_type);
      setRoles(getCommaSeparatedRoles(UserInfo?.roles));
    }
  }, [UserInfo]);

  const NavItem = ({ path, label, index, onClick, labelStyleOverride, lastNode }: any) => {
    const handleClick = (e: any, label: any) => {
      e.stopPropagation();
      onClick(label);
      navigate(path);
    };

    const activeLinkModule: any = `plantModulesAndFunctions.${activeLink}`;
    return (
      <li
        style={{
          ...(lastNode ? { backgroundColor: 'white' } : {}),
          ...(t(activeLinkModule) === label || (path && location.pathname.includes(path))
            ? { backgroundColor: '#0d659e' }
            : {}),
        }}
        key={index}
        className={`aside-menu-list__sub-item ${
          t(activeLinkModule) === label || (path && location.pathname.includes(path))
            ? 'active'
            : ''
        }`}
        onClick={(e) => handleClick(e, label)}
        onKeyDown={(e) => handleClick(e, label)}
      >
        <span style={labelStyleOverride}>{label}</span>
      </li>
    );
  };

  const [activeLink, setActiveLink] = useState<string>('');
  const [activeSubModule, setActiveSubModule] = useState('');
  const [isOpen, setIsOpen] = useState(false);

  const handleNavLinkClick = (label: any) => {
    setActiveLink(label);
  };

  const [activeItem, setActiveItem] = useState<string>('');

  const handleItemClick = (item: string) => {
    if (activeItem === item) {
      setActiveItem('');
    } else {
      setActiveItem(item);
    }
  };
  const userInfo: { permission_list?: PermissionItem } | undefined = useAppSelector(
    (state) => state.userData.userData
  );
  const plantData = useAppSelector((state) => state.plantData.plantData);
  useEffect(() => {
    if (isEmpty(userInfo)) return;

    const permissionList = userInfo?.permission_list;

    if (permissionList) {
      const filteredData = Object.fromEntries(
        Object.entries(permissionList).map(([category, items]) => {
          const filteredItems = Object.fromEntries(
            Object.entries(items).filter(([, value]) => value.isEligibleForMenu)
          );
          return [category, filteredItems];
        })
      );

      setPermissions(filteredData);
    }

    if (plantData?.plant_name) {
      setPlantName(plantData.plant_name);
    }
  }, [userInfo]);

  useEffect(() => {
    if (location.pathname) {
      const module: any = location.pathname?.split('/')[1];
      const subModule: any = location.pathname?.split('/')[2];
      setActiveItem(permissionsMapper[module]);
      setActiveLink(permissionsMapper[subModule]);
      if (module && subModule) {
        const foundedSubModule = findSubModule(
          permissionsMapper[module],
          permissionsMapper[subModule]
        ); // subModule -> this is the last node (function/screen)
        foundedSubModule && setActiveSubModule(foundedSubModule);
      }
    }
  }, [location.pathname]);

  const nodeHasSubModule = (module: string, lastNode: string) => {
    return findSubModule(module, lastNode);
  };

  const renderModule = (item: string, subItems: string[]) => {
    const subModuleItems: any = {};
    const singleNodes: string[] = [];

    // mapping keys of subItems, ie - node end name
    Object.keys(subItems).forEach((sItem: any) => {
      const modulePermissions = validatePermissions(item, sItem, crudType.view);
      if (modulePermissions) {
        const foundedSubModule = nodeHasSubModule(item, sItem);
        if (foundedSubModule) {
          if (!subModuleItems[foundedSubModule]) {
            subModuleItems[foundedSubModule] = []; // Create the array if it doesn't exist
          }
          subModuleItems[foundedSubModule].push(sItem); // Push sItem into the array
        } else {
          singleNodes?.push(sItem);
        }
      } else {
        return null;
      }
    });

    const menuItem: any = `plantModulesAndFunctions.${item}`; // added this solve a type error in t()
    return (
      <ul className='mt-4'>
        <li
          className={`aside-menu-list ${activeItem === item ? 'active' : ''}`}
          onClick={() => handleItemClick(item)}
          onKeyDown={() => handleItemClick(item)}
        >
          <div className='aside-menu-list__item'>
            {getSvg(item)}
            <div className='flex items-center flex-1 justify-between ml-2'>
              <span className='aside-menu-list__title'> {t(menuItem)} </span>
              {arrowDownSvg}
            </div>
          </div>
          <ol
            className='aside-menu-list__sub-item-wrapper'
            // style={{ display: subItemsHasSubModule(Object.keys(subItems)) ? 'none' : 'block' }}
          >
            {Object.keys(subModuleItems).map((subModuleKey) => {
              const subModuleArray = subModuleItems[subModuleKey];
              if (subModuleArray && subModuleArray.length > 0) {
                return renderSubModule(subModuleKey, subModuleArray, item);
              }
              return null; // Return null if the array is not found or empty
            })}
            {singleNodes.map((sItem: any, index: number) => {
              const modulePermissions = validatePermissions(item, sItem, crudType.view);
              if (modulePermissions) {
                const menuItem: any = `plantModulesAndFunctions.${sItem}`;
                return (
                  <NavItem
                    key={sItem}
                    index={index}
                    path={
                      sItem == uniqueCodesMapper.plantConfigFunction
                        ? plant?.results?.id
                          ? paths.plantScreen.view
                          : getPath(sItem)
                        : getPath(sItem)
                    }
                    label={`${t(menuItem)}`}
                    onClick={handleNavLinkClick}
                  />
                );
              } else {
                return null;
              }
            })}
          </ol>
        </li>
      </ul>
    );
  };

  // the nested drop down
  const renderSubModule = (item: string, subItems: string[], module: string) => {
    const menuItem: any = `plantModulesAndFunctions.${item}`;
    return (
      <ul>
        <li
          onClick={(e) => {
            setActiveSubModule((prev) => (prev === item ? '' : item));
            e.stopPropagation();
          }}
          onKeyDown={(e) => {
            setActiveSubModule((prev) => (prev === item ? '' : item));
            e.stopPropagation();
          }}
        >
          <div className='dropdown2__item'>
            <div className='flex items-center flex-1 justify-between ml-2'>
              <span
                style={{
                  color: activeSubModule === item ? '#0d659e' : '',
                }}
                className='dropdown2__title'
              >
                {t(menuItem)}
              </span>
              <svg
                width='13'
                height='8'
                viewBox='0 0 13 8'
                fill='none'
                className='dropdown2__arrow-down'
                style={{ transform: activeSubModule === item ? 'rotate(180deg)' : 'rotate(0deg)' }}
              >
                <path
                  d='M1.2002 1.6001L6.4002 6.4001L11.6002 1.6001'
                  stroke='#041724'
                  strokeWidth='1.5'
                  strokeLinecap='round'
                  strokeLinejoin='round'
                />
              </svg>
            </div>
          </div>
          <ol
            className='aside-menu-list__sub-item-wrapper'
            style={{ display: activeSubModule === item ? 'block' : 'none' }}
          >
            {subItems.map((sItem: any, index: number) => {
              const modulePermissions = validatePermissions(module, sItem, crudType.view);
              if (modulePermissions) {
                const menuItem: any = `plantModulesAndFunctions.${sItem}`;
                return (
                  <NavItem
                    key={sItem}
                    lastNode
                    labelStyleOverride={{ marginLeft: '10px' }}
                    index={index}
                    path={
                      sItem == uniqueCodesMapper.plantConfigFunction
                        ? plant?.results?.id
                          ? paths.plantScreen.view
                          : getPath(sItem)
                        : getPath(sItem)
                    }
                    label={t(menuItem)}
                    onClick={handleNavLinkClick}
                  />
                );
              } else {
                return null;
              }
            })}
          </ol>
        </li>
      </ul>
    );
  };

  const canShowModule = (module: string, subModules: object) => {
    //check if at least one sub module has view permission enabled
    if (module && !isEmpty(subModules)) {
      return Object.keys(subModules).some((func: string) =>
        validatePermissions(module, func, crudType.view)
      );
    }
    return false;
  };

  const onLogout = async () => {
    setIsLoading(true);
    clearSessionStorage(['accessToken', 'selectedLanguage']);
    setIsLoading(false);
    navigate(`${paths.login}`);
  };

  const chnagePasswordAPI = async (request: any) => {
    setIsLoading(true);
    const data = await dispatch(chnagePassword(request));
    if (data?.payload.status == '200') {
      notify('success', t(data.payload.data.message));
      closeModel();
      setTimeout(() => {
        onLogout();
      }, 1000);
    }
    setIsLoading(false);
  };

  const handleChangePassword = (request: any) => {
    chnagePasswordAPI(request);
  };

  return (
    <>
      {isLoading && <Loading />}
      <aside className='dashboard-side-menu'>
        <div className='dashboard-side-menu__header'>
          <div className='flex items-center'>
            <img
              className='cursor-pointer'
              style={{ width: '70%', height: '80%' }}
              src={logo}
              alt='logo'
              onClick={() => navigate('/dashboard')}
              onKeyDown={() => navigate('/dashboard')}
            />
            <div
              className='text-white text-sm font-semibold uppercase rounded ml-6'
              style={{ padding: '2px 6px', backgroundColor: '#E0625D' }}
            >
              MES
            </div>
          </div>
        </div>
        <div className='dashboard-side-menu__body scroll-0'>
          <div className='px-4 mt-4'>
            <div className='plant-details'>
              <div className='flex items-center'>
                <img src={locationIcon} alt='lcoation-icon' />
                <div className='flex flex-col ml-2'>
                  <span
                    className='color-secondary-text text-sm font-semibold'
                    style={{ color: '#606466' }}
                  >
                    {t('sharedTexts.plant')}
                  </span>
                  <span
                    className='color-secondary-text text-sm font-semibold'
                    style={{ color: '#0D659E' }}
                  >
                    {plantName}
                  </span>
                </div>
                {/* <div style={{ fontSize: '12px', color: '#F26924', fontWeight: 600 }}>
                  Change Plant
                </div> */}
              </div>
            </div>
            <div className='flex items-center'>
              <div className='menu-line color-secondary-text text-sm mt-4'>
                {t('sharedTexts.menu')}
              </div>
              <code className='border-line'></code>
            </div>
          </div>
          {Object.keys(permissions)?.map((item: any) => {
            const subItems: any = permissions[item];
            if (item && !isEmpty(subItems))
              return <>{canShowModule(item, subItems) && renderModule(item, subItems)}</>;
          })}
        </div>

        <div className='dashboard-side-menu__footer'>
          <div className='relative flex items-center justify-between'>
            <div className='flex items-center'>
              <figure
                className='avatar-container avatar-container--cover'
                style={{ width: 40, height: 40 }}
              >
                <figure>
                  {getNameInitial(firstName, true)}
                  {getNameInitial(lastName, true)}
                </figure>
              </figure>
              <div className='flex flex-col ml-3'>
                <span className='text-sm font-semibold'>
                  {firstName} {lastName}
                </span>
                <span className='color-tertiary-text text-sm mt-1'>{roles}</span>
              </div>
            </div>
            <div
              className='ml-auto cursor-pointer'
              onClick={() => {
                setIsOpen(!isOpen);
              }}
              onKeyDown={() => {
                setIsOpen(!isOpen);
              }}
            >
              <img src={arrowDown} alt='arrow-down' />
            </div>
            <OutsideClickHandler onOutsideClick={() => setIsOpen(false)}>
              <ul className={`profile-dropdown-menu ${isOpen ? 'open' : ''}`}>
                {loginType == 'simple' && (
                  <li
                    className='profile-dropdown-menu__list'
                    onClick={() => {
                      setOpenModel(true);
                      setIsOpen(false);
                    }}
                    onKeyDown={() => {
                      setOpenModel(true);
                      setIsOpen(false);
                    }}
                  >
                    <svg
                      width='20'
                      height='19'
                      viewBox='0 0 20 19'
                      fill='none'
                      className='profile-dropdown-menu__list__icon mr-2'
                    >
                      <path
                        d='M17.5002 1.66675L15.8336 3.33341M15.8336 3.33341L18.3336 5.83341L15.4169 8.75008L12.9169 6.25008M15.8336 3.33341L12.9169 6.25008M9.4919 9.67508C9.92218 10.0996 10.2642 10.6051 10.4984 11.1624C10.7325 11.7197 10.8541 12.3178 10.8561 12.9223C10.8581 13.5267 10.7405 14.1257 10.5102 14.6845C10.2798 15.2433 9.94111 15.7511 9.51368 16.1785C9.08625 16.606 8.5785 16.9446 8.01965 17.175C7.4608 17.4054 6.86189 17.523 6.25742 17.5209C5.65295 17.5189 5.05485 17.3973 4.49755 17.1632C3.94026 16.9291 3.43478 16.587 3.01023 16.1567C2.17534 15.2923 1.71336 14.1346 1.72381 12.9328C1.73425 11.7311 2.21627 10.5815 3.06606 9.73175C3.91585 8.88196 5.0654 8.39994 6.26714 8.38949C7.46887 8.37905 8.62663 8.84102 9.49106 9.67592L9.4919 9.67508ZM9.4919 9.67508L12.9169 6.25008'
                        stroke='#0D659E'
                        strokeWidth='1.5'
                        strokeLinecap='round'
                        strokeLinejoin='round'
                      />
                    </svg>
                    {t('sharedTexts.changePassword')}
                  </li>
                )}
                {/* ========== Language */}

                <li
                  className='profile-dropdown-menu__list'
                  onClick={() => {
                    setShowLanguageChangeModal(true);
                    setIsOpen(false);
                  }}
                  onKeyDown={() => {
                    setShowLanguageChangeModal(true);
                    setIsOpen(false);
                  }}
                >
                  <img
                    src={globeIcon}
                    alt='view'
                    className='icon mr-10'
                    style={{
                      fill: '#04436B',
                      width: '20px',
                      height: '20px',
                      marginRight: '8px',
                    }}
                  />
                  {t('sharedTexts.changeLanguage')}
                </li>
                {/* ========== */}
                <li className='profile-dropdown-menu__list' onClick={onLogout} onKeyDown={onLogout}>
                  <svg
                    width='14'
                    height='14'
                    viewBox='0 0 14 14'
                    fill='none'
                    className='profile-dropdown-menu__list__icon mr-2'
                  >
                    <path
                      d='M9 1H11.6667C12.0203 1 12.3594 1.14048 12.6095 1.39052C12.8595 1.64057 13 1.97971 13 2.33333V11.6667C13 12.0203 12.8595 12.3594 12.6095 12.6095C12.3594 12.8595 12.0203 13 11.6667 13H9'
                      stroke='#0D659E'
                      strokeWidth='1.5'
                      strokeLinecap='round'
                      strokeLinejoin='round'
                    />
                    <path
                      d='M5.66699 10.3337L9.00033 7.00033L5.66699 3.66699'
                      stroke='#0D659E'
                      strokeWidth='1.5'
                      strokeLinecap='round'
                      strokeLinejoin='round'
                    />
                    <path
                      d='M9 7H1'
                      stroke='#0D659E'
                      strokeWidth='1.5'
                      strokeLinecap='round'
                      strokeLinejoin='round'
                    />
                  </svg>
                  {t('sharedTexts.logout')}
                </li>
              </ul>
            </OutsideClickHandler>
          </div>
        </div>
      </aside>
      <ModalChangePassword
        showModal={openModel}
        closeModel={closeModel}
        handleChangePassword={handleChangePassword}
      />

      <ReusableModal
        title={`Change language`}
        confirmButtonText={t('sharedTexts.save')}
        closeModal={() => {
          setShowLanguageChangeModal(false);
        }}
        showModal={showLanguageChangeModal}
        hideButtons={true}
        customWidth='50vh'
        customHeight='20vh'
        preventOverFlowScroll
      >
        {showLanguageChangeModal && (
          <div className='d-flex justify-content-center'>
            <LanguageSelect showSelectLangLabel />{' '}
          </div>
        )}
      </ReusableModal>
    </>
  );
};

export default DashboardSideMenu;
