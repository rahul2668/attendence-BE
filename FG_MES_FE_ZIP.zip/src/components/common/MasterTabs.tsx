import checkIcon from '../../assets/icons/check-tick.svg';
type Props = {
  index: any;
  editMode: any;
  activeTab: any;
  isNextTabAllowed: boolean;
  tab: any;
  setActiveTab: any;
};

function MasterTabs({
  index,
  editMode,
  activeTab,
  isNextTabAllowed,
  tab,
  setActiveTab,
}: Readonly<Props>) {
  return (
    <div
      key={index}
      className={`${!editMode ? 'tab__header__item' : ''} ${
        activeTab === tab.value ? 'active' : ''
      }`}
      onClick={() => isNextTabAllowed === true && setActiveTab(tab.value)}
      onKeyDown={() => isNextTabAllowed === true && setActiveTab(tab.value)}
    >
      {!editMode && (
        <div className='tab__header__status-count'>
          <span className='tab__header__status-count__label-text'>{index + 1}</span>
          <img src={checkIcon} alt='check-icon' className='tab__header__check-icon' />
        </div>
      )}
      {!editMode && <label className='tab__header__label'>{tab.label}</label>}
    </div>
  );
}

export default MasterTabs;
