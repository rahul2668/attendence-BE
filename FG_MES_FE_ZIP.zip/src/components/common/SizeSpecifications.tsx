import { FC, useEffect, useState } from 'react';
import { MaterialElement } from 'types/material.model';
import { preventArrowBehavior } from 'utils/utils';
import CustomSelect from './SelectField';
import { useTranslation } from 'react-i18next';
import { getSizeDropdown } from 'store/slices/furnaceMaterialSlice';
import { useAppDispatch } from 'store';
// import setSelectedUnit from

interface SizeSpecificationsProps {
  isEdit: boolean;
  elements: Array<MaterialElement>;
  elementNameWithError: Array<string>;
  handleSizeInputChange: (
    elementName: string,
    property: 'low_size' | 'high_size' | 'aim' | 'i' | 'above_tolerance' | 'below_tolerance',
    value: any,
    id: number,
    validationValue: number,
    dropdownList: any
  ) => void;
  handleTrackSizesChangeHistory: (
    property:
      | 'low_size'
      | 'high_size'
      | 'aim'
      | 'i'
      | 'above_tolerance'
      | 'below_tolerance'
      | 'unit',
    value: any,
    id: number,
    dropdownList: any
  ) => void;
}

const SizeSpecifications: FC<SizeSpecificationsProps> = ({
  isEdit,
  elements,
  elementNameWithError,
  handleTrackSizesChangeHistory,
  handleSizeInputChange,
}) => {
  const { t } = useTranslation();
  const dispatch = useAppDispatch();
  const [dropdownList, setDropdownList] = useState<any>([]);

  const fetchDropdownData = async () => {
    const dropdownResp = await dispatch(getSizeDropdown());
    const dropdownDataList = dropdownResp.payload.data.map((val: any) => {
      const list = {
        option: val.value + ' ' + val.unit,
        value: val.id,
      };
      return list;
    });
    setDropdownList(dropdownDataList);
  };
  useEffect(() => {
    fetchDropdownData();
  }, []);

  return (
    <div className='col-6 px-2'>
      <div className={`products__container col-6 ${isEdit && 'mb-3'} `}></div>
      <div>
        <table className='table-value-of-elements table-value-of-elements--list-view'>
          <thead>
            <tr>
              <td style={{ textAlign: 'center' }}>{t('masterData.sharedMasterDataTexts.low')}</td>
              <td
                style={{ textAlign: 'center' }}
              >{`${t('masterData.sharedMasterDataTexts.belowTolerance')}%`}</td>
              <td style={{ textAlign: 'center' }}>{t('masterData.sharedMasterDataTexts.high')}</td>
              <td
                style={{ textAlign: 'center' }}
              >{`${t('masterData.sharedMasterDataTexts.aboveTolerance')}%`}</td>
            </tr>
          </thead>
          <tbody>
            {elements?.map((element: any) => {
              const elementName: any = 'Sizes';
              return (
                <tr key={element.element}>
                  <td style={{ fontWeight: 'normal' }}>
                    {isEdit ? (
                      <CustomSelect
                        options={dropdownList}
                        loading={dropdownList.length <= 0}
                        styles={{
                          border: elementNameWithError.includes(elementName)
                            ? '1px solid #d73c3c'
                            : '1px solid #ccd0d1',
                          paddingRight: '20px',
                          width: '115px',
                          backgroundColor: elementNameWithError.includes(elementName)
                            ? '#d73c3c1a'
                            : '#fff',
                        }}
                        onChange={(value: any) => {
                          handleSizeInputChange(
                            'Sizes',
                            'low_size',
                            value,
                            element.id,
                            Number(
                              dropdownList
                                ?.filter((item: any) => item.value == value)?.[0]
                                ?.option.split(' ')[0]
                            ),
                            dropdownList
                          );
                          handleTrackSizesChangeHistory(
                            'low_size',
                            Number(
                              dropdownList
                                ?.filter((item: any) => item.value == value)?.[0]
                                ?.option.split(' ')[0]
                            ),
                            element.id,
                            dropdownList
                          );
                        }}
                        disabled={!isEdit}
                        searchText='Search Product Code'
                        value={
                          dropdownList?.filter((item: any) =>
                            elements.some((value: any) => item.value == value.low_size)
                          )?.[0]?.option || 0
                        }
                      />
                    ) : (
                      <p
                        style={{
                          color: '#000',
                          fontWeight: 'normal',
                          fontSize: '14px',
                          width: 'max-content',
                        }}
                      >
                        {dropdownList?.filter((item: any) =>
                          elements.some((value: any) => item.value == value.low_size)
                        )?.[0]?.option || 0}
                      </p>
                    )}
                  </td>
                  <td style={{ textAlign: 'center' }}>
                    <input
                      type='number'
                      min={1}
                      max={100}
                      style={{ textAlign: 'center', height: '40px', width: '115px' }}
                      disabled={
                        !dropdownList?.filter((item: any) =>
                          elements.some((value: any) => item.value == value.low_size)
                        )?.[0]?.option
                      }
                      value={element.below_tolerance}
                      className={` input-field ${!isEdit && 'disabled-input-view'} ${
                        elementNameWithError.includes(elementName) ? 'input-field--error' : ''
                      }`}
                      onChange={(e: any) => {
                        if (e.target.value >= 0 && e.target.value <= 100) {
                          handleSizeInputChange(
                            elementName,
                            'below_tolerance',
                            +e.target.value,
                            element.id,
                            +e.target.value,
                            []
                          );
                          handleTrackSizesChangeHistory(
                            'below_tolerance',
                            +e.target.value,
                            element.id,
                            dropdownList
                          );
                        }
                      }}
                      onKeyDown={(e: any) => preventArrowBehavior(e, 'number')}
                      onWheel={(event: any) => event.currentTarget.blur()}
                    />
                  </td>
                  <td>
                    {isEdit ? (
                      <CustomSelect
                        styles={{
                          border: elementNameWithError.includes(elementName)
                            ? '1px solid #d73c3c'
                            : '1px solid #ccd0d1',
                          paddingRight: '20px',
                          width: '115px',
                          backgroundColor: elementNameWithError.includes(elementName)
                            ? '#d73c3c1a'
                            : '#fff',
                        }}
                        options={dropdownList}
                        loading={dropdownList.length <= 0}
                        onChange={(value: any) => {
                          handleSizeInputChange(
                            'Sizes',
                            'high_size',
                            value,
                            element.id,
                            Number(
                              dropdownList
                                ?.filter((item: any) => item.value == value)?.[0]
                                ?.option.split(' ')[0]
                            ),
                            dropdownList
                          );
                          handleTrackSizesChangeHistory(
                            'high_size',
                            Number(
                              dropdownList
                                ?.filter((item: any) => item.value == value)?.[0]
                                ?.option.split(' ')[0]
                            ),
                            element.id,
                            dropdownList
                          );
                        }}
                        disabled={!isEdit}
                        searchText='Search Product Code'
                        value={
                          dropdownList?.filter((item: any) =>
                            elements.some((value: any) => item.value == value.high_size)
                          )?.[0]?.option || 0
                        }
                      />
                    ) : (
                      <p style={{ fontSize: '14px', width: 'max-content' }}>
                        {dropdownList?.filter((item: any) =>
                          elements.some((value: any) => item.value == value.high_size)
                        )?.[0]?.option || 0}
                      </p>
                    )}
                  </td>
                  <td style={{ textAlign: 'center' }}>
                    <input
                      type='number'
                      disabled={
                        !dropdownList?.filter((item: any) =>
                          elements.some((value: any) => item.value == value.high_size)
                        )?.[0]?.option
                      }
                      style={{ textAlign: 'center', height: '40px', width: '115px' }}
                      value={element.above_tolerance}
                      className={` input-field ${!isEdit && 'disabled-input-view'} ${
                        elementNameWithError.includes(elementName) ? 'input-field--error' : ''
                      }`}
                      onChange={(e: any) => {
                        if (e.target.value >= 0 && e.target.value <= 100) {
                          handleSizeInputChange(
                            elementName,
                            'above_tolerance',
                            +e.target.value,
                            element.id,
                            +e.target.value,
                            []
                          );
                          handleTrackSizesChangeHistory(
                            'above_tolerance',
                            +e.target.value,
                            element.id,
                            dropdownList
                          );
                        }
                      }}
                      onKeyDown={(e) => preventArrowBehavior(e, 'number')}
                      onWheel={(event) => event.currentTarget.blur()}
                    />
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default SizeSpecifications;
