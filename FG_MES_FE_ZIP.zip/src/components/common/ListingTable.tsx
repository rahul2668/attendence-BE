import React, { useEffect, useState } from 'react';
import 'assets/styles/scss/components/table-general.scss';
import { formatDateHelper, isEmpty, validatePermissions } from 'utils/utils';
import editIcon from '../../assets/icons/edit1.svg';
import viewIcon from '../../assets/icons/eye1.svg';
import deactivateIcon from '../../assets/icons/deactivate.svg';
import { Link, useLocation } from 'react-router-dom';
import Loading from 'components/common/Loading';
import addIcon from '../../assets/icons/add.svg';
import { crudType, permissionsMapper } from 'utils/constants';
import { useTranslation } from 'react-i18next';
import { UnfoldMore as SortIcon } from '@mui/icons-material';
import { North as UpIcon } from '@mui/icons-material';
import { South as DownIcon } from '@mui/icons-material';
import { useAppSelector } from 'store';
import { UtilsMasterData } from 'types/plant.model';

interface TableColumn {
  key: string;
  header: string;
}

interface ListingTable {
  tableHeader: Array<TableColumn>;
  tableBody: Array<any>;
  handleOnchangeStatus: (id: number, value: string, code: string) => void;
  loading?: boolean;
  handleTableRowClick: (id: number) => void;
  handleEditClick: (event: React.MouseEvent<HTMLAnchorElement, MouseEvent>, id: number) => void;
  handleViewClick: (event: React.MouseEvent<HTMLAnchorElement, MouseEvent>, id: number) => void;
  handleCreateClick?: (id: number) => void;
  deleteIcon?: string;
  code?: string;
  sortHandler?: (columnName: string, orderBy: string) => void;
  triggeredReset?: boolean;
}

const ListingTable: React.FC<ListingTable> = ({
  tableBody,
  handleOnchangeStatus,
  // hasEditPermission,
  tableHeader,
  loading,
  handleTableRowClick,
  handleEditClick,
  handleViewClick,
  handleCreateClick,
  deleteIcon,
  code,
  sortHandler = () => {},
  triggeredReset,
}) => {
  const { t } = useTranslation();
  const [isHovered, setIsHovered] = useState('');
  const [isHoveredIcon, setIsHoveredIcon] = useState(0);
  const [isHoveredActivate, setIsHoveredActivate] = useState(false);
  const [isHoveredAdd, setIsHoveredAdd] = useState(false);
  const [activeSortColumn, setActiveSortColumn] = useState<string>('');
  const [sortOrder, setSortOrder] = useState<string>('');

  const utilsMasterData = useAppSelector((state) => state.master);

  const utilsMasterList: Array<UtilsMasterData> = utilsMasterData?.results;

  const plantDataString = useAppSelector((state) => state.plantData.plantData);
  const plantData: any = plantDataString ?? null;
  const plant_time_zone_id: any = plantData.plant_time_zone_id;

  const timeZone = utilsMasterList?.filter((item: any) => item.id == plant_time_zone_id)?.[0]
    ?.description;

  const handleMouseEnter = (role: any) => {
    setIsHovered(role);
  };
  const handleMouseLeave = () => {
    setIsHovered('');
  };

  let hoverMessage = '';
  if (isHoveredIcon !== 0) {
    if (isHoveredIcon == 1) {
      hoverMessage = t('sharedTexts.view');
    } else if (isHoveredIcon == 2) {
      hoverMessage = t('sharedTexts.edit');
    } else {
      hoverMessage = deleteIcon ? t('sharedTexts.delete') : t('sharedTexts.deactivate');
    }
  }

  const handleDeactivateAction = (item: any) => {
    handleOnchangeStatus(item.id, 'Deactivate', item[code || 'mes_mat_code']);
  };

  const { pathname } = useLocation();
  const module = pathname?.split('/')[1];
  const subModule = pathname?.split('/')[2];

  const hasCreatePermission = validatePermissions(
    permissionsMapper[module],
    permissionsMapper[subModule],
    crudType.create
  );

  const hasEditPermission = validatePermissions(
    permissionsMapper[module],
    permissionsMapper[subModule],
    crudType.edit
  );

  const hasDeletePermission = validatePermissions(
    permissionsMapper[module],
    permissionsMapper[subModule],
    crudType.delete
  );

  const handleSortClick = (columnName: string) => {
    const compareController = activeSortColumn === columnName ? sortOrder : '';
    const sortOrderToPass: string =
      compareController === '' ? 'ASC' : compareController === 'ASC' ? 'DESC' : 'ASC';
    setSortOrder(sortOrderToPass);
    setActiveSortColumn(columnName);
    sortHandler(columnName, sortOrderToPass);
  };

  const clearSort = () => {
    setSortOrder('');
    setActiveSortColumn('');
    sortHandler('', '');
  };

  useEffect(() => {
    clearSort();
  }, [triggeredReset]);

  if (loading) return <Loading />;
  return (
    <div className='container mt-3 mb-3'>
      <div className='table-general-wrapper'>
        <table className='table-general'>
          <thead>
            <tr>
              {tableHeader.map((item: any) => (
                <td onClick={() => handleSortClick(item.key)} key={item.header}>
                  {item.header}

                  {item.sortEnabled && (
                    <span className='ml-2' style={{ cursor: 'pointer' }}>
                      {activeSortColumn !== item.key && (
                        <SortIcon sx={{ color: '#04436b', fontSize: '20px' }} />
                      )}
                      {activeSortColumn === item.key && (
                        <>
                          {sortOrder === 'ASC' ? (
                            <DownIcon sx={{ color: '#04436b', fontSize: '15px' }} />
                          ) : (
                            <UpIcon sx={{ color: '#04436b', fontSize: '15px' }} />
                          )}
                        </>
                      )}{' '}
                    </span>
                  )}
                </td>
              ))}

              <td>{''}</td>
            </tr>
          </thead>
          <tbody>
            {!isEmpty(tableBody) &&
              tableBody.map((item: any) => (
                <tr
                  onMouseEnter={() => handleMouseEnter(item.id)}
                  onMouseLeave={handleMouseLeave}
                  key={item.id}
                  onClick={() => item.record_status && handleTableRowClick(item.id)}
                  // className={`${role.record_status ? 'pointer-events-none' : ''}`}
                  style={{ height: '50px' }}
                >
                  {tableHeader.map((column: any) =>
                    column.key !== 'record_status' ? (
                      column.key && (
                        <td style={{ padding: '8px', paddingLeft: '13px' }}>
                          {column.key == 'created_at'
                            ? `${new Date(item[column.key]).toLocaleDateString('en-GB', {
                                day: '2-digit',
                                month: '2-digit',
                                year: 'numeric',
                              })}`
                            : column.key == 'observation_dt'
                              ? formatDateHelper(item[column.key], timeZone)
                              : item[column.key]}
                        </td>
                      )
                    ) : (
                      <td
                        key={item.id}
                        style={{
                          pointerEvents: 'auto',
                          padding: '8px',
                          verticalAlign: 'baseline',
                          paddingTop: '12px',
                        }}
                      >
                        <div className='flex items-center'>
                          <div className='switch-container mr-2' style={{ width: 'auto' }}>
                            {!item.record_status ? (
                              <span
                                style={{
                                  backgroundColor: '#FFD3CD',
                                  color: ' #B60000',
                                  padding: '4px 10px',
                                  borderRadius: '12px',
                                  gap: '10px',
                                  fontSize: '13px',
                                }}
                              >
                                {t('sharedTexts.inactive')}
                              </span>
                            ) : (
                              <span
                                style={{
                                  backgroundColor: '#D8E9C1',
                                  color: '#357821',
                                  padding: '4px 15px',
                                  borderRadius: '12px',
                                  gap: '10px',
                                  fontSize: '13px',
                                }}
                              >
                                {t('sharedTexts.active')}
                              </span>
                            )}
                          </div>
                        </div>
                      </td>
                    )
                  )}

                  <td
                    style={{ width: '100px', display: 'flex', justifyContent: 'end' }}
                    onClick={(e) => e.stopPropagation()}
                    className={`${item.record_status ? 'cursor-pointer' : 'cursor-default'}`}
                  >
                    <div style={{ width: '15px' }}>
                      <div
                        className={`relative flex items-center justify-center ${
                          item.record_status ? 'cursor-pointer' : 'cursor-default'
                        } `}
                        style={{ width: 16, height: 16 }}
                      >
                        {isHovered === item.id && item.record_status && (
                          <div className='flex items-center'>
                            <Link
                              to='#'
                              onClick={(e) => handleViewClick(e, item.id)}
                              data-tip='View'
                            >
                              <button
                                style={{ border: '0px solid', backgroundColor: '#f0ffff00' }}
                                type='button'
                                onMouseEnter={() => setIsHoveredIcon(1)}
                                onMouseLeave={() => setIsHoveredIcon(0)}
                              >
                                <img
                                  src={viewIcon}
                                  alt='view'
                                  className='icon mr-10'
                                  style={{ fill: '#04436B', width: '20px', height: '20px' }}
                                />
                              </button>
                            </Link>
                            {hasEditPermission && (
                              <Link
                                to='#'
                                onClick={(e) => handleEditClick(e, item.id)}
                                data-tip='Edit'
                              >
                                <button
                                  style={{ border: '0px solid', backgroundColor: '#f0ffff00' }}
                                  type='button'
                                  onMouseEnter={() => setIsHoveredIcon(2)}
                                  onMouseLeave={() => setIsHoveredIcon(0)}
                                >
                                  <img
                                    src={editIcon}
                                    alt='edit'
                                    className='icon mr-10'
                                    style={{ fill: '#04436B', width: '15px', height: '15px' }}
                                  />
                                </button>
                              </Link>
                            )}

                            {/* <Link to={`/deactivate/${role.id}`} data-tip='Deactivate'> */}
                            {hasEditPermission && !deleteIcon && (
                              <button
                                style={{ border: '0px solid', backgroundColor: '#f0ffff00' }}
                                type='button'
                                onClick={() => handleDeactivateAction(item)}
                                onMouseEnter={() => setIsHoveredIcon(3)}
                                onMouseLeave={() => setIsHoveredIcon(0)}
                              >
                                <img
                                  src={deactivateIcon}
                                  alt='deactivate'
                                  className='icon mr-6'
                                  style={{ fill: '#04436B', width: '15px', height: '15px' }}
                                />
                              </button>
                            )}

                            {hasDeletePermission && deleteIcon && (
                              <button
                                style={{ border: '0px solid', backgroundColor: '#f0ffff00' }}
                                type='button'
                                onClick={() => handleDeactivateAction(item)}
                                onMouseEnter={() => setIsHoveredIcon(3)}
                                onMouseLeave={() => setIsHoveredIcon(0)}
                              >
                                <img
                                  src={deleteIcon}
                                  alt='delete'
                                  className='icon mr-6'
                                  style={{ fill: '#04436B', width: '15px', height: '15px' }}
                                />
                              </button>
                            )}

                            {isHoveredIcon !== 0 && (
                              <span
                                style={{
                                  position: 'absolute',
                                  top: '25px',
                                  left:
                                    isHoveredIcon == 1
                                      ? '-55px'
                                      : hoverMessage == 'Delete'
                                        ? '15px'
                                        : '-15px',
                                  backgroundColor: '#022549',
                                  padding: '5px',
                                  color: '#fff',
                                  fontSize: '14px',
                                  borderRadius: '4px',
                                  minWidth: 'max-content',
                                }}
                              >
                                {hoverMessage}
                              </span>
                            )}
                          </div>
                        )}

                        {isHovered === item.id &&
                          !item.record_status &&
                          ((item.is_created && hasEditPermission) || hasCreatePermission) && (
                            <div className='flex items-center justify-start cursor-pointer gap-2'>
                              {item.is_created && hasEditPermission && (
                                <button
                                  className='switch-container mr-2'
                                  style={{ border: '0px solid', backgroundColor: '#f0ffff00' }}
                                  onClick={(e) => e.stopPropagation()}
                                  onMouseEnter={() => setIsHoveredActivate(true)}
                                  onMouseLeave={() => setIsHoveredActivate(false)}
                                  type='button'
                                >
                                  <input
                                    id={`switch-${item.id}`}
                                    type='checkbox'
                                    className='switch-input '
                                    checked={item.record_status}
                                    onChange={() =>
                                      handleOnchangeStatus(
                                        item.id,
                                        'Activate',
                                        item[code || 'mes_mat_code']
                                      )
                                    }
                                  />
                                  <label
                                    htmlFor={`switch-${item.id}`}
                                    className='switch-label switch-label--sm'
                                  ></label>
                                </button>
                              )}

                              {hasCreatePermission && (
                                <button
                                  style={{
                                    border: '0px solid',
                                    backgroundColor: '#f0ffff00',
                                    width: '38px',
                                  }}
                                  onClick={() => handleCreateClick && handleCreateClick(item.id)}
                                  onMouseEnter={() => setIsHoveredAdd(true)}
                                  onMouseLeave={() => setIsHoveredAdd(false)}
                                  type='button'
                                >
                                  <img
                                    src={addIcon}
                                    alt='view'
                                    className='icon mr-10'
                                    style={{ fill: '#04436B', width: '16px', height: '16px' }}
                                  />
                                </button>
                              )}

                              {(isHoveredActivate || isHoveredAdd) && (
                                <span
                                  style={{
                                    position: 'absolute',
                                    top: '25px',
                                    left: isHoveredAdd ? '-30px' : '-50px',
                                    backgroundColor: '#022549',
                                    padding: '5px',
                                    color: '#fff',
                                    fontSize: '14px',
                                    borderRadius: '4px',
                                    width: 'max-content',
                                  }}
                                >
                                  {isHoveredAdd
                                    ? t('sharedTexts.addDetails')
                                    : t('sharedTexts.activate')}
                                </span>
                              )}
                            </div>
                          )}
                      </div>
                      {/* <ReactTooltip effect='solid' place='bottom' /> */}
                    </div>
                  </td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ListingTable;
