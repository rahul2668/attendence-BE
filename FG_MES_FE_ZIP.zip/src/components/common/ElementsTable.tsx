import React from 'react';
import { preventArrowBehavior } from 'utils/utils';
import { MaterialElement } from 'types/material.model';
import { useTranslation } from 'react-i18next';
import { autoCalculatedFields } from 'utils/constants';

interface IElementsTableProps {
  isEdit: boolean;
  elements: Array<MaterialElement>;
  elementNameWithError: Array<string>;
  warningTolerance?: boolean;
  handleInputChange: (
    elementName: string,
    property: 'low' | 'high' | 'aim' | 'i' | 'warning_tolerance' | 'control',
    value: any,
    id: number
  ) => void;
  handleTrackChangeHistory: (
    elementName: string,
    property: 'low' | 'high' | 'aim' | 'i' | 'warning_tolerance' | 'control',
    new_value: any,
    id: number
  ) => void;
  handleCheckBoxChange: (elementName: string, id: number, value: boolean) => void;
}

const ElementsTable: React.FC<IElementsTableProps> = ({
  isEdit,
  elements,
  handleInputChange,
  handleTrackChangeHistory,
  elementNameWithError,
  warningTolerance,
  handleCheckBoxChange,
}) => {
  const { t } = useTranslation();

  return (
    <div
      className={elements?.length > 1 ? 'px-2 mt-1' : 'col-6 px-2 mt-1'}
      style={elements?.length > 1 ? { flex: 1 } : {}}
    >
      <table
        className={
          warningTolerance
            ? 'wip-table table-value-of-elements table-value-of-elements--list-view'
            : 'table-value-of-elements table-value-of-elements--list-view'
        }
      >
        <thead>
          <tr>
            <td style={{ textAlign: 'left' }}>{t('masterData.sharedMasterDataTexts.elements')}</td>
            <td style={{ textAlign: 'center' }}>{t('masterData.sharedMasterDataTexts.low')}</td>
            <td style={{ textAlign: 'center' }}>{t('masterData.sharedMasterDataTexts.aim')}</td>
            <td style={{ textAlign: 'center' }}>{t('masterData.sharedMasterDataTexts.high')}</td>
            {warningTolerance && (
              <td style={{ textAlign: 'center' }}>
                {t('masterData.workInProgress.warningTolerance')}
              </td>
            )}
            {warningTolerance && (
              <td style={{ textAlign: 'center' }}>
                {t('masterData.sharedMasterDataTexts.control')}
              </td>
            )}
            {/* <td>I</td> */}
          </tr>
        </thead>
        <tbody>
          {elements?.map((element: any) => {
            const elementName: any = element['element'];
            const inputDisabled: boolean = autoCalculatedFields?.includes(elementName);
            return (
              <tr key={element.element}>
                <td>{elementName}</td>
                <td style={{ textAlign: 'center' }}>
                  <input
                    style={{ textAlign: 'center' }}
                    type='number'
                    disabled={inputDisabled || !isEdit}
                    placeholder='0.00'
                    value={element.low}
                    className={` input-field ${!isEdit && 'disabled-input-view'} ${
                      elementNameWithError.includes(elementName) ? 'input-field--error' : ''
                    }`}
                    onChange={(e) => {
                      handleInputChange(elementName, 'low', +e.target.value, element.id);
                      handleTrackChangeHistory(elementName, 'low', +e.target.value, element.id);
                    }}
                    onKeyDown={(e: any) => preventArrowBehavior(e, 'number')}
                    onWheel={(event: any) => event.currentTarget.blur()}
                  />
                </td>
                <td style={{ textAlign: 'center' }}>
                  <input
                    type='number'
                    style={{ textAlign: 'center' }}
                    disabled={inputDisabled || !isEdit}
                    placeholder='0.00'
                    value={element.aim}
                    className={` input-field ${!isEdit && 'disabled-input-view'} ${
                      elementNameWithError.includes(elementName) ? 'input-field--error' : ''
                    }`}
                    onChange={(e) => {
                      handleInputChange(elementName, 'aim', +e.target.value, element.id);
                      handleTrackChangeHistory(elementName, 'aim', +e.target.value, element.id);
                    }}
                    onKeyDown={(e) => preventArrowBehavior(e, 'number')}
                    onWheel={(event) => event.currentTarget.blur()}
                  />
                </td>
                <td style={{ textAlign: 'center' }}>
                  <input
                    type='number'
                    disabled={inputDisabled || !isEdit}
                    style={{ textAlign: 'center' }}
                    placeholder='0.00'
                    value={element.high}
                    className={` input-field ${!isEdit && 'disabled-input-view'} ${
                      elementNameWithError.includes(elementName) ? 'input-field--error' : ''
                    }`}
                    onChange={(e) => {
                      handleInputChange(elementName, 'high', +e.target.value, element.id);
                      handleTrackChangeHistory(elementName, 'high', +e.target.value, element.id);
                    }}
                    onKeyDown={(e) => preventArrowBehavior(e, 'number')}
                    onWheel={(event) => event.currentTarget.blur()}
                  />
                </td>
                {warningTolerance && (
                  <td style={{ textAlign: 'center' }}>
                    <input
                      type='number'
                      disabled={true}
                      style={{ textAlign: 'center' }}
                      placeholder='0.00'
                      value={element.warning_tolerance}
                      className={`warning-tolerance-input input-field ${
                        elementNameWithError.includes(elementName) ? 'input-field--error' : ''
                      }`}
                      onChange={(e) => {
                        handleInputChange(
                          elementName,
                          'warning_tolerance',
                          +e.target.value,
                          element.id
                        );
                        handleTrackChangeHistory(
                          elementName,
                          'warning_tolerance',
                          +e.target.value,
                          element.id
                        );
                      }}
                      onKeyDown={(e) => preventArrowBehavior(e, 'number')}
                      onWheel={(event) => event.currentTarget.blur()}
                    />
                  </td>
                )}
                {warningTolerance && (
                  <td style={{ textAlign: 'center', display: 'flex', justifyContent: 'center' }}>
                    <div className='form-check'>
                      <input
                        className='form-check-input wip-checkbox products__input'
                        type='checkbox'
                        style={{ padding: '10px' }}
                        value={element.control}
                        checked={element.control}
                        defaultChecked={element.control}
                        name='productName'
                        disabled={!isEdit}
                        onChange={(e: any) =>
                          handleCheckBoxChange(elementName, element.id, e.target.checked)
                        }
                      />
                    </div>
                  </td>
                )}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default ElementsTable;
