// Observation log form - reusable component
import { FC } from 'react';
import { Box, Grid } from '@mui/material';
import dayjs from 'dayjs';
import { useTranslation } from 'react-i18next';
import { logBook } from 'utils/constants';

const ObservationView: FC<any> = ({ observationData, screen }) => {
  const { t } = useTranslation();
  const handleDateFormat = (value: string) => {
    const date = dayjs(value);
    const formattedDate = date.format('DD-MMM-YYYY | hh:mm A');
    return formattedDate;
  };
  const dataEntries = Object.keys(observationData)
    .filter(
      (key) =>
        (typeof observationData[key] === 'object' &&
          key !== 'observation_dt' &&
          observationData[key] !== null) ||
        key === 'comments'
    )
    .map((key) => {
      if (
        typeof observationData[key] === 'object' &&
        observationData[key] !== null &&
        observationData[key]?.label !== 'Observation Date & Time'
      ) {
        return { label: observationData[key].label, value: observationData[key].value || '- -' };
      } else if (
        key !== 'observation_dt' &&
        observationData[key]?.label === 'Observation Date & Time'
      ) {
        return {
          label: observationData[key].label,
          value: handleDateFormat(observationData[key].value),
        };
      } else if (key === 'comments') {
        return { label: 'Comments', value: observationData[key] || '- -' };
      } else {
        return { label: key, value: observationData[key] || '- -' };
      }
    });

  const handleTranslate = (label: string) => {
    let translationKey: any;
    if (screen === logBook.furnaceBed) {
      translationKey = `logBook.furnaceBedLog.${label}`;
    } else if (screen === logBook.tapHole) {
      translationKey = `logBook.tapHoleLog.${label}`;
    }
    const translatedString = t(translationKey);

    // If the translation exists, `translatedString` will be the translated value,
    // otherwise, it will be the same as `translationKey`
    const displayString = translatedString !== translationKey ? translatedString : label;

    return displayString;
  };

  return (
    <Box display={'flex'} flexDirection={'column'} sx={{ gap: '25px' }}>
      <Grid container spacing={2}>
        {dataEntries.map((item: any, index: number) => (
          <Grid item xs={6} sm={3} key={index}>
            <div style={{ fontWeight: 600, color: '#606466', fontSize: '14px' }}>
              {handleTranslate(item.label)}
            </div>
            <div>
              <strong style={{ fontWeight: 600, fontSize: '14px', overflowWrap: 'break-word' }}>
                {item.label !== 'Observation Date & Time' && item.label !== 'comments'
                  ? handleTranslate(item.value)
                  : item.value}
              </strong>
            </div>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default ObservationView;
