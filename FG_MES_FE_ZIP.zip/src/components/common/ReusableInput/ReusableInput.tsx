import { Box, FormControl, InputLabel, Typography } from '@mui/material';

import { useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';

interface ReusableInputProps {
  label: string;
  valueState?: string | number;
  name?: string;
  requiredField?: boolean;
  type: 'number' | 'text';
  handleOnChange: (event: any) => void;
  customWidth?: string; // pixels as number
  fieldDisabled?: boolean; // Use this flag to disable field on certain conditions
  placeholder?: string;
  unit?: string;
  globalErrorState?: any;
  fieldError?: string;
  viewMode?: boolean;
}

const ReusableInput = ({
  label,
  valueState = '',
  name = 'defaultName',
  placeholder = 'Enter',
  requiredField,
  type,
  handleOnChange,
  fieldDisabled = false,
  customWidth,
  unit = '',
  globalErrorState = {},
  fieldError = '',
  viewMode,
}: ReusableInputProps) => {
  const { t } = useTranslation();

  const [spanWidth, setSpanWidth] = useState(0);
  const spanRef = useRef<HTMLSpanElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (spanRef.current) {
      setSpanWidth(spanRef.current.offsetWidth);
    }
  }, [spanRef]);

  return (
    <Box>
      <InputLabel
        id='fn'
        sx={{
          fontWeight: 600,
          color: '#606466',
          marginBottom: '5px',
          fontSize: '14px',
        }}
      >
        {/* pass translated label - use t() in prop  */}
        {requiredField && !viewMode ? `${t(label, label)}*` : t(label, label)}
      </InputLabel>

      {viewMode ? (
        <Box minWidth={250}>
          <Typography
            variant='body1'
            style={{
              fontFamily: 'Inter, sans-serif',
              fontWeight: 600,
              fontSize: '14px',
              lineHeight: '19.6px',
            }}
          >
            {valueState} {unit && <span>{unit}</span>}
          </Typography>
        </Box>
      ) : (
        <FormControl>
          <div style={{ position: 'relative' }}>
            <input
              type={type}
              ref={inputRef}
              onKeyDown={(evt) => {
                if (type === 'number')
                  ['e', 'E', '+', '-'].includes(evt.key) && evt.preventDefault();
              }}
              style={{
                width: customWidth ? `${customWidth}` : '',
                backgroundColor: fieldDisabled ? '#e3e9ea' : '',
                paddingRight: unit ? `${spanWidth + 20}px` : '', // Add extra space (10px) for better visual separation
              }}
              className='furnace__input'
              name={name}
              onChange={(event) => handleOnChange(event)}
              value={valueState}
              placeholder={placeholder}
              disabled={fieldDisabled}
            />
            {unit && (
              <span ref={spanRef} className='unit-display'>
                {unit}
              </span>
            )}
          </div>
          {globalErrorState[name] && <p className='error-text'>{t(globalErrorState[name])}</p>}
          {fieldError && (
            <p className='error-text' style={{ maxWidth: inputRef?.current?.offsetWidth }}>
              {fieldError}
            </p> // Add this line
          )}
        </FormControl>
      )}
    </Box>
  );
};

export default ReusableInput;
