import CustomDrawer from './Drawer';
import CloseIcon from '@mui/icons-material/Close';
import CheckboxesTags from './multiSelector';
import CustomSelect from './SelectField';
import { Box, Checkbox, FormControlLabel, FormGroup, InputLabel } from '@mui/material';
import { useTranslation } from 'react-i18next';
import { useAppSelector } from 'store';
import CustomDatePicker from './CustomDatePicker';
import CustomDateRangePicker from './DateRange';
import dayjs, { Dayjs } from 'dayjs';
import { useDispatch } from 'react-redux';
import { setFilterDataList } from 'store/slices/filterDataList';
import { useEffect } from 'react';
import { isEmpty } from 'utils/utils';
import MUIToolTip from './ToolTip/MUIToolTip';
import { FilterFieldKeys, filterFieldTranslationKeyPrefix } from 'utils/constants';

interface CustomFilter {
  openFilter: boolean;
  setOpenFilter: (value: boolean) => void;
  setOpenStatusList: (value: boolean) => void;
  setDisableFilter: (value: boolean) => void;
  openStatusList: boolean;
  disableFilter: boolean;
  setIsFilterApplied: (value: boolean, item: boolean) => void;
  appliedFilter: Array<any>;
  filterFieldList: Array<any>;
  setAppliedFilter: Array<any>;
  triggeredReset?: () => void;
}

interface CheckBoxList {
  id: number;
  value: string;
}

interface Selector {
  option: string;
  value: any;
}

const CustomFilter = ({
  openFilter,
  setOpenFilter,
  setOpenStatusList,
  setDisableFilter,
  // openStatusList,
  disableFilter,
  setIsFilterApplied,
  appliedFilter,
  filterFieldList,
  setAppliedFilter,
  triggeredReset = () => {},
  onResetFilter = () => {},
}: any) => {
  const { t } = useTranslation();
  const filterDataListState = useAppSelector((state) => state.filterDataList.filterDataList);

  const dispatch = useDispatch();

  const handleTypeCheckbox = (value: Array<string>, type: string) => {
    dispatch(setFilterDataList({ ...filterDataListState, [type]: value }));
    setDisableFilter(false);
  };

  const handleSelectChange = (val: Selector, type: string) => {
    setOpenStatusList(false);
    dispatch(setFilterDataList({ ...filterDataListState, [type]: val }));
    setDisableFilter(false);
  };

  const handleDateAndTimeChange = (newDateAndTime: Dayjs | null, type: string) => {
    dispatch(setFilterDataList({ ...filterDataListState, [type]: newDateAndTime }));
    setDisableFilter(false);
  };

  const handleDateRangeChange = (newDateAndTime: Array<Dayjs | null>, type: string) => {
    dispatch(setFilterDataList({ ...filterDataListState, [type]: newDateAndTime }));
    setDisableFilter(false);
  };

  const handleCheckboxSelected = (event: any, typeName: any, type: string) => {
    const isChecked = event.target.checked;
    if (isChecked) {
      if (filterDataListState[type]) {
        // If checkbox is checked, add it to selectedCheckboxList
        dispatch(
          setFilterDataList({
            ...filterDataListState,
            [type]: [...filterDataListState[type], typeName],
          })
        );
      } else {
        dispatch(setFilterDataList({ ...filterDataListState, [type]: [typeName] }));
      }
    } else {
      // If checkbox is unchecked, remove it from selectedCheckboxList

      const removedData = filterDataListState[type].filter(
        (selectedItem: any) => selectedItem !== typeName
      );
      dispatch(setFilterDataList({ ...filterDataListState, [type]: removedData }));
    }

    setDisableFilter(false);
  };

  function transformData(data: any) {
    let transformedData: any = [];

    const changeArrayOfDataToObject = (key: any, value: any) => {
      const result = [];

      if (Array.isArray(value) && value.length === 2 && dayjs(value[0] || value[1]).isValid()) {
        result.push({
          [key]: `${dayjs(value[0]).format('YYYY-MM-DD')} - ${dayjs(value[1]).format('YYYY-MM-DD')}`,
        });
      } else if (Array.isArray(value) && value.every((item) => typeof item === 'string')) {
        value.forEach((item) => result.push({ [key]: item }));
      } else if (
        typeof value === 'object' &&
        value !== null &&
        'option' in value &&
        'value' in value
      ) {
        result.push({ [key]: value.option });
      } else if (dayjs(value).isValid()) {
        result.push({ [key]: dayjs(value).format('YYYY-MM-DD') });
      } else if (typeof value === 'string') {
        result.push({ [key]: value });
      } else {
        result.push({ [key]: value });
      }

      return result;
    };

    Object.keys(data).forEach((key) => {
      const value = data[key];
      transformedData = transformedData.concat(changeArrayOfDataToObject(key, value));
    });

    return transformedData;
  }

  const handleFilterApply = () => {
    const formattedData = transformData(filterDataListState);
    setAppliedFilter(formattedData);
  };

  const removeFilter = (value: any, index: number) => {
    const arrayToRemove = [...appliedFilter];
    arrayToRemove.splice(index, 1);

    setAppliedFilter(arrayToRemove);

    const key: any = Object.keys(value);

    if (
      Array.isArray(filterDataListState[key]) &&
      !dayjs(filterDataListState[key][0] || filterDataListState[key][1]).isValid()
    ) {
      const removedData = filterDataListState[key].filter(
        (selectedItem: any) => selectedItem !== value[key]
      );

      dispatch(setFilterDataList({ ...filterDataListState, [key]: removedData }));
    } else {
      const { [key]: toBeRemoved, ...updatedFilterDataListState } = filterDataListState;
      // -> extract toBeRemoved  and just return the rest
      dispatch(setFilterDataList(updatedFilterDataListState));
    }
  };

  useEffect(() => {
    setIsFilterApplied(true, true);
    handleFilterApply();
  }, [filterDataListState]);

  return (
    <>
      <CustomDrawer open={openFilter} setOpen={setOpenFilter}>
        <div
          className='d-flex'
          style={{
            position: 'fixed',
            display: 'flex',
            justifyContent: 'space-between',
            backgroundColor: 'white',
            width: '500px',
            padding: '1rem',
            zIndex: 2,
            boxShadow: '0 4px 8px rgba(149, 157, 165, 0.2)',
          }}
        >
          <strong style={{ marginLeft: '10px' }}>{t('sharedTexts.filters')}</strong>
          <CloseIcon
            fontSize='small'
            onClick={(event) => {
              setOpenStatusList(false);
              event.stopPropagation();
              setOpenFilter(false);
            }}
          />
        </div>
        <div className='p-3 mt-5 mb-5 pb-5'>
          {/* Heading and close  */}

          {/* Heading and close end   */}

          <div className='d-flex justify-content-center w-100 mt-3'>
            <div className='d-flex flex-column gap-3'>
              {filterFieldList.map((item: any) => (
                <>
                  {/* TYPE  */}
                  {item?.type == 'multiSelector' && (
                    <div style={{ marginBottom: '1rem' }}>
                      <CheckboxesTags
                        data={item.option}
                        checkboxChange={handleTypeCheckbox}
                        value={filterDataListState?.[item.option.name] || []}
                      />
                    </div>
                  )}
                  {/* TYPE END  */}
                  {item?.type == 'selector' && (
                    <div
                      className={`filters-sort-dropdown-menu__list mb-0`}
                      style={{ width: '450px' }}
                    >
                      <InputLabel
                        id='fn'
                        sx={{
                          fontWeight: 600,
                          color: '#606466',
                          fontSize: '14px',
                          marginBottom: '5px',
                        }}
                      >
                        {item?.label}
                      </InputLabel>
                      <CustomSelect
                        placeholder={item?.name}
                        options={item.option}
                        onChange={(val: any) => {
                          handleSelectChange(
                            item.option.filter((item: any) => item.value == val)[0] || {},
                            item?.name
                          );
                        }}
                        value={filterDataListState?.[item?.name]?.option || item?.name}
                      />
                    </div>
                  )}
                  {item?.type == 'date' && (
                    <Box>
                      <InputLabel
                        id='fn'
                        sx={{
                          fontWeight: 600,
                          color: '#606466',
                          fontSize: '14px',
                          marginBottom: '5px',
                        }}
                      >
                        {item?.name}
                      </InputLabel>
                      <CustomDatePicker
                        handleDateAndTimeChange={(value) =>
                          handleDateAndTimeChange(value, item?.name)
                        }
                        value={
                          filterDataListState?.[item.name] ? filterDataListState?.[item.name] : null
                        }
                      />
                    </Box>
                  )}
                  {item?.type == 'dateRange' && (
                    <Box sx={{ width: '450px' }}>
                      <CustomDateRangePicker
                        value={
                          filterDataListState?.[item.name]
                            ? filterDataListState?.[item.name]
                            : [null, null]
                        }
                        handleChange={(value: Array<Dayjs | null>) =>
                          handleDateRangeChange(value, item?.name)
                        }
                      />
                    </Box>
                  )}
                  {item?.type == 'checkbox' && (
                    <FormGroup>
                      <InputLabel
                        id='fn'
                        sx={{
                          fontWeight: 600,
                          color: '#606466',
                          fontSize: '14px',
                          marginBottom: '5px',
                        }}
                      >
                        {item?.option?.name}
                      </InputLabel>
                      {item?.option?.list.map((value: CheckBoxList) => (
                        <FormControlLabel
                          key={value.id}
                          control={<Checkbox />}
                          label={value.value}
                          onChange={(event) =>
                            handleCheckboxSelected(event, value.value, item?.option?.name)
                          }
                        />
                      ))}
                    </FormGroup>
                  )}
                </>
              ))}
            </div>
          </div>
        </div>
        {/* ------------------   buttons section   ---------------------------------*/}
        <div
          style={{
            display: 'flex',
            justifyContent: 'end',
            backgroundColor: 'white',
            position: 'fixed',
            bottom: 0,
            zIndex: 20,
            width: '500px',
            padding: '1rem',
            paddingRight: '1.4rem',
            boxShadow: '0 -4px 12px rgba(149, 157, 165, 0.2)',
          }}
        >
          <button
            className={`btn btn--reset btn--h36 px-4 py-2 ${
              isEmpty(filterDataListState) || disableFilter ? 'disabled' : ''
            }`}
            type='button'
            onClick={(event) => {
              dispatch(setFilterDataList({}));
              triggeredReset();
              setIsFilterApplied(!isEmpty(appliedFilter), true);
              setAppliedFilter([]);
              setOpenStatusList(false);
              setOpenFilter(false); // closes the filter slide
              onResetFilter();
              event.stopPropagation();
            }}
          >
            {t('sharedTexts.reset')}
          </button>

          {/* <button
            className={`btn btn--primary btn--h36 ${openStatusList === true ? 'mt-18' : ''} ${
              isEmpty(filterDataListState) || disableFilter ? 'disabled' : ''
            }`}
            type='button'
            onClick={(event) => {
              handleFilterApply();
              setIsFilterApplied(true, false);
              setOpenStatusList(false);
              setOpenFilter(false); // closes the filter slide
              event.stopPropagation();
            }}
          >
            {t('sharedTexts.applyFilter')}
          </button> */}
        </div>

        {/* ==================   buttons section end   ============================= */}
      </CustomDrawer>

      <div
        style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', margin: '20px 10px 10px 10px' }}
      >
        {appliedFilter.map((filter: any, index: number) => (
          <div
            key={index} // Assigning a unique key to each rendered element
            style={{
              backgroundColor: '#fff',
              display: 'flex',
              padding: '2px 15px 5px 15px',
              borderRadius: '40px',
              boxShadow: 'rgb(219 219 219) 0px 0px 3px 1px',
            }}
          >
            {Object.entries(filter).map(
              (
                [key, value]: any // Extracting key and value
              ) => {
                const translatedAccessKey: any = Object.keys(
                  filterFieldTranslationKeyPrefix
                ).includes(key)
                  ? `${filterFieldTranslationKeyPrefix[key as FilterFieldKeys]}${value}`
                  : null;
                return (
                  <MUIToolTip
                    key={key}
                    text={`${key}: ${translatedAccessKey ? `${t(translatedAccessKey)}` : value}`}
                    arrowVersion
                    topPosition
                  >
                    <div
                      style={{
                        maxWidth: '150px',
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        whiteSpace: 'nowrap',
                      }}
                    >
                      <strong style={{ fontSize: '13px', color: '#606466' }}>{key}: </strong>
                      <span
                        style={{
                          fontSize: '13px',
                          maxWidth: '80px',
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                          whiteSpace: 'nowrap',
                          margin: '0px 5px',
                        }}
                      >
                        {translatedAccessKey ? `${t(translatedAccessKey)}` : value}
                      </span>
                    </div>
                  </MUIToolTip>
                );
              }
            )}
            {/* <MUIToolTip text={`remove`} > */}
            <CloseIcon
              sx={{ margin: '5px 0px 0px 3px', cursor: 'pointer' }}
              fontSize='inherit'
              onClick={() => removeFilter(filter, index)}
            />{' '}
            {/* </MUIToolTip> */}
            {/* Pass entire filter object */}
          </div>
        ))}
      </div>
    </>
  );
};

export default CustomFilter;
