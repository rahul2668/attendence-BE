import CustomSelect from './SelectField';
import plusIcon from '../../assets/icons/plus-white.svg';
import React from 'react';
import '../../assets/styles/scss/components/sub-header.scss';
import { validatePermissions } from 'utils/utils';
import { crudType, permissionsMapper } from 'utils/constants';
import { useLocation } from 'react-router-dom';

interface SubHeader {
  label: string;
  dropDown: Array<any>;
  onChange: (value: string | number) => void;
  addButtonClick?: () => void;
  placeholder?: string;
  selectedFurnaceValue: string;
  addButtonText?: string;
  subModuleOverride?: string;
}

const SubHeader: React.FC<SubHeader> = ({
  label,
  dropDown,
  onChange,
  addButtonClick,
  placeholder,
  selectedFurnaceValue,
  addButtonText,
  subModuleOverride,
}) => {
  const { pathname } = useLocation();
  const module = pathname?.split('/')[1];
  const subModule = pathname?.split('/')[2];

  const hasCreatePermission = validatePermissions(
    permissionsMapper[module],
    subModuleOverride ?? permissionsMapper[subModule],
    crudType.create
  );

  return (
    <div className='sub_header'>
      <div className='sub_header__container'>
        <label className='sub_header__label'>{label}</label>

        <CustomSelect
          index={0}
          options={dropDown}
          onChange={(val: any) => onChange(val)}
          disabled={false}
          toShowTooltip={false}
          placeholder={placeholder}
          value={selectedFurnaceValue}
        />
      </div>

      {hasCreatePermission && addButtonClick && (
        <button
          onClick={() => addButtonClick()}
          className={`btn btn--primary btn--h36 px-4 py-2 ml-3`}
          type='button'
        >
          <img src={plusIcon} alt='plus-icon' className='mr-2' /> {addButtonText}
        </button>
      )}
    </div>
  );
};

export default SubHeader;
