import { useTranslation } from 'react-i18next';

const Pagination = (props: any) => {
  const { t } = useTranslation();
  const {
    totalItems,
    itemsPerPage,
    onPageChange,
    currentPage,
    previous = true,
    next = true,
  } = props;

  const totalPages = Math.ceil(totalItems / itemsPerPage);

  const pageNumbers = Array.from({ length: totalPages }, (_, index) => index + 1);

  const handlePageChange = (newPage: any) => {
    if (newPage >= 1 && newPage <= totalPages) {
      onPageChange(newPage);
    }
  };

  if (totalPages <= 1) {
    return null;
  }

  return (
    <div className='pagination-container'>
      <div
        className={`pagination-btn pagination-btn--prev`}
        onClick={() => previous && handlePageChange(currentPage - 1)}
        onKeyDown={() => {
          previous && handlePageChange(currentPage - 1);
        }}
        role='none'
      >
        <div className='arrow-left-container mr-4'>
          <svg width='14' height='14' viewBox='0 0 14 14' fill='none'>
            <path
              d='M12.8332 7H1.1665'
              stroke='#989A9C'
              strokeWidth='2'
              strokeLinecap='round'
              strokeLinejoin='round'
            />
            <path
              d='M6.99984 12.8334L1.1665 7.00008L6.99984 1.16675'
              stroke='#989A9C'
              strokeWidth='2'
              strokeLinecap='round'
              strokeLinejoin='round'
            />
          </svg>
        </div>
        {t('sharedTexts.previous')}
      </div>
      <div className='pagination-count-wrapper mx-3'>
        {pageNumbers.map((pageNumber, index) => {
          if (
            index === 0 ||
            index === pageNumbers.length - 1 ||
            (index >= currentPage - 2 && index <= currentPage + 2)
          ) {
            // Render page number or ellipsis if it's the first, last, or within range
            return (
              <div
                key={pageNumber}
                className={`pagination-count__item ${currentPage === pageNumber ? 'active' : ''}`}
                onClick={() => handlePageChange(pageNumber)}
                onKeyDown={() => {
                  handlePageChange(pageNumber);
                }}
                role='none'
              >
                {pageNumber}
              </div>
            );
          } else if (index === currentPage - 3 || index === currentPage + 3) {
            // Render ellipsis at specific positions
            return (
              <div key={`ellipsis${index}`} className='pagination-count__ellipsis'>
                ...
              </div>
            );
          }
          // Return null for other cases
          return null;
        })}
      </div>

      <div
        className={`pagination-btn pagination-btn--next`}
        onClick={() => next && handlePageChange(currentPage + 1)}
        onKeyDown={() => next && handlePageChange(currentPage + 1)}
        role='none'
      >
        {t('sharedTexts.next')}
        <div className='arrow-right-container ml-4'>
          <svg width='14' height='14' viewBox='0 0 14 14' fill='none'>
            <path
              d='M12.8332 7H1.1665'
              stroke='#989A9C'
              strokeWidth='2'
              strokeLinecap='round'
              strokeLinejoin='round'
            />
            <path
              d='M6.99984 12.8334L1.1665 7.00008L6.99984 1.16675'
              stroke='#989A9C'
              strokeWidth='2'
              strokeLinecap='round'
              strokeLinejoin='round'
            />
          </svg>
        </div>
      </div>
    </div>
  );
};

export default Pagination;
