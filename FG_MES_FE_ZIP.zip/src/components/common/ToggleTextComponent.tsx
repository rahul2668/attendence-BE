import React from 'react';

interface ToggleTextComponentProps {
  label?: string;
  value: string;
  color?: string;
}

const ToggleTextComponent: React.FC<ToggleTextComponentProps> = ({ label, value, color }) => (
  <div style={{ flexBasis: '23%', marginBottom: '5px' }}>
    <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
      {label && (
        <label className='input-field-label font-semibold' style={{ fontWeight: 600 }}>
          {label}
        </label>
      )}
      <span style={{ height: '40px', fontSize: '14px', fontWeight: 600, color }}>{value}</span>
    </div>
  </div>
);

export default ToggleTextComponent;
