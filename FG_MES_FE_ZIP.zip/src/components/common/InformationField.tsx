import React, { useEffect, useState } from 'react';
import arrowDown from ' ../../assets/icons/chevron-down.svg';
import { isEmpty, notify, preventArrowBehavior } from 'utils/utils';
import OutsideClickHandler from 'react-outside-click-handler';
import '../../assets/styles/scss/components/inputField.scss';
import { useTranslation } from 'react-i18next';

enum className {
  col4 = 'col-4 px-2 mb-6 ',
  col8 = 'col-3 px-2 mb-6 ',
  col12 = 'col-12 px-2 mb-6',
}

export interface IInformationField {
  data: {
    unit: any;
    type: string;
    label: string;
    keyName: string;
    editable: boolean;
    value: string | number;
    inputComponent: 'input' | 'select' | 'select-dropdown';
    options: any;
    validation: string;
  };
  isEdit: boolean;
  gridSize: number;
  onChange: (value: string | number | boolean, keyName: string) => void;
}

const InformationField: React.FC<IInformationField> = ({
  data,
  isEdit,
  onChange,
  gridSize,
}): React.ReactElement => {
  const { t } = useTranslation();
  const [isOpen, setIsOpen] = useState<number>();
  const [touched, setTouched] = useState(false);

  const findValue = data.options?.find((opt: any) => opt.value === data.value)?.key || 'Select';
  const [inputField, setInputField] = useState(data.inputComponent === 'input' ? data.value : '');
  enum IntgerValidations {
    cooling_metal_no = 'Cooling Metal Number',
    casting_fines_no = 'Casting Fines Number',
    lot_mass = 'Lot Mass',
    unit_weight = 'Unit weight',
    primary_elment = 'Primary Element',
    inventory_prot_factor = 'Inventory Prot Factor',
    batching_system_bin = 'Batching System Bin',
    fesi_50_molten_prod_no = 'FeSi 50 Molten Prod No',
    fesi_65_molten_prod_no = 'FeSi 65 Molten Prod No',
    fesi_70_molten_prod_no = 'FeSi 70 Molten Prod No',
    fesi_50_solid_prod_no = 'FeSi 50 Solid Prod No',
    si_gd10_molten_prod_no = 'Si Gd10 Molten Prod No',
    si_gd8_molten_prod_no = 'Si Gd8 Molten Prod No',
    si_chem_molten_prod_no = 'Si Chem Molten Prod No',
    Purchased_65_FeSi_Prod_No = 'Purchased 65 FeSi Prod No',
    purchased_50_feSi_prod_no = 'Purchased 50 FeSi Prod No',
    Purchased_75_FeSi_Prod_No = 'Purchased 75 FeSi Prod No',
    Purchased_Si_Prod_No = 'Purchased Si Prod No',
    Electrode_1_Material_Number = 'Electrode 1 Material No',
    Electrode_2_Material_Number = 'Electrode 2 Material No',
    Electrode_3_Material_Number = 'Electrode 3 Material No',
    taps_per_day = 'Taps Per Day',
    power_meter_factor = 'Power Meter Factor',
  }
  enum NonZeroInteger {
    furnace_code = 'Furnace No',
  }
  useEffect(() => {
    setInputField(data.inputComponent === 'input' ? data.value : '');
  }, [data.inputComponent, data.value]);

  const handleBlur = () => {
    setTouched(true);
  };

  const handleChange = (e: any) => {
    const value = e.target.value;
    if (/^(?:\d{0,4}(?:\.\d{1,2})?|\.\d{1,2})$/.test(value)) {
      if (data.validation === 'integer' && data.keyName in IntgerValidations) {
        if (+value % 1 == 0 && +value >= 0 && value[0] != '.') {
          setInputField(e.target.value);
          onChange(e.target.value, data.keyName);
        } else {
          notify(
            'error',
            `${
              IntgerValidations[data.keyName as keyof typeof IntgerValidations]
            } ${t('masterData.sharedMasterDataTexts.shouldBePositiveInteger')}`
          );
          return;
        }
      } else if (data.validation === 'non-zero-integer' && data.keyName in NonZeroInteger) {
        if (value > 0 && +value % 1 == 0 && value[0] != '.') {
          setInputField(e.target.value);
          onChange(e.target.value, data.keyName);
        } else {
          notify(
            'error',
            `${
              NonZeroInteger[data.keyName as keyof typeof NonZeroInteger]
            } ${t('masterData.sharedMasterDataTexts.shouldBeANonZeroPositiveInteger')}`
          );
          return;
        }
      } else {
        setInputField(e.target.value);
        onChange(e.target.value, data.keyName);
      }
    }
  };

  const gridClassName =
    gridSize === 2 ? className.col8 : gridSize === 1 ? className.col12 : className.col4;

  let inputComponent;
  if (data.inputComponent === 'input') {
    inputComponent = (
      <div className='col-wrapper'>
        <label className='input-field-label font-semibold'>{data.label}</label>
        {data.editable ? (
          <div className='input_field__input_container input-group ' style={{ width: '100%' }}>
            <input
              type={data.type ? data.type : 'text'}
              className='input_field__input form-control input-field--md input-field--h40 w-full'
              style={{ borderRight: data?.unit ? '0px' : '1px solid #cdd0d1' }}
              // defaultValue={data.value}
              onBlur={handleBlur}
              onChange={handleChange}
              value={inputField}
              onKeyDown={(e) => preventArrowBehavior(e, data)}
              onWheel={(event) => event.currentTarget.blur()}
              onTouchMove={(e) => e.preventDefault()}
              placeholder={`${t('systemAdmin.furnaceConfiguration.enterValue')}`}
            />

            {data?.unit ? (
              <div className='input-group-append'>
                <span className='input_field__input_icon input-group-text'>{data.unit}</span>
              </div>
            ) : null}
          </div>
        ) : (
          <p className={'input-field-text'}>{inputField ? inputField : '-'}</p>
        )}
        {touched && isEmpty(data.value) && data.editable && (
          <span className='error-message'>{t('sharedTexts.pleaseEnterAValue')}</span>
        )}
      </div>
    );
  } else {
    inputComponent = (
      <OutsideClickHandler onOutsideClick={() => setIsOpen(0)}>
        <div className='col-wrapper'>
          <label className='input-field-label font-semibold'>{data.label}</label>
          <div className='custom-select-wrapper'>
            <button
              type='button'
              className='custom-select-container custom-select-container--md custom-select-container--h40 satoshi-bold text-sm'
              onClick={() => setIsOpen(isOpen === 1 ? 0 : 1)}
              onKeyDown={() => setIsOpen(isOpen === 1 ? 0 : 1)}
              onBlur={handleBlur}
              style={{ width: '-webkit-fill-available' }}
            >
              {findValue}
              <img src={arrowDown} alt='arrow-down' className='custom-select__arrow-down' />
            </button>
            <ul
              className={`select-dropdown-menu ${isOpen === 1 ? 'open' : ''}`}
              style={{ maxHeight: 140, overflow: 'auto' }}
            >
              {data.options?.map((option: any) => {
                return (
                  <li
                    key={option}
                    className='select-dropdown-menu__list'
                    onClick={() => {
                      setIsOpen(0);
                      onChange(option.value, data.keyName);
                    }}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        setIsOpen(0);
                        onChange(option.value, data.keyName);
                      }
                    }}
                  >
                    {option.key}
                  </li>
                );
              })}
            </ul>
          </div>
          {touched && isEmpty(data.value) && data.editable && (
            <span className='error-message'>{t('sharedTexts.pleaseEnterAValue')}</span>
          )}
        </div>
      </OutsideClickHandler>
    );
  }

  return (
    <div className={gridClassName}>
      {isEdit ? (
        inputComponent
      ) : (
        <div className='col-wrapper'>
          <label className='input-field-label font-semibold'>{data.label}</label>
          <p
            className={
              isEdit ? 'input-field input-field--md input-field--h40 w-full' : 'input-field-text'
            }
            style={{ width: 'fit-content' }}
          >
            {data.inputComponent === 'select' ? findValue : data.value || '-'}{' '}
            {data.value ? data?.unit : '-'}
          </p>
        </div>
      )}
    </div>
  );
};

export default InformationField;
