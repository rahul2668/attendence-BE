import httpClient from 'http/httpClient';
import CloseIcon from '../../../assets/icons/close-btn.svg';
import { isEqual } from 'lodash';
import { useCallback, useEffect, useRef, useState } from 'react';
// this component might need modifications to use it in edit screen
interface Data {
  next: string;
  results: any;
  status: number;
  // other properties...
}

interface LazyDropDownProps {
  options?: string[];
  onChange?: (value: any) => void;
  disabled?: boolean;
  value?: string;
  placeholder?: string;
  styles?: React.CSSProperties;
  widthRelativeToParent?: number | null;
  apiCall?: any;
  valueKey: string;
  otherParams?: any;
  firstCallDependency?: string | boolean;
  resetProductDropDown?: boolean;
  idsToBeExcluded?: number[];
}
const LazyDropDown = ({
  onChange = () => {}, // pass the value in onchange
  disabled = false,
  value = '',
  styles = {},
  placeholder = 'select a value',
  widthRelativeToParent = null, // pass a number less than 100 to change the width of the dropdown
  apiCall,
  valueKey,
  otherParams = {},
  firstCallDependency = false,
  resetProductDropDown = false,
  idsToBeExcluded = [],
}: LazyDropDownProps) => {
  const [isOpen, setIsOpen] = useState(false); // controls the dropdown visibility
  const [mouseOver, setMouseOver] = useState(false);
  const [selectedName, setSelectedName] = useState(''); // selected names string
  const [selectedOption, setSelectedOption] = useState(null); // selected option
  const [nextApiLink, setNextApiLink] = useState(''); // django api gives a next url
  const [loading, setLoading] = useState(false); // used to show loader
  const [fetchingMoreData, setFetchingMoreData] = useState(false); // used to prevent actions while an api call is under progress
  const dropdownRef: any = useRef(null); // change type
  const scrollingList: any = useRef(null); // change type
  const [options, setOptions] = useState<any>([]); // state which holds everything thats listed

  // toggle action on click of drop down box
  const handleToggle = () => {
    if (!disabled) {
      setIsOpen(!isOpen);
    }
  };

  const openDropDown = () => {
    setIsOpen(true);
  };

  useEffect(() => {
    resetComponent();
  }, [resetProductDropDown, firstCallDependency]);

  const resetComponent = () => {
    // maybe fire the onchange with a "removed flag" here?
    setOptions([]); // clear options in dropdown
    setSelectedName('');
    setSelectedOption(null);
    setIsOpen(false); // closing the drop down
  };

  // onclick of a listed item
  const handleOptionClick = (option: any) => {
    onChange(option); // firing a call back with the value (use it to populate the state)
    setSelectedName(option[valueKey]); // set the selected value's name using "key"
    setSelectedOption(option); // set the whole item to a state - the same is passed to parent
    setIsOpen(false); // closing the drop down
  };

  // this is needed... to populate
  useEffect(() => {
    // when a value is passed set it to the appropriate states
    setSelectedName(value);
  }, [value]);

  // this was here since this was a custom made drop down
  useEffect(() => {
    function handleClickOutside(event: any) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // lazy loading api call and other logics ----------

  // this is fired only for the first set of data. ie the first api call in the lazy load
  const fetchData = async (searchKey?: string) => {
    setLoading(true);
    const response = await apiCall(searchKey, otherParams);
    if (response?.data?.results) {
      setOptions(response.data.results);
    }
    if (response?.data?.next) {
      setNextApiLink(response?.data?.next);
    }
    setLoading(false);
    return response;
  };

  // this triggers the first api call
  useEffect(() => {
    const triggerApiCall = async () => {
      try {
        if (firstCallDependency) {
          // make the API call and wait for it to complete
          await fetchData();
        }
      } catch (error) {
        // Handle any errors that occur during the API call
        console.error('Error fetching data:', error);
      }
    };

    triggerApiCall();
  }, [firstCallDependency]);

  // the main function, ie fetching data again and again on scrolling down
  const getMoreData = async () => {
    if (nextApiLink) {
      // Django has a build in response (a link) of "next set of data". its stored in 'nextApiLink'
      try {
        // transforming the link to be used in our app
        const parsedUrl = new URL(nextApiLink);
        // const extractedLInk = parsedUrl.pathname + parsedUrl.search;
        setLoading(true);
        // Extract the pathname and search parameters from the URL
        const { pathname, searchParams } = parsedUrl;

        // Extract the value of the 'page' parameter from the search parameters
        const pageParam = searchParams.get('page');

        // Create a new URL containing only the 'page' parameter
        const extractedLInk = pathname + (pageParam ? `?page=${pageParam}` : '');

        const moreData = await httpClient.get(extractedLInk, {
          params: { search_key: selectedName, ...(otherParams ? otherParams : {}) }, // change it to search key
        });
        if (moreData?.status === 404) {
          //handling an exception case (found on unit testing)
          setNextApiLink(''); // if this is falsy, getMore data wont fire
          setLoading(false);
          return;
        }
        if ((moreData?.data as Data)?.results) {
          setOptions((prev: any) => [...prev, ...(moreData?.data as Data).results]); // adding new results of api to the existing results
          if (!(moreData?.data as Data)?.next) {
            // if next is null, setting it falsy. Note :  only happens on last page / chunk of data
            setNextApiLink('');
          }
        }
        if ((moreData?.data as Data)?.next) {
          setNextApiLink((moreData?.data as Data)?.next); // storing the next link
        } else {
          setNextApiLink('');
        }
      } catch (e) {
        console.log('error in lazy load component', e);
      }
    }
    setFetchingMoreData(false);
    setLoading(false);
  };

  // scroll of the list
  const handleScroll = () => {
    const { scrollTop, clientHeight, scrollHeight } = scrollingList.current;
    if (!fetchingMoreData && scrollHeight - scrollTop <= clientHeight + 1) {
      // this eqn is important (provides room for a little margin of error in calculation)
      // Reached the bottom of the dropdown
      setFetchingMoreData(true);
      getMoreData();
    }
  };

  const handleInputChange = (e: any) => {
    setOptions([]);
    if (!isOpen) setIsOpen(true);
    setSelectedName(e.target.value);
    // fetchData(e.target.value) // this will result in lot of api calls. if needed, then uncomment
    debouncedFetchData(e.target.value); // optimizes the api call
  };

  // ======= used to optimize api calls
  const debounce = (func: any, delay: number) => {
    let timer: ReturnType<typeof setTimeout>;
    return (...args: any[]) => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        func(...args);
      }, delay);
    };
  };

  // const debouncedFetchData = useCallback(debounce(fetchData, 500), []);
  const debouncedFetchData = useCallback(debounce(fetchData, 500), [otherParams]);

  // ======= used to optimize api calls

  return (
    <div
      className='custom-select'
      style={{
        height: '40px',
        overflow: 'visible',
        ...(widthRelativeToParent ? { width: `${widthRelativeToParent}%` } : {}),
      }}
      ref={dropdownRef}
    >
      <div
        onClick={openDropDown}
        onKeyDown={(e) => {
          if (e.key === 'Enter') openDropDown();
        }} // Handle Enter key
        style={{
          height: '40px',
          border: '1px solid #CDCDCD',
          padding: '8.5px 12px 8.5px 12px',
          borderRadius: '4px',
          borderBottomLeftRadius: isOpen ? '0px' : '4px',
          borderBottomRightRadius: isOpen ? '0px' : '4px',
          backgroundColor: disabled ? '#e3e9ea' : 'white',
          ...styles,
        }}
      >
        <div
          style={{
            fontSize: '14px',
            textOverflow: 'ellipsis',
            overflow: 'hidden',
            whiteSpace: 'nowrap',
            display: 'inline-block',
            width: '80%',
          }}
        >
          {selectedOption ? (
            <>
              <span style={{ fontSize: '14px' }}>
                {' '}
                {/* displaying the selection  */}
                {selectedOption[valueKey]}{' '}
                <span
                  style={{
                    border: 'solid 1px lightblue',
                    padding: '5px',
                    borderRadius: '10px 10px',
                    marginLeft: '10px',
                    cursor: 'pointer',
                  }}
                  onClick={() => {
                    setSelectedOption(null);
                    setSelectedName('');
                  }}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      setSelectedOption(null);
                      setSelectedName('');
                    }
                  }} // Handle Enter key
                >
                  {' '}
                  <img src={CloseIcon} height={10} alt='Close button' />
                </span>{' '}
              </span>
            </>
          ) : (
            <input
              value={selectedName}
              placeholder={placeholder}
              onChange={(e) => handleInputChange(e)}
              style={{
                width: '100%',
                border: 'none',
                backgroundColor: disabled ? '#e3e9ea' : 'white',
              }}
              type='text'
              name=''
              id=''
              disabled={disabled}
            />
          )}
        </div>
        <div style={{ position: 'relative' }}>
          <svg
            onClick={handleToggle}
            style={{ position: 'absolute', bottom: '8.5px', left: '96%' }}
            xmlns='http://www.w3.org/2000/svg'
            width='16'
            height='16'
            fill='currentColor'
            className='bi bi-chevron-down'
            viewBox='0 0 16 16'
          >
            <path
              fillRule='evenodd'
              d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708'
            />
          </svg>
        </div>
      </div>

      {/* the drop down begins  */}
      {isOpen && !disabled && (
        <ul
          className='options-list'
          style={{
            border: '1px solid #CDCDCD',
            borderBottomLeftRadius: '4px',
            borderBottomRightRadius: '4px',
            borderTop: '0px',
            position: 'relative',
            backgroundColor: '#fff',
            zIndex: '99999',
            maxHeight: '220px',
            overflow: 'auto',
            boxShadow: '4px 16px 24px 0px #7A7A7A40',
          }}
          onScroll={handleScroll}
          ref={scrollingList}
        >
          {options.map(
            (option: any, index: any) =>
              !idsToBeExcluded.includes(option.id) && (
                <li
                  key={option?.option}
                  onMouseOver={() => setMouseOver(index)}
                  onMouseOut={() => setMouseOver(false)}
                  onFocus={() => setMouseOver(index)}
                  onBlur={() => setMouseOver(false)}
                  onClick={() => handleOptionClick(option)}
                  onKeyDown={() => handleOptionClick(option)}
                  style={{
                    padding: '8px 12px 8px 12px',
                    cursor: 'pointer',
                    fontSize: '14px',
                    transform: '2s',
                    ...(isEqual(option, selectedOption)
                      ? { backgroundColor: '#0D659E', color: 'white' }
                      : { backgroundColor: mouseOver === index ? '#ebf4fa' : 'white' }),
                  }}
                >
                  {/* displayed inside the dropdown values  */}
                  {option[valueKey]}
                </li>
              )
          )}

          {/*message shown when all the items are selected */}
          {!loading &&
            options?.length > 0 &&
            idsToBeExcluded &&
            idsToBeExcluded?.length === options?.length && (
              <>
                {options.every((option: any) => idsToBeExcluded.includes(option.id)) && (
                  <li
                    style={{
                      padding: '8px 12px 8px 12px',
                      cursor: 'pointer',
                      fontSize: '14px',
                      transform: '2s',
                    }}
                  >
                    No results...
                  </li>
                )}
              </>
            )}

          {options.length === 0 && !loading && (
            <>
              <li
                style={{
                  padding: '8px 12px 8px 12px',
                  cursor: 'pointer',
                  fontSize: '14px',
                  transform: '2s',
                }}
              >
                {/* displayed inside the dropdown values  */}
                No results
              </li>
            </>
          )}

          {loading && (
            <div className='d-flex justify-content-center' style={{ margin: '10px' }}>
              <div className='spinner-border text-secondary' role='status'></div>
            </div>
          )}
        </ul>
      )}

      {/* the drop down ends  */}
    </div>
  );
};

export default LazyDropDown;
