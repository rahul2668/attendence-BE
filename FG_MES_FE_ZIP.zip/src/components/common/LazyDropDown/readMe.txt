how to use this component-------

<LazyDropDown
    onChange={handleDropDownChange} // handleDropDownChange(selectedItem)
    apiCall={furnaceMaterialService.getLazyDataTestApi} 
    valueKey='material_name'
/>

// the passed func in onChange will carry out the changes value from the drop down. set that to a state/ use it as per requirement
// create a pagination api in the backend, define it in services and pass in the apiCall prop

example:
   getLazyDataTestApi: (searchKey?: string): HttpPromise<GetAllFurnaceMaterialResponse> => {  // GetAllFurnaceMaterialResponse -> change to appropriate type
      return httpClient.get(
        `/api/materials/`,
        {params: {search_key: searchKey}}
      );
    },
    
// searchKey this is passed inside the component when pinging the api. Make sure the key name for search key is exactly 'search_key'  