import { useState } from 'react';
import Linear from '../../assets/icons/LinearGraph.svg';
import BarGraph from '../../assets/icons/BarGraph.svg';
import Stacked from '../../assets/icons/StockedGraph.svg';
import Tabular from '../../assets/icons/TabularGraph.svg';
import addButton from '../../assets/icons/AddButton.svg';
import DisabledLinear from '../../assets/icons/DisabledLinear.svg';
import DisabledBarGraph from '../../assets/icons/DisabledBar.svg';
import DisabledStocked from '../../assets/icons/DisabledStocked.svg';
import DisabledTabular from '../../assets/icons/DisabledTabular.svg';
import DisabledAdd from '../../assets/icons/DisabledAddButton.svg';
import { useTranslation } from 'react-i18next';
interface VisualizatonProps {
  handleGraph: any;
  handleReportAdd: any;
  disabled: boolean;
  showStacked: boolean;
  showLineGraph?: boolean;
}
export const VisualizationGraph: React.FC<VisualizatonProps> = ({
  handleGraph,
  handleReportAdd,
  disabled,
  showStacked,
  showLineGraph = true,
}) => {
  const { t } = useTranslation();

  const [selectedGraph, setSelectedGraph] = useState(0);
  const [showLineToolTip, setShowLineToolTip] = useState(false);
  const [showBarToolTip, setShowBarToolTip] = useState(false);
  const [showStackedToolTip, setShowStackedToolTip] = useState(false);
  const [showTableToolTip, setShowTableToolTip] = useState(false);

  const handleGraphClick = (graphNumber: any, graphname: any) => {
    if (disabled === false) {
      setSelectedGraph(graphNumber);
      handleGraph(graphname);
    }
  };

  const reportAdd = () => {
    if (disabled === false) {
      handleReportAdd();
      setSelectedGraph(0);
    }
  };

  return (
    <div style={styles.mainDiv}>
      <div style={styles.dropdownHeadingText}>{t('reports.visualizationGraph')}</div>
      <div style={styles.graphWrapper}>
        {showLineGraph ? (
          <>
            <div
              onClick={() => handleGraphClick(1, 'Linear')}
              style={
                disabled
                  ? styles.disabledBackground
                  : selectedGraph === 1
                    ? styles.clickedGraph
                    : styles.normalGraph
              }
              onMouseOver={() => setShowLineToolTip(true)}
              onMouseOut={() => setShowLineToolTip(false)}
            >
              {showLineToolTip && (
                <div
                  className='tooltiptext mt-5'
                  style={{
                    zIndex: 1,
                    position: 'fixed',
                    backgroundColor: '#022549',
                    color: 'white',
                    fontSize: '12px',
                    borderRadius: '4px',
                    padding: '10px',
                  }}
                >
                  {t('reports.lineGraph')}
                </div>
              )}
              <img
                src={disabled ? DisabledLinear : Linear}
                style={styles.graphImages}
                alt='graph1'
              />
            </div>
          </>
        ) : (
          ''
        )}

        <div
          onClick={() => handleGraphClick(2, 'Bar')}
          style={
            disabled
              ? styles.disabledBackground
              : selectedGraph === 2
                ? styles.clickedGraph
                : styles.normalGraph
          }
          onMouseOver={() => setShowBarToolTip(true)}
          onMouseOut={() => setShowBarToolTip(false)}
        >
          {showBarToolTip && (
            <div
              className='tooltiptext mt-5'
              style={{
                zIndex: 1,
                position: 'fixed',
                backgroundColor: '#022549',
                color: 'white',
                fontSize: '12px',
                borderRadius: '4px',
                padding: '10px',
              }}
            >
              {t('reports.barGraph')}
            </div>
          )}
          <img
            src={disabled ? DisabledBarGraph : BarGraph}
            style={styles.graphImages}
            alt='graph2'
          />
        </div>
        {showStacked ? (
          <div
            onClick={() => handleGraphClick(3, 'Stacked')}
            style={
              disabled
                ? styles.disabledBackground
                : selectedGraph === 3
                  ? styles.clickedGraph
                  : styles.normalGraph
            }
            onMouseOver={() => setShowStackedToolTip(true)}
            onMouseOut={() => setShowStackedToolTip(false)}
          >
            {showStackedToolTip && (
              <div
                className='tooltiptext mt-5'
                style={{
                  zIndex: 1,
                  position: 'fixed',
                  backgroundColor: '#022549',
                  color: 'white',
                  fontSize: '12px',
                  borderRadius: '4px',
                  padding: '10px',
                }}
              >
                {t('reports.stackedBarGraph')}
              </div>
            )}
            <img
              src={disabled ? DisabledStocked : Stacked}
              style={styles.graphImages}
              alt='graph3'
            />
          </div>
        ) : (
          <></>
        )}
        <div
          onClick={() => handleGraphClick(4, 'Tabular')}
          style={
            disabled
              ? styles.disabledBackground
              : selectedGraph === 4
                ? styles.clickedGraph
                : styles.normalGraph
          }
          onMouseOver={() => setShowTableToolTip(true)}
          onMouseOut={() => setShowTableToolTip(false)}
        >
          {showTableToolTip && (
            <div
              className='tooltiptext mt-5'
              style={{
                zIndex: 1,
                position: 'fixed',
                backgroundColor: '#022549',
                color: 'white',
                fontSize: '12px',
                borderRadius: '4px',
                padding: '10px',
              }}
            >
              {t('reports.tabularGraph')}
            </div>
          )}
          <img src={disabled ? DisabledTabular : Tabular} style={styles.graphImages} alt='graph4' />
        </div>
        <div
          style={disabled ? styles.disabledBackgroundImg : styles.addicon}
          onClick={() => reportAdd()}
        >
          <img src={disabled ? DisabledAdd : addButton} alt='Add' />
        </div>
      </div>
    </div>
  );
};

const styles = {
  wrapper: {
    width: '100%',
  },
  mainDiv: {
    width: '245px',
  },
  graphImages: {},
  headingText: {
    fontFamily: 'Body/Semibold',
    fontWeight: '500',
    fontSize: '14px',
    lineHeight: '19.6px',
    color: 'var(--primary75)',
  },
  graphContainer: {
    display: 'flex',
    gap: '10px',
    paddingTop: '2%',
  },
  graphWrapper: {
    display: 'flex',
  },
  clickedGraph: {
    border: '1px solid #0D659E',
    cursor: 'pointer',
    width: '41px',
    height: '40px',
    display: 'flex',
    justifyContent: 'center',
  },
  normalGraph: {
    cursor: 'pointer',
    width: '41px',
    height: '40px',
    display: 'flex',
    justifyContent: 'center',
  },
  disabledBackground: {
    backgroundColor: '#DEE3E4',
    width: '39px',
    height: '39px',
  },
  addicon: {
    borderRadius: '4px',
    marginLeft: '7%',
    width: '39px',
    height: '39px',
    cursor: 'pointer',
    backgroundColor: '#0D659E',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  disabledBackgroundImg: {
    borderRadius: '4px',
    marginLeft: '7%',
    width: '39px',
    height: '39px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#DEE3E4',
  },
  dropdownHeadingText: {
    fontfamily: 'Body/Semibold',
    fontWeight: '500',
    fontSize: '14px',
    lineHeight: '19px',
    color: 'var(--primary75)',
    padding: '0px 0px 5px 0px',
  },
};
