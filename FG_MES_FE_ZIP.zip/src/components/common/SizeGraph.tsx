import React, { useEffect, useState } from 'react';
import {
  Bar,
  BarChart,
  Legend,
  Line,
  CartesianGrid,
  LineChart,
  Tooltip,
  XAxis,
  YAxis,
  ResponsiveContainer,
} from 'recharts';
interface GraphPayload {
  graphPayload: any;
  layout: string;
}

const colors = [
  '#142459',
  '#142459',
  '#29066B',
  '#820401',

  '#176BA0',
  '#7D3AC1',
  '#C02323',

  '#19AADE',
  '#AF4BCE',
  '#DE542C',

  '#1AC9E6',
  '#DB4CB2',
  '#EF7E32',

  '#1AC9E6',
  '#EB548C',
  '#EE93A3A',

  '#1DE48D',
  '#EA7369',
  '#EABD3B',
];

const Graph: React.FC<GraphPayload> = ({ graphPayload, layout }) => {
  const [totalChartData, setTotalChartData] = useState(loadData());

  useEffect(() => {
    setTotalChartData(loadData());
  }, [graphPayload]);

  function loadData(): any {
    let result: any = [];
    graphPayload.forEach((g1: any) => {
      let chartDataDetails: {
        chartData: any[];
        chart_type: string;
        title: string;
        chartDataCompare: any[];
        'x-axis_2': boolean;
      } = {
        chartData: [],
        chart_type: '',
        title: '',
        chartDataCompare: [],
        'x-axis_2': false,
      };
      chartDataDetails.chart_type = g1.chart_type;
      chartDataDetails.title = g1.title;
      //for fixed values
      g1['x-axis_1'].forEach((x1: any, index: number) => {
        let chartDataEachObj: { [key: string]: any } = { name: x1 };

        let keys1 = Object.keys(g1?.fixed_values);
        keys1.forEach((k1: any) => {
          let y1 = g1.fixed_values[k1];
          let keys2 = Object.keys(y1);
          keys2.forEach((k2: any) => {
            if (!chartDataEachObj[k2]) {
              chartDataEachObj[`${k2} ${k1}`] = [];
            }
            let value = y1[k2][index];
            chartDataEachObj[`${k2} ${k1}`] = value;
          });
        });

        chartDataDetails.chartData.push(chartDataEachObj);
      });

      //for compare values
      if (g1?.['x-axis_2'] || g1?.['compare_material_values']?.length > 0) {
        let axisLoop = g1['x-axis_2'] || g1['x-axis_1'];
        axisLoop.forEach((x1: any, index: number) => {
          //x1 is timestamp for name
          let chartDataEachObj: { [key: string]: any } = { name: x1 };
          if (g1['x-axis_2']) {
            chartDataDetails['x-axis_2'] = true;
          }

          g1?.compare_material_values.forEach((k1: any) => {
            let keys2 = Object.keys(k1); //k1 is {MQ30_178_values}
            keys2.forEach((k2: any) => {
              //k2 is MQ30_178_values
              let y1 = k1[k2];
              let keys3 = Object.keys(y1); // array of keys of MQ30_178_values
              keys3.forEach((k3: any) => {
                //k3 is Above Accepted
                let keyName = '';
                if (g1['x-axis_2']) {
                  keyName = `${k3} ${k2}_2`;
                } else {
                  keyName = `${k2} ${k3}`;
                }

                if (!chartDataEachObj[k3]) {
                  chartDataEachObj[keyName] = [];
                }

                let value = k1[k2][k3][index];
                chartDataEachObj[keyName] = value;
              });
            });
          });

          chartDataDetails.chartDataCompare.push(chartDataEachObj);
        });
      }

      //pusing final
      result.push(chartDataDetails);
    });
    return result;
  }

  function getKeysMapData(data: any, order: number) {
    let mapData: any = [];
    if (data[0]?.name) {
      let keys1 = Object.keys(data[0]);
      keys1.forEach((k1: any, index: number) => {
        let n1 = { dataKey: k1, color: colors[index + (order == 1 ? 3 : 0)] || '#720455' };
        if (k1 != 'name') {
          mapData.push(n1);
        }
      });
    }
    return mapData;
  }

  function mergeAndSortArrays(arr1: any[], arr2: any[]): any[] {
    let result: any = [];
    let arrLength = Math.max(arr1?.length, arr2?.length);
    for (let i = 0; i < arrLength; i++) {
      result.push({ name1: arr1?.[i]?.name, name2: arr2?.[i]?.name, ...arr1?.[i], ...arr2?.[i] });
    }
    return result;
  }

  return (
    <div className='row'>
      {totalChartData.map((totalChartDataEle: any) => {
        return (
          <>
            <div
              style={{ width: layout === '1 column' ? '90%' : '50%' }}
              className='print-new-page'
            >
              {totalChartDataEle.chart_type === 'Linear' ? (
                <>
                  <label style={graphTitles}>{totalChartDataEle.title}</label>
                  <ResponsiveContainer width='110%' height={850}>
                    <LineChart
                      data={mergeAndSortArrays(
                        totalChartDataEle.chartData,
                        totalChartDataEle.chartDataCompare
                      )}
                    >
                      <CartesianGrid strokeDasharray='3 3' />
                      <XAxis xAxisId={0} height={120} angle={90} tickMargin={50} dataKey='name1' />
                      {totalChartDataEle?.['x-axis_2'] ? (
                        <XAxis
                          xAxisId={1}
                          height={120}
                          angle={90}
                          tickMargin={50}
                          dataKey='name2'
                        />
                      ) : (
                        ''
                      )}
                      <YAxis />
                      <Tooltip />
                      <Legend layout='vertical' />
                      {getKeysMapData(totalChartDataEle.chartData, 0).map((item: any) => {
                        return <Line type='monotone' dataKey={item.dataKey} stroke={item.color} />;
                      })}
                      {getKeysMapData(totalChartDataEle.chartDataCompare, 1).map((item: any) => {
                        return <Line type='monotone' dataKey={item.dataKey} stroke={item.color} />;
                      })}
                    </LineChart>
                  </ResponsiveContainer>
                </>
              ) : (
                ''
              )}
              {totalChartDataEle.chart_type === 'Bar' ? (
                <>
                  <label style={graphTitles}>{totalChartDataEle.title}</label>
                  <ResponsiveContainer width='110%' height={850}>
                    <BarChart
                      data={mergeAndSortArrays(
                        totalChartDataEle.chartData,
                        totalChartDataEle.chartDataCompare
                      )}
                    >
                      <CartesianGrid strokeDasharray='3 3' />
                      <XAxis xAxisId={0} height={120} angle={90} tickMargin={50} dataKey='name1' />
                      {totalChartDataEle?.['x-axis_2'] ? (
                        <XAxis
                          xAxisId={1}
                          height={120}
                          angle={90}
                          tickMargin={50}
                          dataKey='name2'
                        />
                      ) : (
                        ''
                      )}
                      <YAxis />
                      <Tooltip />
                      <Legend layout='vertical' />
                      {getKeysMapData(totalChartDataEle.chartData, 0).map((item: any) => {
                        return <Bar type='monotone' dataKey={item.dataKey} fill={item.color} />;
                      })}
                      {getKeysMapData(totalChartDataEle.chartDataCompare, 1).map((item: any) => {
                        return <Bar type='monotone' dataKey={item.dataKey} fill={item.color} />;
                      })}
                    </BarChart>
                  </ResponsiveContainer>
                </>
              ) : (
                ''
              )}
              {totalChartDataEle.chart_type === 'Stacked' ? (
                <>
                  <label style={graphTitles}>{totalChartDataEle.title}</label>
                  <ResponsiveContainer width='110%' height={850}>
                    <BarChart
                      data={mergeAndSortArrays(
                        totalChartDataEle.chartData,
                        totalChartDataEle.chartDataCompare
                      )}
                    >
                      <CartesianGrid strokeDasharray='3 3' />
                      <XAxis xAxisId={0} height={120} angle={90} tickMargin={50} dataKey='name1' />
                      {totalChartDataEle?.['x-axis_2'] ? (
                        <XAxis
                          xAxisId={1}
                          height={120}
                          angle={90}
                          tickMargin={50}
                          dataKey='name2'
                        />
                      ) : (
                        ''
                      )}
                      <YAxis />
                      <Tooltip />
                      <Legend layout='vertical' />
                      {getKeysMapData(totalChartDataEle.chartData, 0).map((item: any) => {
                        return <Bar stackId='a' dataKey={item.dataKey} fill={item.color} />;
                      })}
                      {getKeysMapData(totalChartDataEle.chartDataCompare, 1).map((item: any) => {
                        return <Bar stackId='b' dataKey={item.dataKey} fill={item.color} />;
                      })}
                    </BarChart>
                  </ResponsiveContainer>
                </>
              ) : (
                ''
              )}
              {totalChartDataEle.chart_type === 'Tabular' ? (
                <div className='p-4 tabular-graph'>
                  <label style={graphTitles}>{totalChartDataEle.title}</label>
                  <table className='table'>
                    <thead>
                      <tr>
                        <td>Time Period</td>
                        {getKeysMapData(totalChartDataEle.chartData, 0).map((item: any) => {
                          return (
                            <td style={{ color: item.color }}>
                              {item.dataKey?.split('_')?.join(' ')}
                            </td>
                          );
                        })}
                        {getKeysMapData(totalChartDataEle.chartDataCompare, 1).map((item: any) => {
                          return (
                            <td style={{ color: item.color }}>
                              {item.dataKey?.split('_')?.join(' ')}
                            </td>
                          );
                        })}
                      </tr>
                    </thead>
                    <tbody>
                      {mergeAndSortArrays(
                        totalChartDataEle.chartData,
                        totalChartDataEle.chartDataCompare
                      ).map((element: any, index: number) => {
                        return (
                          <tr key={index}>
                            <td>{element.name}</td>
                            {getKeysMapData(totalChartDataEle.chartData, 0).map((item: any) => {
                              return (
                                <td style={{ color: item.color }}>
                                  {element[item.dataKey] || '-'}
                                </td>
                              );
                            })}
                            {getKeysMapData(totalChartDataEle.chartDataCompare, 1).map(
                              (item: any) => {
                                return (
                                  <td style={{ color: item.color }}>
                                    {element[item.dataKey] || '-'}
                                  </td>
                                );
                              }
                            )}
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              ) : (
                ''
              )}
            </div>
          </>
        );
      })}
    </div>
  );
};

export default Graph;

const graphTitles = {
  fontWeight: 500,
  fontSize: '16px',
  lineheight: '24px',
  color: 'var(--primary75)',
};
