import { HeadersForCSV } from 'types/header.model';
import downloadIcon from '../../assets/icons/download.svg';
import { CSVLink } from 'react-csv';

interface DownloadExcel {
  csvData: any;
  headersForCSV: Array<HeadersForCSV> | undefined;
  excelTitle: string | undefined;
  handleClick: any;
  csvLinkRef: any;
}

const DownloadExcel = ({
  csvData = '',
  headersForCSV,
  excelTitle,
  handleClick,
  csvLinkRef,
}: DownloadExcel) => {
  return (
    <>
      <CSVLink
        className='download-icon'
        style={{ display: 'none' }}
        ref={csvLinkRef}
        data={csvData}
        headers={headersForCSV}
        filename={excelTitle}
      ></CSVLink>
      <button
        onClick={handleClick}
        style={{ margin: '0px 8px', backgroundColor: '#fff', border: '0px' }}
      >
        <img src={downloadIcon} alt='Download' />
      </button>
    </>
  );
};

export default DownloadExcel;
