import React, { useEffect, useState } from 'react';
import plusIcon from '../../assets/icons/plus-white.svg';
import { isEmpty, validatePermissions } from 'utils/utils';
import { paths } from 'routes/paths';
import { useLocation } from 'react-router-dom';
import { crudType, permissionsMapper } from 'utils/constants';
import arrowLeft from '../../assets/icons/arrow-left.svg';

interface HeaderProps {
  title: string;
  buttonText?: string;
  onButtonClick?: () => void;
  filteredData?: any;
  fetchSearchList?: (inputData: any) => Promise<any>;
  onBackClick?: () => void;
  onReset?: () => void;
}

const Header: React.FC<HeaderProps> = ({
  title,
  buttonText,
  filteredData,
  onButtonClick,
  fetchSearchList = () => {},
  onBackClick,
  onReset,
}) => {
  const { pathname } = useLocation();

  const [searchedResponse, setSearchedResponse] = useState<any>();

  const defaultCheckbox = {
    materialNameList: [],
    materialNoList: [],
    customerNameList: [],
    shipToList: [],
  };

  const module = pathname?.split('/')[1];
  const subModule = pathname?.split('/')[2];

  const hasCreatePermission = validatePermissions(
    permissionsMapper[module],
    permissionsMapper[subModule],
    crudType.create
  );

  useEffect(() => {
    const temp: any = defaultCheckbox;
    if (isEmpty(filteredData)) {
      setSelectedCheckboxes(defaultCheckbox);
      setSelectedDummyCheckboxes(defaultCheckbox);
    } else {
      Object.keys(searchedResponse).forEach((key) => {
        searchedResponse[key].forEach((res: any, index: number) => {
          if (key === 'materialNameList') {
            filteredData['material_name']?.forEach((data: any) => {
              if (res.id === data.id) {
                temp[key].push(index);
              }
            });
          } else {
            filteredData[
              key === 'customerNameList'
                ? 'customer_name'
                : key === 'materialNoList'
                  ? 'material_no'
                  : 'ship_to'
            ]?.forEach((data: any) => {
              if (res === data) {
                temp[key].push(index);
              }
            });
          }
        });
      });
      setSelectedCheckboxes(temp);
      setSelectedDummyCheckboxes(temp);
    }
  }, [filteredData]);

  const onSearchAPI = async (input: any) => {
    const inputData = {
      material_name: input.materialNameList,
      material_no: input.materialNoList,
      customer_name: input.customerNameList,
      ship_to: input.shipToList,
    };
    const response = await fetchSearchList(inputData);
    setSearchedResponse(response);
  };

  const onResetFilter = () => {
    onReset && onReset();
  };

  useEffect(() => {
    onSearchAPI('');
  }, []);

  const noFilterNeededPathNames = [
    `${paths.usersList}`,
    `${paths.rolesList}`,
    `${paths.activeFurnaceList.list}`,
  ];
  const isFilterSortAllowed = !noFilterNeededPathNames.includes(pathname);

  return (
    <div className='dashboard__main__header'>
      <div className='flex items-center justify-between'>
        <div className='flex items-center'>
          {onBackClick && (
            <img
              src={arrowLeft}
              alt='back-arrow'
              onClick={onBackClick}
              style={{ cursor: 'pointer' }}
              onKeyDown={onBackClick}
            />
          )}
        </div>
        <h2 className='text-xl font-semibold ml-1'>{title}</h2>
        <div className='flex items-center ml-auto'>
          {isFilterSortAllowed && onReset && (
            <button className='btn btn--reset btn--h36 px-4 py-2 ml-3' onClick={onResetFilter}>
              Reset
            </button>
          )}
          {buttonText && hasCreatePermission && (
            <button
              className={`btn btn--primary btn--h36 px-4 py-2 ml-3`}
              onClick={hasCreatePermission && onButtonClick}
            >
              <img src={plusIcon} alt='plus-icon' className='mr-2' />
              {buttonText}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default Header;
// eslint-disable-next-line @typescript-eslint/no-unused-vars
function setSelectedCheckboxes(_defaultCheckbox: {
  materialNameList: never[];
  materialNoList: never[];
  customerNameList: never[];
  shipToList: never[];
}) {
  // throw new Error('Function not implemented.');
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function setSelectedDummyCheckboxes(_defaultCheckbox: {
  materialNameList: never[];
  materialNoList: never[];
  customerNameList: never[];
  shipToList: never[];
}) {
  // throw new Error('Function not implemented.');
}
