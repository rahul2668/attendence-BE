import { Grid, InputLabel } from '@mui/material';
import { DesktopDatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
// import dayjs from 'dayjs';
import { useTranslation } from 'react-i18next';
import { useAppSelector } from 'store';
import { UtilsMasterData } from 'types/plant.model';
import { handleTimezone } from 'utils/utils';

const DateOnlyPicker = ({
  handleEffectiveDateChange,
  valueInState,
  //   timeZone,
  view,
}: any) => {
  const { t } = useTranslation();
  const utilsMasterData = useAppSelector((state) => state.master);
  const utilsMasterList: Array<UtilsMasterData> = utilsMasterData?.results;
  const plantDataString = useAppSelector((state) => state.plantData.plantData);
  const plantData: any = plantDataString ?? null;
  const plant_time_zone_id: any = plantData.plant_time_zone_id;
  const timeZone = utilsMasterList?.filter((item: any) => item.id == plant_time_zone_id)?.[0]
    ?.description;
  return (
    <div>
      {view && (
        <Grid item xs={2} sm={4} md={4}>
          <InputLabel
            id='fn'
            sx={{
              fontWeight: 600,
              color: '#606466',
              fontSize: '14px',
              marginBottom: '5px',
            }}
          >
            {t('sharedTexts.effectiveDate')}*
          </InputLabel>
          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DesktopDatePicker
              closeOnSelect={false}
              format='DD/MM/YYYY'
              sx={{
                '& .MuiInputBase-input': {
                  height: '40px',
                  padding: '0px 0px 0px 14px',
                  fontSize: '14px',
                },
                width: '250px!important', // this solved a UI bug in date
              }}
              onChange={(e) => handleEffectiveDateChange(e)}
              value={handleTimezone(valueInState, timeZone)}
            />
          </LocalizationProvider>
        </Grid>
      )}
    </div>
  );
};

export default DateOnlyPicker;
