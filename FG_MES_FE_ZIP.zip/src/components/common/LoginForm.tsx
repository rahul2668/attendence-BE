import { FC } from 'react';
import eyeClose from '../../assets/icons/eye-off.svg';
import eye from '../../assets/icons/eye.svg';
import '../../assets/styles/scss/components/login-form.scss';
import globeLogo from '../../assets/img/globe-logo.png';
import { useTranslation } from 'react-i18next';
import LanguageSelect from './LanguageSelect';

interface LoginFormProps {
  handleSubmit: (e: any) => void;
  formErrors: any;
  showPassword: any;
  password: any;
  handlePasswordChange: (e: any) => void;
  setShowPassword: (e: any) => void;
  handleUsernameChange: (e: any) => void;
  email: any;
  loading: boolean;
  handleSsoLogin: () => void;
  ssoLoading: boolean;
}

const LoginForm: FC<LoginFormProps> = ({
  handleSubmit,
  handleUsernameChange,
  formErrors,
  showPassword,
  password,
  handlePasswordChange,
  setShowPassword,
  email,
  loading,
  handleSsoLogin,
  ssoLoading,
}) => {
  const { t } = useTranslation();

  return (
    <form className='auth-module__main__container' onSubmit={handleSubmit}>
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <h2 className='text-2xl font-semibold'>{t('authentication.login.userLoginTitle')}</h2>
        <LanguageSelect />
      </div>

      <div className='mt-5 mb-5'>
        <div className='input-field-wrapper'>
          <label className='input-field-label' htmlFor='userID'>
            {t('authentication.login.loginUserId')}
          </label>
          <input
            type='text'
            id='userid'
            className='input-field  input-field--md input-field--h40 text-sm w-full'
            placeholder={t('sharedTexts.enterUserId')}
            onChange={(e) => handleUsernameChange(e.target.value)}
            name='email'
            value={email}
          />
          <span className='error-message'>{formErrors.email}</span>
        </div>

        <div className='input-field-wrapper'>
          <label className='input-field-label' htmlFor='password'>
            {t('authentication.login.loginPassword')}
          </label>
          <div className='relative'>
            <input
              type={showPassword ? 'text' : 'password'}
              id='password'
              className='input-field input-field--password input-field--md input-field--h40 text-sm w-full'
              placeholder={t('authentication.login.enterPassword')}
              name='password'
              value={password}
              // minLength={4}
              onChange={(e) => handlePasswordChange(e.target.value)}
            />
            <span className='error-message'>{formErrors.password}</span>
            {showPassword ? (
              <button
                style={{ border: '0px solid', backgroundColor: '#f0ffff00' }}
                type='button'
                onClick={() => setShowPassword(!showPassword)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === 'Space') {
                    setShowPassword(!showPassword);
                  }
                }}
              >
                <img
                  src={eye}
                  style={{ position: 'absolute', top: 13, right: 11 }}
                  alt='eye'
                  className='eye-icon eye-icon--normal'
                />
              </button>
            ) : (
              <button
                style={{ border: '0px solid', backgroundColor: '#f0ffff00' }}
                type='button'
                onClick={() => setShowPassword(!showPassword)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === 'Space') {
                    setShowPassword(!showPassword);
                  }
                }}
              >
                <img
                  src={eyeClose}
                  style={{ position: 'absolute', top: 12, right: 12 }}
                  alt='eye'
                  className='eye-icon eye-icon-close'
                />
              </button>
            )}
          </div>
        </div>
      </div>
      <button
        className={`btn btn--primary btn--lg btn--h42 w-full mt-3 ${
          loading || ssoLoading ? 'disabled' : ''
        }`}
      >
        {loading ? (
          <output className='spinner-border text-danger' />
        ) : (
          `${t('authentication.login.loginText')}`
        )}
      </button>
      <div className='divider'>
        <p />
        <span>{t('authentication.login.or')}</span>
        <p />
      </div>
      <button
        className={`btn btn--primary btn--lg btn--h42 w-full mt-3 ${
          loading || ssoLoading ? 'disabled' : ''
        }`}
        type='button'
        onClick={() => handleSsoLogin()}
      >
        {ssoLoading ? (
          <output className='spinner-border text-danger' />
        ) : (
          <>
            <img src={globeLogo} alt='globe' /> &nbsp;
            <span>{t('authentication.login.ssoLogin')}</span>
          </>
        )}
      </button>
    </form>
  );
};

export default LoginForm;
