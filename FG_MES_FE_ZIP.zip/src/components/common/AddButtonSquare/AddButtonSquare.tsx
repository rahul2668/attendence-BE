interface AddButtonSquareProps {
  onClickHandler?: any;
  buttonDisabled?: boolean;
}

const AddButtonSquare: React.FC<AddButtonSquareProps> = ({
  onClickHandler,
  buttonDisabled = false,
}) => {
  return (
    <button
      className='products__add_container'
      onClick={onClickHandler}
      type='button'
      style={{
        backgroundColor: buttonDisabled ? '#6993af' : '#0d659e',
        cursor: buttonDisabled ? 'default' : 'pointer',
      }}
      disabled={buttonDisabled}
    >
      <svg
        xmlns='http://www.w3.org/2000/svg'
        width='40'
        height='40'
        fill='#fff'
        className='bi bi-plus'
        viewBox='0 0 16 16'
      >
        <path d='M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4' />
      </svg>
    </button>
  );
};

export default AddButtonSquare;
