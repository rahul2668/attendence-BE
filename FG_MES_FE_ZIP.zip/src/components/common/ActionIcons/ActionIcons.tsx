// icons
import editIcon from '../../../assets/icons/edit1.svg';
import viewIcon from '../../../assets/icons/eye1.svg';
import addIcon from '../../../assets/icons/add.svg';
import trashIcon from '../../../assets/icons/trash1.svg';
import MUIToolTip from '../ToolTip/MUIToolTip';
import deactivateIcon from '../../../assets/icons/deactivate.svg';
import resetIcon from '../../../assets/icons/reset.svg';
// import { ToggleOff as ActivateIcon } from '@mui/icons-material';
import 'assets/styles/scss/components/table-general.scss';

interface Permissions {
  hasCreate?: boolean;
  hasEdit?: boolean;
  hasDelete?: boolean;
  hasDeactivate?: boolean;
  hasReset?: boolean;
}

interface ActionIconsProps {
  permissions?: Permissions;
  viewClick?: any; // give click event type
  addClick?: any; // give click event type
  editClick?: any; // give click event type
  deleteClick?: any; // give click event type
  deactivateClick?: any; // give click event type
  activateClick?: any; // give click event type
  resetClick?: any; // give click event type
  isHovered?: boolean;
  viewToolText?: string;
  addToolText?: string;
  editToolText?: string;
  deleteToolText?: string;
  deactivateToolText?: string;
  activateToolText?: string;
  resetToolText?: string;
  onlyView?: boolean;
  disableAdd?: boolean; // if needed, provide for others
  allowOnlyViewAndEdit?: boolean;
  onlyActivate?: boolean;
  onlyAdd?: boolean;
  allowOnlyActivateAndAdd?: boolean;
  rowNeedsReset?: boolean;
  useTranslationHookInToolTip?: boolean;
}

// new Icons component ---- NEED TO CHECK ON ICONS
const ActionIcons: React.FC<ActionIconsProps> = ({
  permissions,
  viewClick = () => {},
  addClick = () => {},
  editClick = () => {},
  deleteClick = () => {},
  deactivateClick = () => {},
  activateClick = () => {},
  resetClick = () => {},
  isHovered = false,
  viewToolText = 'View',
  addToolText = 'Add',
  editToolText = 'Edit',
  deleteToolText = 'Delete',
  deactivateToolText = 'Deactivate',
  activateToolText = 'Activate',
  resetToolText = 'Reset',
  onlyView = false,
  disableAdd = false, // if needed, provide for others
  allowOnlyViewAndEdit = false, // this overrides everything in action icons
  onlyActivate = false,
  onlyAdd = false,
  allowOnlyActivateAndAdd = false,
  rowNeedsReset = false,
  useTranslationHookInToolTip = true,
}) => {
  // hasReset(the permission bool passed from top level parent) && rowNeedsReset(each row dependent key),
  //-> both should be true to show the reset icon

  if (onlyActivate)
    return (
      <div
        style={{
          minWidth: '110px',
          minHeight: '24px',
          maxHeight: '24px',
          display: 'flex',
          justifyContent: 'center',
          gap: '10px',
        }}
      >
        {isHovered && permissions?.hasEdit && (
          <MUIToolTip useTranslationHook={useTranslationHookInToolTip} text={activateToolText}>
            {/* Needed the old icons - commented out mui action  */}
            {/* <ActivateIcon
                sx={{ marginTop: '-5px' }}
                height={24}
                fontSize='large'
                color='disabled'
                onClick={activateClick}
              /> */}
            <button onClick={activateClick} style={{ border: 'none', backgroundColor: 'white' }}>
              <label
                style={{ height: '13px', width: '22px' }}
                className='switch-label switch-label--sm'
              >
                {' '}
              </label>
            </button>
          </MUIToolTip>
        )}
      </div>
    );
  if (onlyAdd)
    return (
      <div
        style={{
          minWidth: '110px',
          minHeight: '24px',
          maxHeight: '24px',
          display: 'flex',
          justifyContent: 'center',
          gap: '10px',
        }}
      >
        {isHovered && permissions?.hasEdit && (
          <MUIToolTip useTranslationHook={useTranslationHookInToolTip} text={addToolText}>
            <button
              // onMouseEnter={() => setIsHoveredIcon(2)}
              // onMouseLeave={() => setIsHoveredIcon(0)}
              style={{ border: '0px solid', backgroundColor: '#f0ffff00' }}
              type='button'
              onClick={addClick}
            >
              <img
                src={addIcon}
                alt='View'
                className='icon mr-2'
                style={{ fill: '#04436B', width: '15px', height: '15px' }}
              />
            </button>
          </MUIToolTip>
        )}
      </div>
    );

  if (allowOnlyActivateAndAdd)
    return (
      <div
        style={{
          minWidth: '110px',
          minHeight: '24px',
          display: 'flex',
          justifyContent: 'center',
          gap: '10px',
        }}
      >
        {isHovered && (
          <>
            {permissions?.hasEdit && (
              <MUIToolTip useTranslationHook={useTranslationHookInToolTip} text={activateToolText}>
                <button
                  onClick={activateClick}
                  style={{ border: 'none', backgroundColor: 'white' }}
                >
                  <label
                    style={{ height: '13px', width: '22px' }}
                    className='switch-label switch-label--sm'
                  >
                    {' '}
                  </label>
                </button>
              </MUIToolTip>
            )}

            {/* EDIT --- */}
            {permissions?.hasEdit && (
              <MUIToolTip useTranslationHook={useTranslationHookInToolTip} text={editToolText}>
                <button
                  // onMouseEnter={() => setIsHoveredIcon(2)}
                  // onMouseLeave={() => setIsHoveredIcon(0)}
                  style={{ border: '0px solid', backgroundColor: '#f0ffff00' }}
                  type='button'
                  onClick={editClick}
                >
                  <img
                    src={editIcon}
                    alt='View'
                    className='icon mr-2'
                    style={{ fill: '#04436B', width: '17px', height: '17px' }}
                  />
                </button>
              </MUIToolTip>
            )}
            {/* EDIT === */}
          </>
        )}
      </div>
    );
  if (allowOnlyViewAndEdit)
    return (
      <div
        style={{
          minWidth: '110px',
          minHeight: '24px',
          display: 'flex',
          justifyContent: 'center',
          gap: '10px',
        }}
      >
        {isHovered && (
          <>
            <MUIToolTip useTranslationHook={useTranslationHookInToolTip} text={viewToolText}>
              <button
                // onMouseEnter={() => setIsHoveredIcon(2)}
                // onMouseLeave={() => setIsHoveredIcon(0)}
                onClick={viewClick}
                style={{ border: '0px solid', backgroundColor: '#f0ffff00' }}
                type='button'
              >
                <img
                  src={viewIcon}
                  alt='View'
                  className='icon mr-2'
                  style={{ fill: '#04436B', width: '22px', height: '22px' }}
                />
              </button>
            </MUIToolTip>

            {/* EDIT --- */}
            {permissions?.hasEdit && (
              <MUIToolTip useTranslationHook={useTranslationHookInToolTip} text={editToolText}>
                <button
                  // onMouseEnter={() => setIsHoveredIcon(2)}
                  // onMouseLeave={() => setIsHoveredIcon(0)}
                  style={{ border: '0px solid', backgroundColor: '#f0ffff00' }}
                  type='button'
                  onClick={editClick}
                >
                  <img
                    src={editIcon}
                    alt='View'
                    className='icon mr-2'
                    style={{ fill: '#04436B', width: '17px', height: '17px' }}
                  />
                </button>
              </MUIToolTip>
            )}
            {/* EDIT === */}
          </>
        )}
      </div>
    );

  return (
    <div
      style={{
        minWidth: '110px',
        minHeight: '24px',
        display: 'flex',
        justifyContent: 'center',
        gap: '10px',
      }}
    >
      {/* VIEW --- */}
      {isHovered && (
        <>
          <MUIToolTip useTranslationHook={useTranslationHookInToolTip} text={viewToolText}>
            <button
              // onMouseEnter={() => setIsHoveredIcon(2)}
              // onMouseLeave={() => setIsHoveredIcon(0)}
              onClick={viewClick}
              style={{ border: '0px solid', backgroundColor: '#f0ffff00' }}
              type='button'
            >
              <img
                src={viewIcon}
                alt='View'
                className='icon mr-2'
                style={{ fill: '#04436B', width: '22px', height: '22px' }}
              />
            </button>
          </MUIToolTip>

          {/* VIEW === */}

          {!onlyView && (
            <>
              {/* ADD --- */}
              {permissions?.hasCreate && !disableAdd && (
                <MUIToolTip useTranslationHook={useTranslationHookInToolTip} text={addToolText}>
                  <button
                    // onMouseEnter={() => setIsHoveredIcon(2)}
                    // onMouseLeave={() => setIsHoveredIcon(0)}
                    style={{ border: '0px solid', backgroundColor: '#f0ffff00' }}
                    type='button'
                    onClick={addClick}
                  >
                    <img
                      src={addIcon}
                      alt='View'
                      className='icon mr-2'
                      style={{ fill: '#04436B', width: '15px', height: '15px' }}
                    />
                  </button>
                </MUIToolTip>
              )}
              {/* ADD === */}

              {/* EDIT --- */}
              {permissions?.hasEdit && (
                <MUIToolTip useTranslationHook={useTranslationHookInToolTip} text={editToolText}>
                  <button
                    // onMouseEnter={() => setIsHoveredIcon(2)}
                    // onMouseLeave={() => setIsHoveredIcon(0)}
                    style={{ border: '0px solid', backgroundColor: '#f0ffff00' }}
                    type='button'
                    onClick={editClick}
                  >
                    <img
                      src={editIcon}
                      alt='View'
                      className='icon mr-2'
                      style={{ fill: '#04436B', width: '17px', height: '17px' }}
                    />
                  </button>
                </MUIToolTip>
              )}
              {/* EDIT === */}

              {/* DELETE  */}
              {permissions?.hasDelete && (
                <MUIToolTip useTranslationHook={useTranslationHookInToolTip} text={deleteToolText}>
                  <button
                    // onMouseEnter={() => setIsHoveredIcon(2)}
                    // onMouseLeave={() => setIsHoveredIcon(0)}
                    style={{ border: '0px solid', backgroundColor: '#f0ffff00' }}
                    type='button'
                    onClick={deleteClick}
                  >
                    <img
                      src={trashIcon}
                      alt='View'
                      className='icon mr-2'
                      style={{ fill: '#04436B', width: '17px', height: '17px' }}
                    />
                  </button>
                </MUIToolTip>
              )}
              {/* DELETE === */}

              {/* Deactivate  */}
              {permissions?.hasDeactivate && (
                <MUIToolTip
                  useTranslationHook={useTranslationHookInToolTip}
                  text={deactivateToolText}
                >
                  <button
                    // onMouseEnter={() => setIsHoveredIcon(2)}
                    // onMouseLeave={() => setIsHoveredIcon(0)}
                    style={{ border: '0px solid', backgroundColor: '#f0ffff00' }}
                    type='button'
                    onClick={deactivateClick}
                  >
                    <img
                      src={deactivateIcon}
                      alt='View'
                      className='icon mr-2'
                      style={{ fill: '#04436B', width: '17px', height: '17px' }}
                    />
                  </button>
                </MUIToolTip>
              )}
              {/* Deactivate === */}

              {/* RESET  */}
              {permissions?.hasReset && rowNeedsReset && (
                <MUIToolTip useTranslationHook={useTranslationHookInToolTip} text={resetToolText}>
                  <button
                    // onMouseEnter={() => setIsHoveredIcon(2)}
                    // onMouseLeave={() => setIsHoveredIcon(0)}
                    style={{ border: '0px solid', backgroundColor: '#f0ffff00' }}
                    type='button'
                    onClick={resetClick}
                  >
                    <img
                      src={resetIcon}
                      alt='View'
                      className='icon mr-2'
                      style={{ fill: '#04436B', width: '17px', height: '17px' }}
                    />
                  </button>
                </MUIToolTip>
              )}
              {/* RESET === */}
            </>
          )}
        </>
      )}
    </div>
  );
};

export default ActionIcons;
