/* eslint-disable no-prototype-builtins */
import React, { useEffect, useState } from 'react';
import filterIcon from '../../assets/icons/filter.svg';
import plusIcon from '../../assets/icons/plus-white.svg';
import caretDownIcon from '../../assets/icons/caret-down.svg';
import { debounce, isEmpty, validatePermissions } from 'utils/utils';
import OutsideClickHandler from 'react-outside-click-handler';
import { paths } from 'routes/paths';
import { useLocation } from 'react-router-dom';
import { crudType, permissionsMapper } from 'utils/constants';
import { useTranslation } from 'react-i18next';

interface HeaderProps {
  title: string;
  buttonText?: string;
  placeholder?: string;
  onSearchChange?: (value: string) => void;
  handleTypeCheckboxChange?: (value: any) => void;
  isCheckedOfTypeFilter?: (typeObject: any) => boolean | undefined;
  onButtonClick?: () => void;
  sort_filter_click?: (inputValue: any, fromFilterSerach?: boolean) => Promise<void>; // Add sort_filter_click and onFilterClick props
  onReset?: () => void;
  filteredData?: any;
  fetchSearchList?: (inputData: any) => Promise<any>;
  removeStatus?: boolean;
  additiveDeleted?: boolean;
  showTypeFilter?: boolean;
  hasTypesSelected?: () => boolean;
  typesData?: any[];
}

const Header: React.FC<HeaderProps> = ({
  title,
  placeholder,
  buttonText,
  filteredData,
  onSearchChange,
  handleTypeCheckboxChange = () => {},
  isCheckedOfTypeFilter = () => {},
  onButtonClick,
  sort_filter_click, // Add sort_filter_click prop
  onReset = () => {}, //to reset the filter / sort
  fetchSearchList = () => {},
  removeStatus = false,
  additiveDeleted,
  showTypeFilter,
  hasTypesSelected = () => false,
  typesData = [],
}) => {
  const { t } = useTranslation();
  const sortTypeList = [
    { id: 1, label: t('sharedTexts.ascending') },
    { id: 2, label: t('sharedTexts.descending') },
  ];
  const statusTypeList = [
    { id: 1, label: t('sharedTexts.active'), value: true },
    { id: 2, label: t('sharedTexts.inactive'), value: false },
  ];
  const { pathname } = useLocation();
  const [searchValue, setSearchValue] = useState('');
  const [filterSearchValue, setFilterSearchValue] = useState('');
  const [filterTypeSearchValue, setFilterTypeSearchValue] = useState('');
  const [filteredTypeData, setFilteredTypeData] = useState(typesData);
  const [searchedResponse, setSearchedResponse] = useState<Array<any>>();
  const [searchedResponseDuplicate, setSearchedResponseDuplicate] = useState<any>();
  const [openStatusList, setOpenStatusList] = useState(false);
  const [openFilter, setOpenFilter] = useState(false);
  const [activeStatus, setActiveStatus] = useState({ label: '', value: '' });
  const [selectedSortType, setSelectedSortType] = useState<string>('');
  const [materialDropdown, setMaterialDropdown] = useState(false);
  const [typeDropdown, setTypeDropdown] = useState(false);
  const [statusDropdown, setStatusDropdown] = useState(false);
  const [radioBtn, setRadioBtn] = useState(0);
  const [isFilterApplied, setIsFilterApplied] = useState(false);
  const [selectedCheckboxes, setSelectedCheckboxes] = useState<number[]>([]);
  const [selectedDummyCheckboxes, setSelectedDummyCheckboxes] = useState<number[]>([]);
  const [disableFilter, setDisableFilter] = useState<boolean>(true);

  const sortOptions: { [key: number]: { [key: string]: string } } = {
    1: {
      [sortTypeList[0].label]: 'created_at',
      default: 'created_at',
    },
    2: {
      [sortTypeList[0].label]: removeStatus ? 'material__material_no' : 'material_no',
      default: removeStatus ? '-material__material_no' : 'material_no',
    },
  };

  const sortStore =
    sortOptions[radioBtn]?.[selectedSortType] || sortOptions[radioBtn]?.default || '';

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/[^a-zA-Z0-9_]/g, '');
    if (value.length == 1 && value.startsWith(' ')) {
      e.preventDefault();
    } else {
      const sanitizedValue = value.replace(/\s+/g, '');
      debounce(setSearchValue(sanitizedValue), 500);
      const emptyCheck = checkAllStates();
      emptyCheck
        ? onSearchChange && onSearchChange(sanitizedValue)
        : onSort_filterClick(sanitizedValue);
    }
  };

  const handleFilterSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
      .replace(/(\s{2,})|[^a-zA-Z0-9_@.!$%*()/#&+-]/g, ' ')
      .replace(/^\s+/g, '');
    setFilterSearchValue(value);

    if (value.length > 0 || activeStatus.label) {
      setDisableFilter(false);
    } else {
      setDisableFilter(true);
    }
  };

  const handleFilterTypeSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
      .replace(/(\s{2,})|[^a-zA-Z0-9_@.!$%*()/#&+-]/g, ' ')
      .replace(/^\s+/g, '');
    setFilterTypeSearchValue(value);
  };

  const handleCheckboxChange = (index: number) => {
    setDisableFilter(false);
    if (selectedCheckboxes.includes(index)) {
      setSelectedCheckboxes(selectedCheckboxes.filter((selectedIndex) => selectedIndex !== index)); // uncheck the checkbox if already selected
      !isFilterApplied &&
        setSelectedDummyCheckboxes(
          selectedDummyCheckboxes.filter((selectedIndex) => selectedIndex !== index)
        );
    } else {
      setSelectedCheckboxes([...selectedCheckboxes, index]);
      !isFilterApplied && setSelectedDummyCheckboxes([...selectedCheckboxes, index]);
    }
  };

  useEffect(() => {
    const data: any = {};
    data['material_name'] = filteredData?.material_name ? filteredData.material_name : null;
    data['is_active'] = filteredData?.is_active ? filteredData.is_active : null;

    if (isEmpty(data)) {
      setActiveStatus({ label: '', value: '' });
      setSelectedCheckboxes([]);
      setSelectedDummyCheckboxes([]);
      setIsFilterApplied(false);
    } else {
      if (!data?.hasOwnProperty('material_name')) {
        setSelectedCheckboxes([]);
        setSelectedDummyCheckboxes([]);
      } else {
        const tempSelectedIndex: number[] = [];
        const valuesToFind = data?.material_name || [];
        if (Array.isArray(valuesToFind) && searchedResponse) {
          valuesToFind.forEach((value: string) => {
            if (value) {
              const index = searchedResponse.indexOf(value);
              if (index !== -1) {
                tempSelectedIndex.push(index);
              }
            }
          });
        }
        setSelectedCheckboxes(tempSelectedIndex);
        setSelectedDummyCheckboxes(tempSelectedIndex);
      }
      if (!data?.hasOwnProperty('is_active')) {
        setActiveStatus({ label: '', value: '' });
      }
    }
  }, [filteredData]);

  const checkAllStates = () => {
    let allStatesEmpty = false;
    if (
      isEmpty(selectedSortType) &&
      isEmpty(filterSearchValue) &&
      isEmpty(activeStatus.label) &&
      isEmpty(selectedCheckboxes)
    ) {
      allStatesEmpty = true;
      return allStatesEmpty;
    }
    return allStatesEmpty;
  };

  const onResetFilter = () => {
    setSearchValue('');
    setFilterTypeSearchValue('');
    onSearchChange?.('');
    setOpenFilter(false);
    setFilterSearchValue('');
    setActiveStatus({ label: '', value: '' });
    setSelectedCheckboxes([]);
    setSelectedDummyCheckboxes([]);
    setIsFilterApplied(false);
    onReset();
    setSelectedSortType('');
    setRadioBtn(0);
    setMaterialDropdown(false);
    setTypeDropdown(false);
    setStatusDropdown(false);
    setDisableFilter(true);
  };
  const onSearchAPI = async (value: string) => {
    const inputData = {
      material_name: value,
    };
    const response = await fetchSearchList(inputData);
    const {
      payload: { data },
    } = response;
    setSearchedResponse([]);
    setSearchedResponseDuplicate(data);
  };

  useEffect(() => {
    onSearchAPI('');
  }, []);

  useEffect(() => {
    if (additiveDeleted === true) {
      onSearchAPI('');
    }
  }, [additiveDeleted]);

  const onSort_filterClick = (searchText?: string) => {
    const inputData = {
      search: searchText?.replace(/^\s+/g, ''),
      material_name: filterSearchValue,
      is_active: activeStatus?.value,
      ordering: sortStore,
      page: 1,
      sort_type: selectedSortType,
    };
    sort_filter_click?.(inputData);
    setOpenFilter(false);
  };

  // function for that little search in types drop down inside the filter
  useEffect(() => {
    const newFilteredData = typesData.filter((item) =>
      item.type_name?.toLowerCase().includes(filterTypeSearchValue?.toLowerCase())
    );
    setFilteredTypeData(newFilteredData);
  }, [typesData, filterTypeSearchValue]);

  const renderFilterUI = () => {
    return (
      <button
        className='relative btn btn--h36 px-3 py-2 ml-3'
        onClick={() => {
          setOpenFilter(true);
        }}
      >
        <img src={filterIcon} alt='filter-icon' className='mr-1' />
        {t('sharedTexts.allFilters')}
        {isFilterApplied && (
          <span
            className='inline-block absolute rounded-full'
            style={{
              width: 14,
              height: 14,
              top: -5,
              right: -4,
              backgroundColor: '#F23D24',
            }}
          />
        )}
        <div className={`filters-sort-dropdown-menu ${openFilter ? 'open' : ''}`}>
          <div className='filters-sort-dropdown-menu__header'>
            <span className='color-secondary-text text-13 font-semibold'>
              {t('sharedTexts.filters')}{' '}
            </span>
          </div>
          <div className='filters-sort-dropdown-menu__body'>
            <div className={`filters-sort-dropdown-menu__list ${materialDropdown ? 'active' : ''}`}>
              <div className='filters-sort-dropdown-menu__list__container'>
                <button
                  type='button'
                  style={{
                    border: '0px solid',
                    backgroundColor: '#f0ffff00',
                    width: '-webkit-fill-available',
                  }}
                  className='flex items-center justify-between'
                  onClick={() => setMaterialDropdown(!materialDropdown)}
                  onKeyDown={(event) => {
                    event.key === 'Enter' && setMaterialDropdown(!materialDropdown);
                  }}
                >
                  <span className='filters-sort-dropdown-menu__list__title'>
                    {t('masterData.sharedMasterDataTexts.materialName')}
                  </span>
                  <img src={caretDownIcon} alt='arrow-down' className='arrow-down' />
                </button>
                <div className='filters-sort-dropdown-menu__list__content'>
                  <div className='pt-3'>
                    <input
                      type='text'
                      className='input-field input-field--search input-field--md input-field--h32 w-full'
                      placeholder={t('sharedTexts.search')}
                      value={filterSearchValue}
                      onChange={handleFilterSearchChange}
                      onPaste={(event) => event.preventDefault()}
                    />
                    <div className='flex flex-col overflow-auto' style={{ maxHeight: '150px' }}>
                      {!isEmpty(searchedResponse && searchedResponseDuplicate)
                        ? searchedResponse
                            ?.filter((res: any) =>
                              res.material_name
                                .toString()
                                ?.toLowerCase()
                                ?.includes(filterSearchValue?.replace(/^\s+/g, '')?.toLowerCase())
                            )
                            .map((item, index) => {
                              const isChecked = selectedCheckboxes.includes(
                                searchedResponseDuplicate
                                  ? searchedResponseDuplicate.indexOf(item)
                                  : 0
                              );
                              return (
                                <div
                                  className='custom-checkbox custom-checkbox--md '
                                  key={item.material_name}
                                >
                                  <input
                                    type='checkbox'
                                    id={`${index}`}
                                    className='custom-checkbox__input'
                                    checked={isChecked} // Set the checked state based on whether it matches the selected status
                                    onChange={() => {
                                      handleCheckboxChange(
                                        searchedResponseDuplicate
                                          ? searchedResponseDuplicate.indexOf(item)
                                          : 0
                                      );
                                    }}
                                  />
                                  <label htmlFor={`${index}`} className='custom-checkbox__label'>
                                    <code className='custom-checkbox__label__box'></code>
                                    <span
                                      className='custom-checkbox__label__text font-semibold'
                                      style={{
                                        color: '#001f33',
                                      }}
                                    >
                                      {item.material_name}
                                    </span>
                                  </label>
                                </div>
                              );
                            })
                        : null}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* TYPE  */}

            {showTypeFilter && (
              <div className={`filters-sort-dropdown-menu__list ${typeDropdown ? 'active' : ''}`}>
                <div className='filters-sort-dropdown-menu__list__container'>
                  <div
                    className='flex items-center justify-between'
                    onClick={() => setTypeDropdown((prev) => !prev)}
                    onKeyDown={(event) => {
                      event.key === 'Enter' && setTypeDropdown((prev) => !prev);
                    }}
                  >
                    <span className='filters-sort-dropdown-menu__list__title'>
                      {t('sharedTexts.type')}
                    </span>
                    <img src={caretDownIcon} alt='arrow-down' className='arrow-down' />
                  </div>
                  <div className='filters-sort-dropdown-menu__list__content'>
                    <div className='pt-3'>
                      <input
                        type='text'
                        className='input-field input-field--search input-field--md input-field--h32 w-full'
                        placeholder={t('sharedTexts.search')}
                        value={filterTypeSearchValue}
                        onChange={handleFilterTypeSearchChange}
                        onPaste={(event) => event.preventDefault()}
                      />
                      <div className='flex flex-col overflow-auto' style={{ maxHeight: '150px' }}>
                        {/* ============================ */}
                        {filteredTypeData.map((typeObject, index) => (
                          <div
                            className='custom-checkbox custom-checkbox--md '
                            key={typeObject.type_name}
                          >
                            <input
                              type='checkbox'
                              id={`${index}`}
                              className='custom-checkbox__input'
                              checked={
                                isCheckedOfTypeFilter
                                  ? isCheckedOfTypeFilter(typeObject) || false
                                  : false
                              }
                              // checked={isChecked} // Set the checked state based on whether it matches the selected status
                              onChange={() => {
                                handleTypeCheckboxChange(typeObject);
                              }}
                            />
                            <label htmlFor={`${index}`} className='custom-checkbox__label'>
                              <code className='custom-checkbox__label__box'></code>
                              <span
                                className='custom-checkbox__label__text font-semibold'
                                style={{
                                  color: '#001f33',
                                }}
                              >
                                {typeObject.type_name}
                              </span>
                            </label>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TYPE END  */}

            {!removeStatus && (
              <div className={`filters-sort-dropdown-menu__list ${statusDropdown ? 'active' : ''}`}>
                <div className='filters-sort-dropdown-menu__list__container'>
                  <button
                    type='button'
                    style={{
                      border: '0px solid',
                      backgroundColor: '#f0ffff00',
                      width: '-webkit-fill-available',
                    }}
                    className='flex items-center justify-between'
                    onClick={() => setStatusDropdown(!statusDropdown)}
                    onKeyDown={(event) => {
                      event.key === 'Enter' && setStatusDropdown(!statusDropdown);
                    }}
                  >
                    <span className='filters-sort-dropdown-menu__list__title'>
                      {t('sharedTexts.status')}
                    </span>
                    <img src={caretDownIcon} alt='arrow-down' className='arrow-down' />
                  </button>
                  <div className='filters-sort-dropdown-menu__list__content'>
                    <div className='pt-3'>
                      <div className='filters-sort-dropdown-menu__list__container relative'>
                        <button
                          type='button'
                          style={{
                            border: '0px solid',
                            backgroundColor: '#f0ffff00',
                            width: '-webkit-fill-available',
                          }}
                          className='flex items-center justify-between'
                          onClick={() => {
                            setOpenStatusList(!openStatusList);
                          }}
                          onKeyDown={(event) => {
                            event.key === 'Enter' && setOpenStatusList(!openStatusList);
                          }}
                        >
                          <span className='filters-sort-dropdown-menu__list__title'>
                            {isEmpty(activeStatus.label)
                              ? t('sharedTexts.selectStatusType')
                              : activeStatus.label}
                          </span>
                          <img src={caretDownIcon} alt='arrow-down' className='arrow-down' />
                        </button>
                        <ul className={`select-dropdown-menu ${openStatusList ? 'open' : ''}`}>
                          {statusTypeList.map((item: any) => {
                            return (
                              <button
                                type='button'
                                style={{
                                  border: '0px solid',
                                  backgroundColor: '#f0ffff00',
                                  width: '-webkit-fill-available',
                                  fontWeight: 500,
                                }}
                                key={item.label}
                                className='select-dropdown-menu__list text-left'
                                onClick={() => {
                                  setOpenStatusList(false);
                                  setActiveStatus(item);
                                  setDisableFilter(false);
                                }}
                                onKeyDown={(event) => {
                                  event.key === 'Enter' && setOpenStatusList(false);
                                  setActiveStatus(item);
                                  setDisableFilter(false);
                                }}
                              >
                                {item.label}
                              </button>
                            );
                          })}
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
          <div className='mt-3'>
            <button
              className={`btn btn--primary btn--h36 w-full ${
                openStatusList === true ? 'mt-18' : ''
              } ${
                !hasTypesSelected() &&
                ((isEmpty(selectedCheckboxes) &&
                  isEmpty(activeStatus.label) &&
                  filterSearchValue === '') ||
                  disableFilter)
                  ? 'disabled'
                  : ''
              }`}
              onClick={(event) => {
                setOpenFilter(false);
                onSort_filterClick(searchValue);
                setIsFilterApplied(true);
                setMaterialDropdown(false);
                setStatusDropdown(false);
                setOpenStatusList(false);
                event.stopPropagation();
              }}
            >
              {t('sharedTexts.applyFilter')}
            </button>
            <div className='mt-3'>
              <button
                className='btn btn--h36 w-full btn btn--h36 px-4 py-2'
                onClick={(event) => {
                  setOpenFilter(false);
                  setFilterTypeSearchValue('');
                  setFilterSearchValue('');
                  setMaterialDropdown(false);
                  setStatusDropdown(false);
                  setOpenStatusList(false);
                  !isFilterApplied && setSelectedCheckboxes([]);
                  isFilterApplied && setSelectedCheckboxes(selectedDummyCheckboxes);
                  event.stopPropagation();
                }}
              >
                {t('sharedTexts.cancel')}
              </button>
            </div>
          </div>
        </div>
      </button>
    );
  };

  const noFilterNeededPathNames = [
    `${paths.usersList}`,
    `${paths.rolesList}`,
    `${paths.activeFurnaceList.list}`,
  ];
  const noSearchNeededPathName = [
    `${paths.usersList}`,
    `${paths.rolesList}`,
    `${paths.activeFurnaceList.list}`,
  ];
  const isFilterSortAllowed = !noFilterNeededPathNames.includes(pathname);
  const isSearchFieldAllowed = !noSearchNeededPathName.includes(pathname);

  const module = pathname?.split('/')[1];
  const subModule = pathname?.split('/')[2];

  const hasCreatePermission = validatePermissions(
    permissionsMapper[module],
    permissionsMapper[subModule],
    crudType.create
  );

  return (
    <div className='dashboard__main__header'>
      <div className='flex items-center justify-between'>
        <h2 className='text-xl font-semibold'>{title}</h2>
        <div className='flex items-center ml-auto'>
          {isSearchFieldAllowed && (
            <div className='search-bar-contaienr'>
              <input
                type='text'
                className='input-field input-field--search input-field--md input-field--h36'
                placeholder={
                  placeholder ?? t('masterData.sharedMasterDataTexts.searchByMaterialNo')
                }
                value={searchValue}
                min={0}
                onChange={handleSearchChange}
                onKeyDown={(event) => {
                  if (
                    event.key === '.' ||
                    event.key === '+' ||
                    event.key === '-' ||
                    event.key === 'e' ||
                    event.key === 'E'
                  ) {
                    event.preventDefault();
                  }
                }}
                onPaste={(event) => event.preventDefault()}
              />
            </div>
          )}
          {isFilterSortAllowed && (
            <>
              <OutsideClickHandler onOutsideClick={() => setOpenFilter(false)}>
                {renderFilterUI()}
              </OutsideClickHandler>
              <button className='btn btn--reset btn--h36 px-4 py-2 ml-3' onClick={onResetFilter}>
                {t('sharedTexts.reset')}
              </button>
            </>
          )}
          {buttonText && (
            <button
              className={`btn btn--primary btn--h36 px-4 py-2 ml-3 ${
                hasCreatePermission ? '' : 'disabled'
              }`}
              onClick={hasCreatePermission && onButtonClick}
            >
              <img src={plusIcon} alt='plus-icon' className='mr-2' />
              {buttonText}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default Header;
