import React, { useEffect, useRef } from 'react';
import InformationField from './InformationField';
import DateOnlyPicker from './DateOnlyPicker';
import dayjs from 'dayjs';
import MUIToolTip from './ToolTip/MUIToolTip';
import DownloadExcel from './ExcelDownload';
import { useTranslation } from 'react-i18next';
// import { useAppDispatch, useAppSelector } from 'store';
// import {
//   getFurnaceMaterialExcel,
//   setFurnaceMaterialExcelList,
// } from 'store/slices/furnaceMaterialSlice';
// import { useParams } from 'react-router-dom';

interface IInformationTabSection {
  title?: string;
  isEdit: boolean;
  gridSize: number;
  sectionData: any;
  onChange: (value: string | number | boolean, keyName: string) => unknown;
  noTitle?: boolean;
  handleEffectiveDateChange?: (e: any) => void;
  dateState?: any;
  excelHeader?: any;
  handleExcelClick?: any;
  materialExcelList?: any;
  clearExcelState?: () => void;
  excelTitle?: string;
}

const InformationTabSection: React.FC<IInformationTabSection> = ({
  title,
  isEdit,
  gridSize,
  onChange,
  sectionData,
  noTitle,
  handleEffectiveDateChange,
  dateState,
  excelHeader,
  handleExcelClick,
  materialExcelList,
  clearExcelState = () => {},
  excelTitle,
}): React.ReactElement => {
  // const { id }: any = useParams();
  // const dispatch = useAppDispatch();
  const { t } = useTranslation();
  const csvLinkRef: any = useRef();

  useEffect(() => {
    if (materialExcelList && materialExcelList.length > 0) {
      csvLinkRef?.current?.link?.click();
      clearExcelState();
    }
  }, [materialExcelList]);

  return (
    <div className='tab-section-content flex mt-4' style={{ flexDirection: 'column' }}>
      {noTitle ? null : (
        <div className='tab-section-left mb-4 flex'>
          <h3 className='tab-section-heading'>{title}</h3>
          {!isEdit && dateState && (
            <>
              <span className='furnaceConfigHeader ml-2'>
                | Effective Date: {dayjs(dateState).format('DD.MM.YY')}
              </span>
              <MUIToolTip text={t(`sharedTexts.downloadExcel`)}>
                <DownloadExcel
                  csvData={materialExcelList}
                  headersForCSV={excelHeader}
                  excelTitle={excelTitle}
                  handleClick={handleExcelClick}
                  csvLinkRef={csvLinkRef}
                />
              </MUIToolTip>
            </>
          )}
        </div>
      )}
      {title && (
        <div className='mb-4 ml-2'>
          <DateOnlyPicker
            view={isEdit}
            handleEffectiveDateChange={handleEffectiveDateChange}
            valueInState={dateState}
          />
          {/* {dateState} ----- */}
          {/* {   <pre>{JSON.stringify(sectionData, null, 2)}</pre>} */}
        </div>
      )}
      <div className='tab-section-right mb-4 mx-0'>
        <div
          className='flex flex-wrap '
          style={{ flexDirection: 'row', flexWrap: 'wrap', gap: '0px' }}
        >
          {sectionData?.map((data: any, index: number) => (
            <InformationField
              key={data.id || index}
              data={data}
              isEdit={isEdit}
              gridSize={gridSize}
              onChange={onChange}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default InformationTabSection;
