// can be used everywhere in the application. the color of pill depend on the text passed to this component
import { Chip } from '@mui/material';
import { getColor } from './pillHelper';
import { useTranslation } from 'react-i18next';

interface PillProps {
  displayText: string;
}

const DynamicPill: React.FC<PillProps> = ({ displayText = 'pill_text' }) => {
  const { t } = useTranslation();
  const translatedText: string = t(`${displayText}`, displayText);
  const [labelText, key] = translatedText.split('_');
  return (
    <>
      <Chip
        label={labelText}
        size='small'
        sx={{
          ...getColor(key),
          '& .MuiChip-label': {
            fontSize: '13px',
            padding: '4px 10px',
          },
        }}
      />
    </>
  );
};

export default DynamicPill;
