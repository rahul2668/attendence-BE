export const getColor = (key: string) => {
  let colorsToApply = {};
  switch (key) {
    case 'completed':
      // green color
      colorsToApply = {
        backgroundColor: '#D8E9C1',
        color: '#357821',
      };
      break;

    case 'pending':
      colorsToApply = {
        //    red
        backgroundColor: '#FFD3CD',
        color: '#B60000',
      };
      break;

    case 'active':
      // green color
      colorsToApply = {
        backgroundColor: '#D8E9C1',
        color: '#357821',
      };
      break;

    case 'inactive':
      colorsToApply = {
        //    red
        backgroundColor: '#FFD3CD',
        color: '#B60000',
      };
      break;

    case 'enabled':
      // green color
      colorsToApply = {
        backgroundColor: '#D8E9C1',
        color: '#357821',
      };
      break;

    case 'disabled':
      colorsToApply = {
        //    red
        backgroundColor: '#FFD3CD',
        color: '#B60000',
      };
      break;
  }
  return colorsToApply;
};
