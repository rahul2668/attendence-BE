import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
import { LocalizationProvider } from '@mui/x-date-pickers-pro';
import { AdapterDayjs } from '@mui/x-date-pickers-pro/AdapterDayjs';
import { DateRangePicker } from '@mui/x-date-pickers-pro/DateRangePicker';
import { InputLabel } from '@mui/material';
import { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
// import {DateRangePicker} from '@adobe/react-spectrum'
// import {defaultTheme, Provider} from '@adobe/react-spectrum';

const CustomDateRangePicker = ({ handleChange, value }: any) => {
  const { t } = useTranslation();
  const hideFunc = () => {
    const calendarRoot = document.querySelector('.MuiDateRangeCalendar-root');
    if (calendarRoot) {
      const firstDiv = calendarRoot.querySelector('div');
      if (firstDiv && window.getComputedStyle(firstDiv).display !== 'none') {
        firstDiv.style.display = 'none';
      }
    }
  };
  useEffect(() => {
    document.addEventListener('mousemove', hideFunc);
    // Cleanup function to remove event listener when component unmounts
    return () => {
      document.removeEventListener('mousemove', hideFunc);
    };
  }, []);
  return (
    <>
      <InputLabel
        id='fn'
        sx={{
          fontWeight: 600,
          color: '#606466',
          fontSize: '14px',
          marginBottom: '5px',
        }}
      >
        {t(`sharedTexts.date`)}
      </InputLabel>
      <LocalizationProvider dateAdapter={AdapterDayjs}>
        <DemoContainer components={['DateRangePicker']}>
          <DateRangePicker
            disableFuture
            format='DD/MM/YYYY'
            onChange={handleChange}
            value={value}
            sx={{
              '& .MuiInputLabel-outlined': {
                transform: 'translate(14px, 10px) scale(1)', // Adjusted translation for initial position
              },
              '& .MuiInputLabel-outlined.Mui-focused': {
                transform: 'translate(14px, 12px) scale(1)', // Reset transformation for focused state
              },
              '& .MuiInputLabel-outlined.MuiInputLabel-shrink': {
                transform: 'translate(14px, -10px) scale(0.75)', // Adjusted translation and scale for shrink state
              },
              '& .MuiInputLabel-outlined.MuiInputLabel-shrink.Mui-focused': {
                transform: 'translate(14px, -10px) scale(0.75)', // Adjusted translation and scale for focused state with value
              },
              '& .MuiInputBase-input': {
                padding: '10px 14px',
              },
            }}
            localeText={{ start: 'Start Date', end: 'End Date' }}
          />
        </DemoContainer>
      </LocalizationProvider>
      {/* <Provider theme={defaultTheme}>
      <DateRangePicker onChange={handleChange} value={value} zIndex={99999999999999999999999999999999999}/>
        </Provider> */}
    </>
  );
};

export default CustomDateRangePicker;
