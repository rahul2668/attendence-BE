import { useEffect, useState } from 'react';
import { connect } from 'react-redux';
import Cancel from '../../assets/icons/close-btn-thin.svg';
import Linear from '../../assets/icons/Linear.svg';
import BarGraph from '../../assets/icons/Bar.svg';
import Stacked from '../../assets/icons/Stocked.svg';
import Tabular from '../../assets/icons/Tabular.svg';
import info from '../../assets/icons/info.svg';
import reportsequence from '../../assets/icons/ReportSequenceMenuIcon.svg';
import { useTranslation } from 'react-i18next';

interface ReportSequenceProps {
  items: any;
  stateUpdation: any;
  element: any;
  selectedName: any;
  materialIds: any;
  materialTypes: any;
  materialIdsForSelection: any;
  disabled: boolean;
}

const ReportSequence: React.FC<ReportSequenceProps> = ({
  items,
  stateUpdation,
  selectedName,
  materialIdsForSelection,
  materialTypes,
  disabled,
}) => {
  const { t } = useTranslation();
  const removeReport = (id: any) => {
    const updatedBoxes = boxes.filter((_: any, index: any) => index !== id);
    setBoxes(updatedBoxes);
    stateUpdation(updatedBoxes);
  };
  const [dragId, setDragId] = useState<any>();
  const [boxes, setBoxes] = useState(items);
  const [showTooltip, setShowTooltip] = useState(false);
  useEffect(() => {
    setBoxes(items);
  }, [items]);

  const handleDrag = (ev: any) => {
    setDragId(ev.currentTarget.id);
  };

  const handleDrop = (ev: any) => {
    const newBoxes = [...boxes];
    [newBoxes[ev.currentTarget.id], newBoxes[dragId]] = [
      newBoxes[dragId],
      newBoxes[ev.currentTarget.id],
    ];
    setBoxes(newBoxes);
    stateUpdation(newBoxes);
  };
  const materialTypeAndIdName = (typeId: any, materialId: any, selectedReportOption: any) => {
    if (selectedReportOption.material_id_all && selectedReportOption?.type_name) {
      return selectedReportOption.type_name ? selectedReportOption.type_name + '-All' : '-All';
    } else if (selectedReportOption.type_name && selectedReportOption?.material_code_name) {
      return (
        selectedReportOption.type_name + '-' + selectedReportOption.material_code_name.slice(0, 4)
      );
    }
    let material = materialIdsForSelection?.filter(
      (item: any) => item.option.split('-')[0].replace(/\s/g, '') === materialId
    );
    let type = materialTypes?.filter((item: any) => item.value === typeId);

    return type[0].option + '-' + material[0].option.slice(0, 4);
    //return type[0].option
  };

  return (
    <div className='mt-4' style={{ pointerEvents: disabled ? 'none' : 'auto' }}>
      <div style={reportSequenceMainDiv} className='ms-3 me-3 pb-3'>
        <span style={dropdownHeadingStyle}>{t('reports.reportSequence')}</span>{' '}
        <img
          src={info}
          style={reportSequenceImg}
          onMouseOut={() => setShowTooltip(false)}
          onMouseOver={() => setShowTooltip(true)}
        />{' '}
        {showTooltip && (
          <span
            className='tooltiptext mt-4'
            style={{
              position: 'fixed',
              width: '206px',
              backgroundColor: '#022549',
              color: 'white',
              fontSize: '12px',
              borderRadius: '4px',
              padding: '10px',
            }}
          >
            {t('reports.dragAndDropToChangeTheSequenceInWhichTheyWouldAppear')}
          </span>
        )}
      </div>
      <div style={reportSequenceSubDiv} className='pb-3'>
        {boxes?.map((text: any, index: any) => (
          <div
            className='me-3'
            id={index}
            style={selectedBox}
            key={index}
            draggable={true}
            onDrag={handleDrag}
            onDragOver={(ev) => ev.preventDefault()}
            onDrop={handleDrop}
          >
            <div style={selectedItemsdiv}>
              <div style={circledNumber}>{index + 1}</div>
              <div style={{ display: 'flex', gap: '7px' }}>
                <img src={reportsequence} />
                <span style={reporSequenceText}>
                  {selectedName === 'consumption'
                    ? text?.material_id_all
                      ? materialTypeAndIdName(text.type_id, 'All', text)
                      : materialTypeAndIdName(text.type_id, text.mes_mat_code, text)
                    : text[selectedName]}
                </span>
                <div>
                  <img
                    src={
                      text?.chart_type == 'Bar'
                        ? BarGraph
                        : text?.chart_type == 'Linear'
                          ? Linear
                          : text?.chart_type == 'Stacked'
                            ? Stacked
                            : text?.chart_type == 'Tabular'
                              ? Tabular
                              : ''
                    }
                  ></img>
                </div>
              </div>
            </div>
            <div>
              <span style={removeReportCss}>
                <img src={Cancel} onClick={() => removeReport(index)} />
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
const mapStateToProps = (state: any) => ({
  materialTypes: state.consumption?.materialTypes,
  materialIds: state.consumption?.materialIds,
  materialIdsForSelection: state.consumption?.materialIdsForSelection,
});
export default connect(mapStateToProps)(ReportSequence);
const selectedItemsdiv = {
  width: '200px',
  display: 'flex',
  alignItems: 'center',
};
const selectedBox = {
  marginLeft: '1%',
  backgroundColor: '#F5F8FA',
  display: 'flex',
  padding: '8px',
  border: '1px solid #CDCDCD',
  marginTop: '1%',
  boxShadow: '0 0 5px rgba(0, 0, 0, 0.2)',
};

const reportSequenceMainDiv = {
  display: 'flex',
};
const reportSequenceImg = {
  height: '20px',
  width: '21px',
  marginLeft: '1%',
  display: 'block',
};
const reportSequenceSubDiv: any = {
  display: 'flex',
  flexWrap: 'wrap',
};
const removeReportCss = {
  cursor: 'pointer',
};
const reporSequenceText = {
  fontfamily: 'Body/Semibold',
  fontweight: 500,
  fontSize: '14px',
  lineheight: '19.6px',
  color: '#041724',
  display: 'flex',
  paddingRight: '8px',
  paddingTop: '1%',
  borderRight: '2px solid #041724',
};
const circledNumber: any = {
  backgroundColor: '#04436B',
  width: '22px',
  height: '20px',
  color: 'white',
  display: 'flex',
  alignItems: 'center',
  borderRadius: '50%',
  position: 'relative',
  left: '-10%',
  padding: '4% 3%',
};
const dropdownHeadingStyle: any = {
  fontWeight: 500,
  fontSize: '14px',
  color: 'var(--primary75)',
};
