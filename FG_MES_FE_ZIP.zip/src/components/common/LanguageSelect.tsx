import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import { useEffect, useState } from 'react';
import { Languages } from 'utils/constants';
import i18n from 'i18n';
import { getSessionStorage, setSessionStorage } from 'utils/utils';
import globeIcon from '../../assets/icons/blue_globe.svg';
import { useAppDispatch, useAppSelector } from 'store';
import { getPlantLanguage } from 'store/slices/authSlice';
// import downIcon from '../../assets/icons/chevron-down.svg';

export default function LanguageSelect({
  showSelectLangLabel = false,
}: {
  showSelectLangLabel?: boolean; // can use the same thing to know if its not the login screen
}) {
  const [language, setLanguage] = useState('');
  const dispatch = useAppDispatch();
  const plantLanguage = useAppSelector((state) => state.login.plantLanguage);

  const handleChange = (event: SelectChangeEvent) => {
    const selectedLanguage = event.target.value;
    setLanguage(selectedLanguage);
    i18n.changeLanguage(selectedLanguage);
    setSessionStorage('selectedLanguage', selectedLanguage);
  };

  useEffect(() => {
    i18n.changeLanguage(language);
  }, [language]);

  useEffect(() => {
    if (!plantLanguage) {
      // plantLanguage ->  response of plant language api is in this
      if (!showSelectLangLabel)
        dispatch(getPlantLanguage()); //showSelectLangLabel this falsy in login page. therefore in login page we make the plant default lang api call
      else {
        // this block behaves like useEffect with no conditions.. just getting lang in session storage and setting it as value
        const existingLangInLocalStorage = getSessionStorage('selectedLanguage');
        if (existingLangInLocalStorage) setLanguage(existingLangInLocalStorage);
      }
    } else if (plantLanguage) {
      setLanguage(plantLanguage);
      // need to check if language key is there. Note: "selectedLanguage" is cleared on logout
      const existingLangInLocalStorage = getSessionStorage('selectedLanguage');
      if (!existingLangInLocalStorage) setSessionStorage('selectedLanguage', plantLanguage);
    }
  }, [plantLanguage]);

  return (
    <FormControl
      sx={{
        m: 0,
        mt: '-6px',
        mr: '-17px',
        minWidth: 120,
        ...(showSelectLangLabel ? { width: '100%' } : {}),
        '& .MuiOutlinedInput-notchedOutline': { border: 'none' },
      }}
      size='medium'
    >
      <div style={showSelectLangLabel ? { display: 'flex', justifyContent: 'center' } : {}}>
        {showSelectLangLabel && (
          <div style={{ display: 'flex', alignItems: 'center', marginRight: '30px' }}>
            <h2>Select Language :</h2>
          </div>
        )}

        <div style={{ display: 'flex', alignItems: 'center' }}>
          <img
            src={globeIcon}
            alt='view'
            className='icon mr-10'
            style={{
              fill: '#04436B',
              width: '30px',
              height: '30px',
              marginRight: '0px',
            }}
          />
          <Select
            labelId='lang-select-small-label'
            id='lang-select-small'
            value={language}
            sx={{
              '& #lang-select-small': { paddingLeft: '5px' },
            }}
            onChange={handleChange}
            inputProps={{ 'aria-label': 'Without label' }}
            // IconComponent={CustomGlobeIcon}
          >
            {Languages.map(({ code, label }) => (
              <MenuItem key={code} value={code}>
                {label}
              </MenuItem>
            ))}
          </Select>
        </div>
      </div>
    </FormControl>
  );
}
