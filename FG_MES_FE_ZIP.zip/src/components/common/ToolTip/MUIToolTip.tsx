import { Tooltip, TooltipProps, styled, tooltipClasses } from '@mui/material';
import React from 'react';
import { useTranslation } from 'react-i18next';

interface CustomTooltipProps {
  text: string;
  children: React.ReactNode;
  arrowVersion?: boolean;
  topPosition?: boolean;
  useTranslationHook?: boolean;
}

const BlueToolTip = styled(({ className, ...props }: TooltipProps) => (
  <Tooltip {...props} classes={{ popper: className }} />
))(({ theme }) => ({
  [`& .${tooltipClasses.tooltip}`]: {
    backgroundColor: '#022549',
    color: 'white',
    borderColor: 'red',
    boxShadow: theme.shadows[1],
    fontSize: 14,
  },
  // Styling the arrow element
  [`& .${tooltipClasses.arrow}`]: {
    color: '#022549', // Change the color of the arrow here
  },
}));

// placement position can be send as a prop for further modification of this
const MUIToolTip: React.FC<CustomTooltipProps> = ({
  text,
  arrowVersion,
  topPosition,
  children,
  useTranslationHook,
}) => {
  const { t } = useTranslation();
  return (
    <BlueToolTip
      title={useTranslationHook ? t(text, text) : text}
      arrow={arrowVersion}
      placement={topPosition ? 'top' : undefined}
    >
      <div>{children}</div>
    </BlueToolTip>
  );
};

export default MUIToolTip;
