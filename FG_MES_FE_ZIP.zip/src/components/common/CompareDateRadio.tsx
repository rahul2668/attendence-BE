import { FC } from 'react';
import { useTranslation } from 'react-i18next';

interface RadioOption {
  value: string;
  label: string;
}

interface CompareDateRadioProps {
  radioOptions: RadioOption[];
  heading: string;
  selectedValue: any;
  onChange: (value: string) => void;
  disabled: boolean;
}

const CompareDateRadio: FC<CompareDateRadioProps> = ({ selectedValue, onChange, disabled }) => {
  const { t } = useTranslation();
  const handleChange = (event: any) => {
    onChange(event.target.value);
  };
  const radioButtonListForCompare = [
    { value: 'TimePeriod', label: t('reports.timePeriod'), checked: true },
    { value: 'Material', label: t('reports.material'), checked: false },
  ];

  return (
    <div>
      <label style={dropdownHeadingStyle}>{t('reports.compareBetween')}</label>
      <div className='row'>
        {radioButtonListForCompare?.map((name): any => {
          return (
            <div className='col-6'>
              <input
                className='form-check-input '
                type='radio'
                value={name['value']}
                name='radio'
                checked={selectedValue === name['value']}
                onChange={handleChange}
                disabled={disabled}
              />
              <br />
              <label className='form-check-label' style={{ fontSize: '14px' }}>
                {name['label']}{' '}
              </label>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default CompareDateRadio;
const dropdownHeadingStyle: any = {
  fontWeight: 500,
  fontSize: '14px',
  color: 'var(--primary75)',
};
