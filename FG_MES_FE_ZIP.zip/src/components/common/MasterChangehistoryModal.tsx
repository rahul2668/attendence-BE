import closeIcon from '../../assets/icons/close-btn.svg';
import downloadIcon from '../../assets/icons/download.svg';
import Accordion from 'components/common/Accordion';
import moment from 'moment';
import { useEffect, useState } from 'react';
import { CSVLink } from 'react-csv';
import { useTranslation } from 'react-i18next';
import { useAppSelector } from 'store';
import { UtilsMasterData } from 'types/plant.model';
import { formatDateHelper } from 'utils/utils';

interface MasterChangehistoryModalBlockProps {
  showModal: boolean;
  closeModal: () => void;
  title: string;
  changeLogData: any;
  enableChangeHistoryExtraColumns: boolean;
  excelTitle: string;
}

const MasterChangehistoryModal: React.FC<MasterChangehistoryModalBlockProps> = ({
  showModal,
  closeModal,
  title,
  changeLogData,
  enableChangeHistoryExtraColumns,
  excelTitle,
}) => {
  const { t } = useTranslation();

  const [csvData, setCsvData] = useState<any>([]);

  const utilsMasterData = useAppSelector((state) => state.master);
  const utilsMasterList: Array<UtilsMasterData> = utilsMasterData?.results;
  const plantDataString = useAppSelector((state) => state.plantData.plantData);
  const plantData: any = plantDataString ?? null;
  const plant_time_zone_id: any = plantData.plant_time_zone_id;
  const timeZone = utilsMasterList?.filter((item: any) => item.id == plant_time_zone_id)?.[0]
    ?.description;

  useEffect(() => {
    if (changeLogData) {
      const structureCsvData = () => {
        const renderData = (data: any, param: any, index: number) => {
          const rowData = {
            A: index === 0 ? data?.username : null,
            B:
              index === 0
                ? moment(data?.created_at).format('DD-MMM-YYYY') +
                  ' ' +
                  moment(data?.created_at, 'HH:mm:ss').format('hh:mm:ss')
                : null,
            C: param.element,
            D: 'N/A',
            E: param.old_values.low,
            F: param.old_values.aim,
            G: param.old_values.high,
            H: 'N/A',
            I: 'N/A',
            J: param.new_values.low || param.old_values.low,
            K: param.new_values.aim || param.old_values.aim,
            L: param.new_values.high || param.old_values.high,
            M: 'N/A',
            N: 'N/A',
          };
          return rowData;
        };

        const masterArray: any = [];
        changeLogData?.forEach((data: any) => {
          data?.change_log?.change_logs_elements?.forEach((param: any, index: number) => {
            masterArray.push(renderData(data, param, index));
          });

          if (data?.change_log?.change_logs_sizes) {
            const sec_rowData = {
              A: data?.change_log?.change_logs_elements ? null : `${data?.username}`,

              B: data?.change_log?.change_logs_elements
                ? null
                : moment(data?.created_at).format('DD-MMM-YYYY') +
                  ' ' +
                  moment(data?.created_at, 'HH:mm:ss').format('hh:mm:ss'),
              C: 'N/A',
              D:
                data.change_log.change_logs_sizes?.new_values?.unit ||
                data.change_log.change_logs_sizes?.old_values?.unit,
              E: data.change_log.change_logs_sizes.old_values.low,
              F: 'N/A',
              G: data.change_log.change_logs_sizes.old_values.high,
              H: data.change_log.change_logs_sizes.old_values.below_tolerance,
              I: data.change_log.change_logs_sizes.old_values.above_tolerance,
              J:
                data.change_log.change_logs_sizes.new_values.low ||
                data.change_log.change_logs_sizes.old_values.low,
              K: 'N/A',
              L:
                data.change_log.change_logs_sizes.new_values.high ||
                data.change_log.change_logs_sizes.old_values.high,
              M:
                data.change_log.change_logs_sizes.new_values.below_tolerance ||
                data.change_log.change_logs_sizes.old_values.below_tolerance,
              N:
                data.change_log.change_logs_sizes.new_values.above_tolerance ||
                data.change_log.change_logs_sizes.old_values.above_tolerance,
            };
            masterArray.push(sec_rowData);
          }
        });

        return masterArray;
      };
      setCsvData(structureCsvData());
    }
  }, [changeLogData, enableChangeHistoryExtraColumns]);

  const renderExtraColumnOld = (cp: any) => {
    if (!cp?.new_values?.showColumn) {
      return '';
    } else if (cp?.old_values?.control) {
      return 'Enabled';
    } else {
      return 'Disabled';
    }
  };

  const renderExtraColumnNew = (cp: any) => {
    if (!cp?.new_values?.showColumn) {
      return '';
    } else if (cp?.new_values?.control) {
      return 'Enabled';
    } else if (!Object.hasOwn(cp?.new_values, 'control')) {
      return cp?.old_values?.control ? 'Enabled' : 'Disabled';
    } else {
      return 'Disabled';
    }
  };

  const renderClassNameECHOLD = (cp: any) => {
    if (!cp?.new_values?.showColumn) {
      return 'p-1 text-center grayed';
    } else if (!Object.hasOwn(cp.new_values, 'control')) {
      return 'p-1 text-center';
    } else if (cp?.new_values?.control && cp?.old_values?.control != cp?.new_values?.control) {
      return 'p-1 text-center red';
    } else if (!cp?.new_values?.control && cp?.old_values?.control != cp?.new_values?.control) {
      return 'p-1 text-center red';
    } else {
      return 'p-1 text-center';
    }
  };

  // the alphabet keys are mapped to a column header
  const headersForCSV = [
    { label: 'User Name', key: 'A' },
    { label: 'Date ', key: 'B' },
    { label: 'Element Name', key: 'C' },
    { label: 'Size Unit', key: 'D' },
    { label: 'Old - Low', key: 'E' },
    { label: 'Old - Aim', key: 'F' },
    { label: 'Old - High', key: 'G' },
    { label: 'Old - Below Tolerance %', key: 'H' },
    { label: 'Old - Above Tolerance %', key: 'I' },
    { label: 'New - Low', key: 'J' },
    { label: 'New - Aim', key: 'K' },
    { label: 'New - High', key: 'L' },
    { label: 'New - Below Tolerance %', key: 'M' },
    { label: 'New - Above Tolerance %', key: 'N' },
  ];

  return (
    <section className={`modal modal--plant-selection ${showModal ? 'open' : ''}`}>
      <div className='modal__customcontainer'>
        <div className='modal__header'>
          <div className='flex items-center justify-between'>
            <div className='flex-1 pr-8'>
              <h3 className='modal__title'>{title}</h3>
            </div>
            <div className='modal__close'>
              <button
                type='button'
                style={{
                  border: '0px solid',
                  backgroundColor: '#f0ffff00',
                  width: '-webkit-fill-available',
                }}
                onClick={closeModal}
                onKeyDown={closeModal}
              >
                <img src={closeIcon} alt='close-icon' />
              </button>
            </div>
          </div>
        </div>
        <CSVLink
          className='download-icon'
          data={csvData}
          headers={headersForCSV}
          filename={`${excelTitle}ChangeHistoryReport`}
        >
          <img src={downloadIcon} alt='Download' />
        </CSVLink>
        <div className='modal__body pt-1 px-4 overflow-auto'>
          {changeLogData?.map((item: any) => (
            <div style={{ marginBottom: '20px' }} key={item.created_at}>
              <Accordion
                key={item.id}
                e_id={'Changelog' + item.id}
                title={formatDateHelper(item?.created_at, timeZone) + ' | ' + item?.username}
              >
                <div style={{ overflow: 'hidden', borderRadius: '2px' }}>
                  {item?.change_log?.change_logs_elements?.length ? (
                    <table className='changehistory-view-table'>
                      <tbody>
                        <tr>
                          <th rowSpan={2} style={{ borderRadius: '10px', textAlign: 'center' }}>
                            {t('masterData.sharedMasterDataTexts.element')}
                          </th>
                          <th
                            colSpan={enableChangeHistoryExtraColumns ? 4 : 3}
                            className='p-1 text-center'
                          >
                            {t('sharedTexts.old')}
                          </th>
                          <th
                            colSpan={enableChangeHistoryExtraColumns ? 4 : 3}
                            className='p-1 text-center'
                          >
                            {t('sharedTexts.new')}
                          </th>
                        </tr>
                        <tr>
                          <th className='p-1 text-center'>
                            {t('masterData.sharedMasterDataTexts.low')}
                          </th>
                          <th className='p-1 text-center'>
                            {t('masterData.sharedMasterDataTexts.aim')}
                          </th>
                          <th className='p-1 text-center'>
                            {t('masterData.sharedMasterDataTexts.high')}
                          </th>
                          {enableChangeHistoryExtraColumns && (
                            <th className='p-1 text-center'>
                              {t('masterData.sharedMasterDataTexts.control')}
                            </th>
                          )}
                          <th className='p-1 text-center'>
                            {t('masterData.sharedMasterDataTexts.low')}
                          </th>
                          <th className='p-1 text-center'>
                            {t('masterData.sharedMasterDataTexts.aim')}
                          </th>
                          <th className='p-1 text-center'>
                            {t('masterData.sharedMasterDataTexts.high')}
                          </th>
                          {enableChangeHistoryExtraColumns && (
                            <th className='p-1 text-center'>
                              {t('masterData.sharedMasterDataTexts.control')}
                            </th>
                          )}
                        </tr>

                        {item?.change_log?.change_logs_elements?.map((cp: any) => (
                          <tr key={cp}>
                            <td className='py-1 pl-2 sub-head'>{cp.element}</td>
                            <td className='p-1 text-center'>{cp.old_values.low}</td>
                            <td className={`p-1 text-center`}>{cp.old_values.aim}</td>
                            <td className={`p-1 text-center`}>{cp.old_values.high}</td>
                            {enableChangeHistoryExtraColumns && (
                              <td
                                className={
                                  !cp?.new_values?.showColumn
                                    ? `p-1 text-center grayed`
                                    : `p-1 text-center`
                                }
                              >
                                {renderExtraColumnOld(cp)}
                              </td>
                            )}
                            <td
                              className={
                                cp.new_values.low ? 'p-1 text-center red' : 'p-1 text-center'
                              }
                            >
                              {cp.new_values.low || cp.old_values.low}
                            </td>
                            <td
                              className={
                                cp.new_values.aim ? 'p-1 text-center red' : 'p-1 text-center'
                              }
                            >
                              {cp.new_values.aim || cp.old_values.aim}
                            </td>
                            <td
                              className={
                                cp.new_values.high ? 'p-1 text-center red' : 'p-1 text-center'
                              }
                            >
                              {cp.new_values.high || cp.old_values.high}
                            </td>
                            {enableChangeHistoryExtraColumns && (
                              <td className={renderClassNameECHOLD(cp)}>
                                {renderExtraColumnNew(cp)}
                              </td>
                            )}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  ) : (
                    ''
                  )}

                  {item?.change_log?.change_logs_sizes && (
                    <table className='changehistory-view-table my-3'>
                      <tbody>
                        <tr>
                          <th rowSpan={2} style={{ borderRadius: '10px', textAlign: 'center' }}>
                            {t('masterData.sharedMasterDataTexts.sizeUnit')}
                          </th>
                          <th colSpan={4} className='p-1 text-center'>
                            {t('sharedTexts.old')}
                          </th>
                          <th colSpan={4} className='p-1 text-center'>
                            {t('sharedTexts.new')}
                          </th>
                        </tr>
                        <tr>
                          <th className='p-1 text-center'>
                            {t('masterData.sharedMasterDataTexts.low')}
                          </th>
                          <th className='p-1 text-center'>
                            {t('masterData.sharedMasterDataTexts.belowTolerance')} %
                          </th>
                          <th className='p-1 text-center'>
                            {t('masterData.sharedMasterDataTexts.high')}
                          </th>
                          <th className='p-1 text-center'>
                            {t('masterData.sharedMasterDataTexts.aboveTolerance')} %
                          </th>
                          <th className='p-1 text-center'>
                            {t('masterData.sharedMasterDataTexts.low')}
                          </th>
                          <th className='p-1 text-center'>
                            {t('masterData.sharedMasterDataTexts.belowTolerance')} %
                          </th>
                          <th className='p-1 text-center'>
                            {t('masterData.sharedMasterDataTexts.high')}
                          </th>
                          <th className='p-1 text-center'>
                            {t('masterData.sharedMasterDataTexts.aboveTolerance')} %
                          </th>
                        </tr>

                        <tr>
                          <td
                            className={`py-1 pl-2 sub-head ${
                              item.change_log.change_logs_sizes.old_values.unit !=
                                item.change_log.change_logs_sizes.new_values.unit &&
                              item.change_log.change_logs_sizes.new_values.unit &&
                              'red'
                            }`}
                          >
                            {item.change_log.change_logs_sizes.new_values.unit ||
                              item.change_log.change_logs_sizes.old_values.unit}
                          </td>
                          <td className='p-1 text-center'>
                            {item.change_log.change_logs_sizes.old_values?.low_size}
                          </td>
                          <td className='py-1 pl-2 text-center'>
                            {item.change_log.change_logs_sizes.old_values?.below_tolerance}
                          </td>
                          <td className='p-1 text-center'>
                            {item.change_log.change_logs_sizes.old_values?.high_size}
                          </td>
                          <td className={`p-1 text-center`}>
                            {item.change_log.change_logs_sizes.old_values?.above_tolerance}
                          </td>

                          <td
                            className={`p-1 text-center ${
                              item.change_log.change_logs_sizes.new_values.low_size && 'red'
                            }`}
                          >
                            {item.change_log.change_logs_sizes.new_values?.low_size ||
                              item.change_log.change_logs_sizes.old_values?.low_size}
                          </td>
                          <td
                            className={`l-2 text-center ${
                              item.change_log.change_logs_sizes.new_values.below_tolerance && 'red'
                            }`}
                          >
                            {item.change_log.change_logs_sizes.new_values?.below_tolerance ||
                              item.change_log.change_logs_sizes.old_values?.below_tolerance}
                          </td>
                          <td
                            className={`p-1 text-center ${
                              item.change_log.change_logs_sizes.new_values.high_size && 'red'
                            }`}
                          >
                            {item.change_log.change_logs_sizes.new_values?.high_size ||
                              item.change_log.change_logs_sizes.old_values?.high_size}
                          </td>
                          <td
                            className={`p-1 text-center ${
                              item.change_log.change_logs_sizes.new_values.above_tolerance && 'red'
                            }`}
                          >
                            {item.change_log.change_logs_sizes.new_values?.above_tolerance ||
                              item.change_log.change_logs_sizes.old_values?.above_tolerance}
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  )}
                </div>
              </Accordion>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default MasterChangehistoryModal;
