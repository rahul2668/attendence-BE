import React, { useEffect, useRef } from 'react';
import moment1 from 'moment';
import 'daterangepicker/daterangepicker.css';
import DateRangePicker from 'daterangepicker';

interface DateProps {
  startdate: any;
  enddate: any;
  handleDates: any;
}

const Dropdown: React.FC<DateProps> = ({ startdate, enddate, handleDates }) => {
  const inputRef = useRef<HTMLInputElement>(null);
  let dateRangePicker: DateRangePicker | null = null;

  useEffect(() => {
    const inputElement = inputRef.current;

    if (inputElement) {
      dateRangePicker = new DateRangePicker(
        inputElement,
        {
          buttonClasses: ['btn'],
          startDate: startdate,
          endDate: enddate,
          ranges: {
            'This Week': [moment1().startOf('week'), moment1().endOf('week')],
            'Last Week': [
              moment1().subtract(7, 'days').startOf('week'),
              moment1().subtract(7, 'days').endOf('week'),
            ],
            'This Month': [moment1().startOf('month'), moment1().endOf('month')],
            'Last Month': [
              moment1().subtract(1, 'month').startOf('month'),
              moment1().subtract(1, 'month').endOf('month'),
            ],
            'This Quarter': [moment1().startOf('quarter'), moment1().endOf('quarter')],
            'This Year': [moment1().startOf('year'), moment1().endOf('year')],
          },
        },
        function (start, end) {
          handleDates(start, end);
          inputElement.value = start.format('MM/DD/YYYY') + ' / ' + end.format('MM-DD-YYYY');
        }
      );
    }

    return () => {
      if (dateRangePicker) {
        dateRangePicker.remove();
      }
    };
  }, [startdate, enddate]);

  return (
    <div className='form-group row'>
      <div className='col-lg-12 col-md-9 col-sm-12'>
        <div className='input-group'>
          <input
            ref={inputRef}
            type='text'
            className='form-control'
            readOnly
            placeholder='Select date range'
          />
          <div className='input-group-append'></div>
        </div>
      </div>
    </div>
  );
};

export default Dropdown;
