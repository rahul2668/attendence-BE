const IconToolTip = ({ isHoveredIcon = 0, hoverMessage, styles = {} }: any) => {
  return (
    <div style={{ position: 'relative' }}>
      <span
        style={{
          position: 'absolute',
          top: '10px',
          left: isHoveredIcon == 1 ? '-10px' : '25px',
          backgroundColor: '#022549',
          padding: '5px',
          color: '#fff',
          fontSize: '14px',
          borderRadius: '4px',
          width: 'max-content',
          ...styles,
        }}
      >
        {hoverMessage}
      </span>
    </div>
  );
};

export default IconToolTip;
