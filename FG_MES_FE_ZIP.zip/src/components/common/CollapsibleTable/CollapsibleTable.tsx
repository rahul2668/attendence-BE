import * as React from 'react';
import Box from '@mui/material/Box';
import Collapse from '@mui/material/Collapse';
import IconButton from '@mui/material/IconButton';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import DownIcon from '../../../assets/icons/chevron-down-thick.svg';
import UpIcon from '../../../assets/icons/up_arrow_plain.svg';
import ActionIcons from '../ActionIcons/ActionIcons';
import { useTranslation } from 'react-i18next';
import DynamicPill from '../DynamicPill/DynamicPill';
import {
  UnfoldMore as SortIcon,
  North as SortUpIcon,
  South as SortDownIcon,
} from '@mui/icons-material';

interface CollapsibleTableProps {
  mainHeaders?: any;
  subHeaders?: any;
  renderData?: any;
  subDataKey: string;
  showActionIconsInParentRow?: boolean;
  showActionIconsInChild?: boolean;
  parentRowActionsPermission?: any;
  childRowActionsPermission?: any;
  callBackOnViewClick?: any;
  callBackOnAddClick?: any;
  callBackOnEditClick?: any;
  callBackOnDeleteClick?: any;
  parentActionsValueKey?: string;
  childActionsValueKey?: string;
  childCallBackOnViewClick?: any;
  childCallBackOnAddClick?: any;
  childCallBackOnEditClick?: any;
  childCallBackOnDeleteClick?: any;
  toolTips?: TooltipProps;
  lastUpdatedEventId?: string;
  clearLastUpdatedEvent?: () => void;
  columnsToDisplayAsPills?: string[];
  columnsWithTranslations?: string[];
  sortHandler?: (columnName: string, orderBy: string) => void;
  row?: any;
}

interface TooltipProps {
  parentViewIconToolText?: string;
  parentAddIconToolText?: string;
  parentEditIconToolText?: string;
  parentDeleteIconToolText?: string;

  childViewIconToolText?: string;
  childAddIconToolText?: string;
  childEditIconToolText?: string;
  childDeleteIconToolText?: string;
}

// new Icons component  end ====

// function Row(props: { row: ReturnType<typeof createDownTimeData>; subHeaders: any }) {  <- checkout later

// Body row of main Table
function Row(props: Readonly<CollapsibleTableProps>) {
  const {
    row,
    subHeaders,
    subDataKey,
    parentRowActionsPermission = {},
    childRowActionsPermission = {},
    showActionIconsInParentRow = false,
    showActionIconsInChild = false,
    // parent call backs
    callBackOnViewClick,
    callBackOnAddClick,
    callBackOnEditClick,
    callBackOnDeleteClick,
    // parent call backs end
    parentActionsValueKey = '',
    childActionsValueKey = '',
    // child call backs
    childCallBackOnViewClick,
    childCallBackOnAddClick,
    childCallBackOnEditClick,
    childCallBackOnDeleteClick,
    // child call backs end
    toolTips,
    lastUpdatedEventId,
    clearLastUpdatedEvent = () => {},
    columnsToDisplayAsPills = [],
    columnsWithTranslations = [],
  } = props;
  const [open, setOpen] = React.useState(false);

  /* *** -------------------------------------------------------------------------------------- *** */
  /* *** -------------------------------------------------------------------------------------- *** */
  // HANDLING ACTIONS. DIRECT CALLBACK IS NOT advisable. may cause errors..
  const handleParentActionClick = (valueInKey: any, type: string) => {
    if (!valueInKey)
      return console.error(`falsy value received in  "handleParentActionClick" , type:${type}`);
    switch (type) {
      case 'view':
        if (callBackOnViewClick) {
          callBackOnViewClick(valueInKey);
        } else {
          console.error('callback function for view not found..');
        }
        break;
      case 'add':
        if (callBackOnAddClick) {
          callBackOnAddClick(valueInKey);
        } else {
          console.error('callback function for add not found..');
        }
        break;

      case 'edit':
        if (callBackOnEditClick) {
          callBackOnEditClick(valueInKey);
        } else {
          console.error('callback function for edit not found..');
        }
        break;

      case 'delete':
        if (callBackOnDeleteClick) {
          callBackOnDeleteClick(valueInKey);
        } else {
          console.error('callback function for delete not found..');
        }
        break;
      default:
        console.error('exception case in "handleParentActionClick"');
        break;
    }
  };

  const handleChildActionClick = (valueInKey: any, type: string) => {
    if (!valueInKey)
      return console.error(`falsy value received in  "handleChildActionClick" , type:${type}`);
    switch (type) {
      case 'view':
        if (childCallBackOnViewClick) {
          childCallBackOnViewClick(valueInKey);
        } else {
          console.error('callback function for view not found..');
        }
        break;
      case 'add':
        if (childCallBackOnAddClick) {
          childCallBackOnAddClick(valueInKey);
        } else {
          console.error('callback function for add not found..');
        }
        break;

      case 'edit':
        if (childCallBackOnEditClick) {
          childCallBackOnEditClick(valueInKey);
        } else {
          console.error('callback function for edit not found..');
        }
        break;

      case 'delete':
        if (childCallBackOnDeleteClick) {
          childCallBackOnDeleteClick(valueInKey);
        } else {
          console.error('callback function for delete not found..');
        }
        break;
      default:
        console.error('exception case in "handleChildActionClick"');
        break;
    }
  };
  /* *** -------------------------------------------------------------------------------------- *** */
  /* *** -------------------------------------------------------------------------------------- *** */

  const [parentRowHovered, setParentRowHovered] = React.useState<boolean>(false);
  const [childHoveredId, setHoveredChildId] = React.useState<string>('');
  const { t } = useTranslation();

  React.useEffect(() => {
    if (lastUpdatedEventId && lastUpdatedEventId === row[parentActionsValueKey]) {
      setOpen(true);
    }
  }, [lastUpdatedEventId]);
  return (
    <React.Fragment>
      <TableRow
        sx={{ '& > *': { borderBottom: 'unset' } }}
        onMouseEnter={() => setParentRowHovered(true)}
        onMouseLeave={() => setParentRowHovered(false)}
      >
        {/* first cell should Be the arrow.. always */}
        <TableCell style={{ borderBottomColor: '#dceefa' }} colSpan={1}>
          {row[subDataKey] && row[subDataKey]?.length > 0 && (
            <IconButton
              sx={{ height: '30px', width: '30px' }}
              aria-label='expand row'
              size='small'
              onClick={() => {
                setOpen(!open);
                clearLastUpdatedEvent();
              }}
            >
              {open ? <img src={UpIcon} alt='collapse' /> : <img src={DownIcon} alt='expand' />}
            </IconButton>
          )}
        </TableCell>

        {/* rest of main table cells has to be populated dynamically will depend of the formatting function 
            createDownTimeData - DT page.  */}

        {Object.keys(row).map((columnKey) => {
          if (columnKey !== subDataKey && columnKey !== 'viewOnlyForSubData') {
            return (
              <TableCell
                key={columnKey}
                sx={{ borderBottomColor: '#dceefa' }}
                component='th'
                scope='row'
              >
                {columnsToDisplayAsPills.includes(columnKey) ? (
                  <DynamicPill displayText={`${row[columnKey]}`} />
                ) : (
                  <>
                    {columnsWithTranslations.includes(columnKey)
                      ? t(row[columnKey])
                      : row[columnKey]}
                  </>
                )}
              </TableCell>
            );
          }
          return null; // Skip rendering for the 'subTableData' key
        })}

        {showActionIconsInParentRow && (
          <TableCell align='center' style={{ borderBottomColor: '#dceefa' }}>
            <ActionIcons
              viewClick={() => handleParentActionClick(row[parentActionsValueKey], 'view')}
              addClick={() => handleParentActionClick(row[parentActionsValueKey], 'add')}
              editClick={() => handleParentActionClick(row[parentActionsValueKey], 'edit')}
              deleteClick={() => handleParentActionClick(row[parentActionsValueKey], 'delete')}
              permissions={parentRowActionsPermission}
              isHovered={parentRowHovered}
              viewToolText={toolTips?.parentViewIconToolText}
              addToolText={toolTips?.parentAddIconToolText}
              editToolText={toolTips?.parentEditIconToolText}
              deleteToolText={toolTips?.parentDeleteIconToolText}
              disableAdd={row['viewOnlyForSubData']} // ie, if viewOnlyForSubData is true, add will be disabled (adding of sub data item)
              useTranslationHookInToolTip
            />
          </TableCell>
        )}
      </TableRow>

      {/* Nested Table start  ------- */}
      {row.subTableData?.length > 0 && (
        <TableRow sx={{ backgroundColor: '#F4F4F4' }}>
          <TableCell style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={10}>
            <Collapse in={open} timeout='auto' unmountOnExit>
              <Box sx={{ margin: 1, marginLeft: '50px' }}>
                <Table size='small' aria-label='purchases'>
                  {/* sub table headers - passes as a static prop   */}
                  <TableHead>
                    <TableRow>
                      {subHeaders?.map((subHeading: any) => (
                        <TableCell
                          key={subHeading?.label}
                          align={subHeading?.alignment || ''}
                          sx={{
                            color: '#04436b',
                            fontWeight: '500',
                            fontSize: '14px',
                            borderBottom: 'none',
                          }}
                          style={{ ...(subHeading?.width ? { width: subHeading?.width } : {}) }}
                        >
                          {t(subHeading?.label)}
                        </TableCell>
                      ))}
                    </TableRow>
                  </TableHead>
                  {/* sub table headers - passes as a static prop   */}
                  <TableBody>
                    {/* extra data rendering, array of sub data  */}

                    {row.subTableData.map((splitRow: any) => {
                      return (
                        <TableRow
                          key={splitRow.splitID}
                          style={{ borderBottomColor: 'blue' }}
                          onMouseEnter={() => setHoveredChildId(splitRow[childActionsValueKey])}
                          onMouseLeave={() => setHoveredChildId('')}
                        >
                          {Object.keys(splitRow).map((keyName) => {
                            return (
                              <TableCell
                                key={keyName}
                                style={{ borderBottom: 'none' }}
                                align='left'
                              >
                                {columnsToDisplayAsPills.includes(keyName) ? (
                                  <DynamicPill displayText={`${splitRow[keyName]}`} />
                                ) : (
                                  <>
                                    {columnsWithTranslations.includes(keyName)
                                      ? t(splitRow[keyName])
                                      : splitRow[keyName]}
                                  </>
                                )}
                                {/* {splitRow[keyName]} */}
                              </TableCell>
                            );
                          })}

                          {showActionIconsInChild && (
                            <TableCell align='center' style={{ borderBottom: 'none' }}>
                              <ActionIcons
                                viewClick={() =>
                                  handleChildActionClick(splitRow[childActionsValueKey], 'view')
                                }
                                addClick={() =>
                                  handleChildActionClick(splitRow[childActionsValueKey], 'add')
                                }
                                editClick={() =>
                                  handleChildActionClick(splitRow[childActionsValueKey], 'edit')
                                }
                                deleteClick={() =>
                                  handleChildActionClick(splitRow[childActionsValueKey], 'delete')
                                }
                                permissions={childRowActionsPermission}
                                isHovered={childHoveredId === splitRow[childActionsValueKey]}
                                viewToolText={toolTips?.childViewIconToolText}
                                addToolText={toolTips?.childAddIconToolText}
                                editToolText={toolTips?.childEditIconToolText}
                                deleteToolText={toolTips?.childDeleteIconToolText}
                                onlyView={row['viewOnlyForSubData']}
                                useTranslationHookInToolTip
                              />
                            </TableCell>
                          )}
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </Box>
            </Collapse>
          </TableCell>
        </TableRow>
      )}

      {/* Nested Table end  ====== */}
    </React.Fragment>
  );
}

// MAIN COMPONENT

export default function CollapsibleTable({
  mainHeaders,
  subHeaders,
  renderData,
  subDataKey,
  showActionIconsInParentRow = false,
  showActionIconsInChild = false,
  parentRowActionsPermission,
  childRowActionsPermission,
  // parent call backs
  callBackOnViewClick,
  callBackOnAddClick,
  callBackOnEditClick,
  callBackOnDeleteClick,
  // parent call backs end
  parentActionsValueKey,
  childActionsValueKey,
  // child call backs
  childCallBackOnViewClick,
  childCallBackOnAddClick,
  childCallBackOnEditClick,
  childCallBackOnDeleteClick, // child call backs end

  toolTips,
  lastUpdatedEventId = '',
  clearLastUpdatedEvent = () => {},
  columnsToDisplayAsPills = [],
  columnsWithTranslations = [],
  sortHandler = () => {},
}: Readonly<CollapsibleTableProps>) {
  const { t } = useTranslation();
  const [activeSortColumn, setActiveSortColumn] = React.useState<string>('');
  const [sortOrder, setSortOrder] = React.useState<string>('');

  const handleSortClick = (columnName: string) => {
    const compareController = activeSortColumn === columnName ? sortOrder : '';
    let sortOrderToPass: string;
    if (compareController === '') {
      sortOrderToPass = 'ASC';
    } else if (compareController === 'ASC') {
      sortOrderToPass = 'DESC';
    } else {
      sortOrderToPass = 'ASC';
    }
    setSortOrder(sortOrderToPass);
    setActiveSortColumn(columnName);
    sortHandler(columnName, sortOrderToPass);
  };
  return (
    <TableContainer component={Paper}>
      <Table aria-label='collapsible table'>
        <TableHead>
          <TableRow style={{ backgroundColor: '#ebf4fa' }}>
            {/* Rendering Headings ---- */}
            {mainHeaders?.map((heading: any) => (
              <TableCell
                key={heading}
                align={heading?.alignment || ''}
                sx={{
                  color: '#04436b',
                  fontWeight: '500',
                  fontSize: '14px',
                }}
                style={{ ...(heading?.width ? { width: heading?.width } : {}) }}
              >
                <div style={{ display: 'flex', alignItems: 'center' }}>
                  {t(heading?.label)}
                  {heading?.enableSort && (
                    <span
                      onClick={() => handleSortClick(heading.sortKey)}
                      className='ml-2'
                      style={{ cursor: 'pointer' }}
                    >
                      {activeSortColumn !== heading.sortKey && (
                        <SortIcon sx={{ color: '#04436b', fontSize: '20px' }} />
                      )}
                      {activeSortColumn === heading.sortKey && (
                        <>
                          {sortOrder === 'ASC' ? (
                            <SortDownIcon sx={{ color: '#04436b', fontSize: '15px' }} />
                          ) : (
                            <SortUpIcon sx={{ color: '#04436b', fontSize: '15px' }} />
                          )}
                        </>
                      )}{' '}
                    </span>
                  )}
                </div>
              </TableCell>
            ))}
            {/* Rendering Headings  ==== */}
          </TableRow>
        </TableHead>

        {/* Main Table Body  ----*/}
        <TableBody>
          {(!renderData || renderData?.length < 1) && (
            <TableRow sx={{ '& > *': { borderBottom: 'unset' } }}>
              {/* first cell should Be the arrow.. always */}
              <TableCell style={{ borderBottomColor: '#dceefa' }} colSpan={mainHeaders?.length}>
                <div style={{ textAlign: 'center' }}>
                  <span> {t('sharedTexts.noResults')}</span>
                </div>
              </TableCell>
            </TableRow>
          )}
          {renderData?.map((row: any) => (
            <Row
              subHeaders={subHeaders}
              parentRowActionsPermission={parentRowActionsPermission}
              childRowActionsPermission={childRowActionsPermission}
              subDataKey={subDataKey}
              key={row.eventId}
              row={row}
              showActionIconsInParentRow={showActionIconsInParentRow}
              showActionIconsInChild={showActionIconsInChild}
              // parent call backs
              callBackOnViewClick={callBackOnViewClick}
              callBackOnAddClick={callBackOnAddClick}
              callBackOnEditClick={callBackOnEditClick}
              callBackOnDeleteClick={callBackOnDeleteClick}
              // parent call backs
              parentActionsValueKey={parentActionsValueKey}
              childActionsValueKey={childActionsValueKey}
              // child call backs
              childCallBackOnViewClick={childCallBackOnViewClick}
              childCallBackOnAddClick={childCallBackOnAddClick}
              childCallBackOnEditClick={childCallBackOnEditClick}
              childCallBackOnDeleteClick={childCallBackOnDeleteClick}
              // child call backs end

              // tooltips
              toolTips={toolTips}
              lastUpdatedEventId={lastUpdatedEventId}
              clearLastUpdatedEvent={clearLastUpdatedEvent}
              columnsToDisplayAsPills={columnsToDisplayAsPills}
              columnsWithTranslations={columnsWithTranslations}
            />
          ))}
        </TableBody>
        {/* Main Table Body  ==== */}
      </Table>
    </TableContainer>
  );
}
