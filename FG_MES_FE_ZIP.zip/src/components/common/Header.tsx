/* eslint-disable no-prototype-builtins */
import React, { useState } from 'react';
import filterIcon from '../../assets/icons/filter.svg';
import plusIcon from '../../assets/icons/plus-white.svg';
import { debounce, isEmpty } from 'utils/utils';
import { useTranslation } from 'react-i18next';
import CustomFilter from './Filter';
import { useDispatch } from 'react-redux';
import { setFilterDataList } from 'store/slices/filterDataList';
import DownloadExcel from './ExcelDownload';
import { ExcelDataList } from 'types/header.model';
import MUIToolTip from './ToolTip/MUIToolTip';

interface ReusableHeader {
  title: string;
  buttonText?: string;
  placeholder?: string;
  onSearchChange?: (value: string) => void;
  onButtonClick?: () => void;
  sort_filter_click?: (inputValue: any, fromFilterSerach?: boolean) => Promise<void>; // Add sort_filter_click and onFilterClick props
  onReset?: () => void;
  isFilterSortAllowed?: boolean;
  isSearchFieldAllowed?: boolean;
  filterFieldList?: any;
  onFilter?: () => void;
  excelDataList?: ExcelDataList;
  handleExcelClick?: () => void;
  csvLinkRef?: any;
  isExcel?: boolean;
  hasCreatePermission?: boolean;
  triggeredReset?: () => void;
}

const ReusableHeader: React.FC<ReusableHeader> = ({
  title,
  placeholder,
  buttonText,
  onSearchChange,
  onButtonClick = () => {},
  sort_filter_click, // Add sort_filter_click prop
  onReset = () => {}, //to reset the filter / sort
  isFilterSortAllowed,
  isSearchFieldAllowed,
  filterFieldList = [],
  onFilter,
  excelDataList,
  handleExcelClick,
  csvLinkRef,
  isExcel,
  hasCreatePermission = false,
  triggeredReset = () => {},
}) => {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const [searchValue, setSearchValue] = useState('');
  const [openStatusList, setOpenStatusList] = useState(false);
  const [openFilter, setOpenFilter] = useState(false);
  const [selectedSortType, setSelectedSortType] = useState<string>('');
  const [isFilterApplied, setIsFilterApplied] = useState(false);
  const [disableFilter, setDisableFilter] = useState<boolean>(true);
  const [appliedFilter, setAppliedFilter] = useState([]);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/[^a-zA-Z0-9_ ]/g, '');
    if (value.length == 1 && value.startsWith(' ')) {
      e.preventDefault();
    } else {
      debounce(setSearchValue(value), 500);
      const emptyCheck = checkAllStates();
      emptyCheck ? onSearchChange && onSearchChange(value) : onSort_filterClick(value);
    }
  };

  const checkAllStates = () => {
    let allStatesEmpty = false;
    if (isEmpty(selectedSortType)) {
      allStatesEmpty = true;
      return allStatesEmpty;
    }
    return allStatesEmpty;
  };

  const onResetFilter = () => {
    setSearchValue('');
    onSearchChange?.('');
    setIsFilterApplied(false);
    onReset();
    setSelectedSortType('');
    setOpenFilter(false);
    setDisableFilter(true);
    setAppliedFilter([]);
    dispatch(setFilterDataList({}));
  };

  const onSort_filterClick = (searchText?: string) => {
    const inputData = {
      search: searchText?.replace(/^\s+/g, ''),
      page: 1,
      sort_type: selectedSortType,
    };
    sort_filter_click?.(inputData);
    setOpenFilter(false);
  };

  const renderFilterUI = () => {
    return (
      <button className='relative btn btn--h36 px-3 py-2 ml-3' onClick={() => setOpenFilter(true)}>
        <img src={filterIcon} alt='filter-icon' className='mr-1' />
        {t('sharedTexts.allFilters')}
        {isFilterApplied && (
          <span
            className='inline-block absolute rounded-full'
            style={{
              width: 14,
              height: 14,
              top: -5,
              right: -4,
              backgroundColor: '#F23D24',
            }}
          />
        )}
      </button>
    );
  };

  return (
    <>
      <div className='dashboard__main__header'>
        <div className='flex items-center justify-between'>
          <h2 className='text-xl font-semibold'>{title}</h2>
          <div className='flex items-center ml-auto'>
            {isSearchFieldAllowed && (
              <div className='search-bar-contaienr'>
                <input
                  type='text'
                  className='input-field input-field--search input-field--md input-field--h36'
                  placeholder={
                    placeholder ?? t('masterData.sharedMasterDataTexts.searchByMaterialNo')
                  }
                  value={searchValue}
                  min={0}
                  onChange={handleSearchChange}
                  onKeyDown={(event) => {
                    if (
                      event.key === '.' ||
                      event.key === '+' ||
                      event.key === '-' ||
                      event.key === 'e' ||
                      event.key === 'E'
                    ) {
                      event.preventDefault();
                    }
                  }}
                  onPaste={(event) => event.preventDefault()}
                />
              </div>
            )}
            {isFilterSortAllowed && (
              <>
                {renderFilterUI()}
                {appliedFilter?.length > 0 && (
                  <button
                    className='btn btn--reset btn--h36 px-4 py-2 ml-3'
                    onClick={onResetFilter}
                  >
                    {t('sharedTexts.reset')}
                  </button>
                )}
              </>
            )}

            {buttonText && (
              <button
                className={`btn btn--primary btn--h36 px-4 py-2 ml-3 ${
                  hasCreatePermission ? '' : 'disabled'
                }`}
                onClick={hasCreatePermission ? onButtonClick : undefined}
              >
                <img src={plusIcon} alt='plus-icon' className='mr-2' />
                {buttonText}
              </button>
            )}
            {isExcel && (
              <MUIToolTip text={t(`sharedTexts.downloadExcel`)}>
                <DownloadExcel
                  csvData={excelDataList?.csvData}
                  headersForCSV={excelDataList?.headersForCSV}
                  excelTitle={excelDataList?.title}
                  handleClick={handleExcelClick}
                  csvLinkRef={csvLinkRef}
                />
              </MUIToolTip>
            )}
          </div>
        </div>
      </div>
      <CustomFilter
        openFilter={openFilter}
        setOpenFilter={setOpenFilter}
        setOpenStatusList={setOpenStatusList}
        setDisableFilter={setDisableFilter}
        openStatusList={openStatusList}
        disableFilter={disableFilter}
        setIsFilterApplied={(value: boolean, isClear: boolean) => {
          if (isClear) {
            setIsFilterApplied(false);
          } else {
            setIsFilterApplied(value);
          }
          if (value) {
            onFilter && onFilter();
          }
        }}
        appliedFilter={appliedFilter}
        filterFieldList={filterFieldList}
        setAppliedFilter={setAppliedFilter}
        triggeredReset={triggeredReset}
        onResetFilter={onResetFilter}
      />
    </>
  );
};

export default ReusableHeader;
