interface CustomToolTipPayload {
  active?: any;
  payload?: any;
  label?: any;
}

const CustomToolTip: React.FC<CustomToolTipPayload> = ({ active, payload }) => {
  return (
    <div>
      {active && payload && payload.length ? (
        <div style={{ display: 'inline-block', padding: 10, background: 'white' }}>
          {payload[0] ? (
            <div style={{ color: payload[0]?.color }}>x-Axis 1 - {payload[0]?.payload.xAxis_1}</div>
          ) : (
            <></>
          )}
          {payload[0] ? (
            <div style={{ color: payload[0]?.color }}>
              {payload[0]?.dataKey} - {payload[0]?.value}
            </div>
          ) : (
            <></>
          )}
          {payload[1] ? (
            <div style={{ color: payload[1]?.color }}>x-Axis 2 - {payload[1]?.payload.xAxis_2}</div>
          ) : (
            <></>
          )}
          {payload[1] ? (
            <div style={{ color: payload[1]?.color }}>
              {payload[1]?.dataKey} - {payload[1]?.value}
            </div>
          ) : (
            <></>
          )}
        </div>
      ) : (
        <></>
      )}
    </div>
  );
};

export default CustomToolTip;
