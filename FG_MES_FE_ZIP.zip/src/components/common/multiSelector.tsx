
import Checkbox from '@mui/material/Checkbox';
import TextField from '@mui/material/TextField';
import Autocomplete from '@mui/material/Autocomplete';
import CheckBoxOutlineBlankIcon from '@mui/icons-material/CheckBoxOutlineBlank';
import CheckBoxIcon from '@mui/icons-material/CheckBox';
import { useEffect, useState } from 'react';
import { Chip, InputLabel } from '@mui/material';
import { useTranslation } from 'react-i18next';
import { FilterFieldKeys, filterFieldTranslationKeyPrefix } from 'utils/constants';

interface Data {
  placeholder: string;
  list: Array<string>;
  name: string;
  label?: string;
}

interface CheckboxesTagsProps {
  data: Data;
  checkboxChange: (value: any, name: any) => void;
  value: Array<string>;
}

const icon = <CheckBoxOutlineBlankIcon fontSize='small' />;
const checkedIcon = <CheckBoxIcon fontSize='small' />;

const CheckboxesTags = ({ data, checkboxChange, value }: CheckboxesTagsProps) => {
  const { t, i18n } = useTranslation();
  const [selectedValues, setSelectedValues] = useState<Array<string>>(value);
  const [translatedOptions, setTranslatedOptions] = useState<Array<string>>([]);
  const [optionMap, setOptionMap] = useState<Map<string, string>>(new Map());

  const handleChange = (event: any, newValue: Array<string>) => {
    event.preventDefault();
    const originalValues = newValue.map(translatedValue => 
      Array.from(optionMap.keys()).find(key => optionMap.get(key) === translatedValue)
    );
    setSelectedValues(originalValues as Array<string>);
    checkboxChange([...originalValues], data?.name);
  };

  useEffect(() => {
    if (value) {
      setSelectedValues(value);
    }
  }, [value]);

  useEffect(() => {
    if (data?.list) {
      const newOptionMap = new Map<string, string>();
      const newTranslatedOptions:string[] = data.list.map(option => {
        const translatedAccessKey = Object.keys(filterFieldTranslationKeyPrefix).includes(data?.name)
          ? `${filterFieldTranslationKeyPrefix[data?.name as FilterFieldKeys]}${option}`
          : null;
        const translatedOption:string = translatedAccessKey ? t(translatedAccessKey,translatedAccessKey) : option;
        newOptionMap.set(option, translatedOption);
        return translatedOption;
      });
      setOptionMap(newOptionMap);
      setTranslatedOptions(newTranslatedOptions);
    }
  }, [data, i18n.language]);

  return (
    <>
      <InputLabel
        id='fn'
        sx={{
          fontWeight: 600,
          color: '#606466',
          fontSize: '14px',
          marginBottom: '5px',
        }}
      >
        {data?.label}
      </InputLabel>
      <Autocomplete
        multiple
        id='checkboxes-tags-demo'
        options={translatedOptions}
        disableCloseOnSelect
        renderOption={(props, option, { selected }) => (
          <li {...props}>
            <Checkbox
              icon={icon}
              checkedIcon={checkedIcon}
              style={{ marginRight: 8 }}
              checked={selected}
            />
            {option}
          </li>
        )}
        style={{ width: 450, height: 55 }}
        sx={{
          '& .MuiTextField-root': {
            border: '1px solid #cdcdcd',
            borderRadius: '4px',
            height: '80px',
          },
          '& .MuiOutlinedInput-notchedOutline': {
            border: '0px',
          },
          '& .MuiAutocomplete-inputRoot': {
            height: '80px',
            overflow: 'auto',
            textOverflow: 'ellipsis',
          },
          '& .MuiAutocomplete-tag': {
            height: '30px',
            borderRadius: '10px',
          },
          '& .MuiChip-label': {
            fontSize: '16px',
          },
        }}
        renderTags={(selectedValues, getTagProps) =>
          selectedValues?.map((selectedValue, index) => (
            <Chip
              label={optionMap.get(selectedValue) || selectedValue}
              {...getTagProps({ index })}
              style={{ height: '30px', borderRadius: '10px' }}
            />
          ))
        }
        value={selectedValues.map(val => optionMap.get(val) || val)}
        onChange={handleChange}
        renderInput={(params) => <TextField {...params} placeholder={data?.placeholder} />}
      />
    </>
  );
};

export default CheckboxesTags;

