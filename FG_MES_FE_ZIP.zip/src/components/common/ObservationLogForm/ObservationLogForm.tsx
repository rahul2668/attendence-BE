// Observation log form - reusable component
import { FC, useEffect, useState } from 'react';
import {
  InputLabel,
  FormControl,
  FormLabel,
  RadioGroup,
  Radio,
  FormControlLabel,
  MenuItem,
  Box,
  Typography,
} from '@mui/material';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DesktopDateTimePicker } from '@mui/x-date-pickers/DesktopDateTimePicker';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import dayjs from 'dayjs';
import { ObservationLogFormType } from 'types/logBook.model';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import { useTranslation } from 'react-i18next';
import { logBook } from 'utils/constants';
import { useAppSelector } from 'store';
import { handleTimezone } from 'utils/utils';
import { UtilsMasterData } from 'types/plant.model';

dayjs.extend(utc);
dayjs.extend(timezone);

const ObservationLogForm: FC<any> = ({
  renderData,
  saveClicked = false,
  onSave,
  enableSaveButton,
  disableSaveButton,
  furnaces = [],
  existingObservationData = null,
  isEdit = false,
  screen,
}) => {
  const { t } = useTranslation();
  const [formData, setFormData] = useState<ObservationLogFormType>({
    furnace: '',
    comments: '',
    // observation_dt: dayjs(),
    observation_dt: dayjs().toDate(),
  });
  const utilsMasterData = useAppSelector((state) => state.master);

  const utilsMasterList: Array<UtilsMasterData> = utilsMasterData?.results;
  const [dateError, setDateError] = useState<null | string>('');
  const plantDataString = useAppSelector((state) => state.plantData.plantData);
  const plantData: any = plantDataString ?? null;
  const plant_time_zone_id: any = plantData.plant_time_zone_id;

  const timeZone = utilsMasterList?.filter((item: any) => item.id == plant_time_zone_id)?.[0]
    ?.description;

  const textareaStyles: any = {
    boxSizing: 'border-box',
    width: '740px',
    fontFamily: "'IBM Plex Sans', sans-serif",
    fontSize: '0.875rem',
    fontWeight: 400,
    lineHeight: 1.5,
    padding: '8px 12px',
    borderRadius: '8px',
    // color: '#9da8b7', // Grey 500
    border: '1px solid #bcbcbc', // Grey 200
    // boxShadow: '0px 2px 2px #dae2ed', // Grey 200
    resize: 'none',
    outline: 'none', // remove default focus outline
    transition: 'box-shadow 0.2s ease', // add transition for focus effect
  };

  const handleChange = (event: SelectChangeEvent) => {
    setFormData((prev: ObservationLogFormType) => ({
      ...prev,
      [event.target.name]: event.target.value,
    }));
    // setFurnace(event.target.value as string);
  };

  const handleRadioChange = (event: any) => {
    // alert(JSON.stringify(event.target.value))
    // alert(JSON.stringify(event.target.value))

    setFormData((prev: ObservationLogFormType) => ({
      ...prev,
      [event.target.name]: event.target.value,
    }));
    // setFormData((prev) => ({ ...prev, [event.target.name]: event.target.value as string }));
    // setFurnace(event.target.value as string);
  };

  // not working for comments...
  const handleCommentChange = (event: any) => {
    setFormData((prev: ObservationLogFormType) => ({
      ...prev,
      [event.target.name]: event.target.value,
    }));
    // setComment(event.target.value as string);
  };

  const handleDateAndTimeChange = (newDateAndTime: any) => {
    setFormData((prev: ObservationLogFormType) => ({ ...prev, observation_dt: newDateAndTime }));
  };

  // radio label
  const generateLabelStyles = () => {
    return {
      fontWeight: 600,
      color: '#606466',
      marginBottom: '10px',
      fontSize: '14px',
      position: 'relative',
      '&.Mui-focused': { color: '#0D659E' },
      '&.Mui-focused::after': {
        content: '""',
        position: 'absolute',
        left: 0,
        bottom: 0,
        width: 'fit-content',
        height: '2px',
        backgroundColor: '#0D659E',
        animation: 'underlineDraw 0.2s forwards',
        '@keyframes underlineDraw': {
          from: {
            width: 0,
          },
          to: {
            width: 'calc(var(--text-length) * 8.3px)',
          },
        },
      },
    };
  };

  useEffect(() => {
    if (saveClicked !== null) {
      // Check for null - initial value of state, ie, save button is not clicked yet!
      //   alert('Save Clicked');
      onSave(formData);
    }
  }, [saveClicked]);

  useEffect(() => {
    const requiredKeysFromOptions = renderData?.radioData
      .filter((option: any) => option.required)
      .map((option: any) => option.payload_key);

    // Add 'furnace' and 'observation_dt' keys extra
    const allRequiredKeys: Array<keyof ObservationLogFormType> = [
      ...requiredKeysFromOptions,
      'furnace',
      'observation_dt',
    ];
    // Check if all required fields have values
    const areAllRequiredFieldsFilled = allRequiredKeys.every((key) => !!formData[key]);
    if (areAllRequiredFieldsFilled && !dateError) {
      enableSaveButton();
    } else {
      disableSaveButton();
    }
  }, [formData, enableSaveButton]);

  //dateError - > adding this dependency didn't work as expected because of state setting lag. therefore made a separate comparing logic on date errors
  useEffect(() => {
    if (dateError) {
      disableSaveButton();
    } else {
      const requiredKeysFromOptions = renderData?.radioData
        .filter((option: any) => option.required)
        .map((option: any) => option.payload_key);

      // Add 'furnace' and 'observation_dt' keys extra
      const allRequiredKeys: Array<keyof ObservationLogFormType> = [
        ...requiredKeysFromOptions,
        'furnace',
        'observation_dt',
      ];
      // Check if all required fields have values
      const areAllRequiredFieldsFilled = allRequiredKeys.every((key) => !!formData[key]);
      if (areAllRequiredFieldsFilled && !dateError) {
        enableSaveButton();
      }
    }
  }, [dateError]);

  useEffect(() => {
    if (existingObservationData) {
      setFormData(existingObservationData);
    }
  }, [existingObservationData]);

  const handleTranslate = (label: string) => {
    let translationKey: any;
    if (screen === logBook.furnaceBed) {
      translationKey = `logBook.furnaceBedLog.${label}`;
    } else if (screen === logBook.tapHole) {
      translationKey = `logBook.tapHoleLog.${label}`;
    }
    const translatedString = t(translationKey);

    // If the translation exists, `translatedString` will be the translated value,
    // otherwise, it will be the same as `translationKey`
    const displayString = translatedString !== translationKey ? translatedString : label;

    return displayString;
  };

  return (
    <Box display={'flex'} flexDirection={'column'} sx={{ gap: '25px' }}>
      {/* Top section --- */}

      <Box display={'flex'} flexDirection={'row'} sx={{ gap: '25px' }}>
        {/* Furnace Input --- */}
        <Box>
          <InputLabel
            id='fn'
            sx={{
              fontWeight: 600,
              color: '#606466',
              marginBottom: '5px',
              fontSize: '14px',
            }}
          >
            {t('systemAdmin.furnaceConfiguration.furnaceNo')}.*{' '}
          </InputLabel>

          <FormControl>
            <Select
              id='demo-simple-select'
              value={formData?.furnace ? formData.furnace.toString() : ''}
              name='furnace'
              //   notched={true}
              displayEmpty
              disabled={isEdit}
              onChange={handleChange}
              inputProps={{ 'aria-label': 'Without label' }}
              sx={{
                height: '40px',
                width: '250px',
                backgroundColor: isEdit ? '#e3e9ea' : '',
              }}
            >
              {/* excludes id 0  */}
              <MenuItem disabled value=''>
                <em style={{ fontStyle: 'normal' }}>{t('sharedTexts.select')}</em>
              </MenuItem>
              {furnaces
                .filter((furnace: any) => furnace.id !== 0)
                .map((furnace: any) => (
                  <MenuItem key={furnace.id} value={furnace.furnace_no}>
                    {furnace.furnace_no}
                  </MenuItem>
                ))}
            </Select>
          </FormControl>
        </Box>

        {/* Furnace Input end === */}

        <Box>
          <div style={{ display: 'flex', gap: '60px' }}>
            {/* date-time --- */}
            <Box>
              <InputLabel
                id='fn'
                sx={{
                  fontWeight: 600,
                  color: '#606466',
                  fontSize: '14px',
                  marginBottom: '5px',
                }}
              >
                {t('logBook.sharedLogBookTexts.observationDateAndTime')}*
              </InputLabel>
              <LocalizationProvider dateAdapter={AdapterDayjs}>
                <DesktopDateTimePicker
                  // defaultValue={dayjs()}
                  disableFuture
                  format='DD/MM/YYYY hh:mm A'
                  closeOnSelect={false}
                  sx={{
                    '& .MuiInputBase-input': {
                      height: '40px',
                      padding: '0px 0px 0px 14px',
                      fontSize: '14px',
                    },
                    // '& .css-14s5rfu-MuiFormLabel-root-MuiInputLabel-root': {
                    //   top: '-6px',
                    // },
                    width: '250px!important', // this solved a UI bug in date
                  }}
                  // connected error of this component to a state
                  onError={(errorInDate) => {
                    if (errorInDate) setDateError(errorInDate);
                    else setDateError(null);
                  }}
                  value={handleTimezone(formData?.observation_dt, timeZone)}
                  onChange={handleDateAndTimeChange}
                />
              </LocalizationProvider>
            </Box>

            {/* date-time end === */}
          </div>
        </Box>
        {/* Top section  end === */}
      </Box>

      {/* radio inputs --- */}
      <Box>
        <div
          style={{
            display: 'grid',
            gap: '20px 0px',
            justifyContent: 'start',
            gridTemplateColumns: `auto 1fr`,
          }}
        >
          {renderData?.radioData?.map((radioData: any, index: any) => (
            <>
              {/* <h6>{JSON.stringify(radioData)}</h6> */}

              <FormControl
                // key={section}
                component='fieldset'
                style={{
                  //   marginBottom: '10px',
                  gridColumn: `${radioData?.options?.length > 3 ? 'span 3' : 'auto'}`,
                  textAlign: 'left',
                  // maxWidth: index === 0 || index === 3 ? '310px' : 'none',
                  // minWidth: index === 0 || index === 3 ? '310px' : 'none',
                  width: index === 0 || index === 3 ? '310px' : 'none',
                }}
              >
                <FormLabel
                  // HARD TO SEE THIS
                  //   sx={{
                  //     fontWeight: 600,
                  //     color: '#606466',
                  //     //   '&.Mui-focused': { color: '#0D659E', textDecoration: "underline" },
                  //     '&.Mui-focused': { color: '#0D659E' },
                  //   }}

                  // ADDED AN ANIMATED LINE FOR BETTER UX
                  sx={generateLabelStyles()}
                  ref={(label) => {
                    if (label) {
                      label.style.setProperty('--text-length', `${radioData?.label?.length}`);
                    }
                  }}
                >
                  {handleTranslate(radioData.label)}
                </FormLabel>

                <RadioGroup row aria-label={radioData.label} name={radioData.label}>
                  {radioData?.options?.map((option: any) => (
                    <FormControlLabel
                      sx={{ width: '150px', marginRight: '0px' }}
                      key={option?.id}
                      value={option?.value}
                      onChange={(event) => {
                        handleRadioChange(event);
                      }}
                      name={radioData.payload_key}
                      control={
                        <Radio
                          // type assertion
                          checked={
                            option?.value ==
                            formData[radioData.payload_key as keyof ObservationLogFormType]
                          }
                          sx={{
                            '&, &.Mui-checked': {
                              color: '#0D659E',
                            },
                          }}
                        />
                      }
                      label={
                        <Typography sx={{ fontSize: '14px', fontWeight: 600 }}>
                          {handleTranslate(option?.value)}
                        </Typography>
                      } // what displayed in UI
                    />
                  ))}
                </RadioGroup>
              </FormControl>
            </>
          ))}
        </div>
      </Box>
      {/* radio inputs end === */}

      {/* comment  ---*/}
      <Box>
        <InputLabel
          id='fn'
          sx={{
            fontWeight: 600,
            color: '#606466',
            fontSize: '14px',
          }}
        >
          {t('sharedTexts.comments')}
        </InputLabel>
        <textarea
          onChange={handleCommentChange}
          rows={4}
          cols={50}
          maxLength={500}
          name='comments'
          value={formData?.comments}
          style={textareaStyles}
          onFocus={(e) => {
            e.target.style.border = '2px solid #1976d2';
          }}
          onBlur={(e) => {
            e.target.style.border = '1px solid #bcbcbc';
          }}
        />
      </Box>
      {/* comment end === */}
    </Box>
  );
};

export default ObservationLogForm;
