const ToggleCheck = () => {
  return (
    <div className='mt-2'>
      <label className='p-0'>Compare</label>
      <div className='form-check form-switch'>
        <input
          className='form-check-input'
          type='checkbox'
          role='switch'
          id='flexSwitchCheckChecked'
        />
        <label className='form-check-label'>Disabled</label>
      </div>
    </div>
  );
};
export default ToggleCheck;
