import React, { useEffect, useState } from 'react';
import {
  Bar,
  BarChart,
  Legend,
  Line,
  CartesianGrid,
  LineChart,
  ReferenceLine,
  Tooltip,
  XAxis,
  YAxis,
  ResponsiveContainer,
  Label,
} from 'recharts';
import CustomToolTip from './CustomToolTip';
interface GraphPayload {
  graphPayload: any;
  layout: string;
  date_range?: any;
  compare_time_period?: any;
}

const Graph: React.FC<GraphPayload> = ({
  graphPayload,
  layout,
  date_range,
  compare_time_period,
}) => {
  const [data, setData] = useState(loadData());
  useEffect(() => {
    setData(loadData());
  }, [graphPayload]);
  function loadData(): any {
    const chartDataArray: any[] | null = [];
    graphPayload?.forEach((item: any) => {
      if (!item && 0 === Object.keys(item).length) {
        return {};
      }
      let chartNo: number = 0;
      const chartData: any = {};
      const array: Array<any> = [];
      let xAxisIndex = 1;
      let yAxisElements = [xAxisIndex];
      //let xAxisArray = [xAxisIndex];

      const compareMaterials = item.compare_material_values
        ? item.compare_material_values
        : undefined;

      item['x-axis_' + xAxisIndex].forEach((xAxis: string, index: number) => {
        const reChartObj: any = {};
        reChartObj['xAxis_' + xAxisIndex] = xAxis;
        //reChartObj[item.element] = item['fixed_values'].values[index];
        Object.entries(item['fixed_values'])?.map(([key, val]) => {
          let keyName = key;
          if (compare_time_period?.length == 2 && date_range?.length == 2) {
            keyName = key + '_' + date_range[0] + '_' + date_range[1];
          }
          if (0 < array.length) {
            for (let ind = 0; ind < array.length; ind++) {
              const value: any = val as any;
              reChartObj[keyName] = value[ind + 1];
              chartData['yAxisName_' + chartNo] = keyName;
            }
          } else {
            const value: any = val as any;
            reChartObj[keyName] = value[index];
            chartData['yAxisName_' + chartNo] = keyName;
          }
        });
        array.push(reChartObj);
      });

      if (compareMaterials) {
        ++xAxisIndex;
        if (item['x-axis_' + xAxisIndex]) {
          for (let arrIndex = 0; arrIndex < item['x-axis_' + xAxisIndex].length; arrIndex++) {
            compareMaterials.forEach((material: any, chartNo: number) => {
              Object.entries(material)?.map(([key, val]) => {
                let keyName = key + 1;
                if (compare_time_period?.length == 2 && date_range?.length == 2) {
                  keyName = key + '_' + compare_time_period[0] + '_' + compare_time_period[1];
                }
                chartData['yAxisName_' + (chartNo + 1)] = keyName;
                const maxNum =
                  array.length > item['x-axis_' + xAxisIndex].length
                    ? array.length
                    : item['x-axis_' + xAxisIndex].length;

                for (let ind = 0; ind < maxNum; ind++) {
                  const reChartObj: any = {};
                  const value: any = val as any;
                  if (value[ind] || value[ind] == 0) {
                    if (array[ind]) {
                      array[ind]['xAxis_' + xAxisIndex] = item['x-axis_' + xAxisIndex][ind];
                      array[ind][chartData['yAxisName_' + (chartNo + 1)]] = value[ind];
                    } else {
                      reChartObj[keyName] = value[ind];
                      array.push(reChartObj);
                    }
                  }
                }
              });
            });
          }
        } else {
          --xAxisIndex;
          compareMaterials.forEach((material: any, chartNo: number) => {
            Object.entries(material)?.map(([key, val]) => {
              let keyName = key;
              if (compare_time_period?.length == 2 && date_range?.length == 2) {
                keyName = key + '_' + compare_time_period[0] + '_' + compare_time_period[1];
              }
              chartNo++;
              array.forEach((item, index) => {
                const value: any = val as any;
                item[keyName] = value[index] ? value[index] : 0;
                chartData['yAxisName_' + (chartNo + 1)] = keyName;
                // console.log(item);
              });
            });
          });
        }
      }
      chartData['chart' + '_' + 'mean'] = item.mean;
      chartData['chart' + '_' + 'min'] = item.spec_min;
      chartData['chart' + '_' + 'max'] = item.spec_max;
      chartData['chart' + xAxisIndex + 'xAxis'] = 'xAxis_' + xAxisIndex;

      chartData['noOfXAxis'] = xAxisIndex;
      chartData['chartdata'] = array;
      chartData['noOfYAxis'] = yAxisElements;
      chartData['chartType'] = item.chart_type;
      chartData['chartTitle'] = item.title;
      chartDataArray.push(chartData);
    });
    return chartDataArray;
  }

  return (
    <div className='row'>
      {data && (
        <div className='row'>
          {data.map((bg: any, index: number) => (
            <div
              style={{ width: layout === '1 column' ? '90%' : '50%' }}
              className='print-new-page'
            >
              {bg.chartType == 'Linear' && (
                <div id={'graph' + index} className='line-graph p-4'>
                  <label style={graphTitles}>{bg.chartTitle}</label>
                  <ResponsiveContainer width='110%' height={850}>
                    <LineChart
                      data={bg.chartdata}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray='3 3' />
                      <XAxis
                        xAxisId={0}
                        height={120}
                        angle={bg?.chartdata?.[0]?.['xAxis_1']?.length > 12 ? 45 : 90}
                        fontSize={12}
                        tickMargin={50}
                        dataKey={'xAxis_' + 1}
                      />
                      {bg.noOfXAxis > 1 ? (
                        <XAxis
                          xAxisId={1}
                          height={120}
                          angle={bg?.chartdata?.[0]?.['xAxis_2']?.length > 12 ? 45 : 90}
                          fontSize={12}
                          tickMargin={50}
                          dataKey={'xAxis_' + 2}
                        />
                      ) : (
                        <></>
                      )}
                      <YAxis type='number' />
                      {bg.noOfXAxis > 1 ? (
                        <Tooltip content={<CustomToolTip />} cursor={false} />
                      ) : (
                        <Tooltip />
                      )}
                      <Legend layout='horizontal' verticalAlign='bottom' align='left' />
                      <ReferenceLine y={bg.chart_mean} stroke='blue' strokeDasharray='3 3'>
                        <Label position={'insideBottomRight'}>Aim - {bg.chart_mean}</Label>
                      </ReferenceLine>
                      <ReferenceLine y={bg.chart_min} stroke='green' strokeDasharray='3 3'>
                        <Label position={'insideBottomRight'}>Low - {bg.chart_min}</Label>
                      </ReferenceLine>
                      <ReferenceLine y={bg.chart_max} stroke='red' strokeDasharray='3 3'>
                        <Label position={'insideBottomRight'}>High - {bg.chart_max}</Label>
                      </ReferenceLine>
                      {bg.yAxisName_0 ? (
                        <Line type='monotone' dataKey={bg.yAxisName_0} stroke='#836FFF' />
                      ) : (
                        <></>
                      )}
                      {bg.yAxisName_1 ? (
                        <Line type='monotone' dataKey={bg.yAxisName_1} stroke='#FF8911' />
                      ) : (
                        <></>
                      )}
                      {bg.yAxisName_2 ? (
                        <Line type='monotone' dataKey={bg.yAxisName_2} stroke='#8CB9BD' />
                      ) : (
                        <></>
                      )}
                      {bg.yAxisName_3 ? (
                        <Line type='monotone' dataKey={bg.yAxisName_3} stroke='#720455' />
                      ) : (
                        <></>
                      )}
                      {bg.yAxisName_4 ? (
                        <Line type='monotone' dataKey={bg.yAxisName_4} stroke='#720455' />
                      ) : (
                        <></>
                      )}
                      {bg.yAxisName_5 ? (
                        <Line type='monotone' dataKey={bg.yAxisName_5} stroke='#720455' />
                      ) : (
                        <></>
                      )}
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              )}
              {bg.chartType == 'Bar' && (
                <div id={'graph' + index} className='bar-graph p-4'>
                  <div style={graphTitles}>{bg.chartTitle}</div>
                  <ResponsiveContainer width='110%' height={850}>
                    <BarChart data={bg.chartdata}>
                      <CartesianGrid strokeDasharray='3 3' />
                      <XAxis
                        xAxisId={0}
                        height={120}
                        angle={bg?.chartdata?.[0]?.['xAxis_1']?.length > 12 ? 45 : 90}
                        fontSize={12}
                        tickMargin={50}
                        dataKey={'xAxis_' + 1}
                      />
                      {bg.noOfXAxis > 1 ? (
                        <XAxis
                          xAxisId={1}
                          height={120}
                          angle={bg?.chartdata?.[0]?.['xAxis_2']?.length > 12 ? 45 : 90}
                          fontSize={12}
                          tickMargin={50}
                          dataKey={'xAxis_' + 2}
                        />
                      ) : (
                        <></>
                      )}
                      <YAxis type='number' />
                      {bg.noOfXAxis > 1 ? (
                        <Tooltip content={<CustomToolTip />} cursor={false} />
                      ) : (
                        <Tooltip />
                      )}
                      <ReferenceLine y={bg.chart_mean} stroke='blue' strokeDasharray='3 3'>
                        <Label position={'insideBottomRight'}>Aim - {bg.chart_mean}</Label>
                      </ReferenceLine>
                      <ReferenceLine y={bg.chart_min} stroke='green' strokeDasharray='3 3'>
                        <Label position={'insideBottomRight'}>Low - {bg.chart_min}</Label>
                      </ReferenceLine>
                      <ReferenceLine y={bg.chart_max} stroke='red' strokeDasharray='3 3'>
                        <Label position={'insideBottomRight'}>High - {bg.chart_max}</Label>
                      </ReferenceLine>
                      <Legend layout='horizontal' verticalAlign='bottom' align='left' />
                      {bg.yAxisName_0 ? <Bar dataKey={bg.yAxisName_0} fill='#836FFF' /> : <></>}
                      {bg.yAxisName_1 ? <Bar dataKey={bg.yAxisName_1} fill='#FF8911' /> : <></>}
                      {bg.yAxisName_2 ? <Bar dataKey={bg.yAxisName_2} fill='#8CB9BD' /> : <></>}
                      {bg.yAxisName_3 ? <Bar dataKey={bg.yAxisName_3} fill='#720455' /> : <></>}
                      {bg.yAxisName_4 ? <Bar dataKey={bg.yAxisName_4} fill='#720455' /> : <></>}
                      {bg.yAxisName_5 ? <Bar dataKey={bg.yAxisName_5} fill='#720455' /> : <></>}
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
              {bg.chartType == 'Stacked' && (
                <div id={'graph' + index} className='stacked-graph p-4'>
                  <div style={graphTitles}>{bg.chartTitle}</div>
                  <ResponsiveContainer width='110%' height={850}>
                    <BarChart data={bg.chartdata}>
                      <CartesianGrid strokeDasharray='3 3' />
                      <XAxis
                        xAxisId={0}
                        height={120}
                        angle={bg?.chartdata?.[0]?.['xAxis_1']?.length > 12 ? 45 : 90}
                        fontSize={12}
                        tickMargin={50}
                        dataKey={'xAxis_' + 1}
                      />
                      {bg.noOfXAxis > 1 ? (
                        <XAxis
                          xAxisId={1}
                          height={120}
                          angle={bg?.chartdata?.[0]?.['xAxis_2']?.length > 12 ? 45 : 90}
                          fontSize={12}
                          tickMargin={50}
                          dataKey={'xAxis_' + 2}
                        />
                      ) : (
                        <></>
                      )}
                      <YAxis type='number' />
                      {bg.noOfXAxis > 1 ? (
                        <Tooltip content={<CustomToolTip />} cursor={false} />
                      ) : (
                        <Tooltip />
                      )}
                      <ReferenceLine y={bg.chart_mean} stroke='blue' strokeDasharray='3 3'>
                        <Label position={'insideBottomRight'}>Aim - {bg.chart_mean}</Label>
                      </ReferenceLine>
                      <ReferenceLine y={bg.chart_min} stroke='green' strokeDasharray='3 3'>
                        <Label position={'insideBottomRight'}>Low - {bg.chart_min}</Label>
                      </ReferenceLine>
                      <ReferenceLine y={bg.chart_max} stroke='red' strokeDasharray='3 3'>
                        <Label position={'insideBottomRight'}>High - {bg.chart_max}</Label>
                      </ReferenceLine>
                      <Legend layout='horizontal' verticalAlign='bottom' align='left' />
                      {bg.yAxisName_0 ? (
                        <Bar dataKey={bg.yAxisName_0} stackId='a' fill='#836FFF' />
                      ) : (
                        <></>
                      )}
                      {bg.yAxisName_1 ? (
                        <Bar dataKey={bg.yAxisName_1} stackId='a' fill='#FF8911' />
                      ) : (
                        <></>
                      )}
                      {bg.yAxisName_2 ? (
                        <Bar dataKey={bg.yAxisName_2} stackId='a' fill='#8CB9BD' />
                      ) : (
                        <></>
                      )}
                      {bg.yAxisName_3 ? (
                        <Bar dataKey={bg.yAxisName_3} stackId='a' fill='#720455' />
                      ) : (
                        <></>
                      )}
                      {bg.yAxisName_4 ? (
                        <Bar dataKey={bg.yAxisName_4} stackId='a' fill='#720455' />
                      ) : (
                        <></>
                      )}
                      {bg.yAxisName_5 ? (
                        <Bar dataKey={bg.yAxisName_5} stackId='a' fill='#720455' />
                      ) : (
                        <></>
                      )}
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
              {bg.chartType == 'Tabular' && (
                <div id={'graph' + index} className='p-4 tabular-graph'>
                  <div style={{ width: layout === '1 column' ? '750px' : '550px' }}>
                    <label style={graphTitles}>{bg.chartTitle}</label>
                  </div>
                  <table className='table'>
                    <thead>
                      <tr style={fontWeightBold}>
                        <td>Time Period</td>
                        {bg.noOfXAxis > 1 ? <td>Time Period 2</td> : <></>}
                        {bg.yAxisName_0 ? <td>{bg.yAxisName_0}</td> : <></>}
                        {bg.yAxisName_1 ? <td>{bg.yAxisName_1}</td> : <></>}
                        {bg.yAxisName_2 ? <td>{bg.yAxisName_2}</td> : <></>}
                        {bg.yAxisName_3 ? <td>{bg.yAxisName_3}</td> : <></>}
                        {bg.yAxisName_4 ? <td>{bg.yAxisName_4}</td> : <></>}
                        {bg.yAxisName_5 ? <td>{bg.yAxisName_5}</td> : <></>}
                      </tr>
                    </thead>
                    <tbody>
                      {bg?.chartdata?.map((element: any, index: number) => {
                        return (
                          <tr key={index}>
                            <td>{element.xAxis_1}</td>
                            {bg.noOfXAxis > 1 ? <td>{element.xAxis_2}</td> : <></>}
                            {bg.yAxisName_0 ? <td>{element[bg.yAxisName_0]}</td> : <></>}
                            {bg.yAxisName_1 ? <td>{element[bg.yAxisName_1]}</td> : <></>}
                            {bg.yAxisName_2 ? <td>{element[bg.yAxisName_2]}</td> : <></>}
                            {bg.yAxisName_3 ? <td>{element[bg.yAxisName_3]}</td> : <></>}
                            {bg.yAxisName_4 ? <td>{element[bg.yAxisName_4]}</td> : <></>}
                            {bg.yAxisName_5 ? <td>{element[bg.yAxisName_5]}</td> : <></>}
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Graph;

const graphTitles = {
  fontWeight: 500,
  fontSize: '16px',
  lineheight: '24px',
  color: 'var(--primary75)',
};

const fontWeightBold = {
  fontWeight: 700,
};
