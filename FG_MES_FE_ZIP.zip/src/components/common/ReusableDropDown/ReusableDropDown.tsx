import {
  Box,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  SelectChangeEvent,
  Typography,
} from '@mui/material';
import _ from 'lodash';
import { useTranslation } from 'react-i18next';

interface ReusableDropDownProps {
  label: string;
  selectedValueState?: string | number; // If we pass id, it will be populated in dropdown, used in edit flow
  name?: string;
  requiredField?: boolean;
  fieldError?: boolean;
  idAccessKey?: string;
  codeOrValueAccessKey?: string;
  translationPrefixForCode?: string;
  dropDownItemsData: any[];
  handleDropDownOnChange: (event: SelectChangeEvent<string>) => void; // Adjust the type
  fieldDisabled?: boolean; // Use this flag to disable field on certain conditions
  useTranslationWithCode?: boolean;
  viewMode?: boolean;
  enableValueClearing?: boolean;
  customWidth?: string;
}

const ReusableDropDown = ({
  label,
  selectedValueState = '',
  name = 'defaultName',
  requiredField,
  fieldError,
  idAccessKey = 'id',
  codeOrValueAccessKey = 'code',
  translationPrefixForCode = 'defaultPrefix.',
  dropDownItemsData = [],
  handleDropDownOnChange,
  fieldDisabled = false,
  useTranslationWithCode = false,
  viewMode,
  enableValueClearing = false,
  customWidth,
}: ReusableDropDownProps) => {
  const { t } = useTranslation();

  return (
    <Box>
      <InputLabel
        id='fn'
        sx={{
          fontWeight: 600,
          color: '#606466',
          marginBottom: '5px',
          fontSize: '14px',
        }}
      >
        {/* pass translated label - use t() in prop  */}
        {requiredField && !viewMode ? `${t(label, label)}*` : t(label, label)}
      </InputLabel>
      {viewMode ? (
        <Box minWidth={250}>
          <Typography
            variant='body1'
            style={{
              fontFamily: 'Inter, sans-serif',
              fontWeight: 600,
              fontSize: '14px',
              lineHeight: '19.6px',
            }}
          >
            {_.get(
              _.find(dropDownItemsData, { [idAccessKey]: selectedValueState }),
              codeOrValueAccessKey,
              'Not Found'
            )}{' '}
          </Typography>
        </Box>
      ) : (
        <FormControl>
          <Select
            id='demo-simple-select'
            value={selectedValueState?.toString() || ''} // will be id
            name={name}
            error={fieldError}
            displayEmpty
            disabled={fieldDisabled}
            onChange={handleDropDownOnChange}
            inputProps={{ 'aria-label': 'Without label' }}
            sx={{
              height: '40px',
              width: customWidth ?? '250px',
              backgroundColor: fieldDisabled ? '#e3e9ea' : '',
              fontSize: '14px',
            }}
          >
            {/* excludes id 0  */}
            <MenuItem disabled={!enableValueClearing} value={''}>
              <em style={{ fontStyle: 'normal' }}>{t('sharedTexts.select')}</em>
            </MenuItem>
            {dropDownItemsData
              // .filter((reason: any) => reason.id !== 0) // why do need this?? ask loki
              ?.map((eachDropDownItem: any) => (
                <MenuItem key={eachDropDownItem[idAccessKey]} value={eachDropDownItem[idAccessKey]}>
                  {useTranslationWithCode ? (
                    <>
                      {' '}
                      {t(
                        `${translationPrefixForCode}${eachDropDownItem[codeOrValueAccessKey]}`,
                        `${translationPrefixForCode}${eachDropDownItem[codeOrValueAccessKey]}`
                      )}{' '}
                    </>
                  ) : (
                    <>{eachDropDownItem[codeOrValueAccessKey]}</>
                  )}
                </MenuItem>
              ))}
          </Select>
        </FormControl>
      )}
      {/* {fieldError && <p className='error-text'>   test  </p>} */}
    </Box>
  );
};

export default ReusableDropDown;
