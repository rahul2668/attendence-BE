import checkIcon from '../../assets/icons/check-tick.svg';
type Tabs = {
  label: string;
  value: number;
};

interface MainTab {
  editMode?: boolean;
  tabs: Array<Tabs>;
  activeTab: number;
  setActiveTab: (value: number) => void;
  isNextTabAllowed: boolean;
}

const MainTab: React.FC<MainTab> = ({
  editMode,
  tabs,
  activeTab,
  setActiveTab,
  isNextTabAllowed,
}) => {
  return (
    <div className={`${!editMode ? 'tab__header' : ''}`}>
      {tabs?.map((tab: Tabs, index: number) => {
        return (
          <button
            key={tab.value}
            className={`${!editMode ? 'tab__header__item' : ''} ${
              activeTab === tab.value ? 'active' : ''
            }`}
            onClick={() => isNextTabAllowed && setActiveTab(tab.value)}
          >
            {!editMode && (
              <div className='tab__header__status-count'>
                <span className='tab__header__status-count__label-text'>{index + 1}</span>
                <img src={checkIcon} alt='check-icon' className='tab__header__check-icon' />
              </div>
            )}
            {!editMode && (
              <label className='tab__header__label' style={{ cursor: 'pointer' }}>
                {tab.label}
              </label>
            )}
          </button>
        );
      })}
    </div>
  );
};

export default MainTab;
