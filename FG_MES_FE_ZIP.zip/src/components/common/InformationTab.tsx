import React from 'react';
import editIcon from 'assets/icons/edit-thick.svg';
import { useLocation } from 'react-router-dom';
import { validatePermissions } from 'utils/utils';
import { crudType, permissionsMapper } from 'utils/constants';
import { paths } from 'routes/paths';
import PlantFooter from './PlantFooter';
import { useTranslation } from 'react-i18next';

interface IInformationTab {
  isEdit: boolean;
  hasErrors: () => boolean;
  editHandler: () => void;
  handleBackClick: () => void;
  children?: React.ReactElement;
  isEditButtonDisabled?: boolean | null;
}

const InformationTab: React.FC<IInformationTab> = ({
  isEdit,
  children,
  hasErrors,
  editHandler,
  handleBackClick,
  isEditButtonDisabled,
}): React.ReactElement => {
  const { t } = useTranslation();
  const { pathname } = useLocation();
  const module = pathname?.split('/')[1];
  const subModule = pathname?.split('/')[2];

  const hasEditPermission = validatePermissions(
    permissionsMapper[module],
    permissionsMapper[subModule],
    crudType.edit
  );
  const noEditButtonNeededPathNames = [`${paths.binContenets.detailView}`];
  const isEditButtonAllowed = !noEditButtonNeededPathNames.includes(pathname);

  return (
    <div>
      <div className='tab-body px-6 pt-4 pb-16'>
        <div>
          <div className='flex justify-end'>
            {isEditButtonAllowed && !isEdit && (
              <button
                type='button'
                className={`btn btn--h30 py-1 px-4 font-bold ${
                  hasEditPermission && !isEditButtonDisabled ? '' : 'disabled'
                } 
                `}
                onClick={hasEditPermission && editHandler}
              >
                <img src={editIcon} alt='edit' className='mr-3' /> {t('sharedTexts.edit')}
              </button>
            )}
          </div>
          {children}
        </div>
      </div>
      {isEdit && (
        <div className='dashboard__main__footer dashboard__main__footer--type2'>
          <PlantFooter
            disabled={hasErrors()}
            currentTab={subModule == 'active-furnace' || subModule == 'standard-bom' ? 2 : 1}
            onback={handleBackClick}
          />
        </div>
      )}
    </div>
  );
};

export default InformationTab;
