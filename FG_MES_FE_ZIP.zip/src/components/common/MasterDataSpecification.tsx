import { FC, useEffect, useState, useRef } from 'react';
import editIcon from 'assets/icons/edit-thick.svg';
import TableWrapper from 'components/common/TableWrapper';
import { validatePermissions } from 'utils/utils';
import 'assets/styles/scss/components/table-value-of-elements.scss';
import { crudType, permissionsMapper } from 'utils/constants';
import Accordion from './Accordion';
import MasterChangehistoryModal from './MasterChangehistoryModal';
import { isEmpty } from 'lodash';
import { useTranslation } from 'react-i18next';
import MUIToolTip from './ToolTip/MUIToolTip';
import DownloadExcel from './ExcelDownload';
import { ExcelDataList } from 'types/header.model';
import { useAppDispatch } from 'store';
import { getMaterialSpecificationChangeHistory } from 'store/slices/MaterialSlice';
import { useLocation } from 'react-router-dom';

type Props = {
  apiData: any;
  setData: any;
  onSave: (data: any) => void;
  setChangeHistoryData: any;
  changeHistoryData: any;
  changeHistoryInputData: any;
  warningTolerance: boolean;
  sizesChangeHistoryData: any;
  setSizesChangeHistoryData: any;
  excelTitle: string;
  changeHistoryDataList?: ExcelDataList;
  isChangeHistoryExcel?: boolean;
  materialId: string;
};

const MasterDataSpecification: FC<Props> = ({
  apiData,
  setData,
  onSave,
  setChangeHistoryData,
  changeHistoryData,
  changeHistoryInputData,
  warningTolerance,
  sizesChangeHistoryData,
  setSizesChangeHistoryData,
  excelTitle,
  isChangeHistoryExcel = true,
  materialId,
}) => {
  const url = new URL(window.location.href);
  const { pathname } = url;
  const csvLinkRef: any = useRef();
  const dispatch = useAppDispatch();
  const location = useLocation();
  const currentPath = location.pathname;

  const { t } = useTranslation();
  const [initialData, setInitialData] = useState<any>(null);
  const [isEdit, setIsEdit] = useState(window.location.href.split('/')[5] === 'edit');
  const [hasErrors, setHasErrors] = useState<boolean>(false);
  const [showChangeHistoryModal, setShowChangeHistoryModal] = useState<boolean>(false);
  const editScreen = () => setIsEdit(!isEdit);
  const [excelList, setExcelList] = useState([]);

  const onCancel = () => {
    setData(initialData);
    setChangeHistoryData([]);
    editScreen();
    setHasErrors(false);
  };

  useEffect(() => {
    setInitialData(apiData);
  }, []);

  const excelHeader = [
    {
      label: t('masterData.sharedMasterDataTexts.element'),
      key: 'element',
    },
    {
      label: t('masterData.sharedMasterDataTexts.elementGroup'),
      key: 'element_group',
    },
    {
      label: t('masterData.sharedMasterDataTexts.low'),
      key: 'low',
    },
    {
      label: t('masterData.sharedMasterDataTexts.aim'),
      key: 'aim',
    },
    {
      label: t('masterData.sharedMasterDataTexts.high'),
      key: 'high',
    },
  ];

  if (currentPath.includes('by-products') || currentPath.includes('furnace-material-maintenance')) {
    excelHeader.push({
      label: t('masterData.sharedMasterDataTexts.belowTolerance'),
      key: 'below_tolerance',
    });
    excelHeader.push({
      label: t('masterData.sharedMasterDataTexts.aboveTolerance'),
      key: 'above_tolerance',
    });
  }
  if (currentPath.includes('/wip-maintenance')) {
    excelHeader.push({
      label: t('masterData.workInProgress.warningTolerance'),
      key: 'warning_tolerance',
    });
    excelHeader.push({
      label: t('masterData.sharedMasterDataTexts.control'),
      key: 'control',
    });
  }

  excelHeader.push({
    label: t('masterData.sharedMasterDataTexts.modifiedAt'),
    key: 'modified_at',
  });

  console.log(pathname, 'pathname');

  useEffect(() => {
    if (excelList.length > 0) {
      csvLinkRef?.current?.link?.click();
    }
  }, [excelList]);

  const handleExcelClick = async () => {
    const response = await dispatch(getMaterialSpecificationChangeHistory(`${materialId}`));
    const data = response.payload.data?.excel_data;
    setExcelList(data);
  };

  const module = pathname?.split('/')[1];
  const subModule = pathname?.split('/')[2];

  const hasEditPermission = validatePermissions(
    permissionsMapper[module],
    permissionsMapper[subModule],
    crudType.edit
  );

  const setElements = (newData: any, type: string) => {
    const updatedData = apiData.map((item: any) =>
      item.type === type ? { ...item, list: newData } : item
    );

    setData(updatedData);
  };

  let action: any = window.location.href.split('/');
  action = action[action.length - 1].split('?')[0];

  useEffect(() => {
    if (action === 'create' || action === 'edit') {
      setIsEdit(true);
    }
  }, [action]);

  const calculateWarningTolerance = () => {
    const updated: any = apiData.map((obj: any) => {
      const updatedItem = obj?.list?.map((item: any) => {
        const cpk = 1.33;
        if (Number(item.low) === 0) {
          if (Number(item.high) > Number(item.aim)) {
            return {
              ...item,
              warning_tolerance: ((Number(item.high) - Number(item.aim)) / cpk).toFixed(2),
            };
          } else {
            return { ...item, warning_tolerance: 0 };
          }
        } else if (Number(item.high) - Number(item.aim) > Number(item.aim) - Number(item.low)) {
          return {
            ...item,
            warning_tolerance: ((Number(item.aim) - Number(item.low)) / cpk).toFixed(2),
          };
        } else {
          return { ...item, warning_tolerance: 0 };
        }
      });
      return { ...obj, list: updatedItem };
    });

    setData(updated);
  };
  useEffect(() => {
    console.log(materialId, 'id in tabheader');
  }, []);

  return (
    <>
      <div className='mt-3'>
        <div>
          <div style={{ display: 'inline-flex', float: 'right' }}>
            {!isEdit && (
              <div className='flex flex-row'>
                <button
                  className={`btn btn--h30 py-1 px-4 font-bold mr-2 `}
                  style={{ backgroundColor: '#0d659e', color: 'white' }}
                  onClick={() => {
                    setShowChangeHistoryModal(true);
                  }}
                >
                  {t('masterData.sharedMasterDataTexts.specificationChangeHistory')}
                </button>
                <button
                  className={`btn btn--h30 py-1 px-4 font-bold ${
                    hasEditPermission ? '' : 'disabled'
                  }`}
                  onClick={hasEditPermission && editScreen}
                >
                  <img src={editIcon} alt='edit' className='mr-3' /> {t('sharedTexts.edit')}
                </button>
                {isChangeHistoryExcel && (
                  <MUIToolTip text={t(`sharedTexts.downloadExcel`)}>
                    <DownloadExcel
                      csvData={excelList}
                      headersForCSV={excelHeader}
                      excelTitle={'Downtime type'}
                      handleClick={handleExcelClick}
                      csvLinkRef={csvLinkRef}
                    />
                  </MUIToolTip>
                )}
              </div>
            )}
            {warningTolerance && isEdit && (
              <button
                className={`btn btn--h30 py-1 px-4 font-bold mr-2 `}
                style={{ backgroundColor: '#0d659e', color: 'white' }}
                onClick={calculateWarningTolerance}
              >
                {t('masterData.workInProgress.calculateWarningTolerance')}
              </button>
            )}
          </div>
          {apiData?.map(
            (item: any) =>
              !isEmpty(item.list) && (
                <>
                  <h3 className='text-xl font-medium pb-2 pt-0' key={item.title}>
                    {!item.accordion && item.title}
                  </h3>
                  {item.accordion ? (
                    <div className='pb-4'>
                      <Accordion key={item} title={item.title} e_id={'Accordion' + item.title}>
                        <TableWrapper
                          isEdit={isEdit}
                          elements={item.list}
                          setHasErrors={setHasErrors}
                          setElements={setElements}
                          setChangeHistoryData={setChangeHistoryData}
                          changeHistoryData={changeHistoryData}
                          type={item.type}
                          warningTolerance={item.showWarningToleranceOnTable}
                          setSizesChangeHistoryData={setSizesChangeHistoryData}
                          sizesChangeHistoryData={sizesChangeHistoryData}
                        />
                      </Accordion>
                    </div>
                  ) : (
                    <TableWrapper
                      isEdit={isEdit}
                      elements={item.list}
                      setHasErrors={setHasErrors}
                      setElements={setElements}
                      setChangeHistoryData={setChangeHistoryData}
                      changeHistoryData={changeHistoryData}
                      type={item.type}
                      warningTolerance={item.showWarningToleranceOnTable}
                      setSizesChangeHistoryData={setSizesChangeHistoryData}
                      sizesChangeHistoryData={sizesChangeHistoryData}
                    />
                  )}
                </>
              )
          )}
        </div>
      </div>
      {isEdit && (
        <div className='dashboard__main__footer dashboard__main__footer--type2'>
          <div className='dashboard__main__footer__container'>
            <button className='btn btn--h36 px-4 py-2' onClick={onCancel}>
              {t('sharedTexts.cancel')}
            </button>
            <button
              className={`btn btn--primary btn--h36 px-8 py-2 ml-4 ${
                hasErrors ? 'btn--primary disabled' : ''
              }`}
              onClick={onSave}
              disabled={hasErrors}
            >
              {warningTolerance ? t('sharedTexts.saveAndContinue') : t('sharedTexts.save')}
            </button>
          </div>
        </div>
      )}
      <MasterChangehistoryModal
        enableChangeHistoryExtraColumns={warningTolerance}
        title={t('masterData.sharedMasterDataTexts.specificationChangeHistory')}
        showModal={showChangeHistoryModal}
        closeModal={() => {
          setShowChangeHistoryModal(false);
        }}
        changeLogData={changeHistoryInputData}
        excelTitle={excelTitle}
      />
    </>
  );
};

export default MasterDataSpecification;
