import { FC } from 'react';
import closeIcon from '../../../../assets/icons/close-btn.svg';
import { Button } from '@mui/material';
import { useTranslation } from 'react-i18next';

interface ModalAlertProps {
  title: string;
  children: React.ReactNode;
  showModal: boolean;
  closeModal: () => void;
  confirmButtonText: string;
  isShowCloseIcon?: boolean;
  disabled?: boolean;
  primaryButtonClick?: () => void;
  hideButtons?: boolean;
  customWidth?: string;
  customHeight?: string;
  preventOverFlowScroll?: boolean;
}

const ReusableModal: FC<ModalAlertProps> = ({
  title,
  children,
  showModal,
  closeModal,
  confirmButtonText,
  isShowCloseIcon = true,
  hideButtons = false,
  disabled,
  primaryButtonClick,
  customWidth = '80vw',
  customHeight = '',
  preventOverFlowScroll = false,
}) => {
  const { t } = useTranslation();
  return (
    <section className={`modal modal--plant-selection ${showModal ? 'open' : ''}`}>
      <div
        className='modal__container'
        style={{
          width: customWidth,
          ...(customHeight
            ? { height: customHeight, overflowY: preventOverFlowScroll ? 'hidden' : 'scroll' }
            : {}),
        }}
      >
        <div className='modal__header'>
          <div className='flex items-center justify-between'>
            <div style={{ marginLeft: '8px' }}>
              <h3 className='modal__title'>{title}</h3>
            </div>
            {isShowCloseIcon && (
              <button
                type='button'
                style={{ border: '0px solid', backgroundColor: '#f0ffff00' }}
                className='modal__close'
                onClick={closeModal}
                onKeyDown={closeModal}
              >
                <img src={closeIcon} alt='close-icon' />
              </button>
            )}
          </div>
        </div>
        <div className='modal__body p-4 overflow-auto' style={{ minHeight: '55vh' }}>
          {children}
        </div>
        <div className='modal__footer py-3 px-6'>
          {/* change this buttons to reusable */}

          {!hideButtons && (
            <>
              {isShowCloseIcon && (
                <Button
                  onClick={closeModal}
                  variant='outlined'
                  sx={{
                    marginRight: '10px',
                    color: '#0D659E',
                    borderColor: '#0D659E',
                    textTransform: 'none', // Disable automatic capitalization
                    '&:hover': {
                      backgroundColor: '#0D659E',
                      color: '#FFF',
                    },
                  }}
                >
                  {t('sharedTexts.cancel')}
                </Button>
              )}

              <Button
                onClick={primaryButtonClick}
                sx={{
                  backgroundColor: '#0D659E',
                  textTransform: 'none', // Disable automatic capitalization
                  '&:hover': {
                    backgroundColor: '#074A7B',
                  },
                }}
                disabled={disabled}
                variant='contained'
                color='primary'
              >
                {confirmButtonText}
              </Button>
            </>
          )}
        </div>
      </div>
    </section>
  );
};

export default ReusableModal;
