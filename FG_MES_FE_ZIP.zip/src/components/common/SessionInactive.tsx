import AlertModal from 'components/Modal/AlertModal';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { paths } from 'routes/paths';
import { clearSessionStorage, getSessionStorage, setSessionStorage } from 'utils/utils';
const TimeOut = () => {
  const navigate = useNavigate();
  const [showPrompt, setShowPrompt] = useState(false);
  let timeout: ReturnType<typeof setTimeout>;

  const resetTimeout = () => {
    clearTimeout(timeout);
    timeout = setTimeout(
      () => {
        getSessionStorage('accessToken') && setShowPrompt(true); // the prompt is fired only for logged in user
      },
      5 * 60 * 10000
    ); // 5 minutes for prompt
  };

  const logout = async () => {
    sessionStorage.clear();
    clearSessionStorage(['accessToken', 'selectedLanguage']);
    navigate(`${paths.login}`);
  };

  useEffect(() => {
    const resetActivityTime = () => {
      setSessionStorage('lastActivityTime', Date.now().toString());
      resetTimeout(); // this one is for the prompt
    };
    const handleUserActivity = () => {
      resetActivityTime();
    };
    // Event listeners for user activity
    document.addEventListener('mousemove', handleUserActivity);
    document.addEventListener('keydown', handleUserActivity);
    resetActivityTime(); // Initial setup
    return () => {
      document.removeEventListener('mousemove', handleUserActivity);
      document.removeEventListener('keydown', handleUserActivity);
      clearTimeout(timeout);
    };
  });

  useEffect(() => {
    // Check if there's been activity in other tabs
    const checkActivityInTabs = () => {
      const lastActivityTime = getSessionStorage('lastActivityTime');
      const currentTime = Date.now();
      const inactiveDuration = currentTime - parseInt(lastActivityTime || '0');

      if (inactiveDuration > 10 * 60 * 1000) {
        // given 10 mins
        logout();
      }
    };

    // Check for activity in tabs every second
    const interval = setInterval(checkActivityInTabs, 1000);

    return () => clearInterval(interval);
  });

  return (
    <>
      {' '}
      {
        <AlertModal
          showModal={showPrompt}
          closeModal={() => setShowPrompt(false)}
          onConfirmClick={() => {
            setShowPrompt(false);
          }}
          content={'You have been inactive for a while'}
          title='Anyone there?'
          confirmButtonText={"I'm back"}
          isShowCloseIcon={false}
        />
      }
    </>
  );
};

export default TimeOut;
