import { useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';

const CustomSelect = ({
  options,
  onChange,
  index,
  disabled = false,
  searchText = '',
  search = false,
  value = 'select',
  onClick = () => {},
  toShowTooltip = true,
  styles = {},
  loading = false,
  placeholder = null,
}: any) => {
  const { t } = useTranslation();
  const [isOpen, setIsOpen] = useState(false);
  const [mouseOver, setMouseOver] = useState(false);
  const [selectedName, setSelectedName] = useState(placeholder || t('sharedTexts.select'));
  const [showTooltip, setShowTooltip] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredData, setFilteredData] = useState(options);
  const dropdownRef: any = useRef(null);

  const handleToggle = () => {
    if (!disabled) {
      setIsOpen(!isOpen);
      onClick(true);
    }
  };

  const handleOptionClick = (value: any, valueName: any) => {
    if (value == 'Select') {
      onChange('');
    } else {
      onChange(value);
    }
    setSelectedName(valueName);

    setIsOpen(false);
  };

  useEffect(() => {
    setSelectedName(value || placeholder);
  }, [value]);

  const handleSearch = (event: any) => {
    const term = event.target.value;
    setSearchTerm(term);

    const filtered = options.filter((item: any) =>
      item.option.toLowerCase().includes(term.toLowerCase())
    );

    setFilteredData(filtered);
  };

  useEffect(() => {
    function handleClickOutside(event: any) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  useEffect(() => {
    setFilteredData(options);
  }, [options]);

  const backgroundColor = (index: number | boolean, option: string) => {
    if (mouseOver === index) {
      return '#0D659E';
    } else {
      return selectedName == option ? '#EBF4FA' : 'white';
    }
  };

  return (
    <div
      className='custom-select'
      style={{
        height: '40px',
        overflow: 'visible',
      }}
      ref={dropdownRef}
    >
      <button
        type='button'
        // style={{ border: '0px solid', backgroundColor: '#f0ffff00',width: '-webkit-fill-available' }}
        onClick={handleToggle}
        onKeyDown={handleToggle}
        style={{
          height: '40px',
          border: '1px solid #CDCDCD',
          padding: '8.5px 12px 8.5px 12px',
          borderRadius: '4px',
          borderBottomLeftRadius: isOpen ? '0px' : '4px',
          borderBottomRightRadius: isOpen ? '0px' : '4px',
          color:
            selectedName == t('sharedTexts.select') ||
            selectedName == placeholder ||
            selectedName == `${t('sharedTexts.select')} ` ||
            selectedName == placeholder
              ? '#757E85'
              : 'black',
          backgroundColor: disabled ? '#e3e9ea' : 'white',
          width: '-webkit-fill-available',
          textAlign: 'left',
          ...styles,
        }}
        onMouseOver={() => setShowTooltip(index)}
        onMouseOut={() => setShowTooltip('')}
        onFocus={() => setShowTooltip(index)}
        onBlur={() => setShowTooltip('')}
      >
        <div
          style={{
            fontSize: '14px',
            textOverflow: 'ellipsis',
            overflow: 'hidden',
            whiteSpace: 'nowrap',
            display: 'inline-block',
            width: '80%',
            textAlign: 'left',
          }}
        >
          {selectedName}
        </div>
        <div style={{ position: 'relative' }}>
          <svg
            style={{ position: 'absolute', bottom: '8.5px', left: '96%' }}
            xmlns='http://www.w3.org/2000/svg'
            width='16'
            height='16'
            fill='currentColor'
            className='bi bi-chevron-down'
            viewBox='0 0 16 16'
          >
            <path
              fillRule='evenodd'
              d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708'
            />
          </svg>
        </div>
        {showTooltip === index &&
        selectedName != t('sharedTexts.select') &&
        selectedName != placeholder &&
        selectedName?.length > 27
          ? toShowTooltip && (
              <p
                style={{
                  position: 'relative',
                  bottom: '75px',
                  right: '0px',
                  backgroundColor: 'gray',
                  padding: '5px',
                  color: '#fff',
                  fontSize: '14px',
                  borderRadius: '4px',
                  zIndex: '999999',
                  width: 'max-content',
                }}
              >
                {selectedName}
              </p>
            )
          : ''}
      </button>
      {isOpen && !disabled && (
        <ul
          className='options-list'
          style={{
            border: '1px solid #CDCDCD',
            borderBottomLeftRadius: '4px',
            borderBottomRightRadius: '4px',
            borderTop: '0px',
            position: 'relative',
            backgroundColor: '#fff',
            zIndex: '99999',
            maxHeight: '220px',
            overflow: 'auto',
            boxShadow: '4px 16px 24px 0px #7A7A7A40',
          }}
        >
          {search ? (
            <div>
              <div style={{ display: 'flex', alignItems: 'center' }}>
                <svg
                  style={{ margin: '12px' }}
                  xmlns='http://www.w3.org/2000/svg'
                  width='16'
                  height='16'
                  fill='currentColor'
                  className='bi bi-search'
                  viewBox='0 0 16 16'
                >
                  <path d='M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001q.044.06.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1 1 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0' />
                </svg>
                <input
                  placeholder={searchText}
                  value={searchTerm}
                  onChange={handleSearch}
                  style={{ padding: '12px', fontSize: '14px', border: 0 }}
                />
              </div>
              <hr style={{ margin: '0px' }} />
            </div>
          ) : (
            ''
          )}
          {loading ? (
            <div className='d-flex justify-content-center' style={{ margin: '10px' }}>
              <div className='spinner-border text-secondary' role='status'></div>
            </div>
          ) : (
            filteredData.map((option: any, index: any) => (
              <li
                key={option?.option}
                onMouseOver={() => setMouseOver(index)}
                onMouseOut={() => setMouseOver(false)}
                onFocus={() => setMouseOver(index)}
                onBlur={() => setMouseOver(false)}
                onClick={() => {
                  handleOptionClick(option?.value, option?.option);
                  setMouseOver(false);
                }}
                onKeyDown={() => {
                  handleOptionClick(option?.value, selectedName);
                  setMouseOver(false);
                }}
                style={{
                  padding: '8px 12px 8px 12px',
                  fontSize: '14px',
                  backgroundColor: backgroundColor(index, option.option),
                  color:
                    mouseOver === index
                      ? 'white'
                      : option?.option == t('sharedTexts.select') || option?.option == placeholder
                        ? '#797979'
                        : 'black',
                  transform: '2s',
                }}
              >
                {option?.option}
              </li>
            ))
          )}
        </ul>
      )}
    </div>
  );
};

export default CustomSelect;
