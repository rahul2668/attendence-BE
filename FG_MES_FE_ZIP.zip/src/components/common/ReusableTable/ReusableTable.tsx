import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import ActionIcons from '../ActionIcons/ActionIcons';
import { useTranslation } from 'react-i18next';
import DynamicPill from '../DynamicPill/DynamicPill';
import {
  UnfoldMore as SortIcon,
  North as SortUpIcon,
  South as SortDownIcon,
} from '@mui/icons-material';

interface TooltipProps {
  viewIconToolText?: string;
  addIconToolText?: string;
  editIconToolText?: string;
  deleteIconToolText?: string;
  deactivateIconToolText?: string;
  activateIconToolText?: string;
  resetIconToolText?: string;
}

// Each row of main Table
function Row(props: {
  row: any;
  rowActionsPermission: any;
  showActionIconsInRow?: boolean;
  // call backs
  callBackOnViewClick?: any;
  callBackOnAddClick?: any;
  callBackOnDeleteClick?: any;
  callBackOnEditClick?: any;
  callBackOnDeactivationClick?: any;
  callBackOnActivationClick?: any;
  callBackOnResetClick?: any;
  // call backs end
  // tool tip prop
  toolTips?: TooltipProps;
  columnsToDisplayAsPills?: string[];
  onlyViewAndEditDependencyKey?: string;
  columnsToIgnoreInRendering?: string[];
  activeButtonDependencyKey?: string;
  showOnlyAddButtonDependencyKey?: string;
  showOnlyActivateAndAddButtonDependencyKey?: string;
  resetButtonDependencyKey?: string;
}) {
  const {
    row,
    rowActionsPermission = {},
    showActionIconsInRow = false,
    // parent call backs
    callBackOnViewClick,
    callBackOnAddClick,
    callBackOnEditClick,
    callBackOnDeleteClick,
    callBackOnDeactivationClick,
    callBackOnActivationClick,
    callBackOnResetClick,
    // parent call backs end
    toolTips,
    columnsToDisplayAsPills = [],
    onlyViewAndEditDependencyKey = '',
    columnsToIgnoreInRendering = [],
    activeButtonDependencyKey = '',
    showOnlyAddButtonDependencyKey = '',
    showOnlyActivateAndAddButtonDependencyKey = '',
    resetButtonDependencyKey = '',
  } = props;

  /* *** -------------------------------------------------------------------------------------- *** */
  /* *** -------------------------------------------------------------------------------------- *** */
  // HANDLING ACTIONS. DIRECT CALLBACK IS NOT advisable. may cause errors..
  const handleActionClick = (rowData: any, type: string) => {
    if (!rowData)
      return console.error(`falsy value received in  "handleActionClick" , type:${type}`);
    switch (type) {
      case 'view':
        if (callBackOnViewClick) {
          callBackOnViewClick(rowData);
        } else {
          console.error('callback function for view not found..');
        }
        break;
      case 'add':
        if (callBackOnAddClick) {
          callBackOnAddClick(rowData);
        } else {
          console.error('callback function for add not found..');
        }
        break;

      case 'edit':
        if (callBackOnEditClick) {
          callBackOnEditClick(rowData);
        } else {
          console.error('callback function for edit not found..');
        }
        break;

      case 'delete':
        if (callBackOnDeleteClick) {
          callBackOnDeleteClick(rowData);
        } else {
          console.error('callback function for delete not found..');
        }
        break;
      case 'deactivate':
        if (callBackOnDeactivationClick) {
          callBackOnDeactivationClick(rowData);
        } else {
          console.error('callback function for deactivate not found..');
        }
        break;
      case 'activate':
        if (callBackOnActivationClick) {
          callBackOnActivationClick(rowData);
        } else {
          console.error('callback function for activate not found..');
        }
        break;
      case 'reset':
        if (callBackOnResetClick) {
          callBackOnResetClick(rowData);
        } else {
          console.error('callback function for reset not found..');
        }
        break;
      default:
        console.error('exception case in "handleActionClick"');
        break;
    }
  };
  /* *** -------------------------------------------------------------------------------------- *** */
  /* *** -------------------------------------------------------------------------------------- *** */

  const [rowHovered, setRowHovered] = React.useState<boolean>(false);

  return (
    <TableRow
      sx={{ '& > *': { borderBottom: 'unset' } }}
      onMouseEnter={() => setRowHovered(true)}
      onMouseLeave={() => setRowHovered(false)}
    >
      {/* main table cells has to be populated dynamically will depend of the formatting function 
        - careful modifying this */}
      {Object.keys(row).map((columnKey, index, keysArray) => {
        return (
          <>
            {!columnsToIgnoreInRendering?.includes(columnKey) && (
              <>
                <TableCell style={{ borderBottomColor: '#dceefa' }} component='th' scope='row'>
                  {columnsToDisplayAsPills.includes(columnKey) ? (
                    <DynamicPill displayText={`${row[columnKey]}`} />
                  ) : (
                    row[columnKey]
                  )}
                </TableCell>
              </>
            )}

            {index === keysArray.length - (1 + columnsToIgnoreInRendering?.length) && (
              <>
                {showActionIconsInRow && (
                  <TableCell align='center' style={{ borderBottomColor: '#dceefa' }}>
                    <ActionIcons
                      viewClick={() => handleActionClick(row, 'view')}
                      addClick={() => handleActionClick(row, 'add')}
                      editClick={() => handleActionClick(row, 'edit')}
                      deleteClick={() => handleActionClick(row, 'delete')}
                      deactivateClick={() => handleActionClick(row, 'deactivate')}
                      activateClick={() => handleActionClick(row, 'activate')}
                      resetClick={() => handleActionClick(row, 'reset')}
                      permissions={rowActionsPermission}
                      isHovered={rowHovered}
                      viewToolText={toolTips?.viewIconToolText}
                      addToolText={toolTips?.addIconToolText}
                      editToolText={toolTips?.editIconToolText}
                      deleteToolText={toolTips?.deleteIconToolText}
                      deactivateToolText={toolTips?.deactivateIconToolText}
                      activateToolText={toolTips?.activateIconToolText}
                      resetToolText={toolTips?.resetIconToolText}
                      onlyAdd={row[showOnlyAddButtonDependencyKey]}
                      allowOnlyViewAndEdit={row[onlyViewAndEditDependencyKey]} // this overrides everything in action icons
                      allowOnlyActivateAndAdd={row[showOnlyActivateAndAddButtonDependencyKey]}
                      onlyActivate={row[activeButtonDependencyKey]} // this overrides everything in action icons
                      rowNeedsReset={row[resetButtonDependencyKey]}
                    />
                  </TableCell>
                )}
              </>
            )}
          </>
        );
      })}
    </TableRow>
  );
}

// MAIN COMPONENT

export default function ReusableTable({
  mainHeaders,
  renderData,
  showActionIconsInRow = false,
  rowActionsPermission,
  // parent call backs
  callBackOnViewClick,
  callBackOnAddClick,
  callBackOnEditClick,
  callBackOnDeleteClick,
  callBackOnDeactivationClick,
  callBackOnActivationClick,
  callBackOnResetClick,
  // parent call backs end
  toolTips,
  columnsToDisplayAsPills = [],
  onlyViewAndEditDependencyKey = '',
  columnsToIgnoreInRendering = [],
  activeButtonDependencyKey = '',
  showOnlyAddButtonDependencyKey = '',
  showOnlyActivateAndAddButtonDependencyKey = '',
  resetButtonDependencyKey = '',
  sortHandler = () => {},
}: {
  mainHeaders: any;
  renderData: any;
  showActionIconsInRow?: boolean;
  rowActionsPermission?: any; //define a type
  // parent call backs
  callBackOnViewClick?: any;
  callBackOnAddClick?: any;
  callBackOnEditClick?: any;
  callBackOnDeleteClick?: any;
  callBackOnDeactivationClick?: any;
  callBackOnActivationClick?: any;
  callBackOnResetClick?: any;
  // parent call backs end
  // tootTips (for icons) - as props
  toolTips?: TooltipProps;
  columnsToDisplayAsPills?: string[];
  onlyViewAndEditDependencyKey?: string;
  columnsToIgnoreInRendering?: string[];
  activeButtonDependencyKey?: string;
  showOnlyAddButtonDependencyKey?: string;
  showOnlyActivateAndAddButtonDependencyKey?: string;
  resetButtonDependencyKey?: string;
  sortHandler?: (columnName: string, orderBy: 'ASC' | 'DESC') => void;
}) {
  const { t } = useTranslation();
  const [activeSortColumn, setActiveSortColumn] = React.useState<string>('');
  const [sortOrder, setSortOrder] = React.useState<string>('');

  const handleSortClick = (columnName: string) => {
    const compareController = activeSortColumn === columnName ? sortOrder : '';
    const sortOrderToPass: 'ASC' | 'DESC' =
      compareController === '' ? 'ASC' : compareController === 'ASC' ? 'DESC' : 'ASC';
    setSortOrder(sortOrderToPass);
    setActiveSortColumn(columnName);
    sortHandler(columnName, sortOrderToPass);
  };
  return (
    <TableContainer component={Paper}>
      <Table aria-label='collapsible table'>
        <TableHead>
          <TableRow style={{ backgroundColor: '#ebf4fa' }}>
            {/* Rendering Headings ---- */}
            {mainHeaders?.map((heading: any) => (
              <TableCell
                align={heading?.alignment || ''}
                sx={{
                  color: '#04436b',
                  fontWeight: '500',
                  fontSize: '14px',
                }}
                style={{ ...(heading?.width ? { width: heading?.width } : {}) }}
              >
                <div style={{ display: 'flex', alignItems: 'center' }}>
                  {t(heading?.label)}
                  {/* {heading?.label} */}
                  {heading?.enableSort && (
                    <span
                      onClick={() => handleSortClick(heading.sortKey)}
                      className='ml-2'
                      style={{ cursor: 'pointer' }}
                    >
                      {activeSortColumn !== heading.sortKey && (
                        <SortIcon sx={{ color: '#04436b', fontSize: '20px' }} />
                      )}
                      {activeSortColumn === heading.sortKey && (
                        <>
                          {sortOrder === 'ASC' ? (
                            <SortDownIcon sx={{ color: '#04436b', fontSize: '15px' }} />
                          ) : (
                            <SortUpIcon sx={{ color: '#04436b', fontSize: '15px' }} />
                          )}
                        </>
                      )}{' '}
                    </span>
                  )}
                </div>
              </TableCell>
            ))}
            {/* Rendering Headings  ==== */}
          </TableRow>
        </TableHead>

        {/* Main Table Body  ----*/}
        <TableBody>
          {(!renderData || renderData?.length < 1) && (
            <TableRow sx={{ '& > *': { borderBottom: 'unset' } }}>
              {/* first cell should Be the arrow.. always */}
              <TableCell style={{ borderBottomColor: '#dceefa' }} colSpan={mainHeaders?.length}>
                <div style={{ textAlign: 'center' }}>
                  <span> {t('sharedTexts.noResults')}</span>
                </div>
              </TableCell>
            </TableRow>
          )}
          {renderData?.map((row: any) => (
            <Row
              row={row}
              rowActionsPermission={rowActionsPermission}
              showActionIconsInRow={showActionIconsInRow}
              // parent call backs
              callBackOnViewClick={callBackOnViewClick}
              callBackOnAddClick={callBackOnAddClick}
              callBackOnEditClick={callBackOnEditClick}
              callBackOnDeleteClick={callBackOnDeleteClick}
              callBackOnDeactivationClick={callBackOnDeactivationClick}
              callBackOnActivationClick={callBackOnActivationClick}
              callBackOnResetClick={callBackOnResetClick}
              // parent call backs

              // tooltips
              toolTips={toolTips}
              columnsToDisplayAsPills={columnsToDisplayAsPills}
              onlyViewAndEditDependencyKey={onlyViewAndEditDependencyKey}
              columnsToIgnoreInRendering={columnsToIgnoreInRendering}
              activeButtonDependencyKey={activeButtonDependencyKey}
              showOnlyAddButtonDependencyKey={showOnlyAddButtonDependencyKey}
              showOnlyActivateAndAddButtonDependencyKey={showOnlyActivateAndAddButtonDependencyKey}
              resetButtonDependencyKey={resetButtonDependencyKey}
            />
          ))}
        </TableBody>
        {/* Main Table Body  ==== */}
      </Table>
    </TableContainer>
  );
}
