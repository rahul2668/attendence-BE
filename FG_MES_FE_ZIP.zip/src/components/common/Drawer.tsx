import Drawer from '@mui/material/Drawer';
import React from 'react';

interface CustomDrawer {
  children: React.ReactNode;
  open: boolean;
  setOpen: (value: boolean) => void;
}

const CustomDrawer = ({ children, open, setOpen }: CustomDrawer) => {
  return (
    <div>
      <Drawer
        anchor={'right'}
        PaperProps={{
          sx: { width: '500px' },
        }}
        open={open}
        onClose={() => setOpen(false)}
      >
        {children}
      </Drawer>
    </div>
  );
};

export default CustomDrawer;
