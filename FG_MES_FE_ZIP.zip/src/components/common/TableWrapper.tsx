import Toaster from './Toaster/Toaster';
import ElementsTable from './ElementsTable';
import React, { useEffect, useState } from 'react';
import { MaterialElement } from 'types/material.model';
import {
  isEmpty,
  validateElementValues,
  validateLowAimHigh,
  validateSizeElementValues,
  validateSizeLowAimHigh,
} from 'utils/utils';
import SizeSpecifications from './SizeSpecifications';
import { useTranslation } from 'react-i18next';
import { elementNames, usefulCarbonDependencyFields } from 'utils/constants';
import _ from 'lodash';

interface ITableWrapperProps {
  isEdit: boolean;
  elements: Array<any>;
  setHasErrors: (value: boolean) => void;
  setElements: (ele: any, type: string) => void;
  type: string;
  setChangeHistoryData?: any;
  changeHistoryData?: any;
  setSizesChangeHistoryData?: any;
  sizesChangeHistoryData?: any;
  warningTolerance?: boolean;
}

const TableWrapper: React.FC<ITableWrapperProps> = ({
  isEdit,
  elements,
  setElements,
  setHasErrors,
  type,
  setChangeHistoryData,
  changeHistoryData,
  setSizesChangeHistoryData,
  sizesChangeHistoryData,
  warningTolerance,
}): React.ReactElement => {
  const { t } = useTranslation();
  const check = elements.some((item) => Object.hasOwn(item, 'unit'));

  const updatedSize = check ? JSON.parse(JSON.stringify(elements)) : '';
  if (updatedSize.length > 1 && Object.hasOwn(updatedSize[1], 'unit') && check) {
    // Assign the value of the 'unit' property of the second element to the first element
    updatedSize[0].unit = elements[1].unit;
  }

  const firstFifteenElements: any = updatedSize
    ? updatedSize.slice(0, Math.ceil(updatedSize.length / 2))
    : elements?.slice(0, Math.ceil(elements.length / 2));
  const restOfTheElements: any = elements?.slice(Math.ceil(elements.length / 2));
  const [errorMessage, setErrorMessage] = useState('');
  const [elementNameWithError, setElementNameWithError] = useState<string[]>([]);
  const [copyOfElements, setCopyOfElements] = useState<any>('');
  const [copyOfElements1, setCopyOfElements1] = useState<any>('');

  useEffect(() => {
    if (elements) {
      setCopyOfElements(elements);
      setCopyOfElements1(elements);
    }
  }, []);

  // ========= function for calculating carbon based on 'fixed carbon' and 'carbon yield' ======
  const calculateUsefulCarbon = (property: any, valueEntered: any, activeElementName: any) => {
    const fixedCarbon = elements.find(
      (element: any) => element.element === elementNames.fixedCarbon
    );
    const carbonYield = elements.find(
      (element: any) => element.element === elementNames.yieldUsefulCarbon
    );
    if (activeElementName === elementNames.fixedCarbon) {
      return (parseFloat(valueEntered) * parseFloat(carbonYield[property])).toFixed(3).toString();
    }
    if (activeElementName === elementNames.yieldUsefulCarbon) {
      return (parseFloat(fixedCarbon[property]) * parseFloat(valueEntered)).toFixed(3).toString();
    }
  };

  const handleInputChange = (
    elementName: string,
    property:
      | 'low'
      | 'high'
      | 'aim'
      | 'i'
      | 'above_tolerance'
      | 'below_tolerance'
      | 'warning_tolerance'
      | 'control',
    value: number,
    id: number
  ) => {
    const elementIndex = elements.findIndex((element: any) => element.id === id);
    if (elementIndex !== -1) {
      const updatedElements = JSON.parse(JSON.stringify(elements));
      if (!/^\d{1,4}(?:\.\d{1,3})?$/.test(value.toString())) return;
      updatedElements[elementIndex][property] = parseFloat(value.toFixed(3));
      // ---------- useful carbon code -------------
      if (usefulCarbonDependencyFields.includes(elementName)) {
        const carbonIndex = elements.findIndex(
          (element: any) => element.element === elementNames.usefulCarbon
        );
        const activeElementName = elements[elementIndex]?.element;
        updatedElements[carbonIndex][property] = calculateUsefulCarbon(
          property,
          updatedElements[elementIndex][property],
          activeElementName
        );
      }
      // $$ => // handleTrackChangeHistory(elementName, 'low', +e.target.value, element.id); is this needed????
      // ------------  useful carbon code  end ----------
      const elementData = updatedElements[elementIndex];

      const errors = validateLowAimHigh(
        property,
        parseFloat(value.toFixed(3)),
        elementData,
        elementName,
        t,
        type
      );
      const hasError = !isEmpty(errors);
      setErrorMessage(!isEmpty(errors) ? errors : '');

      if (hasError && !elementNameWithError.includes(elementName)) {
        setElementNameWithError([...elementNameWithError, elementName]);
      } else if (!hasError && elementNameWithError.includes(elementName)) {
        setElementNameWithError(elementNameWithError.filter((name) => name !== elementName));
      }

      setElements(updatedElements, type);
      checkForErrors(updatedElements);
    }
  };
  const handleSizeInputChange = (
    elementName: string,
    property:
      | 'low_size'
      | 'high_size'
      | 'aim'
      | 'i'
      | 'above_tolerance'
      | 'below_tolerance'
      | 'warning_tolerance'
      | 'control',
    value: string,
    id: number,
    validateValue: number,
    dropdownList: any
  ) => {
    const elementIndex = elements.findIndex((element: any) => element.id === id);
    if (elementIndex !== -1) {
      const updatedElements = JSON.parse(JSON.stringify(elements));
      updatedElements[elementIndex][property] = value;
      const elementData = updatedElements[elementIndex];

      const errors = validateSizeLowAimHigh(
        property,
        parseFloat(validateValue.toFixed(2)),
        elementData,
        elementName,
        t,
        dropdownList,
        type
      );

      const hasError = !isEmpty(errors);
      setErrorMessage(!isEmpty(errors) ? errors : '');
      if (hasError && !elementNameWithError.includes(elementName)) {
        setElementNameWithError([...elementNameWithError, elementName]);
      } else if (!hasError && elementNameWithError.includes(elementName)) {
        setElementNameWithError(elementNameWithError.filter((name) => name !== elementName));
      }

      setElements(updatedElements, type);

      checkSizeForErrors(updatedElements, dropdownList);
    }
  };

  const checkSizeForErrors = (updatedElements: Array<MaterialElement>, dropdownList: any) => {
    const updatedErrors = validateSizeElementValues(updatedElements, dropdownList);
    setElementNameWithError(updatedErrors);
    setHasErrors(updatedErrors.length > 0);
  };
  const checkForErrors = (updatedElements: Array<MaterialElement>) => {
    const updatedErrors = validateElementValues(updatedElements);
    setElementNameWithError(updatedErrors);
    setHasErrors(updatedErrors.length > 0);
  };

  const handleTrackChangeHistory = (
    elementName: string,
    property: 'low' | 'high' | 'aim' | 'i' | 'warning_tolerance' | 'control',
    new_value: number,
    id: number
  ) => {
    const filtered = copyOfElements.filter((ele: any) => ele.id === id);
    const oldValue = filtered[0];

    const findExistingEntryIndex = (elementName: any) => {
      return changeHistoryData?.findIndex((entry: any) => entry.element === elementName);
    };

    const existingIndex = findExistingEntryIndex(elementName);

    if (existingIndex !== -1) {
      setChangeHistoryData((prevHistory: any) => {
        const updatedHistory = [...prevHistory];
        const existingEntry = updatedHistory[existingIndex];
        existingEntry.old_values = { ...oldValue };
        existingEntry.new_values = {
          ...existingEntry.new_values,
          showColumn: warningTolerance,
          [property]: parseFloat(new_value.toFixed(2)),
        };
        const filteredHistory = updatedHistory.filter((entry) => {
          const oldValues = entry.old_values;
          const newValues = entry.new_values;
          return (
            (newValues.low !== undefined && parseInt(oldValues.low) !== parseInt(newValues.low)) ||
            (newValues.aim !== undefined && parseInt(oldValues.aim) !== parseInt(newValues.aim)) ||
            (newValues.high !== undefined && parseInt(oldValues.high) !== parseInt(newValues.high))
          );
        });

        return filteredHistory;
      });
    } else {
      setChangeHistoryData((prevHistory: any) => [
        ...prevHistory,
        {
          element: elementName,
          old_values: { ...oldValue },
          new_values: {
            showColumn: warningTolerance,
            [property]: parseFloat(new_value.toFixed(2)),
          },
        },
      ]);
    }
  };

  const handleTrackSizesChangeHistory = (
    property:
      | 'low_size'
      | 'high_size'
      | 'aim'
      | 'i'
      | 'above_tolerance'
      | 'below_tolerance'
      | 'unit',
    value: any,
    id: number,
    dropdownList: any
  ) => {
    const filtered =
      property === 'unit' ? copyOfElements1 : copyOfElements.filter((ele: any) => ele.id === id);
    const oldValue = filtered?.map((value: any) => {
      const sizeOldValue = {
        id: value?.id,
        below_tolerance: value?.below_tolerance,
        above_tolerance: value?.above_tolerance,
        low_size: Number(
          dropdownList
            ?.filter((item: any) => item.value == value?.low_size)?.[0]
            ?.option.split(' ')[0]
        ),
        high_size: Number(
          dropdownList
            ?.filter((item: any) => item.value == value?.high_size)?.[0]
            ?.option.split(' ')[0]
        ),
      };
      return sizeOldValue;
    })?.[0];

    const findExistingEntryIndex = () => {
      return sizesChangeHistoryData?.findIndex((entry: any) => entry.verf_column === 'Sizes');
    };
    const existingIndex = findExistingEntryIndex();
    if (existingIndex !== -1) {
      setSizesChangeHistoryData((prevHistory: any) => {
        const updatedHistory = [...prevHistory];
        const existingEntry = updatedHistory[existingIndex];
        existingEntry.old_values = { ...oldValue };
        existingEntry.new_values = {
          ...existingEntry.new_values,
          showColumn: warningTolerance,
          [property]: property === 'unit' ? value : parseFloat(value.toFixed(2)),
        };

        const filteredHistory = updatedHistory.filter((entry) => {
          const oldValues = entry.old_values;
          const newValues = entry.new_values;
          return (
            (newValues.low_size !== undefined && oldValues.low_size !== newValues?.low_size) ||
            (newValues.below_tolerance !== undefined &&
              oldValues.below_tolerance !== newValues?.below_tolerance) ||
            (newValues.high_size !== undefined && oldValues.high_size !== newValues?.high_size) ||
            (newValues.above_tolerance !== undefined &&
              oldValues.above_tolerance !== newValues?.above_tolerance) ||
            (newValues.unit !== undefined && oldValues.unit !== newValues.unit)
          );
        });
        return filteredHistory;
      });
    } else {
      setSizesChangeHistoryData((prevHistory: any) => [
        ...prevHistory,
        {
          verf_column: 'Sizes',
          old_values: { ...oldValue },
          new_values: {
            showColumn: warningTolerance,
            [property]: property === 'unit' ? value : parseFloat(value.toFixed(2)),
          }, // Capture the changed property only
        },
      ]);
    }
    // setUnit(value, type);
  };
  const handleCheckBoxChange = (elementName: string, id: number, value: boolean) => {
    const updated = elements.map((ele) => {
      if (ele.element === elementName) {
        return { ...ele, control: value };
      }
      return ele;
    });
    setElements(updated, type);
    const filtered = copyOfElements.filter((ele: any) => ele.id === id);
    const oldValue = filtered[0];
    const findExistingEntryIndex = (elementName: any) => {
      return changeHistoryData?.findIndex((entry: any) => entry.element === elementName);
    };
    const existingIndex = findExistingEntryIndex(elementName);

    if (existingIndex !== -1) {
      setChangeHistoryData((prevHistory: any) => {
        const updatedHistory = [...prevHistory];
        const existingEntry = updatedHistory[existingIndex];
        existingEntry.old_values = { ...oldValue };
        existingEntry.new_values = {
          ...existingEntry.new_values,
          showColumn: warningTolerance,
          ['control']: value,
        };

        const filteredHistory = updatedHistory.filter((entry) => {
          const oldValues = entry.old_values;
          const newValues = entry.new_values;
          return newValues.control !== undefined && oldValues.control !== newValues.control;
        });
        return filteredHistory;
      });
    } else {
      setChangeHistoryData((prevHistory: any) => [
        ...prevHistory,
        {
          element: elementName,
          old_values: { ...oldValue },
          new_values: { showColumn: warningTolerance, ['control']: value },
        },
      ]);
    }
  };

  useEffect(() => {
    if (!isEmpty(elements)) {
      const initialErrors = elements?.[0].hasOwnProperty('element')
        ? validateElementValues(elements)
        : validateSizeElementValues(elements, []);
      if (initialErrors.length > 0) {
        setElementNameWithError(initialErrors);
      }
    }
  }, [elements]);

  return (
    <>
      {/* <h1>the elements prop data</h1>
      <pre>{JSON.stringify(elements, null, 2)}</pre> */}
      {!isEmpty(errorMessage) && <Toaster text={errorMessage} toastType='error' />}
      <div className='flex -mx-2 mt-3 pb-4' style={{ flexWrap: 'wrap' }}>
        {type === 'Sizes' ? (
          <SizeSpecifications
            elements={firstFifteenElements}
            elementNameWithError={elementNameWithError}
            isEdit={isEdit}
            handleTrackSizesChangeHistory={handleTrackSizesChangeHistory}
            handleSizeInputChange={handleSizeInputChange}
          />
        ) : (
          ''
        )}
        {type != 'Sizes' && !isEmpty(firstFifteenElements) && (
          <ElementsTable
            elements={firstFifteenElements}
            elementNameWithError={elementNameWithError}
            handleInputChange={handleInputChange}
            handleTrackChangeHistory={handleTrackChangeHistory}
            isEdit={isEdit}
            warningTolerance={warningTolerance}
            handleCheckBoxChange={handleCheckBoxChange}
          />
        )}
        {type != 'Sizes' && !isEmpty(restOfTheElements) && (
          <ElementsTable
            elements={restOfTheElements}
            elementNameWithError={elementNameWithError}
            handleInputChange={handleInputChange}
            handleTrackChangeHistory={handleTrackChangeHistory}
            isEdit={isEdit}
            warningTolerance={warningTolerance}
            handleCheckBoxChange={handleCheckBoxChange}
          />
        )}
      </div>
    </>
  );
};

export default TableWrapper;
