import React from 'react';
import { DatePicker, Space } from 'antd';
import dayjs from 'dayjs';
const { RangePicker } = DatePicker;

const dateFormat = 'MM/DD/YYYY';

interface DateProps {
  startdate: any;
  enddate: any;
  handleDates: any;
  disabled: boolean;
}
const App: React.FC<DateProps> = ({ startdate, enddate, handleDates, disabled }) => {
  return (
    <div>
      <Space direction='vertical' size={12} className='w-100'>
        <RangePicker
          className='w-100'
          format='MM/DD/YYYY'
          defaultValue={[dayjs(startdate, dateFormat), dayjs(enddate, dateFormat)]}
          onChange={handleDates}
          disabled={disabled}
          style={disabled ? { backgroundColor: '#E1E9EA' } : {}}
        />
      </Space>
    </div>
  );
};

export default App;
