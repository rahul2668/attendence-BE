import { SelectChangeEvent, useMediaQuery } from '@mui/material';
// import Loader from 'components/Loader';
import Loading from 'components/common/Loading';
import ReusableDropDown from 'components/common/ReusableDropDown/ReusableDropDown';
import ReusableInput from 'components/common/ReusableInput/ReusableInput';
import httpClient from 'http/httpClient';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useAppDispatch, useAppSelector } from 'store';
import {
  setFurnaceBasicInfo,
  setFurnaceBasicInfoErrors,
} from 'store/slices/furnaceConfigurationSlice';
import { FurnaceBasicInfo, FurnaceBasicInfoErrors } from 'types/furnaceConfig.model';
import { crudType } from 'utils/constants';
import { createOptionsByCategory } from 'utils/utils';
import { useGetFurnaceList } from 'hooks/useGetFurnaceList';

const BasicInfoNameSection = () => {
  const { t } = useTranslation();
  const fetchFurnaceList = useGetFurnaceList();
  const [dropDownsData, setDropDownsData] = useState<any>([]);
  const [workshopDropdownData, setWorkshopDropdownData] = useState<any>([]);
  const furnaceBasicInfo = useAppSelector((state) => state.furnaceConfiguration.furnaceBasicInfo);
  const furnaceBasicInfoErrors = useAppSelector(
    (state) => state.furnaceConfiguration.furnaceBasicInfoErrors
  );
  const isSmallScreen = useMediaQuery('(min-width:601px) and (max-width:1300px)');
  const formAction = useAppSelector((state) => state.furnaceConfiguration.formAction);
  const dispatch = useAppDispatch();
  const utilsMasterData = useAppSelector((state) => state.master);
  const plantDataString = useAppSelector((state) => state.plantData.plantData);
  const plantData: any = plantDataString ?? null;
  const local_plant_id: any = plantData.plant_id;

  // furnace no exists check
  const furnaceNoAlreadyExists = (value: string | number) => {
    const check = fetchFurnaceList?.results?.some(
      (furnaceNo: number) => furnaceNo === Number(value)
    );
    return check;
  };

  useEffect(() => {
    if (utilsMasterData) {
      getWorkShopData();
      const dropDownsData = [
        {
          label: 'systemAdmin.furnaceConfiguration.powerDelivery',
          option: createOptionsByCategory(utilsMasterData.results, 'POWERDELIVERY'),
          name: 'power_delivery',
          required: 'true',
        },
        {
          label: 'systemAdmin.furnaceConfiguration.costCenter',
          option: createOptionsByCategory(utilsMasterData.results, 'COSTCENTER'),
          name: 'cost_center',
          required: 'true',
        },
      ];
      setDropDownsData(dropDownsData);
    }
  }, [utilsMasterData, local_plant_id]);

  // need to fetch it separately. not included in master
  const getWorkShopData = async () => {
    const workshopResponse: any = await httpClient.get(
      `/api/plant/plant-config/${local_plant_id}/`
    );
    const workshopResponseList = workshopResponse?.data?.workshops_json
      .map((val: any) => {
        if (val.record_status) {
          const list = {
            value: val.workshop_name,
            id: val.id,
          };
          return list;
        }
      })
      .filter((item: any) => item !== undefined); // Filter out undefined values
    // return workshopResponseList;
    setWorkshopDropdownData(workshopResponseList);
  };

  const handleChangeOfDropDown = (event: SelectChangeEvent) => {
    dispatch(setFurnaceBasicInfo({ ...furnaceBasicInfo, [event.target.name]: event.target.value }));
  };

  const validateInteger = (value: any) => {
    const numberRegex = /^\d{0,4}?$/;
    return numberRegex.test(value);
  };

  const handleChangeOfInputFields = (event: any) => {
    const { value, name, type } = event.target;
    // error handling (only for furnace number) ------
    // if we have multiple field validations, make the 'state setting' code dynamic, define error msgs or language keys in a constant object
    if ((name === 'furnace_no' && validateInteger(value)) || value === '') {
      if (value.length === 0) {
        // Set error if the value length is 0
        dispatch(
          setFurnaceBasicInfoErrors({
            furnace_no: 'systemAdmin.furnaceConfiguration.furnaceNoIsRequired',
            ...furnaceBasicInfoErrors,
          })
        );
      } else if (furnaceNoAlreadyExists(value)) {
        // Set error if the furnace number already exists
        dispatch(
          setFurnaceBasicInfoErrors({
            furnace_no: 'systemAdmin.furnaceConfiguration.furnaceNoAlreadyExists',
            ...furnaceBasicInfoErrors,
          })
        );
      } else {
        // If no error, remove the error key
        const { [name as keyof FurnaceBasicInfoErrors]: furnaceNoErr, ...restOfErrors } =
          furnaceBasicInfoErrors;
        dispatch(
          setFurnaceBasicInfoErrors({
            ...restOfErrors,
          })
        );
      }
      dispatch(
        setFurnaceBasicInfo({
          ...furnaceBasicInfo,
          [name]: type === 'number' ? Number(value) : value,
        })
      );
    }

    if (name === 'furnace_description') {
      if (value.length === 0) {
        dispatch(
          setFurnaceBasicInfoErrors({
            furnace_description: 'systemAdmin.furnaceConfiguration.furnaceDescriptionIsRequired',
            ...furnaceBasicInfoErrors,
          })
        );
      } else {
        const { [name as keyof FurnaceBasicInfoErrors]: furnaceDescriptionErr, ...restOfErrors } =
          furnaceBasicInfoErrors;
        dispatch(
          setFurnaceBasicInfoErrors({
            ...restOfErrors,
          })
        );
      }
      dispatch(
        setFurnaceBasicInfo({
          ...furnaceBasicInfo,
          [name]: type === 'number' ? Number(value) : value,
        })
      );
    }
    // error handling (only for furnace number) end =====
    if (type === 'number' && value == 0) {
      // to fix a bug in number 0 clearing
      dispatch(
        setFurnaceBasicInfo({
          ...furnaceBasicInfo,
          [name]: '',
        })
      );
      return;
    }
  };

  return (
    <div className='section-container'>
      {/* BasicInfoNameSection */}
      <div className='furnace'>
        <ReusableInput
          type='number'
          label={`${t('systemAdmin.furnaceConfiguration.furnaceNo')}*`}
          handleOnChange={handleChangeOfInputFields}
          name='furnace_no'
          valueState={furnaceBasicInfo['furnace_no' as keyof FurnaceBasicInfo]}
          placeholder={`${t('systemAdmin.furnaceConfiguration.enterValue')}`}
          // unit='km/h'
          globalErrorState={furnaceBasicInfoErrors}
          viewMode={formAction === crudType.view}
          fieldDisabled={!(formAction === crudType.create)}
          customWidth='250px'
        />
        <ReusableInput
          type='text'
          label={`${t('systemAdmin.furnaceConfiguration.furnaceDescription')}*`}
          handleOnChange={handleChangeOfInputFields}
          name='furnace_description'
          valueState={furnaceBasicInfo['furnace_description' as keyof FurnaceBasicInfo]}
          customWidth={isSmallScreen ? '527px' : '880px'}
          placeholder={`${t('systemAdmin.furnaceConfiguration.enterValue')}`}
          globalErrorState={furnaceBasicInfoErrors}
          viewMode={formAction === crudType.view}
        />
        {/* new thing end  */}
      </div>

      {/* drop downs  ------ */}
      <div className='select_body mt-4'>
        {workshopDropdownData?.length === 0 || dropDownsData?.length === 0 ? (
          // whole page loader
          <Loading />
        ) : (
          <>
            {workshopDropdownData?.length > 0 && (
              <>
                <ReusableDropDown
                  label={`${t('systemAdmin.furnaceConfiguration.workshop')}*`}
                  name={'workshop'}
                  selectedValueState={furnaceBasicInfo['workshop' as keyof FurnaceBasicInfo]}
                  handleDropDownOnChange={handleChangeOfDropDown}
                  dropDownItemsData={workshopDropdownData}
                  idAccessKey={'id'}
                  codeOrValueAccessKey={'value'}
                  viewMode={formAction === crudType.view}
                />
              </>
            )}
            {dropDownsData?.map((dropDownData: any) => (
              <ReusableDropDown
                label={t(dropDownData.label)}
                name={dropDownData.name}
                selectedValueState={furnaceBasicInfo[dropDownData.name as keyof FurnaceBasicInfo]}
                handleDropDownOnChange={handleChangeOfDropDown}
                dropDownItemsData={dropDownData.option}
                // 'id' was used eariler - changed to master_code
                idAccessKey={'master_code'}
                codeOrValueAccessKey={'value'}
                viewMode={formAction === crudType.view}
                requiredField={dropDownData.required}
              />
            ))}
          </>
        )}

        {/* drop downs  end  ===== */}
      </div>
      {/* new dropdown component*/}
    </div>
  );
};

export default BasicInfoNameSection;
