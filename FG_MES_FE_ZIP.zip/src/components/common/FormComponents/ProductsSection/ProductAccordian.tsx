import { Box, InputLabel } from '@mui/material';
import Accordion from 'components/common/Accordion';
import { useTranslation } from 'react-i18next';
import { useAppDispatch, useAppSelector } from 'store';
import { FurnaceProduct, FurnaceProductItem } from 'types/furnaceConfig.model';
import _ from 'lodash';
import { setFurnaceBasicInfo } from 'store/slices/furnaceConfigurationSlice';
import TrashIcon from '../../../../assets/icons/red-trash.svg';
import ToggleButton from 'components/common/ToggleButton';

interface ProductAccordianProps {
  productData: FurnaceProduct;
  viewMode?: boolean;
}

const ProductAccordian = ({ productData, viewMode }: ProductAccordianProps) => {
  const { t } = useTranslation();
  const furnaceBasicInfo = useAppSelector((state) => state.furnaceConfiguration.furnaceBasicInfo);

  // const [toggleValue, setToggleValue] = useState(false);
  const dispatch = useAppDispatch();

  const handleToggleChange = (
    product_type: string | number,
    material_master: number | undefined
  ) => {
    // Create a new state object by updating only the record_status property
    const globalStateCopy = _.cloneDeep(furnaceBasicInfo); // Cloning the state
    _.forEach(globalStateCopy.furnace_products, (product) => {
      if (product.product_type === product_type) {
        _.forEach(product.products, (item) => {
          if (item.material_master === material_master) {
            item.record_status = !item.record_status; // Toggle the record_status
          }
        });
      }
    });
    // update the state
    dispatch(setFurnaceBasicInfo(globalStateCopy));
  };

  const handleDeleteClick = (
    product_type: string | number,
    material_master: number | undefined
  ) => {
    // Create a new state object by updating only the record_status property
    const globalStateCopy = _.cloneDeep(furnaceBasicInfo); // Cloning the state
    if (globalStateCopy.furnace_products) {
      _.forEach(globalStateCopy.furnace_products, (product) => {
        if (product.product_type === product_type) {
          _.remove(product.products, (item) => {
            return item.material_master === material_master;
          });
          // If products array is empty, remove the entire product type object
          if (product.products.length === 0) {
            _.remove(globalStateCopy.furnace_products as FurnaceProduct[], (prod) => {
              return prod.product_type === product_type;
            });
          }
        }
      });
      // If furnace_products array is empty, remove the key from the main object
      if (globalStateCopy?.furnace_products?.length === 0) {
        delete globalStateCopy.furnace_products;
      }
    }
    // update the state
    dispatch(setFurnaceBasicInfo(globalStateCopy));
  };

  return (
    <Accordion title={`${productData.product_name}`}>
      {productData.products.map((product: FurnaceProductItem) => (
        <>
          {' '}
          <InputLabel
            id='fn'
            sx={{
              fontWeight: 600,
              color: '#606466',
              marginBottom: '5px',
              fontSize: '14px',
            }}
          >
            {/* pass translated label - use t() in prop  */}
            {t('systemAdmin.furnaceConfiguration.productCode')}
          </InputLabel>
          <Box display={'flex'} alignItems='center' gap={2} my={0.5}>
            <Box
              width={300}
              height={44}
              my={1}
              borderRadius={1}
              pl={viewMode ? 0 : 2}
              display={'flex'}
              alignItems='center'
              sx={!viewMode ? { border: '1px solid #CDD0D1', backgroundColor: '#E3E9EA' } : {}}
            >
              <h6 style={{ fontSize: '14px' }}>{product.material_master_value}</h6>
            </Box>
            {!viewMode && (
              <>
                <ToggleButton
                  isChecked={product?.record_status}
                  text={`${product?.record_status ? t('sharedTexts.activated') : t('sharedTexts.deactivated')}`}
                  onChange={() =>
                    // will get check or not as param of this function. not using it
                    handleToggleChange(productData.product_type, product.material_master)
                  }
                />
                {!product?.id && (
                  <button
                    onClick={() =>
                      handleDeleteClick(productData.product_type, product.material_master)
                    }
                    type='button'
                    style={{ border: '0px', backgroundColor: '#fff' }}
                  >
                    <img
                      src={TrashIcon}
                      alt='View'
                      className='icon mr-2'
                      style={{ fill: '#04436B', width: '15px', height: '15px' }}
                    />
                  </button>
                )}
              </>
            )}
          </Box>
        </>
      ))}
    </Accordion>
  );
};

export default ProductAccordian;
