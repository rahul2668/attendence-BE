import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useAppDispatch, useAppSelector } from 'store';
import httpClient from 'http/httpClient';
import LazyDropDown from 'components/common/LazyDropDown/LazyDropDown';
import GetLazyLoadData from 'store/services/lazyLoadService';
import ReusableDropDown from 'components/common/ReusableDropDown/ReusableDropDown';
import AddButtonSquare from 'components/common/AddButtonSquare/AddButtonSquare';
import { FurnaceProduct, FurnaceProductItem } from 'types/furnaceConfig.model';
import ProductAccordian from './ProductAccordian';
import { setFurnaceBasicInfo } from 'store/slices/furnaceConfigurationSlice';
import _ from 'lodash';
import { crudType } from 'utils/constants';
import { notify } from 'utils/utils';

const ProductsSection = () => {
  const { t } = useTranslation();
  // const utilsMasterData = useAppSelector((state) => state.master);
  const dispatch = useAppDispatch();
  const furnaceBasicInfo = useAppSelector((state) => state.furnaceConfiguration.furnaceBasicInfo);
  const [selectedProductType, setSelectedProductType] = useState<string | undefined>(); // local state
  const [selectedProduct, setSelectedProduct] = useState<FurnaceProductItem>(); // local state
  const [productDataList, setProductDataList] = useState<any>([]);
  // const [productFields, setProductFields] = useState<any>([]);
  const formAction = useAppSelector((state) => state.furnaceConfiguration.formAction);

  useEffect(() => {
    const getTypeData = async () => {
      // change these to redux calls???? - taken from old code, need to change
      const productResponse: any = await httpClient.get('/api/furnace-config/product-type/');
      setProductDataList(productResponse.data);
    };

    getTypeData();
  }, []);
  // const [testFormData, setTestFormdata] = useState<any>({}); // any => later it will be global state type

  const handleSelectionOfProduct = (selectedProductCode: any) => {
    const productObject: FurnaceProductItem = {
      material_master: selectedProductCode?.id,
      material_master_value: selectedProductCode?.material_code, // get from products
      record_status: true,
    };
    setSelectedProduct(productObject);
  };

  const handleAddbuttonClick = () => {
    // selectedProduct - need to get product type id
    const productTypeData = findProductTypeByName(productDataList, selectedProductType);

    if (!_.has(furnaceBasicInfo, 'furnace_products')) {
      // checks if this key is there in the main state. if not, the first element is added
      dispatch(
        setFurnaceBasicInfo({
          ...furnaceBasicInfo,
          furnace_products: [{ ...productTypeData, products: [selectedProduct] }],
        })
      );
    }
    if (_.isArray(furnaceBasicInfo.furnace_products)) {
      const foundDataObj = _.find(furnaceBasicInfo.furnace_products, {
        product_type: productTypeData?.product_type,
      });
      if (foundDataObj) {
        const isMaterialMasterExist = foundDataObj?.products?.some(
          (product) => product.material_master === selectedProduct?.material_master
        );
        if (isMaterialMasterExist) {
          notify('info', `Product already added!`); // dont really need this.. we extract product ids in state and pass it to lazy load component to hide already added values
        } else {
          // If material master doesn't exist, add selectedProduct to products array of found product
          const updatedProducts = [...foundDataObj.products, selectedProduct];
          dispatch(
            setFurnaceBasicInfo({
              ...furnaceBasicInfo,
              furnace_products: furnaceBasicInfo.furnace_products.map((product) =>
                product === foundDataObj ? { ...product, products: updatedProducts } : product
              ),
            })
          );
        }
      } else {
        // in edit mode, the key "furnace_products" is there with empty array- this block fires in that case
        dispatch(
          setFurnaceBasicInfo({
            ...furnaceBasicInfo,
            furnace_products: [{ ...productTypeData, products: [selectedProduct] }],
          })
        );
      }
    }
    setSelectedProduct({});
    setSelectedProductType('');
  };

  function findProductTypeByName(items: any[], itemName: string | undefined) {
    const foundItem = items.find((item) => item.name === itemName);
    if (foundItem) {
      return {
        product_type: foundItem.id,
        product_name: foundItem.name,
      };
    } else {
      return null;
    }
  }

  // need to know the format of api response...
  return (
    <div className='section-container'>
      <p className='title mb-4'> {`${t('systemAdmin.plantConfiguration.products')}`}</p>
      {/* <br />
      material selected ---- {JSON.stringify(selectedProductType)}
      <br />
      product selected ---- {JSON.stringify(selectedProduct)} */}

      {!(formAction === crudType.view) && (
        <div className='products__product_container mb-4'>
          <div className='products__container'>
            <ReusableDropDown
              label={`${t('systemAdmin.furnaceConfiguration.productType')}*`}
              name='productType'
              selectedValueState={selectedProductType} // give it like 'globalState.nameOfinput'
              handleDropDownOnChange={(e) => setSelectedProductType(e.target.value)}
              dropDownItemsData={productDataList}
              idAccessKey={'name'}
              codeOrValueAccessKey={'name'}
              // fieldError
            />
          </div>
          <div className='products__container' style={{ width: '45%' }}>
            <LazyDropDown
              valueKey='material_code'
              placeholder={`${t('systemAdmin.furnaceConfiguration.selectProductCode')}`}
              // idsToBeExcluded={productIdsToHide} the ids in ones has to extracted and passed
              apiCall={GetLazyLoadData.getProductCodes}
              disabled={!selectedProductType}
              otherParams={
                selectedProductType
                  ? { product_type: selectedProductType } // selected product type in send with api call
                  : {}
              }
              firstCallDependency={selectedProductType} // this has to be true to make the first api call
              onChange={(selectedProductCode) => {
                handleSelectionOfProduct(selectedProductCode);
                // alert('on change of lazy');
                // console.log('on change of lazy', selectedProductCode);
                // for now just store in local state
              }}
              // resetProductDropDown={resetProductDropDown}
            />
          </div>
          <AddButtonSquare
            onClickHandler={() => handleAddbuttonClick()}
            buttonDisabled={!(selectedProductType && selectedProduct)} // CHANGE #### TO GLOBAL STATE REFERENCE
          />
        </div>
      )}
      {/* <p className='error-text'> products error </p> */}
      {/* the accordian part  ============== */}
      {furnaceBasicInfo['furnace_products']?.map((eachAccordianData: FurnaceProduct) => {
        return (
          <ProductAccordian
            viewMode={formAction === crudType.view}
            productData={eachAccordianData}
          />
        );
      })}
      {/* the accordian part end  ============== */}
    </div>
  );
};

export default ProductsSection;
