import { SelectChangeEvent } from '@mui/material';
import ReusableDropDown from 'components/common/ReusableDropDown/ReusableDropDown';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useAppDispatch, useAppSelector } from 'store';
import { setFurnaceBasicInfo } from 'store/slices/furnaceConfigurationSlice';
import { FurnaceBasicInfo } from 'types/furnaceConfig.model';
import { crudType } from 'utils/constants';

const DefaultRecoveries = () => {
  const { t } = useTranslation();
  const [recoveries, setRecoveries] = useState<any>([]);
  const furnaceBasicInfo = useAppSelector((state) => state.furnaceConfiguration.furnaceBasicInfo);
  const formAction = useAppSelector((state) => state.furnaceConfiguration.formAction);
  const dispatch = useAppDispatch();
  // need to know the format of api response...
  const utilsMasterData = useAppSelector((state) => state.master);
  const createOptionsByCategory = (masterData: any, category: any) => {
    return [...(masterData?.filter((val: any) => val?.category === category) || [])];
  };

  useEffect(() => {
    if (utilsMasterData) {
      const recoveries = [
        {
          label: 'systemAdmin.furnaceConfiguration.slagProductDefaultMaterial',
          option: createOptionsByCategory(utilsMasterData.results, 'SLAG'),
          name: 'slag',
        },
        {
          label: 'systemAdmin.furnaceConfiguration.silicaFumeDefaultMaterial',
          option: createOptionsByCategory(utilsMasterData.results, 'SILICAFUMEDEFAULTMATERIAL'),
          name: 'silica_fume_default_material',
        },
        {
          label: 'systemAdmin.furnaceConfiguration.skullDefaultMaterial',
          option: createOptionsByCategory(utilsMasterData.results, 'SKULL'),
          name: 'skull',
        },
      ];
      setRecoveries(recoveries);
    }
  }, [utilsMasterData]);

  const handleChangeOfDropDown = (event: SelectChangeEvent) => {
    dispatch(
      setFurnaceBasicInfo({
        ...furnaceBasicInfo,
        [event.target.name]: event.target.value, // null or "" as payload will clear the value in database
      })
    );
  };

  return (
    <div className='section-container'>
      <p className='title mb-4'>{t('systemAdmin.furnaceConfiguration.defaultRecoveries')}</p>
      <div style={{ display: 'flex', gap: '1rem' }}>
        {recoveries.map((recoveryData: any) => (
          <ReusableDropDown
            label={t(recoveryData.label)}
            name={recoveryData.name}
            selectedValueState={furnaceBasicInfo[recoveryData.name as keyof FurnaceBasicInfo]}
            handleDropDownOnChange={handleChangeOfDropDown}
            dropDownItemsData={recoveryData.option}
            idAccessKey={'master_code'}
            codeOrValueAccessKey={'value'}
            viewMode={formAction === crudType.view}
            enableValueClearing
          />
        ))}
      </div>
    </div>
  );
};

export default DefaultRecoveries;
