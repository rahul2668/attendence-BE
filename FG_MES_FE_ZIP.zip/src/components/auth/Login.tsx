import { FC, useEffect, useState } from 'react';
import { useAppDispatch, useAppSelector } from 'store';
import { useMsal } from '@azure/msal-react';
import { loginRequest } from 'helpers/ssoAuthConfig';
import { callMsGraph } from 'helpers/ssoGraph';
import AuthModuleBanner from './AuthModuleBanner';
import { ssoLoginCredentials, userLogin, userLoginSSO } from 'store/slices/authSlice';
import '../../assets/styles/scss/components/auth-module.scss';
import { isEmpty, notify, setSessionStorage } from 'utils/utils';
import LoginForm from 'components/common/LoginForm';
import ModalTermsOfUse from 'components/Modal/TermsModel/ModelTerms';
import { AccountInfo } from '@azure/msal-browser';
import { useTranslation } from 'react-i18next';

// import Loading from 'components/common/Loading';
// import { useNavigate } from 'react-router-dom';

interface LoginProps {
  state: {
    user: {
      email: string;
    };
  };
}

const Login: FC<LoginProps> = ({ state }) => {
  const dispatch = useAppDispatch();
  const [error, setError] = useState<any>({});
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState(state ? state.user.email : '');
  const [formErrors, setFormErrors] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [ssoLoading, setSsoLoading] = useState(false);

  const [openTermsModel, setOpenTermsModel] = useState(false);
  const { instance } = useMsal();
  const ssoKeys = useAppSelector((state) => state.login.ssoLoginKeys);
  // const loadingInRedux = useAppSelector((state) => state.login.loading);

  const { t } = useTranslation();
  // const navigate = useNavigate();

  useEffect(() => {
    if (!ssoKeys) {
      dispatch(ssoLoginCredentials());
    }
  }, [dispatch, ssoKeys]);

  const closeTermsModel = () => setOpenTermsModel(false);
  const validateUsername = (value: any) => {
    if (!value) {
      setPassword('');
      return t('authentication.login.userNameRequired');
    }
    return '';
  };

  const validatePassword = (value: any) => {
    if (!value) {
      return t('authentication.login.passwordRequired');
    }
    return '';
  };
  const validateForm = () => {
    const errors: { email: string; password: string } = { email: '', password: '' };
    if (!email.trim()) {
      errors.email = t('authentication.login.userNameRequired');
      setPassword('');
    }
    if (!password.trim()) {
      errors.password = t('authentication.login.passwordRequired');
    }

    setFormErrors(errors);
    return Object.values(errors).every((error) => error === '');
  };

  const inputData = {
    username: email.trim(),
    password: password.trim(),
  };

  function handleSubmit(e: any) {
    e.preventDefault();
    if (validateForm()) {
      userLoginAPI();
    }
  }
  const handleSsoLogin = async () => {
    setSsoLoading(true);
    if (ssoKeys) {
      instance
        .loginPopup(loginRequest)
        .then(async (response) => {
          instance.setActiveAccount(response.account);
          const loggedInAccounts = instance.getAllAccounts();
          await requestProfileData(loggedInAccounts);
        })
        .catch((error) => {
          setSsoLoading(false);
          notify('error', t('authentication.login.ssoFetchAccountError'));
          console.error('loginMsalError', error);
        });
    } else {
      setSsoLoading(false);
      notify('error', t('authentication.login.ssoConfigError'));
    }
  };

  useEffect(() => {}, []);

  const requestProfileData = async (loggedInAccounts: AccountInfo[]) => {
    instance
      .acquireTokenSilent({
        ...loginRequest,
        account: loggedInAccounts[0],
      })
      .then(async (response) => {
        if (response && response.accessToken) {
          await callMsGraph(response.accessToken)
            .then(async (response) => {
              if (response?.mail) {
                await userSsoLoginAPI(response.mail);
              } else {
                setSsoLoading(false);
                notify('error', t('authentication.login.ssoFetchEmailError'));
              }
            })
            .catch((error) => {
              setSsoLoading(false);
              notify('error', t('authentication.login.ssoFetchAccountDataError'));
              console.error('MicrosoftGraph_API_Error', error);
            });
        } else {
          setSsoLoading(false);
          notify('error', t('authentication.login.ssoAccessTokenError'));
        }
      })
      .catch((error) => {
        setSsoLoading(false);
        notify('error', t('authentication.login.ssoFailedError'));
        console.error('loginRequestProfileDataError', error);
      });
  };

  const handleOpenTermsModel = () => {
    setOpenTermsModel(true);
  };
  const userSsoLoginAPI = async (email: string) => {
    const data = await dispatch(userLoginSSO({ email }));
    handleLoginResponse(data);
  };

  const userLoginAPI = async () => {
    setLoading(true);
    const data = await dispatch(userLogin(inputData));
    handleLoginResponse(data);
  };

  const handleLoginResponse = (data: any) => {
    if (data?.payload.status === 200 && data.payload.data?.access_token) {
      setError({
        toastType: 'success',
        text: t(data.payload.data.message),
      });
      onContinue(data);
      setPassword('');
      setSsoLoading(false);
    } else if (data?.payload.status === 200 && !data.payload.data?.access_token) {
      setLoading(false);
      setSsoLoading(false);
      notify('error', t(data.payload.data.message));
    } else {
      setLoading(false);
      setSsoLoading(false);
      setError({
        toastType: 'error',
        text: t(data.payload.data.message),
      });
    }
  };

  const onContinue = (response: any) => {
    notify('success', t(response.payload.data.message));
    setSessionStorage('accessToken', response.payload.data?.access_token);
    setLoading(false);
    setSsoLoading(false);
    location.reload();
    // navigate('/dashboard')
  };

  useEffect(() => {
    !isEmpty(error) &&
      setTimeout(() => {
        setError({});
      }, 3000);
  }, [error]);

  const handleUsernameChange = (value: any) => {
    const isValid = /^\S(?:.*\S)?$/.test(value) || value === '';
    if (isValid) {
      setEmail(value);
      setFormErrors({ ...formErrors, email: validateUsername(value) });
    }
  };

  const handlePasswordChange = (value: any) => {
    const isValid = /^\S(?:.*\S)?$/.test(value) || value === '';
    if (isValid) {
      setPassword(value);
      setFormErrors({ ...formErrors, password: validatePassword(value) });
    }
  };

  // if(loadingInRedux) return <Loading />

  return (
    <>
      <section className='auth-module-wrapper auth-module--login'>
        <div className='auth-module__container'>
          <AuthModuleBanner />
          <div className='auth-module__main'>
            <LoginForm
              handleSubmit={handleSubmit}
              email={email}
              handleUsernameChange={handleUsernameChange}
              formErrors={formErrors}
              handlePasswordChange={handlePasswordChange}
              password={password}
              showPassword={showPassword}
              setShowPassword={setShowPassword}
              loading={loading}
              handleSsoLogin={handleSsoLogin}
              ssoLoading={ssoLoading}
            />
            <div className='terms-policy_container'>
              <p
                onClick={handleOpenTermsModel}
                onKeyDown={(e) => e.key === 'Enter' && handleOpenTermsModel()}
              >
                {t('authentication.login.termsOfUse')}
              </p>
              <p>
                <a href='https://www.ferroglobe.com/privacy-policy' target='blank'>
                  {t('authentication.login.privacyPolicy')}
                </a>
              </p>
            </div>
          </div>
        </div>
      </section>
      {/* <ModalPlantSelection showModal={openModel} closeModel={closeModel} onContinue={onContinue} /> */}
      <ModalTermsOfUse showModal={openTermsModel} closeModel={closeTermsModel} />
    </>
  );
};

export default Login;
