import { FC } from 'react';
import banner from '../../assets/img/auth-module-banner.png';
import logo from '../../assets/img/blue_FG_logo.png';
import { Trans } from 'react-i18next';

const AuthModuleBanner: FC = () => {
  return (
    <div className='auth-module__banner-section'>
      <div className='text-center'>
        <img src={logo} alt='logo' style={{ height: '80%', width: ' 50%' }} />
      </div>
      <div className='content-container'>
        <div className='mt-8'>
          <img
            src={banner}
            alt='auth-module-banner'
            className='auth-module__banner'
            style={{ width: 450, height: 315 }}
          />
        </div>
      </div>
      <div className='Manufacturing'>
        <p>
          <Trans i18nKey={'authentication.login.MES'}>
            <b>M</b>
            <b>E</b>
            <b>S</b>
          </Trans>
        </p>
      </div>
    </div>
  );
};

export default AuthModuleBanner;
