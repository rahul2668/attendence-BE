import { FC, useEffect, useState } from 'react';
import arrowDown from '../../assets/icons/chevron-down.svg';
import httpClient from 'http/httpClient';
import { isEmpty } from 'utils/utils';
import { useTranslation } from 'react-i18next';

interface ModalProps {
  showModal: boolean;
  closeModel: () => void;
  // selectedRole: number;
  setSelectedRole: any;
  setConfirmClone: any;
}
interface CloneType {
  id: number;
  role_name: string;
}
const ModalClone: FC<ModalProps> = ({
  showModal,
  closeModel,
  setSelectedRole,
  setConfirmClone,
}) => {
  const { t } = useTranslation();
  const [dropdownValue, setDropdownValue] = useState<CloneType | null>(null);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [roles, setRoles] = useState<any>([]);

  const getRoles = () => {
    const url = `/api/account/roles/`;
    httpClient
      .get(url)
      .then((response: any) => {
        if (response.data) {
          const roleData: any = [...response.data.results]?.map((role: any) => ({
            ...role,
            showModal: false,
          }));
          setRoles(roleData);
        }
      })
      .catch((err) => {
        console.log('errored -->', err);
      });
  };

  useEffect(() => {
    getRoles();
  }, []);

  const confirmClone = () => {
    setSelectedRole(dropdownValue?.id);
    setConfirmClone(true);
    closeModel();
  };

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  const selectPlant = (role: any) => {
    setDropdownValue(role);
    setIsDropdownOpen(false);
  };

  const handleClose = () => {
    setDropdownValue(null);
    closeModel();
  };

  return (
    <section className={`modal modal--plant-selection ${showModal ? 'open' : ''}`}>
      <div className='modal__container'>
        <div className='modal__header'>
          <div className='flex items-center justify-between'>
            <div className='flex-1 pr-8'>
              <h3 style={{ fontSize: '16px' }} className='modal__title text-xl'>
                {t('systemAdmin.furnaceConfiguration.cloneRole')}
              </h3>
            </div>
          </div>
        </div>
        <div className='modal__body p-4 overflow-auto'>
          {/* <p className='color-tertiary-text'>Copy data from another role and modify it</p> */}
          <div className='mt-6'>
            <label className='input-field-label font-semibold'>
              {t('userAccessControl.users.selectRole')}
            </label>
            <div className='custom-select-wrapper'>
              <div
                className='custom-select-container custom-select-container--md custom-select-container--h36 satoshi-bold text-sm'
                onClick={toggleDropdown}
                onKeyDown={toggleDropdown}
              >
                {dropdownValue ? dropdownValue?.role_name : t('userAccessControl.users.selectRole')}
                <img src={arrowDown} alt='arrow-down' className='custom-select__arrow-down' />
              </div>
              <ul
                className={`select-dropdown-menu ${isDropdownOpen ? 'open' : ''}`}
                style={{ overflow: 'auto', maxHeight: '160px' }}
              >
                {roles.map((role: any) => (
                  <li
                    className='select-dropdown-menu__list'
                    key={role.id}
                    onClick={() => selectPlant(role)}
                    onKeyDown={() => selectPlant(role)}
                  >
                    {role.role_name}
                  </li>
                ))}
                {/* <li className="select-dropdown-menu__list">results 1</li>
                <li className="select-dropdown-menu__list">results 2</li>
                <li className="select-dropdown-menu__list">results 3</li> */}
              </ul>
            </div>
          </div>
          <div
            style={{ marginLeft: '10px' }}
            className={`flex items-center justify-end pt-6 pb-2 px-4 ${
              isDropdownOpen ? 'mt-170' : ''
            }`}
          >
            <button className='btn btn--sm btn--h36' onClick={handleClose}>
              {t('sharedTexts.cancel')}
            </button>
            <button
              onClick={confirmClone}
              // className="btn btn--primary btn--sm btn--h36 ml-4"
              className={`btn btn--primary btn--sm btn--h36 ml-4 ${
                isEmpty(dropdownValue) && 'disabled'
              }`}
            >
              {t('sharedTexts.save')}
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
export default ModalClone;
