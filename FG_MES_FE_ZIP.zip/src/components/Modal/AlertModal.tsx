import { FC } from 'react';
import closeIcon from '../../assets/icons/close-btn.svg';
import { useTranslation } from 'react-i18next';

interface ModalAlertProps {
  title: string;
  content: string;
  showModal: boolean;
  closeModal: () => void;
  confirmButtonText: string;
  onConfirmClick: () => void;
  isShowCloseIcon?: boolean;
}

const AlertModal: FC<ModalAlertProps> = ({
  title,
  content,
  showModal,
  closeModal,
  onConfirmClick,
  confirmButtonText,
  isShowCloseIcon = true,
}) => {
  const { t } = useTranslation();
  return (
    <section className={`modal modal--plant-selection ${showModal ? 'open' : ''}`}>
      <div className='modal__container'>
        <div className='modal__header'>
          <div className='flex items-center justify-between'>
            <div className='flex-1 pr-8'>
              <h3 className='modal__title'>{title}</h3>
            </div>
            {isShowCloseIcon && (
              <div
                className='modal__close'
                onClick={closeModal}
                onKeyDown={closeModal}
                role='button'
              >
                <img src={closeIcon} alt='close-icon' />
              </div>
            )}
          </div>
        </div>
        <div className='modal__body p-4 overflow-auto'>
          <p className='color-secondary-text mt-1'>{content}</p>
        </div>
        <div className='modal__footer py-3 px-6'>
          {isShowCloseIcon && (
            <button className='btn btn--sm btn--h36' onClick={closeModal}>
              {t('sharedTexts.cancel')}
            </button>
          )}
          <button className='btn btn--primary btn--sm btn--h36' onClick={onConfirmClick}>
            {confirmButtonText}
          </button>
        </div>
      </div>
    </section>
  );
};

export default AlertModal;
