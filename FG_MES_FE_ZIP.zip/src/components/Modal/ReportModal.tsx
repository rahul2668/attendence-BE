import { useEffect, useState } from 'react';
import closeIcon from '../../assets/icons/close-btn.svg';
import { useTranslation } from 'react-i18next';

interface VariantModalProps {
  title: string;
  content: string;
  showModal: boolean;
  closeModal: () => void;
  confirmButtonText: string;
  onConfirmClick: () => void;
  isShowCloseIcon?: boolean;
  variantName: any;
  variantValue: any;
  variantSaveReport: any;
  handleprivatevariant: any;
  privatevariantValue: any;
  updateVariantflag: any;
}

const VariantModal: React.FC<VariantModalProps> = ({
  content,
  closeModal,
  variantSaveReport,
  confirmButtonText,
  variantValue,
  variantName,
  updateVariantflag,
  privatevariantValue,
  handleprivatevariant,
  isShowCloseIcon = true,
}) => {
  const { t } = useTranslation();
  const [variantNameInput, setVariantname] = useState();
  const [privateVariant, setPrivatevariant] = useState(false);

  const handleVariantName = (event: any) => {
    console.log(variantNameInput);
    setVariantname(event.target.value);
    variantName(event.target.value);
  };
  const handlePrivateVariant = () => {
    setPrivatevariant(!privateVariant);
    handleprivatevariant(!privateVariant);
  };
  const variantSaveApi = () => {
    variantSaveReport('save');
  };
  const variantclone = () => {
    variantSaveReport('clone');
  };
  const variantUpdate = () => {
    variantSaveReport('update');
  };

  useEffect(() => {
    setPrivatevariant(privatevariantValue);
  }, [privatevariantValue]);

  return (
    <section className={`modal modal--plant-selection ${true ? 'open' : ''}`}>
      <div className='modal__container'>
        <div className='modal__header'>
          <div className='flex items-center justify-between'>
            <div className='flex-1 pr-8'>
              <h3 className=' fw-bold'>{content}</h3>
            </div>
            {isShowCloseIcon && (
              <div className='modal__close' onClick={closeModal}>
                <img src={closeIcon} alt='close-icon' />
              </div>
            )}
          </div>
        </div>
        <div className='modal__body p-4 overflow-auto'>
          <p className='modal__title mb-2 '>{t('reports.enterVariantName')}</p>
          <div style={{ display: 'flex' }}>
            <input
              className='form-control form-control-sm'
              type='text'
              placeholder={t('reports.enterName')}
              value={variantValue}
              onChange={handleVariantName}
            />
            <input
              className='form-check-input ms-2 me-1'
              type='checkbox'
              checked={privateVariant}
              id='defaultCheck1'
              style={{ width: '5%', height: '20px' }}
              onClick={handlePrivateVariant}
            />
            {t('reports.private')}
          </div>
        </div>
        <div className='modal__footer py-3 px-6'>
          {isShowCloseIcon && (
            <button className='btn btn--sm btn--h36' onClick={closeModal}>
              {t('sharedTexts.cancel')}
            </button>
          )}
          {updateVariantflag == false && (
            <button className='btn btn--primary btn--sm btn--h36' onClick={variantSaveApi}>
              {confirmButtonText}
            </button>
          )}
          {updateVariantflag == true && (
            <button className='btn btn--primary btn--sm btn--h36' onClick={variantUpdate}>
              {confirmButtonText}
            </button>
          )}
          {updateVariantflag == 'clone' && (
            <button className='btn btn--primary btn--sm btn--h36' onClick={variantclone}>
              {confirmButtonText}
            </button>
          )}
        </div>
      </div>
    </section>
  );
};
export default VariantModal;
