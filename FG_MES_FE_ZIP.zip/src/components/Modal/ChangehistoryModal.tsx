import closeIcon from '../../assets/icons/close-btn.svg';
import downloadIcon from 'assets/icons/download.svg';
import Accordion from 'components/common/Accordion';
import moment from 'moment';
import { useEffect, useState } from 'react';
import { CSVLink } from 'react-csv';
import { useTranslation } from 'react-i18next';
import { useAppSelector } from 'store';
import { UtilsMasterData } from 'types/plant.model';
import { formatDateHelper } from 'utils/utils';

interface ChangehistoryModalBlockProps {
  showModal: boolean;
  closeModal: () => void;
  title: string;
  changeLogData: any;
  excelTitle: string;
}

const ChangehistoryModal: React.FC<ChangehistoryModalBlockProps> = ({
  showModal,
  closeModal,
  title,
  changeLogData,
  excelTitle,
}) => {
  const { t } = useTranslation();

  const utilsMasterData = useAppSelector((state) => state.master);
  const utilsMasterList: Array<UtilsMasterData> = utilsMasterData?.results;
  const plantDataString = useAppSelector((state) => state.plantData.plantData);
  const plantData: any = plantDataString ?? null;
  const plant_time_zone_id: any = plantData.plant_time_zone_id;
  const timeZone = utilsMasterList?.filter((item: any) => item.id == plant_time_zone_id)?.[0]
    ?.description;

  const [csvData, setCsvData] = useState<any>([]);
  const controlParamGetclassName = (item: any, obj: any) => {
    console.log(item, obj);
    if (item?.deleted) {
      return 'p-1 text-center';
    }
    if (item?.old_value !== item?.new_value && !obj?.step_deleted) {
      return 'p-1 text-center red';
    }
    if (obj?.step_deleted) {
      return 'p-1 text-center';
    }
    if (item?.newly_added) {
      return 'p-1 text-center red';
    }

    return 'p-1 text-center';
  };

  const additiveGetclassName = (item: any, obj: any) => {
    if (item?.newly_added) {
      return 'p-1 text-center red';
    } else if (obj?.newly_added_step) {
      return 'p-1 text-center red';
    } else if (item?.is_deleted) {
      return 'p-1 text-center';
    } else if (item?.edited) {
      return 'p-1 text-center red';
    } else {
      return 'p-1 text-center';
    }
  };

  const getNewStatusClassname = (item: any, obj: any) => {
    if (item?.deleted) {
      return 'p-1 text-center';
    } else if (item?.old_status !== item?.new_status && !obj?.step_deleted) {
      return 'p-1 text-center red';
    } else {
      return 'p-1 text-center';
    }
  };
  useEffect(() => {
    if (changeLogData) {
      setCsvData(structureCsvData());
    }
  }, [changeLogData]);

  const structureCsvData = () => {
    const masterArray: any = [];
    changeLogData?.forEach((data: any) => {
      // Push header row

      data.steps.forEach((obj: any, stepIndex: number) => {
        // Push data rows
        obj.control_parameters.forEach((param: any) => {
          const rowData = {
            A: stepIndex === 0 ? data.username : null,
            B:
              stepIndex === 0
                ? moment(data?.created_at).format('DD-MMM-YYYY') +
                  ' ' +
                  moment(data?.created_at, 'HH:mm:ss').format('hh:mm:ss')
                : null,
            C: stepIndex === 0 ? obj.process_name : null,
            D: 'controlParameter', // Add FieldType for controlParameter
            E: param.name,
            F: param.old_value,
            G: param.old_status,
            H: param.new_value,
            I: param.new_status,
          };
          masterArray.push(rowData);
        });

        obj.additives.forEach((additive: any) => {
          const tmepData = {
            A: stepIndex === 0 && obj.control_parameters.length === 0 ? data.username : null,
            B:
              stepIndex === 0 && obj.control_parameters.length === 0
                ? moment(data?.created_at).format('DD-MMM-YYYY') +
                  ' ' +
                  moment(data?.created_at, 'HH:mm:ss').format('hh:mm:ss')
                : null,
            D: 'Additives',
            E: additive.name,
            F: additive.old_value,
            G: 'N/A',
            H: additive.new_value,
            I: 'N/A',
          };
          masterArray.push(tmepData);
        });
      });
    });

    return masterArray;
  };

  // the alphabet keys are mapped to a column header
  const headersForCSV = [
    { label: 'User Name', key: 'A' },
    { label: 'Date ', key: 'B' },
    { label: 'Process Name', key: 'C' },
    { label: 'Field Type', key: 'D' },
    { label: 'Name', key: 'E' },
    { label: 'Old Value', key: 'F' },
    { label: 'Old Status', key: 'G' },
    { label: 'New value', key: 'H' },
    { label: 'New Status', key: 'I' },
  ];

  const getTranslateKey: any = (translateKeyParam: string) => {
    return `systemAdmin.furnaceConfiguration.${translateKeyParam}`;
  };

  return (
    <section className={`modal modal--plant-selection ${showModal ? 'open' : ''}`}>
      <div className='modal__customcontainer'>
        <div className='modal__header'>
          <div className='flex items-center justify-between'>
            <div className='flex-1 pr-8'>
              <h3 className='modal__title'>{title}</h3>
            </div>
            <div className='modal__close' onClick={closeModal} onKeyDown={closeModal}>
              <img src={closeIcon} alt='close-icon' />
            </div>
          </div>
        </div>
        {changeLogData.length > 0 && (
          <CSVLink
            className='download-icon'
            data={csvData}
            headers={headersForCSV}
            filename={`${excelTitle}ChangeHistoryReport`}
          >
            <img src={downloadIcon} alt='Download' />
          </CSVLink>
        )}
        <div className='modal__body pt-1 px-4 overflow-auto'>
          {changeLogData?.map((item: any, index: any) => (
            <div style={{ marginBottom: '20px' }} key={item}>
              <Accordion
                e_id={'Changelog' + index}
                title={formatDateHelper(item?.created_at, timeZone) + ' | ' + item?.username}
              >
                <div style={{ overflow: 'hidden', borderRadius: '2px' }}>
                  <table className='changehistory-view-table'>
                    <tbody>
                      <tr>
                        <th style={{ borderRadius: '10px' }}></th>
                        <th colSpan={2} className='p-1 text-center'>
                          {t('sharedTexts.old')}
                        </th>
                        <th colSpan={2} className='p-1 text-center'>
                          {t('sharedTexts.new')}
                        </th>
                      </tr>
                      {item.steps.map((obj: any) => (
                        <>
                          <tr className='bg-row'>
                            <th className='py-1 pl-2' colSpan={5}>
                              {t(getTranslateKey(obj.process_name))}
                            </th>
                          </tr>
                          {obj.control_parameters.map((cp: any) => (
                            <tr key={cp}>
                              <td className='py-1 pl-2 sub-head'>{cp.name}</td>
                              <td className='p-1 text-center'>{cp.old_value || '-'}</td>
                              <td className={`p-1 text-center`}>{cp.old_status || '-'}</td>
                              <td className={controlParamGetclassName(cp, obj)}>
                                {cp.new_value || '-'}
                              </td>
                              <td className={getNewStatusClassname(cp, obj)}>
                                {cp.new_status || '-'}
                              </td>
                            </tr>
                          ))}
                          {obj.additives.map((ad: any) => (
                            <tr key={ad}>
                              <td className='py-1 pl-2 sub-head'>{ad.name || ad.field}</td>
                              <td className='p-1 text-center'>{ad.old_value || '-'}</td>
                              <td
                                className={
                                  !ad.old_status ? `p-1 text-center grayed` : `p-1 text-center`
                                }
                              >
                                {ad.old_status}
                              </td>
                              <td className={additiveGetclassName(ad, obj)}>
                                {ad.new_value || '-'}
                              </td>
                              <td
                                className={
                                  !ad.new_status ? `p-1 text-center grayed` : `p-1 text-center`
                                }
                              >
                                {ad.new_status}
                              </td>
                            </tr>
                          ))}
                        </>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Accordion>
            </div>
          ))}
          {changeLogData.length < 1 && <p className='text-center'>No change history</p>}
        </div>
      </div>
    </section>
  );
};

export default ChangehistoryModal;
