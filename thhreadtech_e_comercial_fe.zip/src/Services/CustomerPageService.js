import { Api } from "../Interceptor/Interceptor";
// import BASE_URL from "../components/config";

// const requestOTPService = (phone) => {
//    return Api.post(`/login/one-time-password?phoneNumber=${phone}`);

//   };

// const validateOTPService = (phone, otp) => {
//   return Api.get(`/login/auth?phoneNumber=${phone}&otp=${otp}`);
// };
// const roleListService = () => {
//   return Api.get("api/role_list/");
// };

// const CustomerPageRequestService = (searchData) => {
//   return Api.post(`api/customer_search/`);
// };
// const CustomerPageServices = {
//   // requestOTPService,
//   //   validateOTPService,
//   //   roleListService,
//   CustomerPageRequestService,
// };
// export default CustomerPageServices;
export const getAllCustomerListOnSearch = (search) => {
  return Api.get("api/customer", {
    params: {
      searchTerm: search,
    },
  });
};

export const getAllCustomerList = (currentPage, itemsPerPage) => {
  return Api.get("/api/customer_list/", {
    params: {
      pageNumber: currentPage,
      size: itemsPerPage,
    },
  });
};

export const ParticularOrderRequestService = (orderData) => {
  return Api.post(`api/particulars_order/`, {
    particular_details: orderData.particular_details,
    order_details: orderData.order_details,
    total_amount: orderData.total_amount,
    customer_name: orderData.customer_name,
    customer_id: orderData.customer_id,
    user_id: orderData.user_id,
    order_date: orderData.order_date,
  });
};