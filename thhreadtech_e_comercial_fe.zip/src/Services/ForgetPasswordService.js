import { Api } from "../Interceptor/Interceptor";

const forgetPasswordRequestService = (forgetPassworddata) => {
  return Api.post(`api/forgot_password/`, {
    username: forgetPassworddata.username,
    email: forgetPassworddata.email,
  });
};
const forgetPasswordServices = {
  forgetPasswordRequestService,
};
export default forgetPasswordServices;
