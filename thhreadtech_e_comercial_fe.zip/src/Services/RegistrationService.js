import { Api } from "../Interceptor/Interceptor";
// import BASE_URL from "../components/config";

// const requestOTPService = (phone) => {
//    return Api.post(`/login/one-time-password?phoneNumber=${phone}`);

//   };

// const validateOTPService = (phone, otp) => {
//   return Api.get(`/login/auth?phoneNumber=${phone}&otp=${otp}`);
// };
const roleListService = () => {
  return Api.get("api/role_list/");
};
const RegistrationRequestService = (registerdata) => {
  return Api.post(`api/register_auth/`, {
    username: registerdata.username,
    email: registerdata.email,
    mobile_no: registerdata.mobile_no,
    address: registerdata.address,
    role: registerdata.role,
  });
};
const RegistrationServices = {
  // requestOTPService,
  //   validateOTPService,
  roleListService,
  RegistrationRequestService,
};
export default RegistrationServices;
