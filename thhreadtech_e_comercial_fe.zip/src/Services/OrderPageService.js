import { Api } from "../Interceptor/Interceptor";

export const getAllOrderListOnSearch = (search) => {
  return Api.get("api/order", {
    params: {
      searchTerm: search,
    },
  });
};

export const getAllOrderList = (currentPage, itemsPerPage) => {
  return Api.get("/api/order_list/", {
    params: {
      pageNumber: currentPage,
      size: itemsPerPage,
    },
  });
};
