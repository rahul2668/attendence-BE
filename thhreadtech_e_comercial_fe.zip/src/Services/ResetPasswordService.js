import { Api } from "../Interceptor/Interceptor";

const resetPasswordRequestService = (resetPassworddata) => {
  return Api.post(`api/reset_password/`, {
    username: resetPassworddata.username,
    email: resetPassworddata.email,
    temp_password: resetPassworddata.temp_password,
    new_password: resetPassworddata.new_password,
    confirm_password: resetPassworddata.confirm_password,
  });
};
const resetPasswordServices = {
  resetPasswordRequestService,
};
export default resetPasswordServices;
