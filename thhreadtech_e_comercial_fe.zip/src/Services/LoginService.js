import { Api } from "../Interceptor/Interceptor";
// import BASE_URL from "../components/config";

// const requestOTPService = (phone) => {
//    return Api.post(`/login/one-time-password?phoneNumber=${phone}`);

//   };

// const validateOTPService = (phone, otp) => {
//   return Api.get(`/login/auth?phoneNumber=${phone}&otp=${otp}`);
// };
const loginRequestService = (logindata) => {
  return Api.post(`api/login/`, {
    username: logindata.username,
    password: logindata.password,
  });
};
const loginServices = {
  // requestOTPService,
  //   validateOTPService,
  loginRequestService,
};
export default loginServices;
