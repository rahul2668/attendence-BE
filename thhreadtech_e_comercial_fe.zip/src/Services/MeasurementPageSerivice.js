import { Api } from "../Interceptor/Interceptor";

export const getAllParticularList = () => {
  return Api.get("/api/particular_list/");
};

export const getAllCustomerList = () => {
  return Api.get("/api/customername_list/");
};

export const getBillnoFromCustomer = (billnoCustomer) => {
  const { customerId } = billnoCustomer;
  return Api.get(`/api/getBillNumber?customerId=${customerId}`);
};

export const getCustomerFromBillno = (customerBillno) => {
  const { billNumber } = customerBillno;
  return Api.get(`/api/getCustomerByBill?billNumber=${billNumber}`);
};

export const saveParticularMeasurementRequestService = (requestPayload) => {
  return Api.post(`api/saveData/`, {
    formData: requestPayload.formData,
    selectedCustomer: requestPayload.selectedCustomer,
    selectedCustomerId: requestPayload.selectedCustomerId,
  });
};

export const fetchMeasurementsByCustomer = (customerId) => {
  // const { customerId } = customerId;
  return Api.get(`/api/measurements?customerId=${customerId}`);
};
