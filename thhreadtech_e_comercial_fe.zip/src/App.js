import React from "react";
import "../src/App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
// import RegistrationForm from "./components/userRegistration.js";
// import ResetPasswordForm from "./components/ResetPasswordForm.js";
// import ForgotPasswordForm from "./components/ForgotPasswordForm.js";
// import ChangePasswordForm from "./components/ChangePasswordForm.js";
// import "react-date-range/dist/styles.css"; // main style file
// import "react-date-range/dist/theme/default.css"; // theme css file
// import "react-datepicker/dist/react-datepicker.css";
import "bootstrap/dist/css/bootstrap.css";
import "bootstrap/dist/js/bootstrap.js";
import "bootstrap/dist/js/bootstrap.bundle.min.js";

import Router from "./components/routes/Router.js";
import { RouterProvider } from "react-router-dom";

function App() {
  return (
    <>
      <div className="App">
        <RouterProvider router={Router} />
      </div>
    </>
  );
}

export default App;
