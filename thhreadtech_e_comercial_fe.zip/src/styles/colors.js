export const WARNING = "#F5C518";
export const ERROR = "#D91F11";
export const WHITE = "#FFFFFF";
export const BLACK = "#000000";
export const SIDEBAR_BACKGROUND = "#1F4246";
export const SIDEBAR_SELECTED = "#3e7378"
// export const SIDEBAR_BACKGROUND = "#3e7378";
