import {
  CUSTOMER_FAIL,
  CUSTOMER_SUCCESS,
  PARTICULAR_ORDER_SAVE_SUCCESS,
  PARTICULAR_ORDER_SAVE_FAIL,
} from "../ActionTypes/CustomerPageTypes";

import {
  getAllCustomerList,
  getAllCustomerListOnSearch,
  ParticularOrderRequestService,
} from "../Services/CustomerPageService";
import { getErrorMessage } from "../Utils";
import { SET_MESSAGE } from "../../src/Utils";

export const customerList = (currentPage, itemsPerPage) => async (dispatch) => {
  return await getAllCustomerList(currentPage, itemsPerPage).then(
    (response) => {
      requestCustomerList(response, dispatch);
      updatePageDetails(
        response.data?.pageNo,
        response.data?.totalPages,
        dispatch
      );
      return Promise.resolve(response);
    },
    (error) => {
      const message = getErrorMessage(error);
      requestCustomerListError(message, dispatch);
      return Promise.reject(message);
    }
  );
};
const updatePageDetails = (currentPage, totalPages, dispatch) => {
  dispatch({ type: "SET_PAGINATION", payload: { currentPage, totalPages } });
};

const requestCustomerList = (response, dispatch) => {
  dispatch({
    type: CUSTOMER_SUCCESS,
    payload: response,
  });
};

const requestCustomerListError = (message, dispatch) => {
  dispatch({
    type: CUSTOMER_FAIL,
  });

  dispatch({
    type: SET_MESSAGE,
    payload: message,
  });
};

export const customerListSearch = (searchTerm) => async (dispatch) => {
  return await getAllCustomerListOnSearch(searchTerm).then(
    (response) => {
      requestCustomerList(response, dispatch);

      return Promise.resolve(response);
    },
    (error) => {
      const message = getErrorMessage(error);

      requestCustomerListError(message, dispatch);

      return Promise.reject(message);
    }
  );
};
// let SET_MESSAGE = "SET_MESSAGE";
// export const CustomerPageRequestAction = (searchData) => (dispatch) => {
//   return CustomerPageService.CustomerPageRequestService(searchData).then(
//     (response) => {
//       console.log("response customer search: ", response);
//       CustomerPageRequestDispatcher(response, dispatch);
//       return Promise.resolve(response);
//     },
//     (error) => {
//       console.log("error", error);

//       const message = getErrorMessage(error);
//       console.log("message", message);
//       CustomerPageRequestError(message, dispatch);
//       return Promise.reject(error);
//     }
//   );
// };

// const CustomerPageRequestDispatcher = (response, dispatch) => {
//   dispatch({
//     type: CUSTOMER_SUCCESS,
//     payload: response,
//   });
// };

// const CustomerPageRequestError = (message, dispatch) => {
//   dispatch({
//     type: CUSTOMER_FAIL,
//     payload: { error: message },
//   });
// };
export const ParticularOrderRequestAction = (orderData) => (dispatch) => {
  return ParticularOrderRequestService(orderData).then(
    (response) => {
      console.log("888888", response);
      ParticularOrderRequestDispatcher(response, dispatch);
      return Promise.resolve(response);
    },
    (error) => {
      console.log("error", error);

      const message = getErrorMessage(error);
      console.log("message", message);
      ParticularOrderRequestError(message, dispatch);
      return Promise.reject(error);
    }
  );
};

const ParticularOrderRequestDispatcher = (response, dispatch) => {
  dispatch({
    type: PARTICULAR_ORDER_SAVE_SUCCESS,
    payload: response,
  });
};

const ParticularOrderRequestError = (message, dispatch) => {
  dispatch({
    type: PARTICULAR_ORDER_SAVE_FAIL,
    payload: { error: message },
  });
};
