import {
  LOGIN_FAIL,
  LOGIN_SUCCESS,
  SET_INITIAL_STATE,
  SET_MESSAGE,
} from "../ActionTypes/LoginTypes";

import loginServices from "../Services/LoginService";
import { getErrorMessage } from "../Utils";
// let SET_MESSAGE = "SET_MESSAGE";
export const loginRequestAction = (logindata) => (dispatch) => {
  return loginServices.loginRequestService(logindata).then(
    (response) => {
      loginRequestDispatcher(response, dispatch);
      return Promise.resolve(response);
    },
    (error) => {
      console.log("error", error);

      const message = getErrorMessage(error);
      console.log("message", message);
      loginRequestError(message, dispatch);
      return Promise.reject(error);
    }
  );
};

const loginRequestDispatcher = (response, dispatch) => {
  dispatch({
    type: LOGIN_SUCCESS,
    payload: response,
  });
};

const loginRequestError = (message, dispatch) => {
  dispatch({
    type: LOGIN_FAIL,
    payload: { error: message },
  });
};

export const setInitialState = (userDetails) => ({
  type: SET_INITIAL_STATE,
  payload: userDetails,
});
