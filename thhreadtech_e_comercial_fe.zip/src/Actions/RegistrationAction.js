import {
  REGISTRATION_FAIL,
  REGISTRATION_SUCCESS,
} from "../ActionTypes/RegistrationTypes";

import RegistrationService from "../Services/RegistrationService";
import { getErrorMessage } from "../Utils";
// let SET_MESSAGE = "SET_MESSAGE";
export const RegistrationRequestAction = (registerdata) => (dispatch) => {
  return RegistrationService.RegistrationRequestService(registerdata).then(
    (response) => {
      console.log("888888", response);
      RegistrationRequestDispatcher(response, dispatch);
      return Promise.resolve(response);
    },
    (error) => {
      console.log("error", error);

      const message = getErrorMessage(error);
      console.log("message", message);
      RegistrationRequestError(message, dispatch);
      return Promise.reject(error);
    }
  );
};

const RegistrationRequestDispatcher = (response, dispatch) => {
  dispatch({
    type: REGISTRATION_SUCCESS,
    payload: response,
  });
};

const RegistrationRequestError = (message, dispatch) => {
  dispatch({
    type: REGISTRATION_FAIL,
    payload: { error: message },
  });
};
