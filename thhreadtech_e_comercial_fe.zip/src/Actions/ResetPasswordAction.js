import {
  RESET_PASSWORD_FAIL,
  RESET_PASSWORD_SUCCESS,
} from "../ActionTypes/ResetPasswordTypes";

import resetPasswordServices from "../Services/ResetPasswordService";
import { getErrorMessage } from "../Utils";
// let SET_MESSAGE = "SET_MESSAGE";
export const resetPasswordRequestAction = (resetPassworddata) => (dispatch) => {
  return resetPasswordServices
    .resetPasswordRequestService(resetPassworddata)
    .then(
      (response) => {
        resetPasswordRequestDispatcher(response, dispatch);
        return Promise.resolve(response);
      },
      (error) => {
        console.log("error", error);

        const message = getErrorMessage(error);
        console.log("message", message);
        resetPasswordRequestError(message, dispatch);
        return Promise.reject(error);
      }
    );
};

const resetPasswordRequestDispatcher = (response, dispatch) => {
  dispatch({
    type: RESET_PASSWORD_SUCCESS,
    payload: response,
  });
};

const resetPasswordRequestError = (message, dispatch) => {
  dispatch({
    type: RESET_PASSWORD_FAIL,
    payload: { error: message },
  });
};
