import { ORDER_FAIL, ORDER_SUCCESS } from "../ActionTypes/OrderPageTypes";

import {
  getAllOrderList,
  getAllOrderListOnSearch,
} from "../Services/OrderPageService";
import { getErrorMessage } from "../Utils";
import { SET_MESSAGE } from "../../src/Utils";

export const orderList = (currentPage, itemsPerPage) => async (dispatch) => {
  return await getAllOrderList(currentPage, itemsPerPage).then(
    (response) => {
      requestOrderList(response, dispatch);
      updatePageDetails(
        response.data?.pageNo,
        response.data?.totalPages,
        dispatch
      );
      return Promise.resolve(response);
    },
    (error) => {
      const message = getErrorMessage(error);
      requestOrderListError(message, dispatch);
      return Promise.reject(message);
    }
  );
};
const updatePageDetails = (currentPage, totalPages, dispatch) => {
  dispatch({ type: "SET_PAGINATION", payload: { currentPage, totalPages } });
};

const requestOrderList = (response, dispatch) => {
  dispatch({
    type: ORDER_SUCCESS,
    payload: response,
  });
};

const requestOrderListError = (message, dispatch) => {
  dispatch({
    type: ORDER_FAIL,
  });

  dispatch({
    type: SET_MESSAGE,
    payload: message,
  });
};



export const orderListSearch = (searchTerm) => async (dispatch) => {
  return await getAllOrderListOnSearch(searchTerm).then(
    (response) => {
      requestOrderList(response, dispatch);

      return Promise.resolve(response);
    },
    (error) => {
      const message = getErrorMessage(error);

      requestOrderListError(message, dispatch);

      return Promise.reject(message);
    }
  );
};