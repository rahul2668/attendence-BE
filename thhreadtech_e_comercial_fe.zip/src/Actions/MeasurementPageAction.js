import {
  ORDER_FAIL,
  ORDER_SUCCESS,
  CUSTOMER_LIST_FAIL,
  CUSTOMER_LIST_SUCCESS,
  CUSTOMER_FROM_BILLNO_FAIL,
  CUSTOMER_FROM_BILLNO_SUCCESS,
  BILLNO_FROM_CUSTOMER_FAIL,
  BILLNO_FROM_CUSTOMER_SUCCESS,
  SAVE_MEASUREMENT_FAIL,
  SAVE_MEASUREMENT_SUCCESS,
} from "../ActionTypes/MeasurementPageTypes";

import {
  getAllParticularList,
  Bi,
  saveParticularMeasurementService,
  saveParticularMeasurementRequestService,
  fetchMeasurementsByCustomer,
} from "../Services/MeasurementPageSerivice";
import {
  getAllCustomerList,
  getCustomerFromBillno,
  getBillnoFromCustomer,
} from "../Services/MeasurementPageSerivice";
import { getErrorMessage } from "../Utils";
import { SET_MESSAGE } from "../../src/Utils";

export const particularList = () => async (dispatch) => {
  return await getAllParticularList().then(
    (response) => {
      requestParticularList(response, dispatch);

      return Promise.resolve(response);
    },
    (error) => {
      const message = getErrorMessage(error);
      requestParticularListError(message, dispatch);
      return Promise.reject(message);
    }
  );
};

const requestParticularList = (response, dispatch) => {
  dispatch({
    type: ORDER_SUCCESS,
    payload: response,
  });
};

const requestParticularListError = (message, dispatch) => {
  dispatch({
    type: ORDER_FAIL,
  });

  dispatch({
    type: SET_MESSAGE,
    payload: message,
  });
};

export const customerList = () => async (dispatch) => {
  return await getAllCustomerList().then(
    (response) => {
      requestCustomerList(response, dispatch);

      return Promise.resolve(response);
    },
    (error) => {
      const message = getErrorMessage(error);
      requestCustomerListError(message, dispatch);
      return Promise.reject(message);
    }
  );
};

const requestCustomerList = (response, dispatch) => {
  dispatch({
    type: CUSTOMER_LIST_SUCCESS,
    payload: response,
  });
};

const requestCustomerListError = (message, dispatch) => {
  dispatch({
    type: CUSTOMER_LIST_FAIL,
    payload: message,
  });
};

export const BillNofromCustomer = (billnoCustomer) => async (dispatch) => {
  return await getBillnoFromCustomer(billnoCustomer).then(
    (response) => {
      dispatch({
        type: BILLNO_FROM_CUSTOMER_SUCCESS,
        payload: response,
      });
      return Promise.resolve(response);
    },
    (error) => {
      const message = getErrorMessage(error);
      dispatch({
        type: BILLNO_FROM_CUSTOMER_FAIL,
        payload: message,
      });
      return Promise.reject(message);
    }
  );
};

export const CustomerFromBillno = (customerBillno) => async (dispatch) => {
  return await getCustomerFromBillno(customerBillno).then(
    (response) => {
      dispatch({
        type: CUSTOMER_FROM_BILLNO_SUCCESS,
        payload: response,
      });

      return Promise.resolve(response);
    },
    (error) => {
      console.log("09090", error);
      const message = getErrorMessage(error);
      requestgetCustomerFromBillnoError(message, dispatch);
      return Promise.reject(error);
    }
  );
};

const requestgetCustomerFromBillnoError = (message, dispatch) => {
  dispatch({
    type: BILLNO_FROM_CUSTOMER_FAIL,
    payload: message,
  });
};

export const saveParticularMeasurementAction =
  (requestPayload) => async (dispatch) => {
    return await saveParticularMeasurementRequestService(requestPayload).then(
      (response) => {
        dispatch({
          type: SAVE_MEASUREMENT_SUCCESS,
          payload: response,
        });

        return Promise.resolve(response);
      },
      (error) => {
        const message = getErrorMessage(error);
        requestSaveParticularMeasurementServiceError(message, dispatch);
        return Promise.reject(error);
      }
    );
  };

const requestSaveParticularMeasurementServiceError = (message, dispatch) => {
  dispatch({
    type: SAVE_MEASUREMENT_FAIL,
  });

  dispatch({
    type: SET_MESSAGE,
    payload: message,
  });
};

// export const fetchMeasurementsByCustomer = (customerId) => {
//   return (dispatch) => {
//     // return axios
//       .get(`/api/measurements/${customerId}/`)
//       .then((response) => response)
//       .catch((error) => {
//         throw error;
//       });
//   };
// };

export const fetchMeasurementData = (billnoCustomer) => async (dispatch) => {
  return await fetchMeasurementsByCustomer(billnoCustomer).then(
    (response) => {
      dispatch({
        type: BILLNO_FROM_CUSTOMER_SUCCESS,
        payload: response,
      });
      return Promise.resolve(response);
    },
    (error) => {
      const message = getErrorMessage(error);
      dispatch({
        type: BILLNO_FROM_CUSTOMER_FAIL,
        payload: message,
      });
      return Promise.reject(message);
    }
  );
};
