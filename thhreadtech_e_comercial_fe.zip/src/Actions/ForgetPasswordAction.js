import {
  FORGET_PASSWORD_FAIL,
  FORGET_PASSWORD_SUCCESS,
} from "../ActionTypes/ForgetPasswordTypes";

import forgetPasswordServices from "../Services/ForgetPasswordService";
import { getErrorMessage } from "../Utils";
// let SET_MESSAGE = "SET_MESSAGE";
export const forgetPasswordRequestAction =
  (forgetPassworddata) => (dispatch) => {
    return forgetPasswordServices
      .forgetPasswordRequestService(forgetPassworddata)
      .then(
        (response) => {
          forgetPasswordRequestDispatcher(response, dispatch);
          return Promise.resolve(response);
        },
        (error) => {
          console.log("error", error);

          const message = getErrorMessage(error);
          console.log("message", message);
          forgetPasswordRequestError(message, dispatch);
          return Promise.reject(error);
        }
      );
  };

const forgetPasswordRequestDispatcher = (response, dispatch) => {
  dispatch({
    type: FORGET_PASSWORD_SUCCESS,
    payload: response,
  });
};

const forgetPasswordRequestError = (message, dispatch) => {
  dispatch({
    type: FORGET_PASSWORD_FAIL,
    payload: { error: message },
  });
};
