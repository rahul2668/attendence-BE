import axios from "axios";
import React, { useState } from "react";
import Backdrop from "@mui/material/Backdrop";
import CircularProgress from "@mui/material/CircularProgress";
import secureLocalStorage from "react-secure-storage";
import { getErrorMessage, unauthorized } from "../Utils";
import { useDispatch, useSelector } from "react-redux";
import { loadingStart, loadingEnd } from "../Actions/LoadingAction";

export const Api = axios.create({
  //   baseURL: "https://medicalapp-identity-management-api-ksfgonz3qq-uc.a.run.app",
  baseURL: "http://127.0.0.1:8000/",
});

const getHeadersFromLocalStorage = () => {
  const headers = {
    // 'hospital-id': null,
    // 'admin-id': null,
    Authorization: null,
  };

  const storedData = JSON.parse(secureLocalStorage.getItem("reactlocal"));

  if (storedData) {
    // headers['hospital-id'] = storedData?.data?.body?.hospitalId || null;
    // headers['admin-id'] = storedData?.data?.body?.workerId || null;
    headers["Authorization"] = storedData?.headers?.token
      ? `Bearer ${storedData.headers.token}`
      : null;
  }

  return headers;
};

Api.interceptors.request.use(
  (config) => {
    const headers = getHeadersFromLocalStorage();
    config.headers = {
      ...config.headers,
      ...headers,
    };
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

const Loader = () => {
  const isLoading = useSelector((state) => state.loading.isLoading);
  const dispatch = useDispatch();

  const startLoading = () => {
    dispatch(loadingStart());
  };

  const endLoading = () => {
    dispatch(loadingEnd());
  };

  Api?.interceptors.request.use(
    function (config) {
      startLoading();
      return config;
    },
    function (error) {
      endLoading();
      return Promise.reject(error);
    }
  );

  Api.interceptors.response.use(
    function (response) {
      endLoading();
      return response;
    },
    function (error) {
      if (getErrorMessage(error) === unauthorized) {
        sessionStorage.clear();
        localStorage.clear();
        window.location.href = "/login";
      }
      endLoading();
      return Promise.reject(error);
    }
  );

  return (
    <Backdrop
      sx={{
        color: "#fff",
        zIndex: (theme) => theme.zIndex.drawer + 1,
        backgroundColor: "rgba(0,0,0,0.2)",
      }}
      open={isLoading}
    >
      <CircularProgress color="inherit" />
    </Backdrop>
  );
};

export default Loader;
