export const SUCCESS = "SUCCESS";
export const WARNING = "Warning";
export const Delete_Warning = "Are you sure you want to delete?";
export const Delete_Success = "Record has been deleted";
export const Station_Deleted_Message = "Station Details Deleted Successfully";
export const Roster_Management_Create_Success_Message =
  "Roster Details Created Successfully";
export const Time_Slots_Succes_Message =
  "Time Slots Details Created successfully";
export const Station_Succes_Message = "Station Details Created Successfully";
export const Floot_Succes_Message = "Floor Details Created Successfully";
export const Department_Succes_Message =
  "Department Details Created Successfully";
export const Department_Management_Updated_Success_Message =
  "Department Details Updated Successfully";
export const Roster_Management_Updated_Success_Message =
  "Roster Details Updated Successfully";
export const Time_Slots_UPDATE_Succes_Message =
  "Time Slots Details updated successfully";
export const Station_UPDATE_Succes_Message =
  "Station Details Updated Successfully";
export const Floot_UPDATE_Succes_Message = "Floor Details Updated Successfully";

export const Role_Success_Message = "Role Created Successfully";
export const Role_Update_Message = "Role Updated Successfully";
export const Role_Delete_Message = "Role Deleted Successfully";

export const Worker_Create_Success_Message = "Worker Created Successfully";
export const Worker_Update_Success_Message = "Worker Updated Successfully";
export const Worker_Deleted_Success_Message = "Worker Deleted Successfully";

export const Role_Delete_Error_Message = "Role Deletion Failed";
export const Role_Update_Error_Message = "Role Updation Failed";
export const Role_Create_Error_Message = "Role Creation Failed";

export const Grade_Create_SuccessMessage = "Grade Created Successfully";
export const Grade_Update_SuccessMessage = "Grade Updated Successfully";
export const Grade_Delete_SuccessMessage = "Grade Deleted Successfully";

export const Grade_Delete_ErrorMessage = "Grade Deletion Failed";
export const Grade_Update_ErrorMessage = "Grade Updation Failed";
export const Grade_Create_ErrorMessage = "Grade Creation Failed";
export const Grade_NA = "NA";
export const View = "view";
export const Twenty = 20;

export const Mandatory_Fields_Error = "Please fill all mandatory fields";

export const View_Screen = "view";
export const Click_Away = "clickaway";
export const Style = "style";
export const Search_Focus_Style_Value =
  "border: 1px solid #00BDD0; box-shadow: 0 0 5px rgba(0, 189, 208, 1)";

export const namefn = (firstName, lastName) => {
  return firstName + " " + lastName;
};

export const setTimeoutfn = () => {
  setTimeout(() => {
    window.location.reload();
  }, 500);
};

// export const getErrorMessage = (error) => {
//   return (
//     (error?.response &&
//       error?.response?.data &&
//       error?.response?.data?.error) ||
//     error?.response?.data?.errors[0]?.message ||
//     error.message ||
//     error.toString()
//   );
// };

export const getErrorMessage = (error) => {
  if (error.response) {
    if (error.response.data && error.response.data.message) {
      return error.response.data.message; // Customize this based on actual API response
    }
    return error.response.statusText;
  }
  return error.message;
};

export const modalWidth = {
  width: "45%",
};
export const tooltipfont = {
  fontSize: "10px",
};

export const floorregex = /^[a-zA-Z0-9\s]*$/;

export const station1regex = /^.*$/;

export const loginregex = /^[0-9\b]+$/;

export const staffregex = /^[a-zA-Z ._']*$/;

export const mobileregex = /^[0-9\b]+$/;

export const stationregex = /\s{2,}/g;

export const dateFormat = "DD/MMM/YYYY";

export const roastercolumnlen = 15;

export const maxlength = 150;

export const filter_column_id_one = 1;

export const filter_column_id_two = 2;

export const MANAGER_EDIT_MAXLENGTH = 25;

export const firstNameError = "First Name is Mandatory";

export const roleError = "Role is Mandatory";

export const managerError = "Manager is Mandatory";

export const gradeError = "Grade is Mandatory";

export const emailError = "Email Id is Mandatory";

export const validemailError = "Please Enter a Valid Email";

export const mobileError = "Mobile Number is Mandatory";

export const validmobileError = "10 digits are mandatory for Mobile Number";

export const ROASTER_WORKER_NAME = "Select Worker Name";

export const ROASTER_WORKERID = "Worker Id";

export const ROASTER_ROLENAME = "Role Name";

export const ROASTER_TIMESLOTS = "Select Shift Time Slots";

export const ROASTER_STATIONNAME = "Select Shift Station Name";

export const ROASTER_LOCATION = "Select Shift Location";

export const COLON = ":";

export const AM = "AM";

export const PM = "PM";

export const SPACE_AM = " AM";

export const SPACE_PM = " PM";

export const splitTime = /:| /;

export const HOURS_24 = 24;

export const HOURS_10 = 10;

export const HOURS_12 = 12;

export const HOURS_0 = "0";

export const ZERO = 0;

export const MIN_SEARCH_LENGTH = 2;

export const ENTER_KEY = "Enter";

export const WORKER_NAME_LENGTH = 20;

export const DATE_LENGTH = 24;

/**
 * 
 * @param {*} timeString 
 * @returns TimeStamp in 24 hour Format
 
  This function takes Time Stamp as parameter and returns the Time Stamp in 24 hour Format
 */

export const time24Formatfn = (timeString) => {
  const [hourString, minute, period] = timeString.split(splitTime);
  let hour = parseInt(hourString, HOURS_10);

  if (period === PM && hour < HOURS_12) {
    hour += HOURS_12;
  } else if (period === AM && hour === HOURS_12) {
    hour = ZERO;
  }

  return (hour < HOURS_10 ? HOURS_0 : "") + hour + COLON + minute;
};

/**
 *
 * @param {*} timeString
 * @returns TimeStamp in 12 hour Format
 *
 * This function takes Time Stamp as parameter and returns the Time Stamp in 12 hour Format
 */

export const timeFormatfn = (timeString) => {
  const [hourString, minute] = timeString.split(COLON);
  const hour = +hourString % HOURS_24;
  return (
    (hour % HOURS_12 || HOURS_12) +
    COLON +
    minute +
    (hour < HOURS_12 ? SPACE_AM : SPACE_PM)
  );
};

export const unauthorized = "Unauthorized";
export const SET_MESSAGE="SET_MESSAGE";

export const DEFAULT_ITEMS_PER_PAGE = 10;

export const DEFAULT_CURRENT_PAGE = 0;

export const NO_RECORDS = "No Records Found";

export const DATE_FORMAT = "DD-MM-YYYY";

export const TIMER_TIME = 59;

export const generatePath = (template, params) => {
    return template.replace(/:([a-zA-Z_]+)/g, (_, key) => params[key] || `:${key}`);
  };