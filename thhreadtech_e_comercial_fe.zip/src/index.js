import React from "react";
import ReactDOM from "react-dom/client";
import "./styles/index.css";
import App from "./App";
import { Provider } from "react-redux";
import store from "./store";
import reportWebVitals from "./reportWebVitals";
//import { ProSidebarProvider } from "react-pro-sidebar";
import Loader from "./Interceptor/Interceptor";
import { PersistGate } from "redux-persist/integration/react";
// import { store, persistor } from "./store";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  // <React.StrictMode>
  //           <App />
  // </React.StrictMode>
  <Provider store={store}>
      <Loader></Loader>
    <App />
     </Provider>
  // document.getElementById("root")
);
reportWebVitals();
