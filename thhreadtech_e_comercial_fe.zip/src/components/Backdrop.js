import React from 'react';
import '../styles/Backdrop.css';

export const Backdrop = props => {
  return (
    <div className='backdrop' onClick={props.click}/>
  )
}

export default Backdrop;