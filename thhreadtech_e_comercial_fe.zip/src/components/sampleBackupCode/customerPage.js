import React, { useState, useEffect } from "react";
// import "../../styles/home.css";
import {
  customerList,
  customerListSearch,
} from "../../Actions/CustomerPageAction";
import { connect, useDispatch } from "react-redux";
import { SUCCESS } from "../../Utils.js";
import search from "../../Assets/images/search.svg";
import close from "../../Assets/images/close.svg";
import closedEye from "../../Assets/images/close_eye.svg";
import eyeIcon from "../../Assets/images/blueEye.svg";
import { ENTER_KEY, modalWidth, MIN_SEARCH_LENGTH } from "../../Utils.js";
import "../../styles/common/common.css";
import "../../styles/customerpage.css";
import ParticularsQuantityTotal from "../../components/pages/ParticularQuantityPage.js";
import Pagination from "../../components/common/pagination.js";
import secureLocalStorage from "react-secure-storage";
import { pink } from "@mui/material/colors";
import { useNavigate } from "react-router-dom";
// import "bootstrap/dist/css/bootstrap.min.css";
// import "bootstrap/dist/js/bootstrap.bundle.min.js";

let path = "/registration";
function CustomerPage({ currentPage, itemsPerPage, totalpages }) {
  const [viewDetails, setViewDetails] = useState();
  const [revealedNumbers, setRevealedNumbers] = useState([]);
  const [errorMessage, setErrorMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [searchData, setSearchData] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [data, setData] = useState(null);
  const dispatch = useDispatch();
  const [successMessage, setSuccessMessage] = useState("");
  const [searchTermFromState, setsearchTermFromState] = useState({
    searchTerm: "",
  });
  const [showOffcanvas, setShowOffcanvas] = useState(false);
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState("");
  let navigate = useNavigate();
  const handleOnChange = (e) => {
    const { name, value } = e.target;
    setsearchTermFromState({ ...searchTermFromState, [name]: value });
  };

  useEffect(() => {
    dispatch(customerList(currentPage, itemsPerPage)).then(
      (response) => {
        if (response.data.status === SUCCESS) {
          setData(response.data);
        }
      },
      (error) => {
        setData(error);
      }
    );
  }, [dispatch, currentPage, itemsPerPage]);

  const handleCustomerSearch = () => {
    if (
      searchTermFromState?.searchTerm.length > MIN_SEARCH_LENGTH ||
      searchTermFromState?.searchTerm.length === 0
    ) {
      dispatch(customerListSearch(searchTermFromState?.searchTerm)).then(
        (response) => {
          if (response?.data?.status === SUCCESS) {
            console.log("-----", response.data);
            setData(response?.data);
          }
        },
        (error) => {
          setData(error);
        }
      );
    }
  };

  const handleViewClick = (index, phoneNumber) => {
    if (revealedNumbers[index]) {
      setRevealedNumbers((prevRevealedNumbers) => ({
        ...prevRevealedNumbers,
        [index]: "",
      }));
    } else {
      setRevealedNumbers((prevRevealedNumbers) => ({
        ...prevRevealedNumbers,
        [index]: phoneNumber,
      }));
    }
  };

  const handleSearchFocus = () => {
    setIsSearchFocused(true);
  };

  const handleSearchBlur = () => {
    setIsSearchFocused(false);
  };

  useEffect(() => {
    let searchId = document.getElementById("mySearchDiv");
    if (isSearchFocused) {
      searchId.setAttribute(
        "style",
        "border: 1px solid #00BDD0; box-shadow: 0 0 5px rgba(0, 189, 208, 1)"
      );
    } else {
      searchId.setAttribute("style", "border-color: none;");
    }
  }, [isSearchFocused]);

  const toggleOffcanvas = () => {
    setShowOffcanvas(!showOffcanvas);
  };

  const handleTableRowClick = (customerName) => {
    setSelectedCustomer(customerName);
    toggleOffcanvas();
  };
  const handleClick = () => {
    // Navigate to the register page when the button is clicked
    navigate(path);
  };
  return (
    <div className="">
      <div className="ng-container d-flex tableBackground">
        <div className="w-100 ms-5">
          <div className=" ms-1  ">
            <div className="d-flex justify-content-between  m-0 bg-white p-2">
              <div className="d-flex">
                <div
                  className="ms-3 search align-items-center d-flex justify-content-center"
                  id="mySearchDiv"
                  onFocus={handleSearchFocus}
                  onBlur={handleSearchBlur}
                >
                  <img src={search} className="ms-2" alt="img" />
                  <input
                    type="text"
                    placeholder="Search"
                    className="search_input w-100 ms-2"
                    id="mySearchInput"
                    onChange={handleOnChange}
                    aria-label="Username"
                    aria-describedby="basic-addon1"
                    name="searchTerm"
                    value={searchTermFromState?.searchTerm}
                    onKeyDown={(event) => {
                      if (event.key === ENTER_KEY) {
                        handleCustomerSearch();
                      }
                    }}
                  />
                </div>
                <div>
                  <button
                    className="submit-button-create w-100 ms-2"
                    onClick={handleClick}
                  >
                    {" "}
                    + <span>create</span>
                  </button>
                </div>
              </div>
            </div>

            <div className="container-fluid mt-3">
              {/* <h3>Right Offcanvas</h3> */}

              <div className=" mt-2 ms-4 ">
                <div className="row w-100">
                  <div className="scroll-container">
                    <table className="table m-0 p-0 w-100">
                      <thead className="table_head border border-top border-end-0  border-start-0 m-0 p-0 table_td w-100">
                        <tr>
                          <th className="labels ">
                            <div className="  d-flex justify-content-between text-center border mb-2  border-top-0 border-bottom-0 border-start-0">
                              <span className="text_font">Bill No</span>
                            </div>
                          </th>
                          <th className="labels ">
                            <div className="  d-flex justify-content-between text-center border mb-2  border-top-0 border-bottom-0 border-start-0">
                              <span className="text_font">Customer Name</span>
                            </div>
                          </th>
                          <th className="labels ">
                            <div className=" d-flex justify-content-between  text-center border mb-2  border-top-0 border-bottom-0 border-start-0 ">
                              <span className="text_font">Role</span>
                            </div>
                          </th>
                          <th className="labels">
                            <div className="  d-flex justify-content-between text-center border mb-2  border-top-0 border-bottom-0 border-start-0 ">
                              <span className="text_font">User</span>
                            </div>
                          </th>
                          <th className="labels ">
                            <div className=" d-flex justify-content-between  text-center border mb-2  border-top-0 border-bottom-0 border-start-0  ">
                              <span className="text_font">Email Id</span>
                            </div>
                          </th>
                          <th className="labels ">
                            <div className=" d-flex justify-content-between  text-center border mb-2  border-top-0 border-bottom-0 border-start-0 ">
                              <span className="text_font">Mobile Number</span>
                            </div>
                          </th>
                          <th className="labels ">
                            <div className=" d-flex justify-content-between  text-center border mb-2 border-top-0 border-bottom-0 border-start-0  ">
                              <span className="text_font">Address</span>
                            </div>
                          </th>
                        </tr>
                      </thead>

                      <tbody>
                        {data?.body?.length > 0 ? (
                          data?.body?.map((val, index) => (
                            <tr key={val.id}>
                              <td
                                className="table_td"
                                onClick={() =>
                                  handleTableRowClick(val.customername)
                                }
                              >
                                {val.id}
                              </td>
                              <td
                                className="table_td"
                                onClick={() =>
                                  handleTableRowClick(val.customername)
                                }
                              >
                                {val.customername.length > 20 ? (
                                  <div
                                    className="truncate"
                                    title={val.customername}
                                  >
                                    {val.customername}
                                  </div>
                                ) : (
                                  <>{val.customername}</>
                                )}
                              </td>
                              <td
                                className="table_td"
                                onClick={() =>
                                  handleTableRowClick(val.customername)
                                }
                              >
                                {val.role.length > 20 ? (
                                  <div className="truncate" title={val.role}>
                                    {val.role}
                                  </div>
                                ) : (
                                  <>{val.role}</>
                                )}
                              </td>
                              <td
                                className="table_td"
                                onClick={() =>
                                  handleTableRowClick(val.customername)
                                }
                              >
                                {val.user}
                              </td>
                              <td
                                className="table_td"
                                onClick={() =>
                                  handleTableRowClick(val.customername)
                                }
                              >
                                {val.email}
                              </td>
                              <td className="table_td" style={{ width: "13%" }}>
                                <div className="d-flex justify-content-between m-0 p-0 me-2">
                                  {revealedNumbers[index] ? (
                                    <>
                                      {val.mobile_number}
                                      <span
                                        onClick={() =>
                                          handleViewClick(
                                            index,
                                            val.mobile_number
                                          )
                                        }
                                        className="m-0 p-0"
                                        style={{ cursor: "pointer" }}
                                      >
                                        <img
                                          src={closedEye}
                                          className="me-2 eye-icon"
                                          alt="img"
                                        />
                                      </span>
                                    </>
                                  ) : (
                                    <>
                                      **********
                                      <span
                                        onClick={() =>
                                          handleViewClick(
                                            index,
                                            val.mobile_number
                                          )
                                        }
                                        className="m-0 p-0"
                                        style={{ cursor: "pointer" }}
                                      >
                                        <img
                                          src={eyeIcon}
                                          className="me-2 eye-icon"
                                          alt="img"
                                        />
                                      </span>
                                    </>
                                  )}
                                </div>
                              </td>
                              <td
                                className="table_td"
                                // onClick={toggleOffcanvas}
                                onClick={() =>
                                  handleTableRowClick(val.customername)
                                }
                              >
                                {val.address}
                              </td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan={9}>
                              <div className="text-center">{errorMessage}</div>
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                  <Pagination
                    totalPages={totalpages}
                    currentPage={currentPage}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showOffcanvas && (
        <div
          className={`offcanvas offcanvas-end ${showOffcanvas ? "show" : ""}`}
          tabIndex="-1"
          id="offcanvasRight"
          aria-labelledby="offcanvasRightLabel"
          style={{
            visibility: showOffcanvas ? "visible" : "hidden",
          }}
        >
          <div className="offcanvas-header">
            <button
              type="button"
              className="btn-close text-reset"
              aria-label="Close"
              onClick={toggleOffcanvas}
            ></button>
          </div>
          <div className="offcanvas-body">
            <ParticularsQuantityTotal selectedCustomer={selectedCustomer} />
          </div>
        </div>
      )}
      {showOffcanvas && (
        <div
          className="offcanvas-backdrop fade show"
          onClick={toggleOffcanvas}
        ></div>
      )}
    </div>
  );
}

const mapStateToProps = (state) => ({
  errorMessage: state.staffCreationReducerFn?.errorMessage,
  currentPage: state.PaginationReducer?.currentPage,
  itemsPerPage: state.PaginationReducer?.itemsPerPage,
  totalpages: state.PaginationReducer?.totalPages,
});

export default connect(mapStateToProps)(CustomerPage);
