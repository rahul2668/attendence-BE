// import { useReducer } from "react";
import {
  LOGIN_SUCCESS,
  LOGIN_FAIL,
  SET_INITIAL_STATE,
  SET_MESSAGE,
} from "../../ActionTypes/LoginTypes";
// import { combineReducers } from "redux";

const initialState = {
  userDetails: "",
  error: "",
  username: "",
};

// const rootReducer = combineReducers({
//   user: useReducer,
// });
const loginReducer = (state = initialState, action) => {
  switch (action.type) {
    case LOGIN_SUCCESS: {
      console.log("----q-", action.payload.data.username);
      return {
        ...state,
        userDetails: action.payload,
        username: action.payload.data.username,
      };
    }
    case LOGIN_FAIL: {
      return {
        ...state,
        error: action.payload,
      };
    }
    case SET_MESSAGE: {
      return {
        ...state,
        error: action.payload,
      };
    }
    case SET_INITIAL_STATE: {
      return {
        ...state,
        userDetails: action.payload,
        username: action.payload.username,
      };
    }
    default: {
      return { ...state };
    }
  }
};

export default loginReducer;
