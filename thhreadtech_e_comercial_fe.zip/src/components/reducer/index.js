import { combineReducers } from "redux";
import loadingReducer from "./LoadingReducer";
import loginReducer from "./LoginReducer";
import PaginationReducer from "./PaginationReducer";

export default combineReducers({
  loading: loadingReducer,
  loginReducer,
  pagination: PaginationReducer,
});
