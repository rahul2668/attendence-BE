import { DEFAULT_ITEMS_PER_PAGE, DEFAULT_CURRENT_PAGE } from "../../Utils";

const initialState = {
  currentPage: DEFAULT_CURRENT_PAGE,
  totalPages: 1,
  itemsPerPage: DEFAULT_ITEMS_PER_PAGE,
  isLoading: false,
  error: null,
  data: [],
};

export const setPagination = (currentPage, totalPages, dispatch) => {
  dispatch({ type: "SET_PAGINATION", payload: { currentPage, totalPages } });
};

export const nextPage = (dispatch) => {
  dispatch({
    type: "NEXT_PAGE",
  });
};

export const prevPage = (dispatch) => {
  dispatch({
    type: "PREV_PAGE",
  });
};
export const itemsPerPage = (dispatch, itemsPerPage) => {
  dispatch({
    type: "ITEMS_PER_PAGE",
    payload: itemsPerPage,
  });
};
export const defaultPage = (dispatch) => {
  dispatch({
    type: "DEFAULT_PAGE",
  });
};

const PaginationReducer = (state = initialState, action) => {
  switch (action.type) {
    case "SET_PAGINATION":
      return {
        ...state,
        currentPage: action.payload.currentPage,
        totalPages: action.payload.totalPages,
      };
    case "NEXT_PAGE":
      return {
        ...state,
        currentPage: state.currentPage + 1,
      };
    case "ITEMS_PER_PAGE":
      return {
        ...state,
        currentPage: DEFAULT_CURRENT_PAGE,
        totalPages: action.payload.totalPages,
        itemsPerPage: action.payload,
      };
    case "PREV_PAGE":
      return {
        ...state,
        currentPage: state.currentPage - 1,
      };
    case "DEFAULT_PAGE":
      return {
        ...state,
        currentPage: DEFAULT_CURRENT_PAGE,
        itemsPerPage: DEFAULT_ITEMS_PER_PAGE,
      };
    default:
      return { ...state };
  }
};

export default PaginationReducer;

// import { DEFAULT_ITEMS_PER_PAGE, DEFAULT_CURRENT_PAGE } from "../../Utils";

// const initialState = {
//   currentPage: DEFAULT_CURRENT_PAGE,
//   totalPages: 1,
//   itemsPerPage: DEFAULT_ITEMS_PER_PAGE,
//   isLoading: false,
//   error: null,
//   data: [],
// };

// export const setPagination = (currentPage, totalPages) => ({
//   type: "SET_PAGINATION",
//   payload: { currentPage, totalPages },
// });

// export const nextPage = () => ({
//   type: "NEXT_PAGE",
// });

// export const prevPage = () => ({
//   type: "PREV_PAGE",
// });

// export const setItemsPerPage = (itemsPerPage) => ({
//   type: "ITEMS_PER_PAGE",
//   payload: itemsPerPage,
// });

// export const defaultPage = () => ({
//   type: "DEFAULT_PAGE",
// });

// const PaginationReducer = (state = initialState, action) => {
//   switch (action.type) {
//     case "SET_PAGINATION":
//       return {
//         ...state,
//         currentPage: action.payload.currentPage,
//         totalPages: action.payload.totalPages,
//       };
//     case "NEXT_PAGE":
//       return {
//         ...state,
//         currentPage: state.currentPage + 1,
//       };
//     case "ITEMS_PER_PAGE":
//       return {
//         ...state,
//         currentPage: DEFAULT_CURRENT_PAGE,
//         itemsPerPage: action.payload,
//       };
//     case "PREV_PAGE":
//       return {
//         ...state,
//         currentPage: state.currentPage - 1,
//       };
//     case "DEFAULT_PAGE":
//       return {
//         ...state,
//         currentPage: DEFAULT_CURRENT_PAGE,
//         itemsPerPage: DEFAULT_ITEMS_PER_PAGE,
//       };
//     default:
//       return { ...state };
//   }
// };

// export default PaginationReducer;
