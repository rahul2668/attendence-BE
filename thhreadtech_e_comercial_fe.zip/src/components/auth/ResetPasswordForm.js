import React, { useState, useEffect } from "react";
import { useDispatch } from "react-redux";
// import { useLocation } from "react-router-dom";
// import { useNavigate, useParams } from "react-router-dom/dist";
import { useLocation, useParams } from "react-router-dom";
// import { useParams, useNavigate } from "react-router-dom/dist";
import { useNavigate } from "react-router-dom";
import { Modal, Button } from "react-bootstrap";
import Backdrop from "@mui/material/Backdrop";
import CircularProgress from "@mui/material/CircularProgress";
import TextField from "@mui/material/TextField";
import Box from "@mui/material/Box";
import { resetPasswordRequestAction } from "../../Actions/ResetPasswordAction";
import { SUCCESS } from "../../Utils";
import resetImagePerson from "../../Assets/images/reset2.avif";
import "../../styles/forgetpassword.css";
import LockResetIcon from "@mui/icons-material/LockReset";


let route_path = "/login/";
const ResetPasswordForm = () => {
  console.log("entered to resetpassword page");
  const dispatch = useDispatch();
  let navigate = useNavigate();
  const [errorMessage, setErrorMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const { username, email } = useParams();
  const [tempPassword, setTempPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [formErrors, setFormErrors] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  const location = useLocation();
  const submitResetPasswordHandler = async (e) => {
    e.preventDefault();
    setLoading(true);
    const resetPassworddata = {
      username: username,
      email: email,
      temp_password: tempPassword,
      new_password: newPassword,
      confirm_password: confirmPassword,
    };
    dispatch(resetPasswordRequestAction(resetPassworddata))
      .then((response) => {
        setLoading(false);
        console.log("2222", response.data, response.data.status);
        if (response?.data?.status === SUCCESS) {
          setSuccessMessage(response.data.message);
        }
      })
      .catch((error) => {
        setLoading(false);
        if (
          error.response &&
          error.response.data &&
          error.response.data.detail
        ) {
          setErrorMessage(error.response.data.detail);
        } else {
          setErrorMessage(
            "An error occured while processing of reset password"
          );
        }
        console.log(error);
      });
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === "temp_password") setTempPassword(value);
    if (name === "new_password") setNewPassword(value);
    if (name === "confirm_password") setConfirmPassword(value);
    setFormErrors({ ...formErrors, [name]: "" });
  };
  const handleClose = () => {
    setErrorMessage("");
  };
  const handleCloseSuccess = () => {
    setSuccessMessage("");
    navigate(route_path);
  };

  return (
    <div className="reset-container">
      <div className="left-image">
        <img src={resetImagePerson} alt="Left Image" />
      </div>
      <div className="form-container">
        <div className="container" align="center">
          <LockResetIcon sx={{ fontSize: 40, marginRight: "10px" }} />
          <h2>Reset Password</h2>
          <Box
            sx={{ "& .MuiTextField-root": { m: 1, width: "25ch" } }}
            noValidate
            autoComplete="off"
          >
            <form>
              <div>
                <TextField
                  required
                  id="outlined-required"
                  label="Temp Password"
                  name="temp_password"
                  value={tempPassword}
                  className="text_input"
                  onChange={handleChange}
                />
              </div>
              <div>
                <TextField
                  required
                  id="outlined-required"
                  label="New Password"
                  name="new_password"
                  value={newPassword}
                  className="text_input"
                  onChange={handleChange}
                />
              </div>
              <div>
                <TextField
                  required
                  id="outlined-required"
                  label="Confirm Password"
                  name="confirm_password"
                  value={confirmPassword}
                  className="text_input"
                  onChange={handleChange}
                />
              </div>
              <input
                type="submit"
                value="Send Email"
                className="btn"
                onClick={submitResetPasswordHandler}
                style={{ backgroundColor: "#1f4246" }}
              />
            </form>
            <div>
              <Backdrop
                sx={{
                  color: "#fff",
                  zIndex: (theme) => theme.zIndex.drawer + 1,
                }}
                open={loading}
              >
                <CircularProgress color="inherit" />
              </Backdrop>
            </div>
            <div>
              <Modal show={!!errorMessage} onHide={handleClose} centered>
                <Modal.Header closeButton={false}></Modal.Header>
                <Modal.Body>{errorMessage}</Modal.Body>
                <Modal.Footer>
                  <Button variant="secondary" onClick={handleClose}>
                    Close
                  </Button>
                </Modal.Footer>
              </Modal>
            </div>
            <div>
              <Modal
                show={!!successMessage}
                onHide={handleCloseSuccess}
                centered
              >
                <Modal.Header closeButton={false}></Modal.Header>
                <Modal.Body>{successMessage}</Modal.Body>
                <Modal.Footer>
                  <Button variant="secondary" onClick={handleCloseSuccess}>
                    Close
                  </Button>
                </Modal.Footer>
              </Modal>
            </div>
          </Box>
        </div>
      </div>
    </div>
  );
};

export default ResetPasswordForm;
