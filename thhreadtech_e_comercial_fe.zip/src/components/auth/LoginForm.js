import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import "../../styles/login.css";
import axios from "axios";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import { Modal, Button } from "react-bootstrap";
import CircularProgress from "@mui/material/CircularProgress";
import Backdrop from "@mui/material/Backdrop";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import secureLocalStorage from "react-secure-storage";
import InputLabel from "@mui/material/InputLabel";
import {
  requestOTPAction,
  validateOTPAction,
  loginRequestAction,
} from "../../Actions/LoginAction";
import { SUCCESS, loginregex, Click_Away } from "../../Utils";
import LoginImagePerson from "../../Assets/images/loginImagePerson.avif";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import backgroundImage from "../../Assets/images/bg.jpg";

let path = "/Home/";

export const LoginForm = () => {
  const dispatch = useDispatch();
  let navigate = useNavigate();

  const [errorMessage, setErrorMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [formErrors, setFormErrors] = useState({});
  // const [roles, setRoles] = useState([]);

  useEffect(() => {
    const storedData = JSON.parse(secureLocalStorage.getItem("reactlocal"));
    if (storedData?.headers?.token) {
      navigate(path);
    }
    // fetchRoles();
  }, []);

  const submitHandler = async (e) => {
    e.preventDefault();
    setLoading(true);
    const logindata = {
      username: username,
      password: password,
    };
    dispatch(loginRequestAction(logindata))
      .then((response) => {
        setLoading(false);
        if (response?.data?.status === SUCCESS) {
          secureLocalStorage.setItem("reactlocal", JSON.stringify(response));
          sessionStorage.setItem("token", response.data.token);
          sessionStorage.setItem("login_type", response.data.login_type);
          sessionStorage.setItem("username", response.data.username);
          sessionStorage.setItem("user_id", response.data.user_id);
          sessionStorage.setItem("reactsessionlocal", JSON.stringify(response));
          navigate(path);
        }
      })
      .catch((error) => {
        setLoading(false);
        if (
          error.response &&
          error.response.data &&
          error.response.data.detail
        ) {
          setErrorMessage(error.response.data.detail); // Set errorMessage to the value of detail
        } else {
          console.log(error.response);
          setErrorMessage(
            "An error occurred while processing your request. Please try again later."
          );
        }
        console.log(error);
      });
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === "username") setUsername(value);
    if (name === "password") setPassword(value);
    setFormErrors({ ...formErrors, [name]: "" });
  };
  const handleClose = () => {
    setErrorMessage("");
  };
  return (
    <div className="login-container">
      <div className="left-image">
        <img src={LoginImagePerson} alt="Left Image" />
      </div>
      <div className="form-container">
        <div className="container" align="center">
          <AccountCircleIcon sx={{ fontSize: 40, marginRight: "10px" }} />
          <h2>Login</h2>
          <Box
            // component="form"
            sx={{
              "& .MuiTextField-root": { m: 1, width: "25ch" },
            }}
            noValidate
            autoComplete="off"
          >
            <form>
              <div>
                <TextField
                  required
                  id="outlined-required"
                  label="User Name"
                  name="username"
                  value={username}
                  className="text_input"
                  onChange={handleChange}
                />
              </div>
              <div>
                <TextField
                  required
                  id="outlined-required"
                  label="Password"
                  name="password"
                  // type="password"
                  value={password}
                  className="text_input"
                  onChange={handleChange}
                />
              </div>
              {/* <div>
                <InputLabel htmlFor="outlined-adornment-password">
                  Password
                </InputLabel>
                <OutlinedInput
                  id="outlined-adornment-password"
                  type={showPassword ? "text" : "password"}
                  endAdornment={
                    <InputAdornment position="end">
                      <IconButton
                        aria-label="toggle password visibility"
                        onClick={handleClickShowPassword}
                        onMouseDown={handleMouseDownPassword}
                        edge="end"
                      >
                        {showPassword ? <VisibilityOff /> : <Visibility />}
                      </IconButton>
                    </InputAdornment>
                  }
                  label="Password"
                />
              </div> */}
              <input
                type="submit"
                value="Login"
                className="btn"
                onClick={submitHandler}
                style={{ backgroundColor: "#1f4246" }}
              />
            </form>
            <div>
              <Backdrop
                sx={{
                  color: "#fff",
                  zIndex: (theme) => theme.zIndex.drawer + 1,
                }}
                open={loading}
              >
                <CircularProgress color="inherit" />
              </Backdrop>
            </div>
            <div>
              <Modal show={!!errorMessage} onHide={handleClose} centered>
                <Modal.Header closeButton={false}>
                  {/* <Modal.Title>Error</Modal.Title> */}
                </Modal.Header>
                <Modal.Body>{errorMessage}</Modal.Body>
                <Modal.Footer>
                  <Button variant="secondary" onClick={handleClose}>
                    Close
                  </Button>
                </Modal.Footer>
              </Modal>
            </div>
          </Box>

          <p>
            <Link to="/forgot_password/" className="forgot-password-link">
              Forgot Password?
            </Link>
          </p>
          {/* 
      <p>
        Don't have an account?{" "}
        <Link to="/registration" className="btn">
          Register
        </Link>
      </p> */}
        </div>
      </div>
    </div>
  );
};

export default LoginForm;
