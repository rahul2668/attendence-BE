import React, { useState } from "react";
import axios from "axios";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import Backdrop from "@mui/material/Backdrop";
import CircularProgress from "@mui/material/CircularProgress";
import { Modal, Button } from "react-bootstrap";
import { useDispatch } from "react-redux";
import { forgetPasswordRequestAction } from "../../Actions/ForgetPasswordAction";
import { SUCCESS } from "../../Utils";
import { useNavigate } from "react-router-dom";
import MuiAlert from "@mui/material/Alert";
import forgetImagePerson from "../../Assets/images/ForgetPasswordImage.avif";
import "../../styles/forgetpassword.css";
import LockResetIcon from "@mui/icons-material/LockReset";
// const Alert = React.forwardRef(function Alert(props, ref) {
//   return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
// });

let path = "/login/";

const ForgotPasswordForm = () => {
  const dispatch = useDispatch();
  let navigate = useNavigate();
  const [errorMessage, setErrorMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [formErrors, setFormErrors] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  const submitForgetPasswordHandler = (e) => {
    e.preventDefault();
    setLoading(true);
    const forgetPassworddata = {
      username: username,
      email: email,
    };
    dispatch(forgetPasswordRequestAction(forgetPassworddata))
      .then((response) => {
        setLoading(false);
        if (response?.data?.status === SUCCESS) {
          setSuccessMessage(response.data.message);
        }
      })
      .catch((error) => {
        setLoading(false);
        if (
          error.response &&
          error.response.data &&
          error.response.data.detail
        ) {
          setErrorMessage(error.response.data.detail);
        } else {
          setErrorMessage(
            "An error occurred while proccing of forget password"
          );
        }
        console.log(error);
      });
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === "username") setUsername(value);
    if (name === "email") setEmail(value);
    setFormErrors({ ...formErrors, [name]: "" });
  };
  const handleClose = () => {
    setErrorMessage("");
  };
  const handleCloseSuccess = () => {
    setSuccessMessage("");
    navigate(path);
  };

  return (
    <div className="forgot-container">
      <div className="left-image">
        <img src={forgetImagePerson} alt="Left Image" />
      </div>
      <div className="form-container">
        <div className="container" align="center">
          <LockResetIcon sx={{ fontSize: 40, marginRight: "10px" }} />
          <h2>Password Reset</h2>
          <Box
            sx={{ "& .MuiTextField-root": { m: 1, width: "25ch" } }}
            noValidate
            autoComplete="off"
          >
            <form>
              <div>
                <TextField
                  required
                  id="outlined-required"
                  label="User Name"
                  name="username"
                  value={username}
                  className="text_input"
                  onChange={handleChange}
                />
              </div>
              <div>
                <TextField
                  required
                  id="outlined-required"
                  label="Email"
                  name="email"
                  value={email}
                  className="text_input"
                  onChange={handleChange}
                />
              </div>
              <input
                type="submit"
                value="Send Email"
                className="btn"
                onClick={submitForgetPasswordHandler}
                style={{ backgroundColor: "#1f4246" }}
              />
            </form>
            <div>
              <Backdrop
                sx={{
                  color: "#fff",
                  zIndex: (theme) => theme.zIndex.drawer + 1,
                }}
                open={loading}
              >
                <CircularProgress color="inherit" />
              </Backdrop>
            </div>
            <div>
              <Modal show={!!errorMessage} onHide={handleClose} centered>
                <Modal.Header closeButton={false}></Modal.Header>
                <Modal.Body>{errorMessage}</Modal.Body>
                <Modal.Footer>
                  <Button variant="secondary" onClick={handleClose}>
                    Close
                  </Button>
                </Modal.Footer>
              </Modal>
            </div>
            <div>
              <Modal
                show={!!successMessage}
                onHide={handleCloseSuccess}
                centered
              >
                <Modal.Header closeButton={false}></Modal.Header>
                <Modal.Body>{successMessage}</Modal.Body>
                <Modal.Footer>
                  <Button variant="secondary" onClick={handleCloseSuccess}>
                    Close
                  </Button>
                </Modal.Footer>
              </Modal>
            </div>
          </Box>
        </div>
      </div>
    </div>
  );
};

export default ForgotPasswordForm;
