import React from "react";
import "../../styles/common/footer.css";
function Footer() {
  //   return (
  //     <div className="footer-body">
  //       All copyrights reserved @ Thread Tech 2024
  //     </div>
  //   );
  return (
    <div className="footer-container position-fixed">
      <span className="footer-text">
        All copyrights reserved @ Thread Tech 2024
      </span>
    </div>
  );
}

export default Footer;
