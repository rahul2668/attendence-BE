import React, { useState, useEffect } from "react";

function useErrorBoundary() {
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    const errorHandler = (error, errorInfo) => {
      console.error("ErrorBoundary Log:🛑", error, errorInfo);
      setHasError(true);
    };

    // Assign the error handler to window
    window.addEventListener("error", errorHandler);

    // Cleanup function to remove the error handler
    return () => {
      window.removeEventListener("error", errorHandler);
    };
  }, []);

  return hasError;
}

function ErrorBoundary({ children }) {
  const hasError = useErrorBoundary();

  if (hasError) {
    return (
      <h1>
        Sorry.. there was an unexpected error. Try going back and doing a
        refresh
      </h1>
    );
  }

  return <React.Fragment>{children}</React.Fragment>;
}

export default ErrorBoundary;
