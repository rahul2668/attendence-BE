import React, { useState } from "react";
import { Box, IconButton, Paper, Popper, Grid } from "@mui/material";
import LogoutIcon from "@mui/icons-material/Logout";
import secureLocalStorage from "react-secure-storage";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import Closeicon from "../../Assets/images/closeicon.svg";
import "../../styles/common/header.css";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import usericon from "../../Assets/images/usericon.svg";
import { namefn } from "../../Utils";
// import loginImage from "../../Assets/images/bilvantistechnologies_logo.jpg";
// import loginImage from "../../Assets/images/r_logo2.jpg";
import loginImage from "../../Assets/images/1234.jpg";
import { Dropdown, OverlayTrigger, Tooltip } from "react-bootstrap";

function Header() {
  const userDetails = JSON.parse(secureLocalStorage.getItem("reactlocal"));
  let userRoleId = userDetails?.data?.username;
  const [showDropdown, setShowDropdown] = useState(false);

  const handleGridClick = () => {
    setShowDropdown(!showDropdown);
  };
  const [showModal, setShowModal] = useState(false);

  const handleShow = () => {
    setShowModal(true);
  };
  const handleClose = () => setShowModal(false);
  const handleLogout = () => {
    setShowModal(false);
    sessionStorage.clear();
    localStorage.clear();
    window.location.href = "/";
  };
  const tooltip = (
    <Tooltip id="tooltip">
      {" "}
      {namefn(
        userDetails?.data?.body?.firstName,
        userDetails?.data?.body?.lastName
      )}
    </Tooltip>
  );
  // const handleLogout = () => {
  //   sessionStorage.clear();
  //   localStorage.clear();
  //   window.location.href = "/";
  // };
  return (
    <>
      <div className="ng-container">
        <Box
          p={1}
          sx={{
            border: "1px solid transparent",
            backgroundColor: "#ffffff",
            height: "66px",
            borderBottom: "2px solid #EBEBEC",
          }}
        >
          <Grid container justifyContent="space-between" alignItems="center">
            <Grid item className="d-flex ms-2">
              <img alt="img" src={loginImage} className="logo-image p-0 m-0" />
              <p className="heading m-1" align="center">
                <span>Thread Tech</span>
              </p>
            </Grid>
            <Grid item onClick={handleGridClick}>
              <div className="d-flex m-2">
                <div className="userbox d-flex justify-content-center align-items-center p-2">
                  <img alt="" src={usericon} className="w-100 h-50 m-1" />
                </div>
                <div className="ps-1 closeCursor">
                  <div className="user-font">
                    {/* <span bsStyle="default"> */}
                    <span className="text-default">
                      {" "}
                      {namefn(
                        userDetails?.data?.username,
                        userDetails?.data?.login_type
                      ).length > 20 ? (
                        <div
                          className="user"
                          title={namefn(
                            userDetails?.data?.username,
                            userDetails?.data?.login_type
                          )}
                        >
                          {`${namefn(
                            userDetails?.data?.username,
                            userDetails?.data?.login_type
                          ).substring(0, 10)}...`}
                        </div>
                      ) : (
                        <>
                          {namefn(
                            userDetails?.data?.username,
                            userDetails?.data?.login_type
                          )}
                        </>
                      )}
                    </span>
                  </div>
                  {/* <div className="row userrole">
                  <span>{userRoleId}</span>
                </div> */}
                </div>
                <div className="d-flex justify-content-start ps-1">
                  <Dropdown show={showDropdown} onToggle={setShowDropdown}>
                    <Dropdown.Toggle
                      variant="white"
                      id="dropdown-basic"
                      className="custom-toggle"
                    ></Dropdown.Toggle>
                    {/* <Dropdown.Menu >
                    <Dropdown.Item onClick={handleShow}>Logout</Dropdown.Item>
                  </Dropdown.Menu> */}

                    <Dropdown.Menu style={{ padding: "0", overflow: "hidden" }}>
                      <Dropdown.Item
                        onClick={handleShow}
                        style={{
                          width: "100%",
                          textAlign: "left",
                          padding: "0.5rem 1rem",
                        }}
                        className="logout-button"
                      >
                        Logout
                      </Dropdown.Item>
                    </Dropdown.Menu>
                  </Dropdown>
                </div>
              </div>{" "}
            </Grid>
          </Grid>
        </Box>
      </div>
      <Modal
        show={showModal}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header>
          <div className="d-flex justify-content-between w-100">
            <span className="alert_text"> Alert</span>
            <span>
              {" "}
              <img
                src={Closeicon}
                style={{ cursor: "pointer", color: "#1f4246" }}
                alt="img"
                onClick={handleClose}
              ></img>
            </span>
          </div>
        </Modal.Header>
        <Modal.Body>Are you sure you want to logout?</Modal.Body>
        <Modal.Footer>
          <Button
            variant="secondary"
            onClick={handleClose}
            style={{ backgroundColor: "#ffffff", color: "#1f4246" }}
          >
            No
          </Button>
          <Button
            // variant="primary"
            onClick={handleLogout}
            style={{ backgroundColor: "#1f4246", color: "#ffffff" }}
          >
            Yes
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default Header;
