import { useDispatch } from "react-redux";
import {
  nextPage,
  prevPage,
  itemsPerPage,
} from "../../components/reducer/PaginationReducer";
import { useEffect, useState } from "react";
import "../../styles/pagination.css";

function Pagination(props) {
  const [formValues, setFormValues] = useState({
    NoOfPageItems: 10,
  });
  const [nextdisable, setNextDisable] = useState(false);
  const [prevdisable, setPrevDisable] = useState(false);
  const dispatch = useDispatch();
  const [currentPage, setCurrentPage] = useState(1);

  useEffect(() => {
    setCurrentPage(props.currentPage + 1);
    if (props.currentPage === 0) {
      setPrevDisable(true);
    }
  }, [props.currentPage]);
  // useEffect(() => {
  //   setCurrentPage(props.currentPage + 1);
  //   setPrevDisable(props.currentPage === 0);
  //   setNextDisable(props.currentPage === props.totalPages - 1);
  // }, [props.currentPage, props.totalPages]); // Updated to include props.totalPages

  const handleOnNext = () => {
    if (props.totalPages - 1 !== props.currentPage) {
      nextPage(dispatch);
      setPrevDisable(false);
    } else {
      setNextDisable(true);
    }
  };

  const handleOnPrev = () => {
    if (props.currentPage !== 0) {
      prevPage(dispatch);
      setNextDisable(false);
    } else {
      setPrevDisable(true);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormValues((formValues) => ({
      ...formValues,
      [name]: value,
    }));
    handleItemsPerPage(value);
  };

  const handleItemsPerPage = (value) => {
    itemsPerPage(dispatch, value);
  };
  // const handleItemsPerPage = (value) => {
  //   dispatch(itemsPerPage(Number(value))); // Ensure value is a number
  // };

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
    const newCurrentPage = pageNumber - 1;
    props.handlePageChange(newCurrentPage);
  };

  const renderPageNumbers = () => {
    const pageNumbers = [];
    for (let i = 1; i <= props.totalPages; i++) {
      pageNumbers.push(
        <span
          key={i}
          className={i === currentPage ? "page-item activePage" : "page-item"}
          onClick={() => handlePageChange(i)}
        >
          {i}
        </span>
      );
    }
    return pageNumbers;
  };

  let itemsList = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100];

  return (
    <>
      <div className="ng-container">
        <nav aria-label="Page navigation example" className="me-1 mb-5 ">
          <div
            className="buttonContainer"
            style={{ display: "flex", justifyContent: "space-between" }}
          >
            <div className="leftButtons" style={{ display: "flex" }}>
              <label className="me-3 mt-3 pagnation-font">Rows Per Page </label>
              <select
                style={{ marginLeft: "3px" }}
                className="pagination_dropdown form-select mt-2"
                name="NoOfPageItems"
                value={formValues.NoOfPageItems}
                // onChangeCapture={handleChange}
                onChange={handleChange}
              >
                {itemsList.map((val, index) => (
                  <option key={index} value={val}>
                    {val}
                  </option>
                ))}
              </select>
            </div>
            <div className="rightButtons me-3 mt-3" style={{ display: "flex" }}>
              <div onClick={handleOnPrev} style={{ marginLeft: "10px" }}>
                <span
                  className={
                    !prevdisable
                      ? "page-item previousButton ms-3"
                      : "page-item previousButtondisabled ms-3"
                  }
                  disabled={prevdisable ? "true" : ""}
                >
                  {"<"}
                </span>
              </div>
              {renderPageNumbers()}
              <div onClick={handleOnNext} style={{ marginLeft: "10px" }}>
                <span
                  className={
                    !nextdisable
                      ? "page-item nextButton ms-3"
                      : "page-item nextButtondisabled ms-3"
                  }
                  disabled={nextdisable ? "true" : ""}
                >
                  {">"}
                </span>
              </div>
            </div>
          </div>
        </nav>
      </div>
    </>
  );
}

export default Pagination;

// import React, { useEffect, useState } from "react";
// import { useDispatch, useSelector } from "react-redux";
// import {
//   nextPage,
//   prevPage,
//   setItemsPerPage,
//   setPagination,
// } from "../../components/reducer/PaginationReducer";
// import "../../styles/pagination.css";

// function Pagination(props) {
//   const [formValues, setFormValues] = useState({
//     NoOfPageItems: 10,
//   });
//   const [nextDisable, setNextDisable] = useState(false);
//   const [prevDisable, setPrevDisable] = useState(false);
//   const dispatch = useDispatch();

//   const { currentPage, totalPages } = useSelector((state) => {
//     console.log("state", state);
//     return state.pagination;
//   });

//   useEffect(() => {
//     setNextDisable(currentPage === totalPages - 1);
//     setPrevDisable(currentPage === 0);
//   }, [currentPage, totalPages]);

//   const handleOnNext = () => {
//     if (currentPage < totalPages - 1) {
//       dispatch(nextPage());
//     }
//   };

//   const handleOnPrev = () => {
//     if (currentPage > 0) {
//       dispatch(prevPage());
//     }
//   };

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setFormValues((prevValues) => ({
//       ...prevValues,
//       [name]: value,
//     }));
//     dispatch(setItemsPerPage(Number(value)));
//   };

//   const handlePageChange = (pageNumber) => {
//     dispatch(setPagination(pageNumber - 1, totalPages));
//   };

//   const renderPageNumbers = () => {
//     const pageNumbers = [];
//     for (let i = 1; i <= totalPages; i++) {
//       pageNumbers.push(
//         <span
//           key={i}
//           className={
//             i === currentPage + 1 ? "page-item activePage" : "page-item"
//           }
//           onClick={() => handlePageChange(i)}
//           tabIndex="0"
//         >
//           {i}
//         </span>
//       );
//     }
//     return pageNumbers;
//   };

//   const itemsList = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100];

//   return (
//     <div className="ng-container">
//       <nav aria-label="Page navigation example" className="me-1 mb-5">
//         <div
//           className="buttonContainer"
//           style={{ display: "flex", justifyContent: "space-between" }}
//         >
//           <div className="leftButtons" style={{ display: "flex" }}>
//             <label className="me-3 mt-3 pagnation-font">Rows Per Page </label>
//             <select
//               style={{ marginLeft: "3px" }}
//               className="pagination_dropdown form-select mt-2"
//               name="NoOfPageItems"
//               value={formValues.NoOfPageItems}
//               onChange={handleChange}
//             >
//               {itemsList.map((val, index) => (
//                 <option key={index} value={val}>
//                   {val}
//                 </option>
//               ))}
//             </select>
//           </div>
//           <div className="rightButtons me-3 mt-3" style={{ display: "flex" }}>
//             <div onClick={handleOnPrev} style={{ marginLeft: "10px" }}>
//               <span
//                 className={
//                   !prevDisable
//                     ? "page-item previousButton ms-3"
//                     : "page-item previousButtondisabled ms-3"
//                 }
//                 disabled={prevDisable}
//               >
//                 {"<"}
//               </span>
//             </div>
//             {renderPageNumbers()}
//             <div onClick={handleOnNext} style={{ marginLeft: "10px" }}>
//               <span
//                 className={
//                   !nextDisable
//                     ? "page-item nextButton ms-3"
//                     : "page-item nextButtondisabled ms-3"
//                 }
//                 disabled={nextDisable}
//               >
//                 {">"}
//               </span>
//             </div>
//           </div>
//         </div>
//       </nav>
//     </div>
//   );
// }

// export default Pagination;
