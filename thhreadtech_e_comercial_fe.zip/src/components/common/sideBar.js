import React, { useState } from "react";
import { Sidebar, Menu, MenuItem } from "react-pro-sidebar";
import { useDispatch } from "react-redux";
import "../../styles/common/sidebar.css";

import { useLocation } from "react-router-dom";
import { Link } from "react-router-dom";
import { Box, SvgIcon } from "@mui/material";

import CloseIcon from "@mui/icons-material/Close";

import ListItemText from "@mui/material/ListItemText";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemButton from "@mui/material/ListItemButton";
import DensityMediumIcon from "@mui/icons-material/DensityMedium";
import HomeOutlinedIcon from "@mui/icons-material/HomeOutlined";
// import PeopleOutlinedIcon from "@mui/icons-material/PeopleOutlined";
import PersonAddAltIcon from "@mui/icons-material/PersonAddAlt";
// import PersonIcon from "@mui/icons-material/Person";
import PersonIcon from "@mui/icons-material/AppRegistration";
import EngineeringIcon from "@mui/icons-material/Engineering";
import AddBoxIcon from "@mui/icons-material/AddBox";
import AddShoppingCartIcon from "@mui/icons-material/AddShoppingCart";

import { SIDEBAR_BACKGROUND, SIDEBAR_SELECTED } from "../../styles/colors";

import { SUCCESS, loginregex, Click_Away } from "../../Utils";
import secureLocalStorage from "react-secure-storage";
import loginImage from "../../Assets/images/bilvantistechnologies_logo.jpg";

function SideBar() {
  const dispatch = useDispatch();
  const location = useLocation();
  const pathname = location.pathname;

  const [collapsed, setCollapsed] = useState(true);
  const [toggled, setToggled] = useState(false);
  const [selectedPage, setSelectedPage] = useState(pathname);

  const handleCollapsedChange = (event, page) => {
    setSelectedPage(page);
    if (!collapsed) {
      setCollapsed(!collapsed);
    }
  };
  const handleToggleSidebar = (value) => {
    setToggled(value);
  };

  const handleOpenSidebar = () => {
    setCollapsed(!collapsed);
  };

  //   const roleDepartmentListfn = () => {
  //     console.log("roledepartment list..........");
  //     dispatch(rolesList()).then((response) => {
  //       if (response.data.status === SUCCESS) {
  //         secureLocalStorage.setItem(
  //           "role_lists",
  //           JSON.stringify(response?.data?.body)
  //         );
  //       }
  //     });
  //     dispatch(departmentList()).then((response) => {
  //       if (response.data.status === SUCCESS) {
  //         secureLocalStorage.setItem(
  //           "department_lists",
  //           JSON.stringify(response?.data?.body)
  //         );
  //       }
  //     });
  //     dispatch(gradesList()).then((response) => {
  //       if (response.data.status === SUCCESS) {
  //         secureLocalStorage.setItem(
  //           "grades_lists",
  //           JSON.stringify(response?.data?.body)
  //         );
  //       }
  //     });
  //   };

  //   roleDepartmentListfn();
  return (
    <div>
      <Sidebar
        backgroundColor={SIDEBAR_BACKGROUND}
        style={{
          height: "100%",
          position: "absolute",
          borderRight: "None",
        }}
        collapsed={collapsed}
        toggled={toggled}
        handleToggleSidebar={handleToggleSidebar}
        handleCollapsedChange={handleCollapsedChange}
        collapsedWidth="60px"
        width="220px"
      >
        <main>
          <Menu
            className="menu"
            renderMenuItemStyles={() => ({
              ".menu-anchor": {
                backgroundColor: SIDEBAR_BACKGROUND,
                "&:hover": {
                  backgroundColor: SIDEBAR_BACKGROUND,
                },
              },
            })}
          >
            {collapsed ? (
              <MenuItem
                icon={<DensityMediumIcon />}
                onClick={handleOpenSidebar}
                style={{
                  color: "white",
                  justifyContent: "center",
                  backgroundColor: SIDEBAR_BACKGROUND,
                }}
              ></MenuItem>
            ) : (
              <MenuItem
                suffix={<CloseIcon />}
                onClick={handleOpenSidebar}
                style={{
                  color: "white",
                  backgroundColor: SIDEBAR_BACKGROUND,
                }}
              >
                <h5 className="d-flex ms-2">
                  <img
                    alt="img"
                    src={loginImage}
                    className="logo-image p-0 m-0"
                  />
                  <p
                    className="heading m-1"
                    align="center"
                    style={{ color: "white" }}
                  >
                    <span>Bilvantis</span>
                  </p>
                </h5>
              </MenuItem>
            )}
            <Box>
              <ListItemButton
                component={Link}
                to={"/Home"}
                onClick={(event) => handleCollapsedChange(event, "/Home")}
                selected={selectedPage === "/Home"}
                sx={{
                  "&.Mui-selected": {
                    backgroundColor: SIDEBAR_SELECTED,
                  },
                  "&.Mui-focusVisible": {
                    backgroundColor: SIDEBAR_SELECTED,
                  },
                  "&.Mui-selected:hover": {
                    backgroundColor: SIDEBAR_SELECTED,
                  },
                }}
              >
                <ListItemIcon
                  sx={{
                    minWidth: "10px",
                    marginRight: "15px",
                  }}
                >
                  <HomeOutlinedIcon style={{ color: "#ffffff" }} />
                </ListItemIcon>
                <ListItemText
                  sx={{
                    flex: "None",
                    paddingLeft: "10px",
                  }}
                  primaryTypographyProps={{
                    fontFamily: "poppins",
                    color: "white",
                  }}
                  primary="Home"
                />
              </ListItemButton>

              <ListItemButton
                component={Link}
                to={"/customer"}
                onClick={(event) => handleCollapsedChange(event, "/customer")}
                selected={selectedPage === "/customer"}
                sx={{
                  "&.Mui-selected": {
                    backgroundColor: SIDEBAR_SELECTED,
                  },
                  "&.Mui-focusVisible": {
                    backgroundColor: SIDEBAR_SELECTED,
                  },
                  "&.Mui-selected:hover": {
                    backgroundColor: SIDEBAR_SELECTED,
                  },
                }}
              >
                <ListItemIcon
                  sx={{
                    minWidth: "10px",
                    marginRight: "15px",
                  }}
                >
                  <AddShoppingCartIcon style={{ color: "#ffffff" }} />
                </ListItemIcon>
                <ListItemText
                  sx={{
                    flex: "None",
                    paddingLeft: "10px",
                  }}
                  primaryTypographyProps={{
                    fontFamily: "poppins",
                    color: "white",
                  }}
                  primary="Customer"
                />
              </ListItemButton>

              <ListItemButton
                component={Link}
                to={"/measurement"}
                onClick={(event) =>
                  handleCollapsedChange(event, "/measurement")
                }
                selected={selectedPage === "/measurement"}
                sx={{
                  "&.Mui-selected": {
                    backgroundColor: SIDEBAR_SELECTED,
                  },
                  "&.Mui-focusVisible": {
                    backgroundColor: SIDEBAR_SELECTED,
                  },
                  "&.Mui-selected:hover": {
                    backgroundColor: SIDEBAR_SELECTED,
                  },
                }}
              >
                <ListItemIcon
                  sx={{
                    minWidth: "10px",
                    marginRight: "15px",
                  }}
                >
                  <PersonIcon style={{ color: "#ffffff" }} />
                </ListItemIcon>
                <ListItemText
                  sx={{
                    flex: "None",
                    paddingLeft: "10px",
                  }}
                  primaryTypographyProps={{
                    fontFamily: "poppins",
                    color: "white",
                  }}
                  primary="Measurements"
                />
              </ListItemButton>

              <ListItemButton
                component={Link}
                to={"/worker"}
                onClick={(event) => handleCollapsedChange(event, "/worker")}
                selected={selectedPage === "/worker"}
                sx={{
                  "&.Mui-selected": {
                    backgroundColor: SIDEBAR_SELECTED,
                  },
                  "&.Mui-focusVisible": {
                    backgroundColor: SIDEBAR_SELECTED,
                  },
                  "&.Mui-selected:hover": {
                    backgroundColor: SIDEBAR_SELECTED,
                  },
                }}
              >
                <ListItemIcon
                  sx={{
                    minWidth: "10px",
                    marginRight: "15px",
                  }}
                >
                  <EngineeringIcon style={{ color: "#ffffff" }} />
                </ListItemIcon>
                <ListItemText
                  sx={{
                    flex: "None",
                    paddingLeft: "10px",
                  }}
                  primaryTypographyProps={{
                    fontFamily: "poppins",
                    color: "white",
                  }}
                  primary="Worker"
                />
              </ListItemButton>

              <ListItemButton
                component={Link}
                to={"/test_path"}
                onClick={(event) => handleCollapsedChange(event, "/test_path")}
                selected={selectedPage === "/test_path"}
                sx={{
                  "&.Mui-selected": {
                    backgroundColor: SIDEBAR_SELECTED,
                  },
                  "&.Mui-focusVisible": {
                    backgroundColor: SIDEBAR_SELECTED,
                  },
                  "&.Mui-selected:hover": {
                    backgroundColor: SIDEBAR_SELECTED,
                  },
                }}
              >
                <ListItemIcon
                  sx={{
                    minWidth: "10px",
                    marginRight: "15px",
                  }}
                >
                  <AddBoxIcon style={{ color: "#ffffff" }} />
                </ListItemIcon>
                <ListItemText
                  sx={{
                    flex: "None",
                    paddingLeft: "10px",
                  }}
                  primaryTypographyProps={{
                    fontFamily: "poppins",
                    color: "white",
                  }}
                  primary="Test Page"
                />
              </ListItemButton>

              <ListItemButton
                component={Link}
                to={"/registration"}
                onClick={(event) =>
                  handleCollapsedChange(event, "/registration")
                }
                selected={selectedPage === "/registration"}
                sx={{
                  "&.Mui-selected": {
                    backgroundColor: SIDEBAR_SELECTED,
                  },
                  "&.Mui-focusVisible": {
                    backgroundColor: SIDEBAR_SELECTED,
                  },
                  "&.Mui-selected:hover": {
                    backgroundColor: SIDEBAR_SELECTED,
                  },
                }}
              >
                <ListItemIcon
                  sx={{
                    minWidth: "10px",
                    marginRight: "15px",
                  }}
                >
                  {/* <PeopleOutlinedIcon color="#ffffff" /> */}
                  <PersonAddAltIcon style={{ color: "#ffffff" }} />
                </ListItemIcon>
                <ListItemText
                  sx={{
                    flex: "None",
                    paddingLeft: "10px",
                  }}
                  primaryTypographyProps={{
                    fontFamily: "poppins",
                    color: "white",
                  }}
                  primary="Registration"
                />
              </ListItemButton>

              <ListItemButton
                component={Link}
                to={"/order"}
                onClick={(event) => handleCollapsedChange(event, "/order")}
                selected={selectedPage === "/order"}
                sx={{
                  "&.Mui-selected": {
                    backgroundColor: SIDEBAR_SELECTED,
                  },
                  "&.Mui-focusVisible": {
                    backgroundColor: SIDEBAR_SELECTED,
                  },
                  "&.Mui-selected:hover": {
                    backgroundColor: SIDEBAR_SELECTED,
                  },
                }}
              >
                <ListItemIcon
                  sx={{
                    minWidth: "10px",
                    marginRight: "15px",
                  }}
                >
                  <AddBoxIcon style={{ color: "#ffffff" }} />
                </ListItemIcon>
                <ListItemText
                  sx={{
                    flex: "None",
                    paddingLeft: "10px",
                  }}
                  primaryTypographyProps={{
                    fontFamily: "poppins",
                    color: "white",
                  }}
                  primary="Order"
                />
              </ListItemButton>
            </Box>
          </Menu>
        </main>
      </Sidebar>
    </div>
  );
}

export default SideBar;
