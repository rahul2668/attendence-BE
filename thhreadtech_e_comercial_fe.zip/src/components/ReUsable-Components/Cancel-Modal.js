import React from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import close from "../../Assets/images/close.svg";

const CancelModal = ({ show, handleClose, resetCancel }) => {
  return (
    <Modal show={show} onHide={handleClose} backdrop="static" keyboard={false}>
      <Modal.Header>
        <div className="d-flex justify-content-between w-100">
          <span className="alert_text"> Alert</span>
          <span>
            {" "}
            <img
              src={close}
              style={{ cursor: "pointer" }}
              alt="img"
              onClick={handleClose}
            ></img>
          </span>
        </div>
      </Modal.Header>
      <Modal.Body>
        <span className="alerttextInModal">
          By Canceling all the entered data will be lost, do you want to go
          ahead?
        </span>
      </Modal.Body>
      <Modal.Footer>
        <Button
          style={{
            borderColor: "#172D76",
            backgroundColor: "#ffffff",
            color: "#172D76",
          }}
          className=" mx-2 my-1 ps-4 pe-4"
          onClick={resetCancel}
        >
          Yes
        </Button>
        <Button
          style={{ backgroundColor: "#172D76" }}
          className=" ps-4 pe-4 me-2"
          onClick={handleClose}
        >
          No
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default CancelModal;
