// import React, { useState, useEffect } from "react";
// import "../styles/home.css";
// import { Link } from "react-router-dom";
// import Home from "./Home.js";
// import About from "./About.js";
// import Dashboard from "./Dashboard.js";
// import Contact from "./Contact.js";
// import Bilvantislogo from "../Bilvantis-logo-png.jpg";
// import MenuRoundedIcon from "@mui/icons-material/MenuRounded";
// //import axios from 'axios';

// export const Topbar = ({ drawerClickHandler }) => {
//   const [user, setUser] = useState("");
//   // const[role,setRole]=useState(null);
//   useEffect(() => {
//     const userData = localStorage.getItem("userData");
//     const userRole = JSON.parse(userData);
//     console.log("userrole", userRole);

//     const roleData = localStorage.getItem("rolesData");
//     const rolesArray = JSON.parse(roleData);
//     const role_id_int = +userRole.role_id_id;
//     // console.log("type of>>",typeof(role_id_int));
//     let roleName = "Role not found";
//     for (let i = 0; i < rolesArray.length; i++) {
//       // console.log("======", rolesArray[i].id === role_id_int);
//       if (rolesArray[i].id === role_id_int) {
//         //console.log("!!",rolesArray[i])
//         roleName = rolesArray[i].role;
//       }
//     }

//     console.log(roleName);

//     setUser(roleName);
//   }, []);

//   return (
//     <header className="toolbar">
//       <nav className="toolbar__navigation">
//         <div
//           style={{ fontSize: "25px", color: "blue" }}
//           onClick={drawerClickHandler}
//         >
//           <MenuRoundedIcon />
//         </div>
//         <div className="toolbar__logo">
//           <img src={Bilvantislogo} alt="" className="split" />
//         </div>
//         <div className="spacer" />
//         <div className="toolbar_navigation-items">
//           <ul>
//             <li>
//               <Link to="/Home">Home</Link>
//             </li>
//             <li>
//               <Link to="/About">About</Link>
//             </li>
//             <li>
//               <Link to="/Contact">Contact</Link>
//             </li>
//             <li>
//               <Link to="/Dashboard">Dashboard</Link>
//             </li>
//           </ul>
//         </div>
//         <div className="user-type">{user && <p>{user}</p>}</div>
//       </nav>
//     </header>
//   );
// };

// export default Topbar;
