import { paths } from "./Paths";
import { Navigate } from "react-router-dom";
import secureLocalStorage from "react-secure-storage";

const UnProtectedRoutes = ({ children }) => {
  const storedData = JSON.parse(secureLocalStorage.getItem("reactlocal"));
  const authenticated = storedData !== null ? storedData.headers.token : null;
  //   return authenticated ? <Navigate to={`${paths.hospital_staff}`} /> : children;
  return authenticated ? <Navigate to={`${paths.home}`} /> : children;
};

export default UnProtectedRoutes;
