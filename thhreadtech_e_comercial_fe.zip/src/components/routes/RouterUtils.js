import React from "react";
import ProtectedRoutes from "./ProtectedRoutes";
import UnProtectedRoutes from "./UnProtectedRoutes";
import Loading from "../../components/loaders/AppLoader";

export const getRouteElement = (Component, isProtected) => (
  <React.Suspense fallback={<Loading />}>
    {isProtected ? (
      <ProtectedRoutes>
        <Component />
      </ProtectedRoutes>
    ) : (
      <UnProtectedRoutes>
        <Component />
      </UnProtectedRoutes>
    )}
  </React.Suspense>
);
