export const USER_REGISTRATION = "/registration";
export const LOGIN = "/login";
export const HOME = "/Home";
export const PASSWORD_RESET =
  "/rest_password/${username}/${email}/${temp_password}";
export const FORGET_PASSWORD = "/forgot_password";
// export const RESET_PASSWORD = "/reset_password/${username}/${email}";
export const RESET_PASSWORD = "/reset_password/:username/:email";
export const CUSTOMER_PAGE = "/customer";
export const WORKER_PAGE = "/worker";
export const ORDER_PAGE = "/order";
export const PARTICULAR_Quantity_PAGE = "/particular_quantity";
export const TEST_PATH = "/test_path";
export const MEASUREMENT_PAGE = "/measurement";
// export const GET_BILLNO_FROM_CUSTOMER =
//   "/getBillNumber?customerId=${customerId}";
// export const GET_CUSTOMER_FROM_BILLNO =
//   "/getCustomerByBill?billNumber=${billNumber}";
