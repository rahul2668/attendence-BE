import { Navigate } from "react-router-dom";
import { paths } from "./Paths";
import secureLocalStorage from "react-secure-storage";

const ProtectedRoutes = ({ children }) => {
  const storedData = JSON.parse(secureLocalStorage.getItem("reactlocal"));
  //   console.log("0707070707", storedData.data);
  //   const authenticated = storedData !== null ? storedData.headers.token : null;
  const authenticated = storedData !== null ? storedData.data.token : null;
  return authenticated ? children : <Navigate to={`${paths.login}`} />;
};

export default ProtectedRoutes;
