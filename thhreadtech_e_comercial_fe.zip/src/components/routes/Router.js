import { paths } from "./Paths";
import { getRouteElement } from "./RouterUtils";
import { createBrowserRouter, Navigate, Outlet } from "react-router-dom";
import Layout from "../../Layout";
import Login from "../auth/LoginForm";
import ForgetPasswordForm from "../auth/ForgotPasswordForm";
import ErrorBoundary from "../common/error/ErrorBoundary";
import ResetPasswordForm from "../auth/ResetPasswordForm";
import RegistrationForm from "../pages/UserRegistrationForm";
import CustomerPage from "../pages/CustomerPage";
import WorkerPage from "../pages/WorkerPage";
import Home from "../pages/Home";
import OrderPage from "../pages/OrderPage";
import ParticularQuantityPage from "../pages/ParticularQuantityPage";
import TestPath from "../pages/TestPath";
import MeasurementPage from "../pages/MeasurementPage";

const ErrorBoundaryLayout = () => (
  <ErrorBoundary>
    <Outlet />
  </ErrorBoundary>
);

const routes = [
  { path: "", element: <Navigate to={paths.login} /> },
  { path: paths.login, element: getRouteElement(Login, false) },
  {
    path: paths.forgetPassword,
    element: getRouteElement(ForgetPasswordForm, false),
  },
  //   {
  //     path: paths.resetPassword,
  //     element: <ResetPasswordDynamic />,
  //     // element: getRouteElement(ResetPasswordForm, false),
  //     // element={<ResetPasswordForm />}
  //   },
  {
    path: paths.resetPassword,
    element: getRouteElement(ResetPasswordForm, false),
  },
  {
    path: "/",
    element: getRouteElement(Layout, true),
    children: [
      {
        path: paths.home,
        element: getRouteElement(Home, true),
      },
      {
        path: paths.register,
        element: getRouteElement(RegistrationForm, true),
      },
      {
        path: paths.customerPage,
        element: getRouteElement(CustomerPage, true),
      },
      {
        path: paths.workerPage,
        element: getRouteElement(WorkerPage, true),
      },
      {
        path: paths.measurementPage,
        element: getRouteElement(MeasurementPage, true),
      },
      {
        path: paths.particularQuantity,
        element: getRouteElement(ParticularQuantityPage, true),
      },
      {
        path: paths.testpath,
        element: getRouteElement(TestPath, true),
      },
      {
        path: paths.orderPage,
        element: getRouteElement(OrderPage, true),
      },
    ],
  },
];
const AppRouter = createBrowserRouter([
  {
    element: <ErrorBoundaryLayout />,
    children: routes,
  },
]);

export default AppRouter;
