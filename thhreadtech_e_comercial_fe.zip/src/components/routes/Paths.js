import {
  LOGIN,
  HOME,
  USER_REGISTRATION,
  PASSWORD_RESET,
  FORGET_PASSWORD,
  RESET_PASSWORD,
  CUSTOMER_PAGE,
  WORKER_PAGE,
  ORDER_PAGE,
  PARTICULAR_Quantity_PAGE,
  TEST_PATH,
  MEASUREMENT_PAGE,
} from "./Routes";

export const paths = {
  login: LOGIN,
  home: HOME,
  register: USER_REGISTRATION,
  ResetPassword: PASSWORD_RESET,
  forgetPassword: FORGET_PASSWORD,
  resetPassword: RESET_PASSWORD,
  customerPage: CUSTOMER_PAGE,
  workerPage: WORKER_PAGE,
  orderPage: ORDER_PAGE,
  particularQuantity: PARTICULAR_Quantity_PAGE,
  testpath: TEST_PATH,
  measurementPage: MEASUREMENT_PAGE,
};
