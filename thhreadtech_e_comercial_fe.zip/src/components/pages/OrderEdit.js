import { useState, useEffect } from "react";
import { connect, useDispatch } from "react-redux";
import group from "../../Assets/images/close.svg";
import CancelModal from "../../components/ReUsable-Components/Cancel-Modal";
import { staffregex } from "../../Utils.js";

function OrderEdit(props, { errorMessage, openCanvas, resetFormData }) {
  useEffect(() => {
    console.log("******** props", props.order_lists);
    setOrders(props?.order_lists);
  }, [props]);

  const initialValues = {
    bill_no: props ? props?.editDetails?.bill_no : "",
    customer: props ? props?.editDetails?.customer : "",
    particular_name: props ? props?.editDetails?.particular_name : "",
    qty: props ? props?.editDetails?.qty : "",
    design_pattern: props ? props?.editDetails?.design_pattern : "",
  };

  const [formValues, setFormValues] = useState(initialValues);
  const [formerrors, setFormErrors] = useState({});
  const [showCancelModal, setShowCancelModal] = useState(false);

  const dispatch = useDispatch();
  const handleCancelShowModal = () => {
    const nonEmptyValues = Object.values(formValues).filter(
      (value) => value !== ""
    );
    const enteredFieldsLength = nonEmptyValues.length;

    if (enteredFieldsLength > 0) {
      setShowCancelModal(true);
    }
  };

  useEffect(() => {
    if (resetFormData) {
      resetForm();
    }
  }, [resetFormData]);

  const handleCancel = () => {
    resetForm();
  };

  const handleCancelCloseModal = () => {
    setShowCancelModal(false);
  };

  const cancelfn = () => {
    window.location.reload();
  };

  const resetForm = () => {
    setFormErrors("");
    setFormValues(initialValues);
  };

  const [orders, setOrders] = useState([]);

  const handleChange = (e) => {
    const { name, value } = e.target;

    const regex = staffregex;

    if (value === "" || regex.test(value)) {
      setFormValues({ ...formValues, [name]: value });
    }

    setFormErrors((prevErrors) => ({
      ...prevErrors,
      [name]: undefined,
    }));
  };

  const handleRoleAndDepartment = (e) => {
    const { name, value } = e.target;
    setFormValues({ ...formValues, [name]: value });
    let roleFilter = orders?.filter(
      (orders) => orders?.bill_no === e.target.value
    );
  };

  return (
    <div className="ng-container d-flex justify-content-between w-100">
      <div className="w-100">
        <div className="d-flex justify-content-between align-items-center border border-end-0 border-top-0 border-bottom-1 border-start-0 p-2"></div>
        <CancelModal
          show={showCancelModal}
          handleClose={handleCancelCloseModal}
          resetCancel={cancelfn}
        />
        <span className="titleHeader mt-2">
          {props?.viewDetails ? (
            <>
              <div style={{ marginBottom: "5px" }}>
                Bill Number: {props.viewDetails.bill_no}
              </div>
              <div style={{ marginBottom: "5px" }}>
                Customer: {props.viewDetails.customer}
              </div>
              <div style={{ marginBottom: "5px" }}>
                Particular Name: {props.viewDetails.particular_name}
              </div>
              <div style={{ marginBottom: "5px" }}>
                Delivery Date: {props.viewDetails.delivery_date}
              </div>
              <div style={{ marginBottom: "5px" }}>
                Trial Date: {props.viewDetails.trail_date}
              </div>
            </>
          ) : (
            "Edit Order List"
          )}
        </span>
        {props?.viewDetails ||
        (formValues?.bill_no === props?.editDetails?.bill_no &&
          formValues?.customer === props?.editDetails?.customer &&
          formValues.particular_name === props?.editDetails?.particular_name &&
          formValues.qty === props?.editDetails?.qty &&
          formValues.design_pattern === props?.editDetails?.design_pattern) ? (
          <span
            className="me-0 mt-1 close_button"
            aria-label="Close"
            data-bs-dismiss="offcanvas"
          >
            {/* <img src={group} alt="img"></img> */}
          </span>
        ) : (
          <span
            className="me-0 mt-1 close_button"
            aria-label="Close"
            onClick={handleCancelShowModal}
          >
            {/* <img src={group} alt="img"></img> */}
          </span>
        )}

        <div>
          <div
            className="modalHeader w-100 border border-end-0 border-top-1 border-bottom-0 border-start-0 align-items-center d-flex justify-content-between p-4"
            style={{ position: "absolute", bottom: "0px" }}
          ></div>
          {props?.viewDetails ? (
            <div className="me-2 mb-2 position-absolute bottom-0  end-0">
              <button
                className="reset ps-3 pe-3 pt-1 pb-1"
                onClick={handleCancel}
                data-bs-dismiss="offcanvas"
                aria-label="Close"
              >
                {" "}
                Close
              </button>
            </div>
          ) : (
            <>
              <div>
                <button
                  className="reset ps-3 pe-3 pt-1 pb-1 ms-2 mb-2 position-absolute bottom-0 start-0"
                  onClick={resetForm}
                >
                  {" "}
                  Reset
                </button>
              </div>

              <div className="me-2 mb-2 position-absolute bottom-0 end-0">
                {formValues?.bill_no === props?.editDetails?.bill_no &&
                formValues?.customer === props?.editDetails?.customer &&
                formValues.particular_name ===
                  props?.editDetails?.particular_name &&
                formValues.qty === props?.editDetails?.qty &&
                formValues.design_pattern ===
                  props?.editDetails?.design_pattern ? (
                  <button
                    className="reset ps-3 pe-3 pt-1 pb-1"
                    data-bs-dismiss="offcanvas"
                    aria-label="Close"
                  >
                    {" "}
                    Cancel
                  </button>
                ) : (
                  <button
                    className="reset ps-3 pe-3 pt-1 pb-1"
                    onClick={handleCancelShowModal}
                    aria-label="Close"
                  >
                    {" "}
                    Cancel
                  </button>
                )}
                <button
                  className="submit ms-2 ps-3 pe-3 pt-1 pb-1"
                  // onClick={handleSubmit}
                >
                  {" "}
                  Save
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

const mapStateToProps = (state) => ({
  errorMessage: state.staffCreationReducerFn?.errorMessage,
  openCanvas: state.staffManagementReducerFn?.openCanvas,
  resetFormData: state.staffManagementReducerFn?.resetFormData,
});

export default connect(mapStateToProps)(OrderEdit);
