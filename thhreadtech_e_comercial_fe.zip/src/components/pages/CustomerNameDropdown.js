import React, { useState, useEffect } from "react";
import {
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  CircularProgress,
  Box,
} from "@mui/material";
import { SUCCESS } from "../../Utils.js";
import { useDispatch } from "react-redux";
// import { customerList } from "../../Actions/OrderPageAction";
import { customerList } from "../../Actions/MeasurementPageAction.js";

const CustomerDropdown = ({ onCustomerSelect, selectedCustomer }) => {
  const [loading, setLoading] = useState(true);
  const [customers, setCustomers] = useState([]);
  const [selectedCustomerName, setSelectedCustomerName] =
    useState(selectedCustomer);
  const [selectedCustomerId, setSelectedCustomerId] = useState("");
  const dispatch = useDispatch();

  useEffect(() => {
    setSelectedCustomerName(selectedCustomer);
  }, [selectedCustomer]);

  useEffect(() => {
    dispatch(customerList()).then(
      (response) => {
        if (response.data.status === SUCCESS) {
          setCustomers(response.data.body);
          setLoading(false);
        }
      },
      (error) => {
        console.error("Error fetching customer data:", error);
        setLoading(false);
      }
    );
  }, [dispatch]);

  const handleChange = (event) => {
    const selectedCustomer = customers.find(
      (customer) => customer.customername === event.target.value
    );
    setSelectedCustomerName(event.target.value);
    setSelectedCustomerId(selectedCustomer.id);
    onCustomerSelect(event.target.value, selectedCustomer.id);
  };

  return (
    <Box sx={{ minWidth: 200, marginTop: "10px", marginLeft: "40px" }}>
      <FormControl fullWidth>
        <InputLabel id="customer-select-label">Select Customer</InputLabel>
        {loading ? (
          <CircularProgress size={24} />
        ) : (
          <Select
            labelId="customer-select-label"
            id="customer-select"
            value={selectedCustomerName}
            label="Select Customer"
            onChange={handleChange}
          >
            {customers.map((customer) => (
              <MenuItem key={customer.id} value={customer.customername}>
                {customer.customername}
              </MenuItem>
            ))}
          </Select>
        )}
      </FormControl>
    </Box>
  );
};

export default CustomerDropdown;
