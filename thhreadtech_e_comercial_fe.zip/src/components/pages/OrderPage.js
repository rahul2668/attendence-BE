import React, { useState, useEffect } from "react";
// import "../../styles/home.css";
import { orderList, orderListSearch } from "../../Actions/OrderPageAction.js";
import OrderEdit from "../../components/pages/OrderEdit.js";
import { connect, useDispatch } from "react-redux";
import { SUCCESS } from "../../Utils.js";
import search from "../../Assets/images/search.svg";
import { ENTER_KEY, modalWidth, MIN_SEARCH_LENGTH } from "../../Utils.js";
import {
  OPEN_CANVAS,
  OPEN_MODAL,
  RESET_FORM,
} from "../../ActionTypes/OrderPageTypes.js";
import "../../styles/common/common.css";
import "../../styles/customerpage.css";
// import OrderEdit from "../../components/pages/OrderEdit.js";
import Pagination from "../../components/common/pagination.js";
import secureLocalStorage from "react-secure-storage";
import { pink } from "@mui/material/colors";
import { useNavigate } from "react-router-dom";
import Modal from "react-bootstrap/Modal";

import { Button } from "react-bootstrap";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import OverlayTrigger from "react-bootstrap/OverlayTrigger";
import Tooltip from "react-bootstrap/Tooltip";
// import "bootstrap/dist/css/bootstrap.min.css";
// import "bootstrap/dist/js/bootstrap.bundle.min.js";
import { Offcanvas } from "bootstrap";

let path = "/registration";
function OrderPage({
  currentPage,
  itemsPerPage,
  totalpages,
  openModal,
  openCanvas,
  closeModal,
}) {
  const [viewDetails, setViewDetails] = useState();
  const [revealedNumbers, setRevealedNumbers] = useState([]);
  const [errorMessage, setErrorMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [searchData, setSearchData] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [data, setData] = useState(null);
  const dispatch = useDispatch();
  const [successMessage, setSuccessMessage] = useState("");
  const [searchTermFromState, setsearchTermFromState] = useState({
    searchTerm: "",
  });
  const [showOffcanvas, setShowOffcanvas] = useState(false);
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState("");
  const [show, setShow] = useState(false);
  const [smShow, setSmShow] = useState(false);
  const [lgShow, setLgShow] = useState(false);

  const [editDetails, setEditDetails] = useState();

  const handleDeleteModalClose = () => setShowModal(false);

  const [bill_no, setBillNo] = useState();

  const [selectedCustomerId, setSelectedCustomerId] = useState("");
  let navigate = useNavigate();
  const handleOnChange = (e) => {
    const { name, value } = e.target;
    setsearchTermFromState({ ...searchTermFromState, [name]: value });
  };
  const handleClose = () => {
    dispatch({
      type: OPEN_CANVAS,
      payload: false,
    });
    dispatch({
      type: OPEN_MODAL,
      payload: false,
    });
    dispatch({
      type: RESET_FORM,
      payload: true,
    });
  };
  let order_lists = JSON.parse(secureLocalStorage.getItem("order_lists"));
  useEffect(() => {
    if (openModal === true) {
      setShow(true);
    } else {
      setShow(false);
    }
    const openOffcanvas = () => {
      const offcanvasElement = document.getElementById("addRole");
      const offcanvas = new Offcanvas(offcanvasElement);
      offcanvas.show();
    };
    if (openCanvas) {
      openOffcanvas();
    }
  }, [openModal, openCanvas, closeModal]);
  useEffect(() => {
    dispatch(orderList(currentPage, itemsPerPage)).then(
      (response) => {
        if (response?.data?.status === SUCCESS) {
          setData(response.data);
          sessionStorage.setItem(
            "order_lists",
            JSON.stringify(response.data.body)
          );

          console.log("88888", response.data);
        }
      },
      (error) => {
        setData(error);
      }
    );
  }, [dispatch, currentPage, itemsPerPage]);

  const handleCustomerSearch = () => {
    if (
      searchTermFromState?.searchTerm.length > MIN_SEARCH_LENGTH ||
      searchTermFromState?.searchTerm.length === 0
    ) {
      dispatch(orderListSearch(searchTermFromState?.searchTerm)).then(
        (response) => {
          if (response?.data?.status === SUCCESS) {
            console.log("-----", response.data);
            setData(response?.data);
          }
        },
        (error) => {
          setData(error);
        }
      );
    }
  };

  const handleViewClick = (index, phoneNumber) => {
    if (revealedNumbers[index]) {
      setRevealedNumbers((prevRevealedNumbers) => ({
        ...prevRevealedNumbers,
        [index]: "",
      }));
    } else {
      setRevealedNumbers((prevRevealedNumbers) => ({
        ...prevRevealedNumbers,
        [index]: phoneNumber,
      }));
    }
  };
  const [showModal, setShowModal] = useState(false);
  const handleSearchFocus = () => {
    setIsSearchFocused(true);
  };

  const handleSearchBlur = () => {
    setIsSearchFocused(false);
  };

  useEffect(() => {
    let searchId = document.getElementById("mySearchDiv");
    if (isSearchFocused) {
      searchId.setAttribute(
        "style",
        "border: 1px solid #00BDD0; box-shadow: 0 0 5px rgba(0, 189, 208, 1)"
      );
    } else {
      searchId.setAttribute("style", "border-color: none;");
    }
  }, [isSearchFocused]);

  const toggleOffcanvas = () => {
    setShowOffcanvas(!showOffcanvas);
  };
  const handleCancelChange = () => {
    dispatch({
      type: OPEN_CANVAS,
      payload: true,
    });
    dispatch({
      type: OPEN_MODAL,
      payload: false,
    });
  };

  const handleClick = () => {
    navigate(path);
  };
  const viewfn = (val) => {
    console.log("666666", val);
    setViewDetails(val);
  };
  const handleDeleteModalShow = () => {
    setShowModal(true);
  };

  const deletefn = (bill_no) => {
    setBillNo(bill_no);
    handleDeleteModalShow();
  };

  const editfn = (val) => {
    setEditDetails(val);
  };
  const handleDesignPatternChange = (e, index) => {
    const newValue = e.target.value;
    const newData = [...data.body];
    newData[index].design_pattern = newValue;
    setData({ ...data, body: newData });
  };

  return (
    <div className="">
      <div className="ng-container d-flex tableBackground">
        <div className="w-100 ms-5">
          <div className=" ms-1  ">
            <div className="d-flex justify-content-between  m-0 bg-white p-2">
              {openModal}
              <div className="d-flex">
                <div
                  className="ms-3 search align-items-center d-flex justify-content-center"
                  id="mySearchDiv"
                  onFocus={handleSearchFocus}
                  onBlur={handleSearchBlur}
                >
                  <img src={search} className="ms-2" alt="img" />
                  <input
                    type="text"
                    placeholder="Search"
                    className="search_input w-100 ms-2"
                    id="mySearchInput"
                    onChange={handleOnChange}
                    aria-label="Username"
                    aria-describedby="basic-addon1"
                    name="searchTerm"
                    value={searchTermFromState?.searchTerm}
                    onKeyDown={(event) => {
                      if (event.key === ENTER_KEY) {
                        handleCustomerSearch();
                      }
                    }}
                  />
                </div>
                <div>
                  <button
                    className="submit-button-create w-100 ms-2"
                    onClick={handleClick}
                  >
                    {" "}
                    + <span>create</span>
                  </button>
                </div>
              </div>
            </div>

            <div className="container-fluid mt-3">
              <div className=" mt-2 ms-4 ">
                <div className="row w-100">
                  <div className="scroll-container">
                    <table className="table m-0 p-0 w-100">
                      <thead className="table_head border border-top border-end-0  border-start-0 m-0 p-0 table_td w-100">
                        <tr>
                          <th className="labels ">
                            <div className="  d-flex justify-content-between text-center border mb-2  border-top-0 border-bottom-0 border-start-0">
                              <span className="text_font">Bill/Order No</span>
                            </div>
                          </th>
                          <th className="labels ">
                            <div className="  d-flex justify-content-between text-center border mb-2  border-top-0 border-bottom-0 border-start-0">
                              <span className="text_font">Customer Name</span>
                            </div>
                          </th>

                          <th className="labels">
                            <div className="  d-flex justify-content-between text-center border mb-2  border-top-0 border-bottom-0 border-start-0 ">
                              <span className="text_font">Particular Name</span>
                            </div>
                          </th>
                          <th className="labels ">
                            <div className=" d-flex justify-content-between  text-center border mb-2  border-top-0 border-bottom-0 border-start-0  ">
                              <span className="text_font">qty</span>
                            </div>
                          </th>
                          <th className="labels ">
                            <div className=" d-flex justify-content-between  text-center border mb-2 border-top-0 border-bottom-0 border-start-0  ">
                              <span className="text_font">Design Pattern</span>
                            </div>
                          </th>
                          <th className="labels ">
                            <div className=" d-flex justify-content-between  text-center border mb-2 border-top-0 border-bottom-0 border-start-0  ">
                              <span className="text_font">Order Status</span>
                            </div>
                          </th>
                          <th className="labels ">
                            <div className=" d-flex justify-content-between  text-center border mb-2 border-top-0 border-bottom-0 border-start-0  ">
                              <span className="text_font">Trial Status</span>
                            </div>
                          </th>
                          <th className="labels ">
                            <div className=" d-flex justify-content-between  text-center border mb-2 border-top-0 border-bottom-0 border-start-0  ">
                              <span className="text_font">Delivery Status</span>
                            </div>
                          </th>
                          {/* <th className="labels ">
                            <div className=" d-flex justify-content-between  text-center border mb-2 border-top-0 border-bottom-0 border-start-0  ">
                              <span className="text_font">Actions</span>
                            </div>
                          </th> */}
                        </tr>
                      </thead>

                      <tbody>
                        {data?.body?.length > 0 ? (
                          data?.body?.map((val, index) => (
                            <tr key={`${val.bill_no}-${index}`}>
                              <td
                                className="table_td"
                                data-bs-toggle="offcanvas"
                                data-bs-target="#viewOrders"
                                aria-controls="offcanvasRight"
                                onClick={() => viewfn(val)}
                              >
                                {val.bill_no}
                              </td>
                              <td
                                className="table_td"
                                data-bs-toggle="offcanvas"
                                data-bs-target="#viewOrders"
                                aria-controls="offcanvasRight"
                                onClick={() => viewfn(val)}
                              >
                                {val.customer}
                              </td>
                              <td
                                className="table_td"
                                data-bs-toggle="offcanvas"
                                data-bs-target="#viewOrders"
                                aria-controls="offcanvasRight"
                                onClick={() => viewfn(val)}
                              >
                                {val.particular_name}
                              </td>
                              <td
                                className="table_td"
                                data-bs-toggle="offcanvas"
                                data-bs-target="#viewOrders"
                                aria-controls="offcanvasRight"
                                onClick={() => viewfn(val)}
                              >
                                {val.qty}
                              </td>
                              {/* <td
                                className="table_td"
                              >
                                {val.design_pattern}
                              </td> */}
                              <td className="table_td">
                                {val.design_pattern}
                                <select
                                  className="custom-dropdown"
                                  // value={val.design_pattern}
                                  onClick={() => viewfn(val)}
                                  onChange={(e) =>
                                    handleDesignPatternChange(e, index)
                                  }
                                >
                                  <option value="Option 1">None</option>
                                  <option value="Option 2">Low</option>
                                  <option value="Option 3">Medium</option>
                                  <option value="Option 4">High</option>
                                </select>
                              </td>

                              <td
                                className="table_td"
                                data-bs-toggle="offcanvas"
                                data-bs-target="#viewOrders"
                                aria-controls="offcanvasRight"
                                // onClick={() => viewfn(val)}
                              >
                                {val.ord_status}
                              </td>
                              <td
                                className="table_td"
                                data-bs-toggle="offcanvas"
                                data-bs-target="#viewOrders"
                                aria-controls="offcanvasRight"
                                // onClick={() => viewfn(val)}
                              >
                                {val.trail_status}
                              </td>
                              <td
                                className="table_td"
                                data-bs-toggle="offcanvas"
                                data-bs-target="#viewOrders"
                                aria-controls="offcanvasRight"
                                // onClick={() => viewfn(val)}
                              >
                                {val.delivery_status}
                              </td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan={9}>
                              <div className="text-center">{errorMessage}</div>
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                  <Pagination
                    totalPages={totalpages}
                    currentPage={currentPage}
                  />
                  <div
                    className="offcanvas border offcanvas-end modalTopMargin"
                    style={{ width: "35%" }}
                    tabIndex="-1"
                    id="viewOrders"
                    aria-labelledby="offcanvasRightLabel"
                  >
                    <OrderEdit viewDetails={viewDetails} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const mapStateToProps = (state) => ({
  errorMessage: state.staffCreationReducerFn?.errorMessage,
  currentPage: state.PaginationReducer?.currentPage,
  itemsPerPage: state.PaginationReducer?.itemsPerPage,
  totalpages: state.PaginationReducer?.totalPages,
  openModal: state.staffManagementReducerFn?.openModal,
  openCanvas: state.staffManagementReducerFn?.openCanvas,
  closeModal: state.staffManagementReducerFn?.closeModal,
});

export default connect(mapStateToProps)(OrderPage);
