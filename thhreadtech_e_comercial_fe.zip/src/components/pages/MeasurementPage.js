// import React, { useState, useEffect } from "react";
// import "../../styles/orderpage.css";
// import axios from "axios";
// import { Modal, Button } from "react-bootstrap";
// import Backdrop from "@mui/material/Backdrop";
// import CircularProgress from "@mui/material/CircularProgress";
// import {
//   particularList,
//   BillNofromCustomer,
//   CustomerFromBillno,
//   saveParticularMeasurementAction,
//   fetchMeasurementData,
// } from "../../Actions/OrderPageAction";
// import { SUCCESS } from "../../Utils.js";
// import { connect, useDispatch } from "react-redux";
// import MeasurementImage from "../../Assets/images/reset2.avif";
// import TextField from "@mui/material/TextField";
// import CustomerDropdown from "./CustomerNameDropdown.js";
// import { prevPage } from "../reducer/PaginationReducer.js";

// const storedUsername = sessionStorage.getItem("username");

// function OrderPage({ username }) {
//   const [errorMessage, setErrorMessage] = useState("");
//   const [loading, setLoading] = useState(false);
//   const [data, setData] = useState([]);
//   const [selectedUser, setSelectedUser] = useState(null);
//   const [formData, setFormData] = useState({});
//   const [successMessage, setSuccessMessage] = useState("");
//   const [selectedCustomer, setSelectedCustomer] = useState("");
//   const [selectedCustomerId, setSelectedCustomerId] = useState("");
//   const [billNumber, setBillNumber] = useState("");
//   const dispatch = useDispatch();

//   useEffect(() => {
//     dispatch(particularList()).then(
//       (response) => {
//         if (response.data.status === SUCCESS) {
//           setData(response.data.body);
//           const initialFormData = {};
//           response.data.body.forEach((item) => {
//             initialFormData[item.particular_name] = {
//               particular_id: item.id,
//               fields: Array(10).fill(""),
//               textarea: "",
//             };
//           });
//           setFormData(initialFormData);
//         }
//       },
//       (error) => {
//         setData(error);
//       }
//     );
//   }, [dispatch]);

//   const handleClose = () => {
//     setErrorMessage("");
//   };

//   const handleCloseSuccess = () => {
//     setSuccessMessage("");
//   };

//   const handleButtonClick = (user) => {
//     console.log("-----w-w--w-w", user);
//     setSelectedUser(user);
//     if (!formData[user.particular_name]) {
//       setFormData((prevData) => ({
//         [user.particular_name]: {
//           particular_id: user.id,
//           fields: Array(10).fill(""),
//           textarea: "",
//         },
//       }));
//     }
//   };
//   const handleChange = (index, value) => {
//     if (selectedUser && formData[selectedUser.particular_name]) {
//       setFormData((prevData) => ({
//         ...prevData,
//         [selectedUser.particular_name]: {
//           ...prevData[selectedUser.particular_name],
//           fields: prevData[selectedUser.particular_name].fields.map((val, i) =>
//             i === index ? value : val
//           ),
//         },
//       }));
//     }
//   };

//   const handleTextareaChange = (value) => {
//     if (selectedUser) {
//       // Add null check for selectedUser
//       setFormData((prevData) => ({
//         ...prevData,
//         [selectedUser.particular_name]: {
//           ...prevData[selectedUser.particular_name],
//           textarea: value,
//         },
//       }));
//     }
//   };
//   const handleSubmit = () => {
//     setLoading(true);

//     const filteredFormData = Object.keys(formData).reduce((acc, key) => {
//       const { fields, textarea, id, measurement_id } = formData[key];
//       const hasNonEmptyField =
//         fields.some((value) => value !== "") || textarea !== "";
//       if (hasNonEmptyField) {
//         acc[key] = { ...formData[key], id, measurement_id };
//       }
//       return acc;
//     }, {});

//     const requestPayload = {
//       formData: filteredFormData,
//       selectedCustomer,
//       selectedCustomerId,
//     };
//     dispatch(saveParticularMeasurementAction(requestPayload))
//       .then((response) => {
//         setLoading(false);
//         if (response?.data?.status === SUCCESS) {
//           setSuccessMessage("Form data submitted successfully!");
//         }
//       })
//       .catch((error) => {
//         setLoading(false);
//         if (error.response && error.response.data) {
//           setErrorMessage("Failed to submit data. Please try again later.");
//         }
//       });
//   };

//   const handleCustomerSelect = (customerName, customerId) => {
//     setSelectedCustomer(customerName);
//     setSelectedCustomerId(customerId);
//     const billnoCustomer = {
//       customerId: customerId,
//     };
//     dispatch(BillNofromCustomer(billnoCustomer))
//       .then((response) => {
//         setBillNumber(response.data.billNumber);
//         fetchMeasurements(customerId);
//       })
//       .catch((error) => {
//         if (error.response && error.response.data) {
//           setErrorMessage(error.response.data);
//         } else {
//           setErrorMessage(
//             "An error occured while processing of reset password"
//           );
//         }
//         // setErrorMessage("Failed to fetch bill number.");
//       });
//   };
//   const fetchMeasurements = (customerId) => {
//     dispatch(fetchMeasurementData(customerId))
//       .then((response) => {
//         if (response.data.status === SUCCESS) {
//           const fetchedData = response.data.data;
//           setFormData((prevData) => {
//             const newData = { ...prevData };
//             Object.keys(fetchedData).forEach((key) => {
//               if (newData[key]) {
//                 newData[key].fields = fetchedData[key].fields;
//                 newData[key].textarea = fetchedData[key].textarea;
//               }
//             });
//             return newData;
//           });
//         }
//       })
//       .catch((error) => {
//         console.error("Failed to fetch measurements", error);
//       });
//   };

//   const handleBillNumberChange = (e) => {
//     setBillNumber(e.target.value);
//   };

//   const handleBillNumberBlur = async (e) => {
//     e.preventDefault();
//     const customerBillno = {
//       billNumber: billNumber,
//     };

//     dispatch(CustomerFromBillno(customerBillno))
//       .then((response) => {
//         setSelectedCustomer(response.data.customerName);
//         setSelectedCustomerId(response.data.customerId);
//         setErrorMessage("");
//         fetchMeasurements(response.data.customerId);
//       })
//       .catch((error) => {
//         if (error.response && error.response.data) {
//           setErrorMessage(error.response.data);
//         } else {
//           setErrorMessage(
//             "An error occured while processing of reset password"
//           );
//         }
//         setSelectedCustomer("");
//         setBillNumber("");
//       });
//   };
//   const handleKeyUp = (event) => {
//     if (event.key === "Enter") {
//       handleBillNumberBlur(event);
//     }
//   };

//   return (
//     <div className="">
//       <div className="ng-container d-flex tableBackground">
//         <div className="w-100 ms-5">
//           <div className=" ms-1  ">
//             <div className="d-flex justify-content-between  m-0 bg-white p-2">
//               <div className="d-flex">
//                 <div className="ms-3  align-items-center d-flex justify-content-center">
//                   <div>
//                     <TextField
//                       required
//                       id="outlined-required"
//                       label="Bill No"
//                       name="billNo"
//                       className="search_input w-100 ms-2"
//                       style={{ marginTop: "10px" }}
//                       value={billNumber}
//                       onChange={handleBillNumberChange}
//                       // onBlur={handleBillNumberBlur}
//                       onKeyUp={handleKeyUp}
//                     />
//                   </div>
//                   <div>
//                     <CustomerDropdown
//                       onCustomerSelect={handleCustomerSelect}
//                       selectedCustomer={selectedCustomer}
//                     />{" "}
//                   </div>
//                   {/* <div>
//                     <TextField
//                       required
//                       id="outlined-required"
//                       label="Customer Name"
//                       name="username"
//                       value={storedUsername}
//                       style={{
//                         marginTop: "10px",
//                         marginLeft: "40px",
//                       }}
//                     />
//                   </div> */}

//                   <div>
//                     <button className="submit-button" onClick={handleSubmit}>
//                       Generate
//                     </button>
//                   </div>
//                   <div>
//                     <button className="submit-button" onClick={handleSubmit}>
//                       Save
//                     </button>
//                   </div>
//                 </div>
//               </div>
//             </div>
//             <div className="d-flex">
//               <div
//                 className="d-flex justify-content-between  m-1 bg-white p-2"
//                 style={{ marginTop: "10px", width: "100%" }}
//               >
//                 <div className="container-fluid mt-3">
//                   <div className=" mt-2 ms-4 ">
//                     <div className="row order_data">
//                       <div className="col-4 left-column">
//                         <h1>Particulars:</h1>
//                         <div className="buttons-container">
//                           {data.map((item) => (
//                             <button
//                               key={item.id}
//                               className="data-button"
//                               onClick={() => handleButtonClick(item)}
//                             >
//                               {item.particular_name}
//                             </button>
//                           ))}
//                         </div>
//                       </div>
//                       <div className="col-3 right-column">
//                         {selectedUser && (
//                           <div className="form-container-data">
//                             <h2>{selectedUser.particular_name} :</h2>
//                             <div className="inputs-grid">
//                               {/* {formData[
//                                 selectedUser.particular_name
//                               ]?.fields.map((value, index) => (
//                                 <input
//                                   key={index}
//                                   type="text"
//                                   placeholder={`${index + 1}`}
//                                   value={value}
//                                   onChange={(e) =>
//                                     handleChange(index, e.target.value)
//                                   }
//                                 />
//                               ))} */}
//                               {Array.from(Array(10).keys()).map((index) => (
//                                 <input
//                                   key={index}
//                                   type="text"
//                                   placeholder={`${index + 1}`}
//                                   value={
//                                     formData[selectedUser.particular_name]
//                                       ?.fields[index] || ""
//                                   }
//                                   onChange={(e) =>
//                                     handleChange(index, e.target.value)
//                                   }
//                                 />
//                               ))}
//                             </div>
//                             <h5>Comments:</h5>
//                             <textarea
//                               className="form-control"
//                               id="exampleFormControlTextarea1"
//                               rows="5"
//                               value={
//                                 formData[selectedUser.particular_name]
//                                   ?.textarea || ""
//                               }
//                               onChange={(e) =>
//                                 handleTextareaChange(e.target.value)
//                               }
//                               style={{ width: "75%" }}
//                             ></textarea>
//                           </div>
//                         )}
//                       </div>
//                       <div className="col-5 measure-image" align="center">
//                         <img
//                           src={MeasurementImage}
//                           alt="Right Image"
//                           align="center"
//                         />
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>
//             <div>
//               <Backdrop
//                 sx={{
//                   color: "#fff",
//                   zIndex: (theme) => theme.zIndex.drawer + 1,
//                 }}
//                 open={loading}
//               >
//                 <CircularProgress color="inherit" />
//               </Backdrop>
//             </div>
//             <div>
//               <Modal show={!!errorMessage} onHide={handleClose} centered>
//                 <Modal.Header closeButton={false}></Modal.Header>
//                 <Modal.Body>{errorMessage}</Modal.Body>
//                 <Modal.Footer>
//                   <Button variant="secondary" onClick={handleClose}>
//                     Close
//                   </Button>
//                 </Modal.Footer>
//               </Modal>
//             </div>
//             <div>
//               <Modal
//                 show={!!successMessage}
//                 onHide={handleCloseSuccess}
//                 centered
//               >
//                 <Modal.Header closeButton={false}></Modal.Header>
//                 <Modal.Body>{successMessage}</Modal.Body>
//                 <Modal.Footer>
//                   <Button variant="secondary" onClick={handleCloseSuccess}>
//                     Close
//                   </Button>
//                 </Modal.Footer>
//               </Modal>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// }

// const mapStateToProps = (state) => ({
//   errorMessage: state.staffCreationReducerFn?.errorMessage,
//   username: state.loginReducer.username,
// });

// export default connect(mapStateToProps)(OrderPage);

import React, { useState, useEffect } from "react";
import "../../styles/measurementpage.css";
import axios from "axios";
import { Modal, Button } from "react-bootstrap";
import Backdrop from "@mui/material/Backdrop";
import CircularProgress from "@mui/material/CircularProgress";
import {
  particularList,
  BillNofromCustomer,
  CustomerFromBillno,
  saveParticularMeasurementAction,
  fetchMeasurementData,
} from "../../Actions/MeasurementPageAction.js";
import { SUCCESS } from "../../Utils.js";
import { connect, useDispatch } from "react-redux";
import MeasurementImage from "../../Assets/images/reset2.avif";
import TextField from "@mui/material/TextField";
import CustomerDropdown from "./CustomerNameDropdown.js";

const storedUsername = sessionStorage.getItem("username");

function MeasurementPage({ username }) {
  const [errorMessage, setErrorMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [formData, setFormData] = useState({});
  const [successMessage, setSuccessMessage] = useState("");
  const [selectedCustomer, setSelectedCustomer] = useState("");
  const [selectedCustomerId, setSelectedCustomerId] = useState("");
  const [billNumber, setBillNumber] = useState("");
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(particularList()).then(
      (response) => {
        if (response.data.status === SUCCESS) {
          setData(response.data.body);
          const initialFormData = {};
          response.data.body.forEach((item) => {
            initialFormData[item.particular_name] = {
              particular_id: item.id,
              fields: Array(10).fill(""),
              textarea: "",
              measurement_id: null,
            };
          });
          setFormData(initialFormData);
        }
      },
      (error) => {
        setData(error);
      }
    );
  }, [dispatch]);

  const handleClose = () => {
    setErrorMessage("");
  };

  const handleCloseSuccess = () => {
    setSuccessMessage("");
  };

  const handleButtonClick = (user) => {
    console.log("Selected Particular:", user);
    setSelectedUser(user);
    if (!formData[user.particular_name]) {
      setFormData((prevData) => ({
        ...prevData,
        [user.particular_name]: {
          particular_id: user.id,
          fields: Array(10).fill(""),
          textarea: "",
          measurement_id: null,
        },
      }));
    }
  };

  const handleChange = (index, value) => {
    if (selectedUser && formData[selectedUser.particular_name]) {
      setFormData((prevData) => ({
        ...prevData,
        [selectedUser.particular_name]: {
          ...prevData[selectedUser.particular_name],
          fields: prevData[selectedUser.particular_name].fields.map((val, i) =>
            i === index ? value : val
          ),
        },
      }));
    }
  };

  const handleTextareaChange = (value) => {
    if (selectedUser) {
      setFormData((prevData) => ({
        ...prevData,
        [selectedUser.particular_name]: {
          ...prevData[selectedUser.particular_name],
          textarea: value,
        },
      }));
    }
  };

  const handleSubmit = () => {
    setLoading(true);

    const filteredFormData = Object.keys(formData).reduce((acc, key) => {
      const { fields, textarea, id, measurement_id } = formData[key];
      const hasNonEmptyField =
        fields.some((value) => value !== "") || textarea !== "";
      if (hasNonEmptyField) {
        acc[key] = { ...formData[key], id, measurement_id };
      }
      return acc;
    }, {});

    const requestPayload = {
      formData: filteredFormData,
      selectedCustomer,
      selectedCustomerId,
    };

    dispatch(saveParticularMeasurementAction(requestPayload))
      .then((response) => {
        setLoading(false);
        if (response?.data?.status === SUCCESS) {
          setSuccessMessage("Form data submitted successfully!");
        }
      })
      .catch((error) => {
        setLoading(false);
        if (error.response && error.response.data) {
          setErrorMessage("Failed to submit data. Please try again later.");
        }
      });
  };

  const handleCustomerSelect = (customerName, customerId) => {
    setSelectedCustomer(customerName);
    setSelectedCustomerId(customerId);
    const billnoCustomer = { customerId: customerId };

    dispatch(BillNofromCustomer(billnoCustomer))
      .then((response) => {
        setBillNumber(response.data.billNumber);
        fetchMeasurements(customerId);
        // setFormData({})
      })
      .catch((error) => {
        if (error.response && error.response.data) {
          setErrorMessage(error.response.data);
        } else {
          setErrorMessage("An error occurred while processing the request.");
        }
      });
  };
  const fetchMeasurements = (customerId) => {
    dispatch(fetchMeasurementData(customerId))
      .then((response) => {
        if (response.data.status === SUCCESS) {
          const fetchedData = response.data.data;

          setFormData((prevData) => {
            const newData = { ...prevData };

            // Clear out formData for particulars not present in fetched data
            Object.keys(newData).forEach((key) => {
              if (!fetchedData[key]) {
                newData[key] = {
                  particular_id: newData[key].particular_id,
                  fields: Array(10).fill(""),
                  textarea: "",
                  measurement_id: null,
                };
              }
            });

            // Update formData with fetched values
            Object.keys(fetchedData).forEach((key) => {
              if (newData[key]) {
                newData[key].fields = fetchedData[key].fields;
                newData[key].textarea = fetchedData[key].textarea;
                newData[key].measurement_id = fetchedData[key].measurement_id;
              }
            });

            return newData;
          });
        }
      })
      .catch((error) => {
        console.error("Failed to fetch measurements", error);
      });
  };

  const handleBillNumberChange = (e) => {
    setBillNumber(e.target.value);
  };

  const handleBillNumberBlur = (e) => {
    e.preventDefault();
    const customerBillno = { billNumber: billNumber };

    dispatch(CustomerFromBillno(customerBillno))
      .then((response) => {
        setSelectedCustomer(response.data.customerName);
        setSelectedCustomerId(response.data.customerId);
        setErrorMessage("");
        fetchMeasurements(response.data.customerId);
        // setFormData({});
      })
      .catch((error) => {
        if (error.response && error.response.data) {
          setErrorMessage(error.response.data);
        } else {
          setErrorMessage("An error occurred while processing the request.");
        }
        setSelectedCustomer("");
        setBillNumber("");
      });
  };

  const handleKeyUp = (event) => {
    if (event.key === "Enter") {
      handleBillNumberBlur(event);
    }
  };

  return (
    <div className="">
      <div className="ng-container d-flex tableBackground">
        <div className="w-100 ms-5">
          <div className="ms-1">
            <div className="d-flex justify-content-between m-0 bg-white p-2">
              <div className="d-flex">
                <div className="ms-3 align-items-center d-flex justify-content-center">
                  <div>
                    <TextField
                      required
                      id="outlined-required"
                      label="Bill No"
                      name="billNo"
                      className="search_input w-100 ms-2"
                      style={{ marginTop: "10px" }}
                      value={billNumber}
                      onChange={handleBillNumberChange}
                      onKeyUp={handleKeyUp}
                    />
                  </div>
                  <div>
                    <CustomerDropdown
                      onCustomerSelect={handleCustomerSelect}
                      selectedCustomer={selectedCustomer}
                    />
                  </div>
                  {/* <div>
                    <button className="submit-button" onClick={handleSubmit}>
                      Generate
                    </button>
                  </div> */}
                  <div>
                    <button className="submit-button" onClick={handleSubmit}>
                      Save
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <div className="d-flex">
              <div
                className="d-flex justify-content-between m-1 bg-white p-2"
                style={{ marginTop: "10px", width: "100%" }}
              >
                <div className="container-fluid mt-3">
                  <div className="mt-2 ms-4">
                    <div className="row order_data">
                      <div className="col-4 left-column">
                        <h1>Particulars:</h1>
                        <div className="buttons-container">
                          {data.map((item) => (
                            <button
                              key={item.id}
                              className="data-button"
                              onClick={() => handleButtonClick(item)}
                            >
                              {item.particular_name}
                            </button>
                          ))}
                        </div>
                      </div>
                      <div className="col-3 right-column">
                        {selectedUser && (
                          <div className="form-container-data">
                            <h2>{selectedUser.particular_name} :</h2>
                            <div className="inputs-grid">
                              {Array.from(Array(10).keys()).map((index) => (
                                <input
                                  key={index}
                                  type="text"
                                  placeholder={`${index + 1}`}
                                  value={
                                    formData[selectedUser.particular_name]
                                      ?.fields[index] || ""
                                  }
                                  onChange={(e) =>
                                    handleChange(index, e.target.value)
                                  }
                                />
                              ))}
                            </div>
                            <h5>Comments:</h5>
                            <textarea
                              className="form-control"
                              id="exampleFormControlTextarea1"
                              rows="5"
                              value={
                                formData[selectedUser.particular_name]
                                  ?.textarea || ""
                              }
                              onChange={(e) =>
                                handleTextareaChange(e.target.value)
                              }
                              style={{ width: "75%" }}
                            ></textarea>
                          </div>
                        )}
                      </div>
                      <div className="col-5 measure-image" align="center">
                        <img
                          src={MeasurementImage}
                          alt="Right Image"
                          align="center"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <Backdrop
                sx={{
                  color: "#fff",
                  zIndex: (theme) => theme.zIndex.drawer + 1,
                }}
                open={loading}
              >
                <CircularProgress color="inherit" />
              </Backdrop>
            </div>
            <div>
              <Modal show={!!errorMessage} onHide={handleClose} centered>
                <Modal.Header closeButton={false}></Modal.Header>
                <Modal.Body>{errorMessage}</Modal.Body>
                <Modal.Footer>
                  <Button variant="secondary" onClick={handleClose}>
                    Close
                  </Button>
                </Modal.Footer>
              </Modal>
            </div>
            <div>
              <Modal
                show={!!successMessage}
                onHide={handleCloseSuccess}
                centered
              >
                <Modal.Header closeButton={false}></Modal.Header>
                <Modal.Body>{successMessage}</Modal.Body>
                <Modal.Footer>
                  <Button variant="secondary" onClick={handleCloseSuccess}>
                    Close
                  </Button>
                </Modal.Footer>
              </Modal>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const mapStateToProps = (state) => ({
  errorMessage: state.staffCreationReducerFn?.errorMessage,
  username: state.loginReducer.username,
});

export default connect(mapStateToProps)(MeasurementPage);
