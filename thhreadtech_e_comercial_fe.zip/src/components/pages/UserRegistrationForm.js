import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import MenuItem from "@mui/material/MenuItem";
import BASE_URL from "../config.js";
import { Modal, Button } from "react-bootstrap";
import { useDispatch } from "react-redux";
// import { useNavigate } from "react-router-dom/dist/index.js";
import { useNavigate } from "react-router-dom";
import { RegistrationRequestAction } from "../../Actions/RegistrationAction.js";
import secureLocalStorage from "react-secure-storage";
import { SUCCESS } from "../../Utils.js";
import Backdrop from "@mui/material/Backdrop";
import CircularProgress from "@mui/material/CircularProgress";
import RegistrationServices from "../../Services/RegistrationService.js";
import Header from "../common/header.js";
import sideBar from "../common/sideBar.js";
import RegisterImage from "../../Assets/images/register.avif";
import "../../styles/common/registrationform.css";
import HowToRegIcon from "@mui/icons-material/HowToReg";

const RegistrationForm = () => {
  const dispatch = useDispatch();
  let navigate = useNavigate();
  const [errorMessage, setErrorMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [mobile_no, setMobileNo] = useState("");
  const [address, setAddress] = useState("");
  const [role, setRole] = useState("");
  const [roles, setRoles] = useState([]);
  const [] = useState("");
  const [formErrors, setFormErrors] = useState({});
  const [successMessage, setSuccessMessage] = useState("");

  useEffect(() => {
    const fetchRoles = async () => {
      try {
        const response = await RegistrationServices.roleListService();
        setRoles(response.data);
      } catch (error) {
        console.error("Error fetching roles:", error);
      }
    };

    fetchRoles();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === "username") setUsername(value);
    if (name === "email") setEmail(value);
    if (name === "mobile_no") setMobileNo(value);
    if (name === "address") setAddress(value);
    if (name === "role") setRole(value);
    setFormErrors({ ...formErrors, [name]: "" });
  };

  const submitHandler = async (e) => {
    e.preventDefault();
    setLoading(true);
    const registerdata = {
      username: username,
      email: email,
      mobile_no: mobile_no,
      address: address,
      role: role,
    };
    dispatch(RegistrationRequestAction(registerdata))
      .then((response) => {
        setLoading(false);
        if (response?.data?.status === SUCCESS) {
          secureLocalStorage.setItem("reactlocal", JSON.stringify(response));

          setSuccessMessage(response.data.message);
        }
      })
      .catch((error) => {
        setLoading(false);
        if (error.response && error.response.data) {
          setErrorMessage(error.response.data);
        } else {
          console.log(error.response);
          setErrorMessage(
            "An error occurred while processing your request. Please try again later."
          );
        }
        console.log(error);
      });
  };

  const handleClose = () => {
    setErrorMessage("");
  };
  const handleCloseSuccess = () => {
    setSuccessMessage("");
    // navigate(path);
  };

  return (
    <div className="ng-container d-flex RegistrationBackground">
      <div className="registration-container">
        {/* <div className="ms-2 ">
        <Header />
      </div> */}
        <div className="left-image">
          <img src={RegisterImage} alt="Right Image" />
        </div>
        <div className="form-container">
          <div className="container" align="center">
            <HowToRegIcon sx={{ fontSize: 40, marginRight: "10px" }} />
            <h2>Registration Form</h2>

            <Box
              sx={{
                "& .MuiTextField-root": { m: 1, width: "25ch" },
              }}
              noValidate
              autoComplete="off"
            >
              <form>
                <div>
                  <TextField
                    id="outlined-required"
                    required
                    select
                    label="Select Role"
                    name="role"
                    value={role}
                    size="small"
                    onChange={handleChange}
                  >
                    {roles.map((role) => (
                      <MenuItem key={role.id} value={role.role}>
                        {role.role}
                      </MenuItem>
                    ))}
                  </TextField>
                </div>
                <div>
                  <TextField
                    required
                    id="outlined-required"
                    label="User Name"
                    name="username"
                    value={username}
                    className="text_input"
                    onChange={handleChange}
                  />
                </div>
                <div>
                  <TextField
                    required
                    id="outlined-required"
                    label="Email"
                    name="email"
                    value={email}
                    className="text_input"
                    onChange={handleChange}
                  />
                </div>
                <div>
                  <TextField
                    required
                    id="outlined-required"
                    label="Mobile"
                    name="mobile_no"
                    value={mobile_no}
                    className="text_input"
                    onChange={handleChange}
                  />
                </div>

                <div>
                  <TextField
                    required
                    id="outlined-required"
                    label="Address"
                    name="address"
                    value={address}
                    className="text_input"
                    onChange={handleChange}
                  />
                </div>

                <input
                  type="submit"
                  value="Register"
                  className="btn"
                  onClick={submitHandler}
                  style={{ backgroundColor: "#1f4246" }}
                />
              </form>
              <div>
                <Backdrop
                  sx={{
                    color: "#fff",
                    zIndex: (theme) => theme.zIndex.drawer + 1,
                  }}
                  open={loading}
                >
                  <CircularProgress color="inherit" />
                </Backdrop>
              </div>

              <div>
                <Modal show={!!errorMessage} onHide={handleClose} centered>
                  <Modal.Header closeButton={false}></Modal.Header>
                  <Modal.Body>{errorMessage}</Modal.Body>
                  <Modal.Footer>
                    <Button variant="secondary" onClick={handleClose}>
                      Close
                    </Button>
                  </Modal.Footer>
                </Modal>
              </div>
              <div>
                <Modal
                  show={!!successMessage}
                  onHide={handleCloseSuccess}
                  centered
                >
                  <Modal.Header closeButton={false}></Modal.Header>
                  <Modal.Body>{successMessage}</Modal.Body>
                  <Modal.Footer>
                    <Button variant="secondary" onClick={handleCloseSuccess}>
                      Close
                    </Button>
                  </Modal.Footer>
                </Modal>
              </div>
            </Box>
          </div>
        </div>{" "}
      </div>
    </div>
  );
};

export default RegistrationForm;
