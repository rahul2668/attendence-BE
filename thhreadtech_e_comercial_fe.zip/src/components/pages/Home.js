// import { useEffect, useState } from "react";

// function Home({ errorMessage }) {
//   // const [show, setShow] = useState(false);
//   // const [showModal, setShowModal] = useState(false);
// }

// export default Home;
import { useEffect, useState } from "react";
import "../../styles/home.css";
import { SIDEBAR_BACKGROUND } from "../../styles/colors";

function Home({ errorMessage }) {
  const storedData = sessionStorage.getItem("username");
  console.log("434343", storedData);
  return (
    <div className=" ng-container d-flex homepageBackground">
      <h1>
        {/* {" "} */}
        Hi
        <span style={{ color: SIDEBAR_BACKGROUND }}> {storedData}</span>{" "}
      </h1>
    </div>
  );
}

export default Home;
