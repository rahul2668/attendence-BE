import React, { useState, useEffect, useRef } from "react";
import "../../styles/particularquantity.css";
import axios from "axios";
import { Modal, Button } from "react-bootstrap";
import Backdrop from "@mui/material/Backdrop";
import CircularProgress from "@mui/material/CircularProgress";
import { particularList } from "../../Actions/MeasurementPageAction.js";
import { ParticularOrderRequestAction } from "../../Actions/CustomerPageAction.js";
import { SUCCESS } from "../../Utils.js";
import { useDispatch } from "react-redux";
import { useReactToPrint } from "react-to-print";
import RegisterImage from "../../Assets/images/quality.avif";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

const loginUserId = sessionStorage.getItem("user_id");
function ParticularsQuantityTotal({
  onSuccess,
  selectedCustomer,
  selectedCustomerId,
}) {
  const [errorMessage, setErrorMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [successMessage, setSuccessMessage] = useState("");
  const dispatch = useDispatch();
  const [quantities, setQuantities] = useState({});
  const [totalAmount, setTotalAmount] = useState(0);
  const printRef = useRef();
  const [tableData, setTableData] = useState([]);
  const [orderDates, setOrderDates] = useState({});
  const [trailDates, setTrailDates] = useState({});
  const [deliveryDate, setDeliveryDate] = useState(null);

  useEffect(() => {
    dispatch(particularList()).then(
      (response) => {
        if (response.data.status === SUCCESS) {
          setData(response.data.body);
          const initialQuantities = {};
          response.data.body.forEach((item) => {
            initialQuantities[item.id] = {
              quantity: 0,
              amount: 0,
              price: item.customer_price,
            };
          });
          setQuantities(initialQuantities);
        }
      },
      (error) => {
        setData(error);
        // console.error("error----", error);
      }
    );
  }, [dispatch]);

  const handleClose = () => {
    setErrorMessage("");
  };

  const handleCloseSuccess = () => {
    setSuccessMessage("");
    // setQuantities({});
    // setOrderDates({});
    // setTrailDates({});
    // setDeliveryDates({});
    // setTotalAmount(0);
    // setTableData([]);

    // onSuccess();
  };

  const handleButtonClick = (user) => {
    setSelectedUser(user);
  };

  const handleQuantityChange = (id, change) => {
    setQuantities((prevQuantities) => {
      const newQuantity = Math.max(0, prevQuantities[id].quantity + change);
      const newAmount = newQuantity * prevQuantities[id].price;
      const updatedQuantities = {
        ...prevQuantities,
        [id]: {
          ...prevQuantities[id],
          quantity: newQuantity,
          amount: newAmount,
        },
      };
      const totalAmount = Object.values(updatedQuantities).reduce(
        (total, item) => total + item.amount,
        0
      );
      setTotalAmount(totalAmount);

      const updatedTableData = [];
      Object.entries(updatedQuantities).forEach(([key, value]) => {
        for (let i = 0; i < value.quantity; i++) {
          updatedTableData.push({
            id: key,
            particular_name: data.find((item) => item.id === parseInt(key))
              .particular_name,
            quantity: 1,
            qty_total_amount: value.price,
            trail_date: trailDates[key],
            delivery_date: deliveryDate,
          });
        }
      });

      setTableData(updatedTableData);

      return updatedQuantities;
    });
  };

  const formatDate = (date) => {
    if (!date) return null;

    return new Date(date).toISOString().split("T")[0];
  };
  const handleOrderDateChange = (date) => {
    setOrderDates({
      global: date,
    });
  };

  const handleTrailDateChange = (date, id, index) => {
    setTrailDates((prevData) => ({
      ...prevData,
      [`${id}-${index}`]: date,
    }));
  };

  const handleDeliveryDateChange = (date) => {
    const moment = require("moment");
    let formattedDate = moment(date).format("YYYY-MM-DD");
    setDeliveryDate(formattedDate);
  };

  const handleSubmit = () => {
    setLoading(true);
    const requestData = tableData.map((record, index) => {
      const { id, particular_name, quantity, qty_total_amount } = record;
      // const order_date = orderDates[`${id}-${index}`]
      //   ? orderDates[`${id}-${index}`].toISOString().split("T")[0]
      //   : new Date().toISOString().split("T")[0];
      // const trail_date = trailDates[`${id}-${index}`]
      //   ? trailDates[`${id}-${index}`].toISOString().split("T")[0]
      //   : null;
      // const delivery_date = deliveryDates[`${id}-${index}`]
      //   ? deliveryDates[`${id}-${index}`].toISOString().split("T")[0]
      //   : null;
      // const order_date = formatDate(orderDates[`${id}-${index}`] || new Date());
      const trail_date = formatDate(trailDates[`${id}-${index}`]);
      // const delivery_date = formatDate(deliveryDates[`${id}-${index}`]);
      const delivery_date = formatDate(deliveryDate);

      return {
        particular_id: id,
        particular_name,
        quantity: quantity || "",
        qty_total_amount: qty_total_amount
          ? parseFloat(qty_total_amount).toFixed(2)
          : "0.00",
        trail_date,
        delivery_date,
      };
    });

    const totalAmount = tableData
      .reduce(
        (sum, { qty_total_amount }) => sum + parseFloat(qty_total_amount || 0),
        0
      )
      .toFixed(2);
    setTotalAmount(totalAmount);

    const orderDetailsMap = {};
    tableData.forEach((record, index) => {
      const { id, particular_name, quantity, qty_total_amount } = record;

      if (!orderDetailsMap[id]) {
        orderDetailsMap[id] = {
          particular_id: id,
          particular_name,
          quantity: 0,
          qty_total_amount: 0,
        };
      }
      orderDetailsMap[id].quantity += quantity;
      orderDetailsMap[id].qty_total_amount += parseFloat(qty_total_amount || 0);
    });

    const orderDetails = Object.values(orderDetailsMap).map((detail) => ({
      ...detail,
      qty_total_amount: detail.qty_total_amount.toFixed(2),
    }));
    const order_date = formatDate(orderDates.global || new Date());

    const orderData = {
      particular_details: requestData,
      order_details: orderDetails,
      total_amount: totalAmount,
      customer_name: selectedCustomer,
      customer_id: selectedCustomerId,
      user_id: loginUserId,
      order_date,
    };

    // setLoading(false);

    dispatch(ParticularOrderRequestAction(orderData))
      // axios
      //   .post("https://example.com/api/saveDataaaa", orderData)
      .then((response) => {
        setLoading(false);
        if (response?.data?.status === SUCCESS) {
          setSuccessMessage(response.data.message);
        }
      })
      .catch((error) => {
        setLoading(false);
        if (error.response && error.response.data) {
          setErrorMessage(error.response.data);
          // setErrorMessage("Failed to submit data. Please try again later.");
        } else {
          console.log(error.response);
          setErrorMessage(
            "An error occurred while processing your request. Please try again later."
          );
        }
        console.log("erererererere", error);
      });
  };

  const handleClear = () => {
    setQuantities((prevQuantities) => {
      const clearedQuantities = {};
      for (const key in prevQuantities) {
        clearedQuantities[key] = {
          quantity: 0,
          amount: 0,
          price: prevQuantities[key].price,
        };
      }
      return clearedQuantities;
    });
    setTotalAmount(0);
    setTableData([]);
    setOrderDates({});
    setTrailDates({});
    setDeliveryDate(null);
  };

  const handlePrint = useReactToPrint({
    content: () => printRef.current,
  });

  return (
    <div className="">
      {/* ng-container d-flex */}
      <div className="worker-row">
        <div className="worker-left-column">
          <div>
            <p>
              <em>Customer: </em> <strong> {selectedCustomer}</strong>
            </p>
            <p>
              <em>Customerid: </em> <strong>{selectedCustomerId}</strong>
            </p>
          </div>
          <table className="worker-table">
            <thead>
              <tr>
                <th>Particular</th>
                <th>Quantity</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
              {data.map((item) => (
                <tr key={item.id}>
                  <td>{item.particular_name}</td>
                  <td>
                    <div className="worker-quantity-controls">
                      <button onClick={() => handleQuantityChange(item.id, -1)}>
                        -
                      </button>
                      <input
                        type="number"
                        readOnly
                        value={quantities[item.id]?.quantity || 0}
                      />
                      <button onClick={() => handleQuantityChange(item.id, 1)}>
                        +
                      </button>
                    </div>
                  </td>
                  <td>
                    <div className="worker-amount-display">
                      Rs.{quantities[item.id]?.amount || 0}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="worker-total-amount" style={{ marginTop: "15px" }}>
            Total Amount: Rs.{totalAmount}
          </div>
        </div>

        <div align="right">
          <button className="particular-submit-button" onClick={handleSubmit}>
            Save
          </button>
          <button className="particular-submit-button" onClick={handleClear}>
            Clear
          </button>
        </div>

        <div className="scroll-container" style={{ marginTop: "20px" }}>
          <table className="table m-0 p-0 w-100">
            <thead className="table_head border border-top border-end-0  border-start-0 m-0 p-0 table_td w-100">
              <tr>
                <th className="labels ">
                  <div className="  d-flex justify-content-between text-center border mb-2  border-top-0 border-bottom-0 border-start-0">
                    <span className="text_font">Particular</span>
                  </div>
                </th>
                <th className="labels ">
                  <div className="  d-flex justify-content-between text-center border mb-2  border-top-0 border-bottom-0 border-start-0">
                    <span className="text_font">Quantity</span>
                  </div>
                </th>
                <th className="labels ">
                  <div className=" d-flex justify-content-between  text-center border mb-2  border-top-0 border-bottom-0 border-start-0 ">
                    <span className="text_font">Total</span>
                  </div>
                </th>
                <th className="labels ">
                  <div className=" d-flex justify-content-between  text-center border mb-2  border-top-0 border-bottom-0 border-start-0 ">
                    <span className="text_font">Order Date</span>
                  </div>
                </th>
                <th className="labels ">
                  <div className=" d-flex justify-content-between  text-center border mb-2  border-top-0 border-bottom-0 border-start-0 ">
                    <span className="text_font">Trail Date</span>
                  </div>
                </th>
                <th className="labels ">
                  <div className=" d-flex justify-content-between  text-center border mb-2  border-top-0 border-bottom-0 border-start-0 ">
                    <span className="text_font">Delivery Date</span>
                  </div>
                </th>
              </tr>
            </thead>
            <tbody>
              {tableData.length > 0 &&
                data.length > 0 &&
                tableData.map((record, index) => (
                  <tr key={`${record.id}-${index}`}>
                    {/* <td>{record.particular_name}</td> */}
                    <td>
                      {
                        data.find((item) => item.id === parseInt(record.id))
                          .particular_name
                      }
                    </td>
                    <td>{record.quantity}</td>
                    <td>Rs.{record.qty_total_amount}</td>
                    <td>
                      <DatePicker
                        // selected={orderDates[record.id] || new Date()}
                        selected={
                          orderDates[`${record.id}-${index}`] || new Date()
                        }
                        onChange={(date) =>
                          // handleOrderDateChange(date, record.id)
                          handleOrderDateChange(date, record.id, index)
                        }
                        dateFormat="yyyy-MM-dd"
                        className="custom-datepicker"
                      />
                    </td>
                    <td>
                      <DatePicker
                        // selected={trailDates[record.id]}
                        selected={trailDates[`${record.id}-${index}`]}
                        onChange={(date) =>
                          handleTrailDateChange(date, record.id, index)
                        }
                        dateFormat="yyyy-MM-dd"
                        className="custom-datepicker"
                      />
                    </td>
                    <td>
                      <DatePicker
                        // selected={deliveryDates[record.id]}
                        selected={deliveryDate}
                        onChange={(date) => handleDeliveryDateChange(date)}
                        dateFormat="yyyy-MM-dd"
                      />
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>
      <div>
        <Backdrop
          sx={{
            color: "#fff",
            zIndex: (theme) => theme.zIndex.drawer + 1,
          }}
          open={loading}
        >
          <CircularProgress color="inherit" />
        </Backdrop>
      </div>
      <div>
        <Modal show={!!errorMessage} onHide={handleClose} centered>
          <Modal.Header closeButton={false}></Modal.Header>
          <Modal.Body>{errorMessage}</Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleClose}>
              Close
            </Button>
          </Modal.Footer>
        </Modal>
      </div>
      <div>
        <Modal show={!!successMessage} onHide={handleCloseSuccess} centered>
          <Modal.Header closeButton={false}></Modal.Header>
          <Modal.Body>{successMessage}</Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleCloseSuccess}>
              Close
            </Button>
          </Modal.Footer>
        </Modal>
      </div>
    </div>
  );
}

export default ParticularsQuantityTotal;
