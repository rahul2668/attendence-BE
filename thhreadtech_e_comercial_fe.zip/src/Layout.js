import React from "react";
import { Outlet } from "react-router-dom";
import Header from "./components/common/header";
import SideBar from "./components/common/sideBar";
import Footer from "./components/common/footer";
const Layout = () => {
  return (
    <main>
      <SideBar />
      <section>
        <Header />
        <Outlet />
        <Footer />
      </section>
    </main>
  );
};
export default Layout;
