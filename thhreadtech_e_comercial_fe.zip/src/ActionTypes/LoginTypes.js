export const LOGIN_SUCCESS = "LOGIN SUCCESS";
export const LOGIN_FAIL = "LOGIN_FAIL";
export const SET_MESSAGE = "SET_MESSAGE";
export const SET_INITIAL_STATE = "SET_INITIAL_STATE"; // New action type
