export const ORDER_SUCCESS = "ORDER_SUCCESS";
export const ORDER_FAIL = "ORDER_FAIL";
export const OPEN_MODAL = "OPEN_MODAL";
export const OPEN_CANVAS = "OPEN_CANVAS";
export const RESET_FORM = "RESET_FORM";
