import { BASE_URL } from "../config";
import axiosInstance from "../axiosInstance";

// Generate OTP Page
export const fetchMeetings = async () => {
  try {
    const response = await axiosInstance.get(
      `${BASE_URL}/api/get_meetings_inprogress/`
    );
    return response.data;
  } catch (error) {
    throw new Error("Failed to fetch meetings");
  }
};

export const generateOtp = async (meetingId, minutes_in_sec) => {
  try {
    const response = await axiosInstance.post(`${BASE_URL}/api/generate_otp/`, {
      meeting_id: meetingId,
      minutes_in_sec: minutes_in_sec,
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to generate OTP");
  }
};
