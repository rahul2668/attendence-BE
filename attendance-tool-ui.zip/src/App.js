// import React from "react";
// import {
//   BrowserRouter as Router,
//   Route,
//   Routes,
//   useLocation,
// } from "react-router-dom";
// import { Layout, Typography } from "antd";
// import MeetingForm from "./components/Meeting/CreateMeetingForm";
// import AttendanceDashboard from "./components/AttendanceDashboard/AttendanceDashboard";
// import HeaderComponent from "./components/Header_Footer/HeaderComponent";
// import FooterComponent from "./components/Header_Footer/FooterComponent";
// import SidebarComponent from "./components/Header_Footer/SidebarComponent";
// import UpdateMeetingForm from "./components/Meeting/UpdateMeetingForm ";
// import UpdateMeetingPage from "./components/Meeting/UpdateMeetingNew";
// import GenerateOTP from "./components/GenerateOTP";
// // import FormFill from "./components/FormFill";

// import FormCreationComponent from "./components/Assessment/AssesmentFormCreation";
// // import FormFillPage from "./components/Assessment/FormAssessmentPreview";
// import AssessmentFormFillUpParticipantPageV2 from "./components/AttendanceDasboard_V2/AssessmentFormFillUpParticipantPageV2";
// import AssessmentResults from "./components/Assessment/AssessmentResults";
// import EmployeeUploadPage from "./components/EmployeeUploadPage";
// import TrainingDashboardPageV2 from "./components/AttendanceDasboard_V2/TrainingDashboardPageV2";
// import TrainingListPageV2 from "./components/AttendanceDasboard_V2/TrainingListPageV2";
// import FormFillUPWithValidOTPPage from "./components/AttendanceDasboard_V2/FormFillUPWithValidOTPPage";
// import AssessmentListPageV2 from "./components/AttendanceDasboard_V2/AssessmentListPageV2";
// const { Content } = Layout;
// const { Title } = Typography;

// const App = () => {
//   const location = useLocation();

//   return (
//     <Layout className="app-layout">
//       <HeaderComponent />
//       <Layout>
//         {location.pathname !== "/form-fillup" &&
//           !location.pathname.startsWith("/form-fill/") && <SidebarComponent />}
//         <Content className="custom-content">
//           <Routes>
//             <Route
//               path="/attendance-dashboard"
//               element={<AttendanceDashboard />}
//             />
//             <Route path="/create-meeting" element={<MeetingForm />} />
//             <Route path="/update-meeting" element={<UpdateMeetingForm />} />
//             <Route path="/meeting-update" element={<UpdateMeetingPage />} />
//             <Route path="/generate-otp" element={<GenerateOTP />} />
//             {/* <Route path="/form-fillup" element={<FormFill />} /> */}
//             <Route
//               path="/form-fillup"
//               element={<FormFillUPWithValidOTPPage />}
//             />

//             <Route
//               path="/form-assessment"
//               element={<FormCreationComponent />}
//             />
//             {/* <Route
//               path="/form-fill/:id/:currentDate/"
//               element={<FormFillPage />}
//             /> */}
//             <Route
//               path="/form-fill/:id/:currentDate/"
//               element={<AssessmentFormFillUpParticipantPageV2 />}
//             />
//             <Route path="/assessment-results" element={<AssessmentResults />} />
//             <Route
//               path="/upload-employee-details"
//               element={<EmployeeUploadPage />}
//             />
//             {/* Home Route */}
//             <Route
//               path="/"
//               element={
//                 <div style={{ textAlign: "center", padding: 100 }}>
//                   <Title level={2}>Attendance Tracking System</Title>
//                 </div>
//               }
//             />
//             <Route
//               path="/training-dashboard_V2"
//               element={<TrainingDashboardPageV2 />}
//             />
//             <Route path="/meetingListV2" element={<TrainingListPageV2 />} />
//             <Route
//               path="/AssessmentListV2"
//               element={<AssessmentListPageV2 />}
//             />
//           </Routes>
//         </Content>
//       </Layout>
//       <FooterComponent />
//     </Layout>
//   );
// };

// const AppWrapper = () => (
//   <Router>
//     <App />
//   </Router>
// );

// export default AppWrapper;

// src/App.jsimport React from "react";

// firstSSO
import React, { useEffect } from "react";
import { useMsal } from "@azure/msal-react";
import {
  BrowserRouter as Router,
  Route,
  Routes,
  useLocation,
} from "react-router-dom";
import { Layout, Typography } from "antd";
import MeetingForm from "./components/Meeting/CreateMeetingForm";
import AttendanceDashboard from "./components/AttendanceDashboard/AttendanceDashboard";
import HeaderComponent from "./components/Header_Footer/HeaderComponent";
import FooterComponent from "./components/Header_Footer/FooterComponent";
import SidebarComponent from "./components/Header_Footer/SidebarComponent";
import UpdateMeetingForm from "./components/Meeting/UpdateMeetingForm ";
import UpdateMeetingPage from "./components/Meeting/UpdateMeetingNew";
import GenerateOTP from "./components/GenerateOTP";
// import FormFill from "./components/FormFill";

import FormCreationComponent from "./components/Assessment/AssesmentFormCreation";
// import FormFillPage from "./components/Assessment/FormAssessmentPreview";
import AssessmentFormFillUpParticipantPageV2 from "./components/AttendanceDasboard_V2/AssessmentFormFillUpParticipantPageV2";
import AssessmentResults from "./components/Assessment/AssessmentResults";
import EmployeeUploadPage from "./components/EmployeeUploadPage";
import TrainingDashboardPageV2 from "./components/AttendanceDasboard_V2/TrainingDashboardPageV2";
import TrainingListPageV2 from "./components/AttendanceDasboard_V2/TrainingListPageV2";
import FormFillUPWithValidOTPPage from "./components/AttendanceDasboard_V2/FormFillUPWithValidOTPPage";
import AssessmentListPageV2 from "./components/AttendanceDasboard_V2/AssessmentListPageV2";
const { Content } = Layout;
const { Title } = Typography;

const App = () => {
  const location = useLocation();
  const { instance, accounts } = useMsal();
  const loginRequest = {
    scopes: ["User.Read"], // Adjust the scopes as necessary
  };
  const handleLogin = () => {
    instance.loginRedirect(loginRequest).catch((error) => {
      console.error(error);
    });
  };

  useEffect((e) => {
    for (let index = 0; index < localStorage.length; index++) {
      let token = localStorage.getItem(localStorage.key(index));
      let validToken = "";
      let validTokenName = "";
      if (token) {
        validToken = safeParse(token);
        validTokenName = safeParse(token);
      }
      if (validToken?.secret && validToken?.tokenType == "Bearer") {
        localStorage.setItem("secretToken", validToken?.secret);
      }
      if (validTokenName?.name) {
        localStorage.setItem("username", validTokenName?.name);
      }

    }
  }, []);
  function safeParse(token) {
    try {
      if (typeof token === "string") {
        if (token.startsWith('"') && token.endsWith('"')) {
          return token.slice(1, -1);
        }
        return JSON.parse(token);
      } else {
        throw new Error("Input is not a string");
      }
    } catch (error) {
      console.error("Parsing error:", error);
      return null;
    }
  }
  const isAuthenticated = accounts.length > 0;

  return (
    <Layout className="app-layout">
      <HeaderComponent />
      <Layout>
        {location.pathname !== "/form-fillup" &&
          !location.pathname.startsWith("/form-fill/") && <SidebarComponent />}
        <Content className="custom-content">
          {!isAuthenticated ? (
            <div style={{ textAlign: "center", padding: 100 }}>
              <Title level={2}>Attendance Tracking System</Title>
              <button
                default="primary"
                onClick={handleLogin}
                className="inprogress-page-button"
              >
                Login with Azure SSO
              </button>
            </div>
          ) : (
            <Routes>
              <Route
                path="/attendance-dashboard"
                element={<AttendanceDashboard />}
              />
              <Route path="/create-meeting" element={<MeetingForm />} />
              {/* Other routes... */}
              <Route path="/update-meeting" element={<UpdateMeetingForm />} />
              <Route path="/meeting-update" element={<UpdateMeetingPage />} />
              <Route path="/generate-otp" element={<GenerateOTP />} />
              <Route
                path="/form-fillup"
                element={<FormFillUPWithValidOTPPage />}
              />
              <Route
                path="/form-assessment"
                element={<FormCreationComponent />}
              />
              <Route
                path="/form-fill/:id/:currentDate/"
                element={<AssessmentFormFillUpParticipantPageV2 />}
              />
              <Route
                path="/assessment-results"
                element={<AssessmentResults />}
              />
              <Route
                path="/upload-employee-details"
                element={<EmployeeUploadPage />}
              />
              <Route
                path="/"
                element={
                  <div style={{ textAlign: "center", padding: 100 }}>
                    <Title level={2}>Attendance Tracking System</Title>
                  </div>
                }
              />
              <Route
                path="/AssessmentListV2"
                element={<AssessmentListPageV2 />}
              />
              <Route
                path="/training-dashboard_V2"
                element={<TrainingDashboardPageV2 />}
              />
              <Route path="/meetingListV2" element={<TrainingListPageV2 />} />
            </Routes>
          )}
        </Content>
      </Layout>
      <FooterComponent />
    </Layout>
  );
};

// Wrap App component in Router
const AppWrapper = () => (
  <Router>
    <App />
  </Router>
);

export default AppWrapper;
