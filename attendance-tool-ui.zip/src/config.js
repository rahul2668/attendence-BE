export const BASE_URL = "http://127.0.0.1:8000";
export const LOCAL_FE_URL = "http://localhost:5050";
