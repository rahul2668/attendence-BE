import React from "react";
import { Menu, Layout } from "antd";
import {
  AppstoreAddOutlined,
  DashboardOutlined,
  // SendOutlined,
  // CloudSyncOutlined,
  // BarChartOutlined,
  // CloudUploadOutlined,
  // FileMarkdownOutlined,
} from "@ant-design/icons";
import { Link } from "react-router-dom";
import "../../css/SidebarComponent.css";

const { Sider } = Layout;

const SidebarComponent = () => {
  const menuItems = [
    // {
    //   key: "1",
    //   icon: <DashboardOutlined className="custom-icon" />,
    //   label: <Link to="/attendance-dashboard">Dashboard</Link>,
    // },
    // {
    //   key: "2",
    //   icon: <CloudSyncOutlined className="custom-icon" />,
    //   label: <Link to="/meeting-update">Meeting Update</Link>,
    // },
    // {
    //   key: "3",
    //   icon: <SendOutlined className="custom-icon" />,
    //   label: <Link to="/generate-otp">Generate OTP</Link>,
    // },
    // {
    //   key: "4",
    //   icon: <AppstoreAddOutlined className="custom-icon" />,
    //   label: <Link to="/form-assessment">Assessment</Link>,
    // },
    // {
    //   key: "5",
    //   icon: <BarChartOutlined className="custom-icon" />,
    //   label: <Link to="/assessment-results">Result</Link>,
    // },
    // {
    //   key: "6",
    //   icon: <CloudUploadOutlined className="custom-icon" />,
    //   label: <Link to="/upload-employee-details">Emp Upload</Link>,
    // },
    {
      key: "7",
      icon: <DashboardOutlined className="custom-icon" />,
      label: <Link to="/training-dashboard_V2">Training</Link>,
    },
    {
      key: "8",
      icon: <AppstoreAddOutlined className="custom-icon" />,
      label: <Link to="/AssessmentListV2">Assessment</Link>,
    },
  ];

  return (
    <Sider width={60} className="site-layout-background">
      <Menu
        mode="inline"
        defaultSelectedKeys={["1"]}
        style={{ height: "100%", borderRight: 0 }}
        items={menuItems}
        className="sidebar-menu"
      />
    </Sider>
  );
};

export default SidebarComponent;
