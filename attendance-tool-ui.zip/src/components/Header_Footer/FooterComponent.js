import React from "react";
import { Layout } from "antd";

const { Footer } = Layout;

const FooterComponent = () => {
  return (
    <Footer
      style={{
        textAlign: "center",
        height: "20px", 
        lineHeight: "20px", 
        backgroundColor: "#f0f0f0", 
        padding: "0 20px", 
      }}
    >
      © {new Date().getFullYear()} Bilvantis. All rights reserved.
    </Footer>
  );
};

export default FooterComponent;
