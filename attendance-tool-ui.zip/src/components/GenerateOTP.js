import React, { useState, useEffect } from "react";
import { Typography, Select, Button, notification, message } from "antd";
import "../css/FormFill.css";
import { CopyOutlined } from "@ant-design/icons";
import { fetchMeetings, generateOtp } from "../services/api_list";

const GenerateOTP = () => {
  const [meetings, setMeetings] = useState([]);
  const [selectedMeeting, setSelectedMeeting] = useState("");
  const [otp, setOtp] = useState(null);
  const [meetingName, setMeetingName] = useState("");
  const [url, setUrl] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [validationMinutes, setValidationMinutes] = useState(null); // State for validation minutes

  const { Title } = Typography;
  const { Option } = Select;

  useEffect(() => {
    const fetchMeetingData = async () => {
      try {
        const meetingData = await fetchMeetings();
        setMeetings(meetingData);
        setLoading(false);
      } catch (error) {
        setError("Failed to fetch meetings");
        setLoading(false);
      }
    };
    fetchMeetingData();
  }, []);

  const handleChange = (value) => {
    setSelectedMeeting(value);
  };
  const handleValidationMinutesChange = (value) => {
    setValidationMinutes(value);
  };
  const handleGenerateOtp = async (e) => {
    e.preventDefault();
    if (selectedMeeting && validationMinutes) {
      try {
        // const response = await axios.post(`${BASE_URL}/api/generate_otp/`, {
        //   meeting_id: selectedMeeting,
        // });
        const response = await await generateOtp(
          selectedMeeting,
          validationMinutes
        );
        setOtp(response.otp);
        setMeetingName(response.meeting_name);
        setUrl(response.url);
      } catch (error) {
        setError("Failed to generate OTP");
        notification.error({
          message: "Error",
          description: "Failed to generate OTP",
          placement: "topRight",
        });
      }
    } else {
      notification.warning({
        message: "Warning",
        description: "Please select both a meeting and validation minutes",
        placement: "topRight",
      });
    }
  };

  const handleNavigateToFormFill = () => {
    window.open(url, "_blank");
  };

  if (loading) return <p>Loading meetings...</p>;
  if (error) return <p>{error}</p>;

  return (
    <div>
      <div className="header-container">
        <Title level={4} style={{ fontWeight: "bold", color: "#013578" }}>
          Generate OTP
        </Title>
      </div>

      <div className="bordered-box">
        {/* <form onSubmit={handleGenerateOtp}>
          <div>
            <label
              htmlFor="meeting-select"
              style={{
                fontWeight: "bold",
                display: "block",
                marginBottom: "8px",
              }}
            >
              Select Training:{" "}
            </label>
            <Select
              id="meeting-select"
              value={selectedMeeting}
              onChange={handleChange}
              placeholder="Select a meeting"
              style={{ width: 250, marginBottom: 20 }}
              required
            >
              {meetings.length > 0 ? (
                meetings.map((meeting) => (
                  <Option key={meeting.id} value={meeting.id}>
                    {meeting.meeting_name}
                  </Option>
                ))
              ) : (
                <Option disabled>No meetings available</Option>
              )}
            </Select>
          </div>
          <Button
            type="primary"
            htmlType="submit"
            style={{ marginTop: "16px" }}
          >
            Generate OTP
          </Button>
        </form> */}
        <div>
          <div>
            <label
              htmlFor="meeting-select"
              style={{
                fontWeight: "bold",
                display: "block",
                marginBottom: "8px",
              }}
            >
              Select Training:{" "}
            </label>
            <Select
              id="meeting-select"
              value={selectedMeeting}
              onChange={handleChange}
              placeholder="Select a meeting"
              style={{ width: 250, marginBottom: 20 }}
              required
            >
              {meetings.length > 0 ? (
                meetings.map((meeting) => (
                  <Option key={meeting.id} value={meeting.id}>
                    {meeting.meeting_name}
                  </Option>
                ))
              ) : (
                <Option disabled>No meetings available</Option>
              )}
            </Select>
          </div>
          <div>
            <label
              htmlFor="validation-minutes-select"
              style={{
                fontWeight: "bold",

                display: "block",

                marginBottom: "8px",
              }}
            >
              Select Timeout Minutes:{" "}
            </label>

            <Select
              id="validation-minutes-select"
              value={validationMinutes}
              onChange={handleValidationMinutesChange}
              placeholder="Select validation minutes"
              style={{ width: 250, marginBottom: 20 }}
              required
            >
              <Option value={120}>2 Min</Option>

              <Option value={300}>5 Min</Option>

              <Option value={600}>10 Min</Option>

              <Option value={900}>15 Min</Option>
              <Option value={1200}>20 Min</Option>
            </Select>
          </div>
          <Button
            type="primary"
            onClick={handleGenerateOtp}
            style={{ marginTop: "16px" }}
            className="inprogress-page-button"
          >
            Generate OTP
          </Button>
        </div>
        <br />
        {otp && (
          <div style={{ marginTop: "20px" }}>
            <p>
              Your OTP for the meeting "{meetingName}" is:{" "}
              <strong style={{ fontSize: "25px" }}>{otp}</strong>
            </p>
            <p>
              Access the form using this URL:{" "}
              <a href={url} target="_blank" rel="noopener noreferrer">
                {url}
              </a>
              {/* <CopyOutlined
                onClick={() => navigator.clipboard.writeText(url)}
                style={{
                  cursor: "pointer",
                  marginLeft: "10px",
                  fontSize: "16px",
                  color: "#00aae8",
                }}
                title="Copy to clipboard"
              /> */}
              <CopyOutlined
                onClick={() => {
                  navigator.clipboard.writeText(url);
                  message.success("URL copied to clipboard!"); // Show success message
                }}
                style={{
                  cursor: "pointer",
                  marginLeft: "15px",
                  fontSize: "20px",
                  color: "#1890ff",
                }}
                title="Copy to clipboard"
              />
            </p>
            <Button
              onClick={handleNavigateToFormFill}
              className="inprogress-page-button"
            >
              Go to Form Fill
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default GenerateOTP;
