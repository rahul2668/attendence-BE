import React, { useState, useEffect } from "react";
import { Select, Table, Button, Typography } from "antd";
import axios from "axios";
import { BASE_URL } from "../../config";
import moment from "moment";
import ExcelJS from "exceljs";
import { DownloadOutlined } from "@ant-design/icons";

const { Title } = Typography;
const { Option } = Select;

const InProgressMeetings = ({ onStatusChange }) => {
  const [inProgressMeetings, setInProgressMeetings] = useState([]);
  const [selectedInProgressMeeting, setSelectedInProgressMeeting] =
    useState(null);
  const [selectedMeetingName, setSelectedMeetingName] = useState("");
  const [inProgressAttendanceData, setInProgressAttendanceData] = useState([]);
  const [uniqueDates, setUniqueDates] = useState([]);
  const [loading, setLoading] = useState(false);
  const [meetingDetails, setMeetingDetails] = useState({
    trainerName: "",
    startDate: "",
    endDate: "",
    startTime: "",
    endTime: "",
    meetingType: "",
    location: "",
  });

  useEffect(() => {
    const fetchInProgressMeetings = async () => {
      try {
        const response = await axios.get(
          `${BASE_URL}/api/meetings_list/?status=in_progress`
        );
        setInProgressMeetings(response.data);
      } catch (error) {
        console.error("Error fetching in-progress meetings:", error);
      }
    };

    fetchInProgressMeetings();
  }, []);

  const handleInProgressMeetingChange = (meetingId) => {
    setSelectedInProgressMeeting(meetingId);
    setLoading(true);

    // Get the selected meeting name for the Excel file name
    const selectedMeeting = inProgressMeetings.find(
      (meeting) => meeting.id === meetingId
    );
    setSelectedMeetingName(selectedMeeting.meeting_name);

    axios
      .get(`${BASE_URL}/api/attendance_list/?meeting=${meetingId}`)
      .then((response) => {
        const { meeting_details, attendance } = response.data;

        setMeetingDetails({
          trainerName: meeting_details.trainer_name,
          startDate: meeting_details.start_date,
          endDate: meeting_details.end_date,
          startTime: meeting_details.start_time,
          endTime: meeting_details.end_time,
          meetingType: meeting_details.type,
          location: meeting_details.location,
        });

        let allDates = [...new Set(attendance.map((item) => item.date))];
        allDates = allDates.sort((a, b) => moment(a).diff(moment(b)));
        setUniqueDates(allDates);

        const attendanceMap = new Map();
        attendance.forEach(({ employee, date }) => {
          const empId = employee.employee_id;
          if (!attendanceMap.has(empId)) {
            attendanceMap.set(empId, {
              key: empId,
              employee_id: empId,
              employee_name: employee.name,
              email: employee.email,
              designation: employee.designation,
              vertical: employee.vertical,
              attendance: {},
            });
          }
          attendanceMap.get(empId).attendance[date] = "Present";
        });

        const requiredEmployeesMap = new Map();
        meeting_details.required_employees.forEach((emp) => {
          requiredEmployeesMap.set(emp.employee_id, {
            key: emp.employee_id,
            employee_id: emp.employee_id,
            employee_name: emp.name,
            email: emp.email,
            designation: emp.designation,
            vertical: emp.vertical,
            attendance: {},
          });
        });

        const dataWithKey = [...requiredEmployeesMap.values()].map((emp) => ({
          ...emp,
          ...attendanceMap.get(emp.employee_id),
        }));

        setInProgressAttendanceData(dataWithKey);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching attendance data:", error);
        setLoading(false);
      });
  };
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "long",
      year: "numeric",
    });
  };
  const baseColumns = [
    {
      title: "Employee ID",
      dataIndex: "employee_id",
      key: "employee_id",
    },
    {
      title: "Employee Name",
      dataIndex: "employee_name",
      key: "employee_name",
    },
    {
      title: "Email",
      dataIndex: "email",
      key: "email",
    },
    {
      title: "Designation",
      dataIndex: "designation",
      key: "designation",
    },
    {
      title: "Vertical",
      dataIndex: "vertical",
      key: "vertical",
    },
  ];

  const dynamicDateColumns = uniqueDates.map((date) => ({
    title: formatDate(date),
    key: date,
    dataIndex: ["attendance", date],
    render: (status) => (status ? status : "Absent"),
  }));

  const inProgressColumns = [...baseColumns, ...dynamicDateColumns];

  const exportToExcel = async () => {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet("In-Progress Attendance");

    const formatDate = (date) => {
      const options = { day: "2-digit", month: "long", year: "numeric" };
      return new Date(date).toLocaleDateString("en-GB", options);
    };

    const formattedDates = uniqueDates.map((date) => formatDate(date));

    const formattedStartDate = formatDate(meetingDetails.startDate);
    const formattedEndDate = formatDate(meetingDetails.endDate);

    const headers = [
      "Employee ID",
      "Employee Name",
      "Email",
      "Designation",
      "Vertical",
      ...formattedDates,
      // "Absent Count",
    ];

    worksheet.mergeCells("A1", `F1`);
    const cellA1 = worksheet.getCell("A1");
    cellA1.value = `${selectedMeetingName} - Training Attendance`;
    cellA1.alignment = { horizontal: "center" };
    cellA1.font = { bold: true };

    const { trainerName, startTime, endTime, location } = meetingDetails;
    const infoText = `Trainer Name: ${trainerName}, Date: ${formattedStartDate} - ${formattedEndDate}, Time: ${startTime} - ${endTime}, Location: ${location}`;
    worksheet.mergeCells("A2", `F2`);
    const cellA2 = worksheet.getCell("A2");
    cellA2.value = infoText;
    cellA2.alignment = { horizontal: "center" };
    cellA2.font = { bold: true };
    const fillStyle = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "FFF5F5DC" },
    };
    cellA1.fill = fillStyle;
    cellA2.fill = fillStyle;
    const headerRow = worksheet.addRow(headers);

    headerRow.eachCell({ includeEmpty: true }, (cell) => {
      cell.font = { bold: true };
      cell.border = {
        top: { style: "thin", color: { argb: "FF000000" } },
        left: { style: "thin", color: { argb: "FF000000" } },
        bottom: { style: "thin", color: { argb: "FF000000" } },
        right: { style: "thin", color: { argb: "FF000000" } },
      };
    });

    inProgressAttendanceData.forEach((item) => {
      // const absentCount = uniqueDates.filter(
      //   (date) => item.attendance[date] === "Absent"
      // ).length;

      const row = [
        item.employee_id,
        item.employee_name,
        item.email,
        item.designation,
        item.vertical,
        ...formattedDates.map((formattedDate) => {
          const originalDate = uniqueDates.find(
            (d) => formatDate(d) === formattedDate
          );
          return item.attendance[originalDate] || "Absent";
        }),
        // absentCount,
      ];
      const dataRow = worksheet.addRow(row);

      dataRow.eachCell({ includeEmpty: true }, (cell) => {
        cell.border = {
          top: { style: "thin", color: { argb: "FF000000" } },
          left: { style: "thin", color: { argb: "FF000000" } },
          bottom: { style: "thin", color: { argb: "FF000000" } },
          right: { style: "thin", color: { argb: "FF000000" } },
        };
      });
    });

    const MAX_COLUMN_WIDTH = 20;
    worksheet.columns.forEach((column) => {
      let maxLength = 0;
      column.eachCell({ includeEmpty: true }, (cell) => {
        const cellLength = cell.value ? cell.value.toString().length : 0;
        maxLength = Math.max(maxLength, cellLength);
      });
      column.width = Math.min(maxLength + 2, MAX_COLUMN_WIDTH);
    });

    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${selectedMeetingName}_inprogress_attendance.xlsx`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };

  return (
    <div>
      <Title level={4}>In-Progress Meetings</Title>
      <Select
        placeholder="Select an in-progress meeting"
        style={{ width: 300, marginBottom: 20 }}
        onChange={handleInProgressMeetingChange}
        value={selectedInProgressMeeting}
      >
        {inProgressMeetings.map((meeting) => (
          <Option key={meeting.id} value={meeting.id}>
            {meeting.meeting_name}
          </Option>
        ))}
      </Select>
      <Button
        type="primary"
        className="inprogress-page-button"
        style={{ marginBottom: 20, marginLeft: 30 }}
        onClick={() => onStatusChange(selectedInProgressMeeting)}
        disabled={!selectedInProgressMeeting}
      >
        Set as Completed
      </Button>

      <Button
        type="primary"
        className="inprogress-page-button"
        style={{ marginBottom: 20, marginLeft: 10 }}
        onClick={() => exportToExcel()}
        disabled={!selectedInProgressMeeting}
        icon={<DownloadOutlined />}
      >
        Excel
      </Button>

      {selectedInProgressMeeting && (
        <Table
          dataSource={inProgressAttendanceData}
          columns={inProgressColumns}
          pagination={false}
          loading={loading}
          scroll={{ x: "max-content" }}
          title={() => <Title level={4}>In-Progress Meeting Attendance</Title>}
        />
      )}
    </div>
  );
};

export default InProgressMeetings;
