import React, { useState } from "react";
import { Button, Typography, Modal } from "antd";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import InProgressMeetings from "./InProgressMeetings";
import CompletedMeetings from "./CompletedMeetings";
import MeetingForm from "../Meeting/CreateMeetingForm";
import { BASE_URL } from "../../config";
import "../../css/AttendanceDashboard.css";
import { PlusOutlined } from "@ant-design/icons";
import { notification } from "antd";
// import GenerateOTP from "../GenerateOTP";
// import UpdateMeetingPage from "../Meeting/UpdateMeetingNew";

const { Title } = Typography;

const AttendanceDashboard = () => {
  const [inprogressIsModalVisable, setInprogressIsModalVisable] =
    useState(false);
  const [completedIsModalVisable, setCompletedIsModalVisable] = useState(false);
  const [isCreateModalVisible, setIsCreateModalVisible] = useState(false);
  const [inprogressmeetingToChange, setInprogressmeetingToChange] =
    useState(null);
  const [completedmeetingToChange, setCompletedmeetingToChange] =
    useState(null);
  const navigate = useNavigate();

  const showStatusChangeInprogressModal = (meetingId) => {
    setInprogressmeetingToChange(meetingId);
    setInprogressIsModalVisable(true);
  };

  const showStatusChangeCompletedModal = (meetingId) => {
    setCompletedmeetingToChange(meetingId);
    setCompletedIsModalVisable(true);
  };

  const handleInprogressStatusChange = () => {
    if (inprogressmeetingToChange) {
      axios
        .get(
          `${BASE_URL}/api/inprogress_to_complete_meeting_status/${inprogressmeetingToChange}/`,
          {
            status: "completed",
          }
        )
        .then((response) => {
          setInprogressIsModalVisable(false);
          notification.success({
            message: "Success",
            description: "Successfully updated to Completed.",
            placement: "topRight",
          });
          setTimeout(() => {
            // setInprogressIsModalVisable(false);
            window.location.reload();
          }, 1500);
          // setInprogressIsModalVisable(false);
          // window.location.reload();
        })
        .catch((error) => {
          console.error("Error updating meeting status:", error);
        });
    }
  };

  const handleCompletedStatusChange = () => {
    if (completedmeetingToChange) {
      axios
        .get(
          `${BASE_URL}/api/complete_to_inprogress_meeting_status/${completedmeetingToChange}/`,
          {
            status: "in_progress",
          }
        )
        .then((response) => {
          setCompletedIsModalVisable(false);
          notification.success({
            message: "Success",
            description: "Successfully updated to Completed.",
            placement: "topRight",
          });
          setTimeout(() => {
            // setCompletedIsModalVisable(false);
            window.location.reload();
          }, 1500);
          // setCompletedIsModalVisable(false);
          // window.location.reload();
        })
        .catch((error) => {
          console.error("Error updating meeting status:", error);
        });
    }
  };

  const handleCreateMeetingModalOpen = () => {
    setIsCreateModalVisible(true);
  };

  const handleCreateMeetingModalClose = () => {
    setIsCreateModalVisible(false);
  };

  return (
    <div>
      <div className="header-container">
        <Title level={4} style={{ fontWeight: "bold", color: "#013578" }}>
          Attendance Dashboard
        </Title>
        <Button
          type="primary"
          className="create-button"
          onClick={handleCreateMeetingModalOpen}
          icon={<PlusOutlined />}
        >
          New Meeting
        </Button>
      </div>

      <div className="attendance-dashboard-bordered-box">
        <InProgressMeetings onStatusChange={showStatusChangeInprogressModal} />
        <CompletedMeetings onStatusChange={showStatusChangeCompletedModal} />

        <br />
        <Button
          type="primary"
          className="inprogress-page-button"
          style={{ marginBottom: 20, marginLeft: 30 }}
          onClick={() => navigate("/")}
        >
          Back to Home
        </Button>
      </div>

      <Modal
        title="Change Meeting Status - to complete"
        open={inprogressIsModalVisable}
        onCancel={() => setInprogressIsModalVisable(false)}
        width={800}
        footer={[
          <Button
            className="inprogress-page-button"
            key="cancel"
            onClick={() => setInprogressIsModalVisable(false)}
          >
            Cancel
          </Button>,
          <Button
            className="inprogress-page-button"
            key="submit"
            type="primary"
            onClick={handleInprogressStatusChange}
          >
            Change to Completed
          </Button>,
        ]}
      >
        <p>
          Are you sure you want to change the status of this meeting to
          completed?
        </p>
      </Modal>

      <Modal
        title="Change Meeting Status - to inprogress"
        open={completedIsModalVisable}
        onCancel={() => setCompletedIsModalVisable(false)}
        width={800}
        footer={[
          <Button
            className="inprogress-page-button"
            key="cancel"
            onClick={() => setCompletedIsModalVisable(false)}
          >
            Cancel
          </Button>,
          <Button
            className="inprogress-page-button"
            key="submit"
            type="primary"
            onClick={handleCompletedStatusChange}
          >
            Change to InProgress
          </Button>,
        ]}
      >
        <p>
          Are you sure you want to change the status of this meeting to
          inprogress?
        </p>
      </Modal>

      <Modal
        open={isCreateModalVisible}
        onCancel={handleCreateMeetingModalClose}
        width={800}
        footer={null}
      >
        <MeetingForm onClose={handleCreateMeetingModalClose} />
      </Modal>
      <br />
      {/* <hr />
      <GenerateOTP />
      <br />
      <hr />
      <UpdateMeetingPage /> 
      <br />
      <hr /> */}
    </div>
  );
};

export default AttendanceDashboard;
