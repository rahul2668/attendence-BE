// src/api.js
import axios from "axios";
import { BASE_URL } from "../../config";

// Create an Axios instance
const api = axios.create({
  baseURL: `${BASE_URL}/api`, // Replace with your backend API base URL
});

// Set up an interceptor to add the token to each request
api.interceptors.request.use(
  (config) => {
    // Get the token from the local storage or wherever you store it
    const token = localStorage.getItem("access_token"); // Adjust according to where you store your token

    if (token) {
      // Add the Authorization header
      config.headers["Authorization"] = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

export default api;
