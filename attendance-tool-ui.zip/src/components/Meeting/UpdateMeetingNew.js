import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
// import axios from "axios";
import axiosInstance from "../../axiosInstance";
import {
  Input,
  Select,
  TimePicker,
  Button,
  Row,
  Col,
  Modal,
  Typography,
  notification,
} from "antd";
import moment from "moment";
import DatePicker from "react-datepicker";
import "bootstrap/dist/css/bootstrap.min.css";
import "react-datepicker/dist/react-datepicker.css";
import { BASE_URL } from "../../config";
import "../../css/UpdateMeetingNew.css";

const { Title } = Typography;
const { Option } = Select;
const { confirm } = Modal;

const UpdateMeetingPage = () => {
  const [meetings, setMeetings] = useState([]);
  const [courses, setCourses] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [locations, setLocations] = useState([]);
  const [selectedLocation, setSelectedLocation] = useState(null);

  const [onlineUrl, setOnlineUrl] = useState("");
  const [meetingType, setMeetingType] = useState(null);

  const [meetingName, setMeetingName] = useState("");
  const [course, setCourse] = useState(null);
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [startTime, setStartTime] = useState(null);
  const [endTime, setEndTime] = useState(null);
  const [trainerName, setTrainerName] = useState(null);
  const [status, setStatus] = useState(null);
  const [requiredEmployees, setRequiredEmployees] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedMeetingId, setSelectedMeetingId] = useState(null);
  const [selectedMeeting, setSelectedMeeting] = useState(null);

  const navigate = useNavigate();

  useEffect(() => {
    axiosInstance
      .get(`${BASE_URL}/api/get_meetings_inprogress/`)
      .then((response) => setMeetings(response.data));
    axiosInstance
      .get(`${BASE_URL}/api/get_courses/`)
      .then((response) => setCourses(response.data));
    axiosInstance
      .get(`${BASE_URL}/api/get_employees/`)
      .then((response) => setEmployees(response.data));
    axiosInstance.get(`${BASE_URL}/api/get_locations/`).then((response) => {
      setLocations(response.data);
      response.data.map((e) => console.log(e.id));
    });
  }, []);

  const handleMeetingSelect = (meetingId) => {
    setLoading(true);
    setSelectedMeetingId(meetingId);
    axiosInstance
      .get(`${BASE_URL}/api/meetings_inprogress_list/${meetingId}/`)
      .then((response) => {
        const meeting = response.data;
        setSelectedMeeting(meeting);
        setMeetingName(meeting.meeting_name);
        setCourse(meeting.course.id);
        setStartDate(meeting.start_date ? new Date(meeting.start_date) : null);
        setEndDate(meeting.end_date ? new Date(meeting.end_date) : null);
        setStartTime(
          meeting.start_time ? moment(meeting.start_time, "HH:mm:ss") : null
        );
        setEndTime(
          meeting.end_time ? moment(meeting.end_time, "HH:mm:ss") : null
        );
        setTrainerName(meeting.trainer_name.map((t) => t.id));
        setStatus(meeting.status);
        setRequiredEmployees(meeting.required_employees.map((e) => e.id));
        setSelectedLocation(
          meeting.location ? meeting.location.location_name : null
        );
        setOnlineUrl(meeting.online_url || "");
        setMeetingType(meeting.type);
        setLoading(false);
      });
  };

  const handleUpdate = () => {
    const payload = {
      meeting_name: meetingName,
      course: course,
      start_date: startDate ? moment(startDate).format("YYYY-MM-DD") : null,
      end_date: endDate ? moment(endDate).format("YYYY-MM-DD") : null,
      start_time: startTime ? startTime.format("HH:mm") : null,
      end_time: endTime ? endTime.format("HH:mm") : null,
      required_employees: requiredEmployees,
      trainer_name: trainerName,
      type: meetingType,
      status: status,
      location: (locations?.filter(
        (data) => data.location_name === selectedLocation
      ))[0].id,
      online_url: onlineUrl,
    };

    axiosInstance
      .post(`${BASE_URL}/api/update_meeting/${selectedMeetingId}/`, payload)
      .then(() => {
        // message.success("Meeting updated successfully");

        setSelectedMeeting(null);
        setSelectedMeetingId(null);

        notification.success({
          message: "Success",
          description: "Meeting updated Successfully",
          placement: "topRight",
        });
        // window.location.reload();
      })
      // .catch((error) => {
      //   notification.error({
      //     message: "Error",

      //     description: "Failed to update meeting.",
      //   });
      // });

      .catch((error) => {
        if (error.response && error.response.data.error) {
          const errorMessage = error.response.data.error;
          const conflictingEmployees =
            error.response.data.conflicting_employees;

          if (conflictingEmployees && conflictingEmployees.length > 0) {
            // Format the employee names into a readable string
            const employeeNames = conflictingEmployees.join(", ");
            notification.error({
              message: "Error",
              description: `${errorMessage} ${employeeNames}`,
              placement: "topRight",
            });
          } else {
            notification.error({
              message: "Error",
              description: errorMessage,
              placement: "topRight",
            });
          }
        } else {
          notification.error({
            message: "Error",
            description: "Failed to Update meeting. Please try again.",
            placement: "topRight",
          });
        }
      });
  };

  const handleBack = () => {
    navigate("/");
  };

  const showDeleteConfirm = () => {
    confirm({
      title: "Are you sure you want to delete this meeting?",
      content: "Once deleted, the meeting cannot be recovered.",
      okText: "Yes",
      okType: "danger",
      cancelText: "No",
      onOk() {
        handleDelete();
      },
    });
  };

  const handleDelete = () => {
    axiosInstance
      .post(`${BASE_URL}/api/delete_meeting/${selectedMeetingId}/`)
      .then(() => {
        setSelectedMeeting(null);
        setSelectedMeetingId(null);
        notification.success({
          message: "Success",
          description: "Meeting deleted Successfully",
          placement: "topRight",
        });
        setMeetings((prevMeetings) =>
          prevMeetings.filter((meeting) => meeting.id !== selectedMeetingId)
        );
      })
      .catch((error) => {
        notification.error({
          message: "Error",

          description: "Failed to delete meeting.",
        });
      });
  };

  return (
    <div>
      <div className="header-container">
        <Title level={4} style={{ fontWeight: "bold", color: "#013578" }}>
          Meeting Update
        </Title>
      </div>
      <div className="bordered-box">
        <Row gutter={16}>
          <Col span={24}>
            <div>
              <label
                style={{
                  fontWeight: "bold",
                  display: "block",
                  marginBottom: "8px",
                }}
              >
                Select Training
              </label>
              <Select
                placeholder="Select a Training"
                onChange={handleMeetingSelect}
                style={{ width: 250, marginBottom: 20 }}
              >
                {/* <Option value={null}>None</Option> */}
                {meetings.map((m) => (
                  <Option key={m.id} value={m.id}>
                    {m.meeting_name}
                  </Option>
                ))}
              </Select>
            </div>
          </Col>

          {selectedMeeting && (
            <>
              <Col span={6}>
                <div>
                  <label>Training Name</label>
                  <Input
                    value={meetingName}
                    style={{ width: 250, marginBottom: 20 }}
                    onChange={(e) => setMeetingName(e.target.value)}
                    disabled
                  />
                </div>
              </Col>

              <Col span={6}>
                <div>
                  <label>Course</label>
                  <Select
                    value={course}
                    style={{ width: 250, marginBottom: 20 }}
                    onChange={(value) => setCourse(value)}
                    placeholder="Select a course"
                    disabled
                  >
                    {courses.map((c) => (
                      <Option key={c.id} value={c.id}>
                        {c.course_name}
                      </Option>
                    ))}
                  </Select>
                </div>
              </Col>

              <Col span={6}>
                <div>
                  <label>Trainer Name</label>
                  <Select
                    mode="multiple"
                    value={trainerName}
                    style={{ width: 250, marginBottom: 20 }}
                    onChange={(values) => setTrainerName(values)}
                    placeholder="Select trainers"
                    showSearch
                    filterOption={(input, option) =>
                      option.children
                        .toLowerCase()
                        .includes(input.toLowerCase())
                    }
                  >
                    {employees.map((e) => (
                      <Option key={e.id} value={e.id}>
                        {e.name}
                      </Option>
                    ))}
                  </Select>
                </div>
              </Col>

              <Col span={12}>
                <label>Type</label>
                <Select
                  value={meetingType}
                  className="input-field"
                  placeholder="Select type"
                  onChange={(value) => {
                    setMeetingType(value);
                  }}
                >
                  <Option value="Offline">Offline</Option>
                  <Option value="Online">Online</Option>
                </Select>
              </Col>

              {meetingType === "Offline" && (
                <Col span={12}>
                  <div>
                    <label>Location Name</label>
                    <Select
                      className="input-field"
                      placeholder="Select a location"
                      value={selectedLocation}
                      onChange={(value) => {
                        setSelectedLocation(value);
                      }}
                    >
                      {locations.map((loc) => (
                        <Option key={loc.id} value={loc.location_name}>
                          {loc.location_name}{" "}
                        </Option>
                      ))}
                    </Select>
                  </div>
                </Col>
              )}

              {meetingType === "Online" && (
                <Col span={12}>
                  <div>
                    <label>Online URL</label>
                    <Input
                      className="input-field"
                      placeholder="Enter URL"
                      value={onlineUrl}
                      onChange={(e) => setOnlineUrl(e.target.value)}
                    />
                  </div>
                </Col>
              )}
              <Col span={6}>
                <div>
                  <label>Start Date</label>
                  <DatePicker
                    selected={startDate}
                    onChange={(date) => setStartDate(date)}
                    dateFormat="yyyy/MM/dd"
                    className="form-control"
                  />
                </div>
              </Col>

              <Col span={6}>
                <div>
                  <label>End Date</label>
                  <DatePicker
                    selected={endDate}
                    onChange={(date) => setEndDate(date)}
                    dateFormat="yyyy/MM/dd"
                    className="form-control"
                  />
                </div>
              </Col>

              <Col span={6}>
                <div>
                  <label>Start Time</label>
                  <TimePicker
                    value={startTime}
                    onChange={(time, timeString) => {
                      setStartTime(time);
                    }}
                    format="HH:mm"
                    minuteStep={15}
                    className="form-control"
                    style={{ width: 250, marginBottom: 20 }}
                    allowClear={true}
                    showNow={false}
                    onPressEnter={(e) => {
                      const inputTime = e.target.value;
                      const parsedTime = moment(inputTime, "HH:mm", true);
                      if (parsedTime.isValid()) {
                        setStartTime(parsedTime);
                      }
                    }}
                  />
                </div>
              </Col>

              <Col span={6}>
                <div>
                  <label>End Time</label>
                  <TimePicker
                    value={endTime}
                    onChange={(time, timeString) => {
                      setEndTime(time);
                    }}
                    format="HH:mm"
                    minuteStep={15}
                    className="form-control"
                    style={{ width: 250, marginBottom: 20 }}
                    allowClear={true}
                    showNow={false}
                    onPressEnter={(e) => {
                      const inputTime = e.target.value;
                      const parsedTime = moment(inputTime, "HH:mm", true);
                      if (parsedTime.isValid()) {
                        setEndTime(parsedTime);
                      }
                    }}
                  />
                </div>
              </Col>

              <Col span={6}>
                <div>
                  <label>Status</label>
                  <Select
                    value={status}
                    style={{ width: 250, marginBottom: 20 }}
                    onChange={(value) => setStatus(value)}
                    placeholder="Select a status"
                  >
                    <Option value="in_Progress">In Progress</Option>
                    <Option value="completed">Completed</Option>
                  </Select>
                </div>
              </Col>

              <Col span={12}>
                <div>
                  <label>Required Participants</label>
                  <Select
                    mode="multiple"
                    value={requiredEmployees}
                    onChange={(values) => setRequiredEmployees(values)}
                    style={{ width: 550, marginBottom: 20 }}
                    placeholder="Select required Participants"
                    showSearch
                    filterOption={(input, option) =>
                      option.children
                        .toLowerCase()
                        .includes(input.toLowerCase())
                    }
                  >
                    {employees.map((e) => (
                      <Option key={e.id} value={e.id}>
                        {e.name}
                      </Option>
                    ))}
                  </Select>
                </div>
              </Col>

              <Col span={24}>
                <div>
                  <Button
                    onClick={handleUpdate}
                    loading={loading}
                    className="inprogress-page-button"
                    style={{ marginBottom: 20 }}
                  >
                    Update
                  </Button>
                  <Button
                    onClick={showDeleteConfirm}
                    loading={loading}
                    className="inprogress-page-button"
                    style={{ marginBottom: 20, marginLeft: 30 }}
                  >
                    Delete
                  </Button>
                  <Button
                    onClick={handleBack}
                    className="inprogress-page-button"
                    style={{ marginBottom: 20, marginLeft: 30 }}
                  >
                    Back to Home
                  </Button>
                </div>
              </Col>
            </>
          )}
        </Row>
      </div>
    </div>
  );
};

export default UpdateMeetingPage;
