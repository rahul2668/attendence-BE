import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import Select from "react-select";
import { Button, Col, Row, Container, Spinner, Modal } from "react-bootstrap";
import moment from "moment";
import { BASE_URL } from "../../config";
import "../../css/UpdateMeetingForm.css";

const UpdateMeetingForm = () => {
  const [meetings, setMeetings] = useState([]);
  const [courses, setCourses] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [meetingName, setMeetingName] = useState("");
  const [course, setCourse] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");
  const [trainerName, setTrainerName] = useState("");
  const [type, setType] = useState("");
  const [status, setStatus] = useState("");
  const [requiredEmployees, setRequiredEmployees] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedMeeting, setSelectedMeeting] = useState(null);
  const [showModal, setShowModal] = useState(false);

  const navigate = useNavigate();

  useEffect(() => {
    axios.get(`${BASE_URL}/api/get_meetings_inprogress/`).then((response) => {
      setMeetings(response.data);
    });
    axios.get(`${BASE_URL}/api/get_courses/`).then((response) => {
      setCourses(response.data);
    });
    axios.get(`${BASE_URL}/api/get_employees/`).then((response) => {
      setEmployees(response.data);
    });
  }, []);

  const handleMeetingSelect = (selectedOption) => {
    if (!selectedOption) return;
    const meetingId = selectedOption.value;
    setLoading(true);
    axios
      .get(`${BASE_URL}/api/meetings_inprogress_list/${meetingId}/`)
      .then((response) => {
        const meeting = response.data;
        setSelectedMeeting(meeting);
        setMeetingName(meeting.meeting_name);
        setCourse(meeting.course.id);
        setStartDate(
          meeting.start_date
            ? moment(meeting.start_date).format("YYYY-MM-DD")
            : ""
        );
        setEndDate(
          meeting.end_date ? moment(meeting.end_date).format("YYYY-MM-DD") : ""
        );
        setStartTime(meeting.start_time ? meeting.start_time.slice(0, 5) : ""); // "HH:MM" format
        setEndTime(meeting.end_time ? meeting.end_time.slice(0, 5) : ""); // "HH:MM" format
        setTrainerName(meeting.trainer_name);
        setType(meeting.type);
        setStatus(meeting.status);
        setRequiredEmployees(
          meeting.required_employees.map((e) => ({
            value: e.id,
            label: e.name,
          }))
        );
        setLoading(false);
      });
  };

  const handleUpdate = () => {
    const payload = {
      meeting_name: meetingName,
      course: course,
      start_date: startDate,
      end_date: endDate,
      start_time: startTime,
      end_time: endTime,
      required_employees: requiredEmployees.map((e) => e.value),
      trainer_name: trainerName,
      type: type,
      status: status,
    };

    axios
      .post(`${BASE_URL}/api/update_meeting/${selectedMeeting.id}/`, payload)
      .then(() => {
        setSelectedMeeting(null);
        alert("Meeting updated successfully");
      })
      .catch((error) => {
        console.error("Error updating meeting:", error);
        alert("Failed to update meeting");
      });
  };

  const handleBack = () => {
    navigate("/");
  };

  const handleDelete = () => {
    axios
      .delete(`${BASE_URL}/api/delete_meeting/${selectedMeeting.id}/`)
      .then(() => {
        setShowModal(false);
        alert("Meeting deleted successfully");
        setSelectedMeeting(null);
        setMeetings((prevMeetings) =>
          prevMeetings.filter((m) => m.id !== selectedMeeting.id)
        );
      })
      .catch((error) => {
        console.error("Error deleting meeting:", error);
        alert("Failed to delete meeting");
      });
  };

  const meetingOptions = meetings.map((m) => ({
    value: m.id,
    label: m.meeting_name,
  }));

  const courseOptions = courses.map((c) => ({
    value: c.id,
    label: c.course_name,
  }));

  const employeeOptions = employees.map((e) => ({
    value: e.id,
    label: e.name,
  }));

  const generateTimeOptions = () => {
    const times = [];
    let time = 0;
    while (time < 24 * 60) {
      const hour = Math.floor(time / 60);
      const minute = time % 60;
      const label = `${String(hour).padStart(2, "0")}:${String(minute).padStart(
        2,
        "0"
      )}`;
      times.push({ value: label, label });
      time += 30; // Increment by 30 minutes
    }
    return times;
  };

  return (
    <Container>
      <h2>Update Meeting</h2>
      <div className="form-container">
        <Row>
          <Col xs={12}>
            <label>Select Meeting:</label>
            <Select
              options={meetingOptions}
              value={meetingOptions.find(
                (option) => option.value === selectedMeeting?.id
              )}
              styles={{
                container: (provided) => ({
                  ...provided,
                  width: "30%",
                  marginBottom: 20,
                }),
              }}
              onChange={handleMeetingSelect}
              placeholder="Select Meeting..."
            />
          </Col>
        </Row>

        {selectedMeeting && (
          <>
            <Row>
              <Col xs={12} md={3}>
                <label>Meeting Name:</label>
                <input
                  type="text"
                  value={meetingName || ""}
                  onChange={(e) => setMeetingName(e.target.value)}
                  className="form-control"
                />
              </Col>
              <Col xs={12} md={3}>
                <label>Trainer:</label>
                <Select
                  options={employeeOptions}
                  value={employeeOptions.find((e) => e.value === trainerName)}
                  onChange={(option) =>
                    setTrainerName(option ? option.value : "")
                  }
                  placeholder="Select Trainer..."
                  style={{ width: "30%" }}
                />
              </Col>
              <Col xs={12} md={3}>
                <label>Course:</label>
                <Select
                  options={courseOptions}
                  value={courseOptions.find((c) => c.value === course)}
                  onChange={(option) => setCourse(option ? option.value : "")}
                  placeholder="Select Course..."
                />
              </Col>
              <Col xs={12} md={3}>
                <label>Type:</label>
                <Select
                  options={[
                    { value: "Offline", label: "Offline" },
                    { value: "Online", label: "Online" },
                  ]}
                  value={{ value: type, label: type }}
                  onChange={(option) => setType(option ? option.value : "")}
                  placeholder="Select Type..."
                />
              </Col>
            </Row>

            <Row>
              <Col xs={12} md={3}>
                <label>Start Date:</label>
                <input
                  type="date"
                  value={startDate || ""}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="form-control"
                />
              </Col>
              <Col xs={12} md={3}>
                <label>End Date:</label>
                <input
                  type="date"
                  value={endDate || ""}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="form-control"
                />
              </Col>
              <Col xs={12} md={3}>
                <label>Start Time:</label>
                <Select
                  options={generateTimeOptions()}
                  value={generateTimeOptions().find(
                    (t) => t.value === startTime
                  )}
                  onChange={(option) =>
                    setStartTime(option ? option.value : "")
                  }
                  placeholder="Select Start Time..."
                />
              </Col>
            </Row>

            <Row>
              <Col xs={12} md={3}>
                <label>End Time:</label>
                <Select
                  options={generateTimeOptions()}
                  value={generateTimeOptions().find((t) => t.value === endTime)}
                  onChange={(option) => setEndTime(option ? option.value : "")}
                  placeholder="Select End Time..."
                />
              </Col>
              <Col xs={12} md={3}>
                <label>Status:</label>
                <Select
                  options={[
                    { value: "Scheduled", label: "Scheduled" },
                    { value: "Completed", label: "Completed" },
                    { value: "Cancelled", label: "Cancelled" },
                  ]}
                  value={{ value: status, label: status }}
                  onChange={(option) => setStatus(option ? option.value : "")}
                  placeholder="Select Status..."
                />
              </Col>
              <Col xs={12} md={6}>
                <label>Required Employees:</label>
                <Select
                  options={employeeOptions}
                  value={requiredEmployees}
                  onChange={(options) => setRequiredEmployees(options || [])}
                  isMulti
                  placeholder="Select Required Employees..."
                />
              </Col>
            </Row>

            <Row>
              <Col>
                <Button
                  variant="primary"
                  onClick={handleUpdate}
                  disabled={loading}
                >
                  {loading ? (
                    <Spinner animation="border" size="sm" />
                  ) : (
                    "Update Meeting"
                  )}
                </Button>
                <Button
                  variant="secondary"
                  onClick={handleBack}
                  className="ms-2"
                >
                  Back
                </Button>
                <Button
                  variant="danger"
                  onClick={() => setShowModal(true)}
                  className="ms-2"
                >
                  Delete Meeting
                </Button>
              </Col>
            </Row>
          </>
        )}

        <Modal show={showModal} onHide={() => setShowModal(false)}>
          <Modal.Header closeButton>
            <Modal.Title>Confirm Delete</Modal.Title>
          </Modal.Header>
          <Modal.Body>Are you sure you want to delete this meeting?</Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={() => setShowModal(false)}>
              Cancel
            </Button>
            <Button variant="danger" onClick={handleDelete}>
              Delete
            </Button>
          </Modal.Footer>
        </Modal>
      </div>
    </Container>
  );
};

export default UpdateMeetingForm;
