import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axiosInstance from "../../axiosInstance";
import {
  Form,
  Input,
  Select,
  DatePicker,
  TimePicker,
  Button,
  Spin,
  Row,
  Col,
  Typography,
  notification,
} from "antd";
import "../../css/MeetingForm.css";
import { BASE_URL } from "../../config";

const { Title } = Typography;
const { Option } = Select;

const MeetingForm = ({ onClose, onSaveSuccess }) => {
  const [courses, setCourses] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(false);
  const [form] = Form.useForm();
  const [meetingType, setMeetingType] = useState("");
  const [locations, setLocations] = useState([]);
  const [selectedParticipants, setSelectedParticipants] = useState([]);
  const [newCourseName, setNewCourseName] = useState("");
  const [isOtherCourse, setIsOtherCourse] = useState(false);

  const navigate = useNavigate();

  useEffect(() => {
    setLoading(true);
    axiosInstance
      .get(`${BASE_URL}/api/get_courses/`)
      .then((response) => setCourses(response.data))
      .catch((error) => {
        notification.error({
          message: "Error",

          description: "Failed to fetch courses.",
        });
      });

    axiosInstance
      .get(`${BASE_URL}/api/get_employees/`)
      .then((response) => setEmployees(response.data))
      .catch((error) => {
        console.error("Error fetching employees:", error);
        notification.error({
          message: "Error",

          description: "Failed to fetch employees.",
        });
      })
      .finally(() => setLoading(false));

    axiosInstance
      .get(`${BASE_URL}/api/get_locations/`)
      .then((response) => setLocations(response.data))
      .catch((error) => {
        console.error("Error fetching locations:", error);
        notification.error({
          message: "Error",
          description: "Failed to fetch locations.",
        });
      })
      .finally(() => setLoading(false));
  }, []);

  const handleCourseChange = (value) => {
    if (value === "Others") {
      setIsOtherCourse(true);
      setNewCourseName("");
    } else {
      setIsOtherCourse(false);
      setNewCourseName(value);
    }
  };

  const handleSubmit = (values) => {
    const course = isOtherCourse ? newCourseName : values.course;

    const meetingData = {
      meeting_name: values.meetingName,
      course: course,
      trainer_name: values.trainerName,
      start_date: values.startDate.format("YYYY-MM-DD"),
      end_date: values.endDate.format("YYYY-MM-DD"),
      start_time: values.startTime.format("HH:mm"),
      end_time: values.endTime.format("HH:mm"),
      required_employees: values.requiredEmployees,
      type: values.type,
      location: values.type === "Offline" ? values.location : null,
      online_url: values.type === "Online" ? values.onlineUrl : null,
    };

    if (isOtherCourse && !newCourseName) {
      notification.error({
        message: "Error",
        description: "Please input the new course name.",
      });
      return;
    }
    axiosInstance
      .post(`${BASE_URL}/api/create_meeting/`, meetingData)
      .then((response) => {
        notification.success({
          message: "Success",
          description: "Meeting created successfully.",
          placement: "topRight",
        });

        form.resetFields();
        setSelectedParticipants([]);
        onSaveSuccess();
        onClose();
      })
      .catch((error) => {
        if (error.response && error.response.data.error) {
          const errorMessage = error.response.data.error;
          const conflictingEmployees =
            error.response.data.conflicting_employees;

          if (conflictingEmployees && conflictingEmployees.length > 0) {
            const employeeNames = conflictingEmployees.join(", ");
            notification.error({
              message: "Error",
              description: `${errorMessage} ${employeeNames}`,
              placement: "topRight",
            });
          } else {
            notification.error({
              message: "Error",
              description: errorMessage,
              placement: "topRight",
            });
          }
        } else {
          notification.error({
            message: "Error",
            description: "Failed to create meeting. Please try again.",
            placement: "topRight",
          });
        }
      });
  };

  const handleTypeChange = (value) => {
    setMeetingType(value);
  };

  const handleClear = () => {
    form.resetFields();
  };

  const handleBack = () => {
    navigate("/");
  };

  return (
    <div className="meeting-form-container">
      <div>
        <Title level={5} style={{ fontWeight: "bold", color: "#013578" }}>
          Training Creation Form:
        </Title>
      </div>
      {loading ? (
        <Spin tip="Loading...">
          <div style={{ height: "100px" }}></div>
        </Spin>
      ) : (
        <Form
          form={form}
          onFinish={handleSubmit}
          layout="vertical"
          className="meeting-form"
        >
          <Row gutter={16}>
            <Col span={12}>
              <Form.Item
                label="Training Name"
                name="meetingName"
                rules={[
                  { required: true, message: "Please input the Training name" },
                ]}
              >
                <Input className="input-field" />
              </Form.Item>
            </Col>

            <Col span={12}>
              <Form.Item
                label="Course"
                name="course"
                rules={[{ required: true, message: "Please select a course" }]}
              >
                <Select
                  className="input-field"
                  placeholder="Select a course"
                  onChange={handleCourseChange}
                >
                  {courses.map((c) => (
                    <Option key={c.id} value={c.id}>
                      {c.course_name}
                    </Option>
                  ))}
                  <Option value="Others">Others</Option>
                </Select>
              </Form.Item>
            </Col>
            {isOtherCourse && (
              <Col span={12}>
                <Form.Item
                  label="New Course Name"
                  name="newCourseName"
                  rules={[
                    {
                      required: isOtherCourse,
                      message: "Please input the new course name",
                    },
                  ]}
                >
                  <Input
                    className="input-field"
                    value={newCourseName}
                    onChange={(e) => setNewCourseName(e.target.value)}
                  />
                </Form.Item>
              </Col>
            )}

            <Col span={12}>
              <Form.Item
                label="Trainer Name"
                name="trainerName"
                rules={[{ required: true, message: "Please select a trainer" }]}
              >
                <Select
                  className="input-field"
                  placeholder="Select a trainer"
                  mode="multiple"
                  showSearch
                  filterOption={(input, option) =>
                    option.children.toLowerCase().includes(input.toLowerCase())
                  }
                >
                  {employees.map((e) => (
                    <Option key={e.id} value={e.id}>
                      {e.name}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>

            <Col span={12}>
              <Form.Item
                label="Type"
                name="type"
                rules={[{ required: true, message: "Please select the type" }]}
              >
                <Select
                  className="input-field"
                  placeholder="Select type"
                  onChange={handleTypeChange}
                >
                  <Option value="Offline">Offline</Option>
                  <Option value="Online">Online</Option>
                </Select>
              </Form.Item>
            </Col>
            {meetingType === "Offline" && (
              <Col span={12}>
                <Form.Item
                  label="Location Name"
                  name="location"
                  rules={[
                    {
                      required: true,
                      message: "Please select a location name",
                    },
                  ]}
                >
                  <Select
                    className="input-field"
                    placeholder="Select a location"
                  >
                    {locations.map((loc) => (
                      <Option key={loc.id} value={loc.id}>
                        {loc.location_name}
                      </Option>
                    ))}
                  </Select>
                </Form.Item>
              </Col>
            )}
            {meetingType === "Online" && (
              <Col span={12}>
                <Form.Item
                  label="Online URL"
                  name="onlineUrl"
                  rules={[
                    {
                      required: true,
                      message: "Please input the online meeting URL",
                    },
                  ]}
                >
                  <Input className="input-field" placeholder="Enter URL" />
                </Form.Item>
              </Col>
            )}
            <Col span={12}>
              <Form.Item
                label="Start Date"
                name="startDate"
                rules={[
                  { required: true, message: "Please select the start date" },
                ]}
              >
                <DatePicker className="input-field" />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                label="End Date"
                name="endDate"
                rules={[
                  { required: true, message: "Please select the end date" },
                ]}
              >
                <DatePicker className="input-field" />
              </Form.Item>
            </Col>

            <Col span={12}>
              <Form.Item
                label="Start Time"
                name="startTime"
                rules={[
                  { required: true, message: "Please select the start time" },
                ]}
              >
                <TimePicker format="HH:mm" className="input-field" />
              </Form.Item>
            </Col>

            <Col span={12}>
              <Form.Item
                label="End Time"
                name="endTime"
                rules={[
                  { required: true, message: "Please select the end time" },
                ]}
              >
                <TimePicker format="HH:mm" className="input-field" />
              </Form.Item>
            </Col>

            <Col span={24}>
              <Form.Item
                label={`Required Participants (${selectedParticipants.length})`}
                name="requiredEmployees"
                rules={[
                  { required: true, message: "Please select Participants" },
                ]}
              >
                {" "}
                <Select
                  mode="multiple"
                  className="input-field"
                  placeholder="Select required Participants"
                  showSearch
                  filterOption={(input, option) =>
                    option.children.toLowerCase().includes(input.toLowerCase())
                  }
                  onChange={(value) => {
                    setSelectedParticipants(value);
                    form.setFieldsValue({ requiredEmployees: value });
                  }}
                >
                  {employees.map((e) => (
                    <Option key={e.id} value={e.id}>
                      {e.name}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>

            <Col span={24}>
              <Form.Item>
                <Button
                  type="primary"
                  className="create-button"
                  htmlType="submit"
                >
                  Create Meeting
                </Button>
                <Button
                  type="primary"
                  className="create-button"
                  style={{ marginLeft: "8px" }}
                  onClick={handleClear}
                >
                  Clear
                </Button>
                <Button
                  type="primary"
                  className="create-button"
                  style={{ marginLeft: "8px" }}
                  onClick={handleBack}
                >
                  Back to Home
                </Button>
              </Form.Item>
            </Col>
          </Row>
        </Form>
      )}
    </div>
  );
};

export default MeetingForm;
