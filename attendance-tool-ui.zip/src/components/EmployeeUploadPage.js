import React, { useState } from "react";
import { Upload, Button, message, Typography, notification } from "antd";
import { UploadOutlined } from "@ant-design/icons";
import axios from "axios";
import { BASE_URL } from "../config";

const EmployeeUploadPage = () => {
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const { Title } = Typography;

  const handleUpload = async () => {
    if (!file) {
      message.error("Please select a file to upload.");
      return;
    }

    const formData = new FormData();
    formData.append("file", file);

    setUploading(true);

    try {
      const response = await axios.post(
        `${BASE_URL}/api/upload-employees/`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );
      notification.success({
        message: "Success",
        description: `${response.data.message}`,
        placement: "topRight",
      });
    } catch (error) {
      if (error.response && error.response.data && error.response.data.error) {
        const errorMessage = error.response.data.error;
        notification.error({
          message: "Error",
          description: `Upload failed: ${errorMessage}`,
          placement: "topRight",
        });
      } else {
        notification.error({
          message: "Error",
          description: "An error occurred while uploading.",
          placement: "topRight",
        });
      }
    } finally {
      setUploading(false);
      setFile(null);
    }
  };

  const props = {
    beforeUpload: (file) => {
      const isExcel =
        file.type === "application/vnd.ms-excel" ||
        file.type ===
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
      if (!isExcel) {
        message.error("You can only upload Excel files.");
      }
      setFile(isExcel ? file : null);
      return false;
    },
    fileList: file ? [file] : [],
    onRemove: () => setFile(null),
  };

  return (
    <div>
      <div className="header-container">
        <Title level={5} style={{ fontWeight: "bold", color: "#013578" }}>
          Upload Employee Details
        </Title>
      </div>

      <div className="bordered-box">
        <div>
          <Upload {...props}>
            <Button icon={<UploadOutlined />}>Select Excel File</Button>
          </Upload>
          <Button
            type="primary"
            onClick={handleUpload}
            disabled={!file || uploading}
            loading={uploading}
            style={{ marginTop: 16 }}
          >
            {uploading ? "Uploading" : "Start Upload"}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default EmployeeUploadPage;
