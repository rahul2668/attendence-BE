import React, { useState, useEffect } from "react";
import { Table, Button, Typography, Spin } from "antd";
import { BASE_URL } from "../../config";
import moment from "moment";
import ExcelJS from "exceljs";
import { DownloadOutlined } from "@ant-design/icons";
import axiosInstance from "../../axiosInstance";

const { Title } = Typography;

const TrainingViewDetailsPageV2 = ({ selectedMeetingId }) => {
  const [inProgressAttendanceData, setInProgressAttendanceData] = useState([]);
  const [uniqueDates, setUniqueDates] = useState([]);
  const [loading, setLoading] = useState(false);
  const [meetingDetails, setMeetingDetails] = useState({
    trainerName: "",
    startDate: "",
    endDate: "",
    startTime: "",
    endTime: "",
    meetingType: "",
    location: "",
    meeting_name: "",
  });

  useEffect(() => {
    if (selectedMeetingId) {
      fetchMeetingData(selectedMeetingId);
    }
  }, [selectedMeetingId]);

  const fetchMeetingData = async (meetingId) => {
    setLoading(true);
    try {
      const response = await axiosInstance.get(
        `${BASE_URL}/api/attendance_list/?meeting=${meetingId}`
      );
      const { meeting_details, attendance } = response.data;
      setMeetingDetails({
        trainerName: meeting_details.trainer_name,
        startDate: meeting_details.start_date,
        endDate: meeting_details.end_date,
        startTime: meeting_details.start_time,
        endTime: meeting_details.end_time,
        meetingType: meeting_details.type,
        location: meeting_details.location,
        meeting_name: meeting_details.meeting_name,
      });

      let allDates = [...new Set(attendance.map((item) => item.date))];
      allDates = allDates.sort((a, b) => moment(a).diff(moment(b)));
      setUniqueDates(allDates);
      const attendanceMap = new Map();
      attendance.forEach(({ employee, date }) => {
        const empId = employee.employee_id;
        if (!attendanceMap.has(empId)) {
          attendanceMap.set(empId, {
            key: empId,
            employee_id: empId,
            employee_name: employee.name,
            email: employee.email,
            designation: employee.designation,
            vertical: employee.vertical,
            attendance: {},
          });
        }
        attendanceMap.get(empId).attendance[date] = "Present";
      });

      const requiredEmployeesMap = new Map();
      meeting_details.required_employees.forEach((emp) => {
        requiredEmployeesMap.set(emp.employee_id, {
          key: emp.employee_id,
          employee_id: emp.employee_id,
          employee_name: emp.name,
          email: emp.email,
          designation: emp.designation,
          vertical: emp.vertical,
          attendance: {},
        });
      });

      const dataWithKey = [...requiredEmployeesMap.values()].map((emp) => ({
        ...emp,
        ...attendanceMap.get(emp.employee_id),
      }));

      setInProgressAttendanceData(dataWithKey);
    } catch (error) {
      console.error("Error fetching attendance data:", error);
    } finally {
      setLoading(false);
    }
  };
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "long",
      year: "numeric",
    });
  };

  const baseColumns = [
    {
      title: "Employee ID",
      dataIndex: "employee_id",
      key: "employee_id",
    },
    {
      title: "Employee Name",
      dataIndex: "employee_name",
      key: "employee_name",
    },
    {
      title: "Email",
      dataIndex: "email",
      key: "email",
    },
    {
      title: "Vertical",
      dataIndex: "vertical",
      key: "vertical",
    },
    ...uniqueDates.map((date) => ({
      title: formatDate(date),
      dataIndex: date,
      key: date,
      render: (text, record) =>
        record.attendance[date] ? record.attendance[date] : "Absent",
    })),
  ];
  const exportToExcel = async () => {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet("Attendance Sheet");

    const formatDate = (date) => {
      const options = { day: "2-digit", month: "long", year: "numeric" };
      return new Date(date).toLocaleDateString("en-GB", options);
    };

    const formattedDates = uniqueDates.map((date) => formatDate(date));

    const formattedStartDate = formatDate(meetingDetails.startDate);
    const formattedEndDate = formatDate(meetingDetails.endDate);

    const headers = [
      "Employee ID",
      "Employee Name",
      "Email",
      "Designation",
      "Vertical",
      ...formattedDates,
    ];

    worksheet.mergeCells("A1", `F1`);
    const cellA1 = worksheet.getCell("A1");
    const { trainerName, startTime, endTime, location, meeting_name } =
      meetingDetails;
    cellA1.value = `${meeting_name} - Training Attendance`;
    cellA1.alignment = { horizontal: "center" };
    cellA1.font = { bold: true };
    const infoText = `Trainer Name: ${trainerName}, Date: ${formattedStartDate} - ${formattedEndDate}, Time: ${startTime} - ${endTime}, Location: ${location}`;
    worksheet.mergeCells("A2", `F2`);
    const cellA2 = worksheet.getCell("A2");
    cellA2.value = infoText;
    cellA2.alignment = { horizontal: "center" };
    cellA2.font = { bold: true };
    const fillStyle = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "FFF5F5DC" },
    };
    cellA1.fill = fillStyle;
    cellA2.fill = fillStyle;
    const headerRow = worksheet.addRow(headers);

    headerRow.eachCell({ includeEmpty: true }, (cell) => {
      cell.font = { bold: true };
      cell.border = {
        top: { style: "thin", color: { argb: "FF000000" } },
        left: { style: "thin", color: { argb: "FF000000" } },
        bottom: { style: "thin", color: { argb: "FF000000" } },
        right: { style: "thin", color: { argb: "FF000000" } },
      };
    });

    inProgressAttendanceData.forEach((item) => {
      const row = [
        item.employee_id,
        item.employee_name,
        item.email,
        item.designation,
        item.vertical,
        ...formattedDates.map((formattedDate) => {
          const originalDate = uniqueDates.find(
            (d) => formatDate(d) === formattedDate
          );
          return item.attendance[originalDate] || "Absent";
        }),
      ];
      const dataRow = worksheet.addRow(row);

      dataRow.eachCell({ includeEmpty: true }, (cell) => {
        cell.border = {
          top: { style: "thin", color: { argb: "FF000000" } },
          left: { style: "thin", color: { argb: "FF000000" } },
          bottom: { style: "thin", color: { argb: "FF000000" } },
          right: { style: "thin", color: { argb: "FF000000" } },
        };
      });
    });

    const MAX_COLUMN_WIDTH = 20;
    worksheet.columns.forEach((column) => {
      let maxLength = 0;
      column.eachCell({ includeEmpty: true }, (cell) => {
        const cellLength = cell.value ? cell.value.toString().length : 0;
        maxLength = Math.max(maxLength, cellLength);
      });
      column.width = Math.min(maxLength + 2, MAX_COLUMN_WIDTH);
    });

    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${meeting_name}_attendance.xlsx`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };
  return (
    <div>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <Title level={5} style={{ margin: 0, fontWeight: "bold" }}>
          Attendance Required Participants List
        </Title>
        <Button
          type="primary"
          className="inprogress-page-button"
          style={{ marginBottom: 20, marginLeft: 10 }}
          onClick={() => exportToExcel()}
          icon={<DownloadOutlined />}
        >
          Excel
        </Button>
      </div>
      {loading ? (
        <Spin />
      ) : (
        <Table
          dataSource={inProgressAttendanceData}
          columns={baseColumns}
          rowKey="employee_id"
          pagination={false}
          locale={{ emptyText: "No attendance records found" }}
          style={{ fontSize: "12px" }}
          components={{
            header: {
              cell: (props) => (
                <th {...props} style={{ padding: "4px", fontSize: "12px" }} />
              ),
            },
            body: {
              cell: (props) => (
                <td {...props} style={{ padding: "4px", fontSize: "12px" }} />
              ),
            },
          }}
        />
      )}
    </div>
  );
};

export default TrainingViewDetailsPageV2;
