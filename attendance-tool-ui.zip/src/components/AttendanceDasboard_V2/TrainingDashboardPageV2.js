import React, { useState } from "react";
import { Button, Modal, Typography } from "antd";
import { PlusOutlined, CloudUploadOutlined } from "@ant-design/icons";
import Box from "@mui/material/Box";
import MeetingListV2 from "./TrainingListPageV2";
import CreateMeetingForm from "../Meeting/CreateMeetingForm";
import { useNavigate } from "react-router-dom";
import EmployeeUploadPage from "../EmployeeUploadPage";

const { Title } = Typography;

const TrainingDashboardPageV2 = ({ title }) => {
  const navigate = useNavigate();
  const [isCreateModalVisible, setIsCreateModalVisible] = useState(false);
  const [isEmpUploadModalVisible, setIsEmpUploadModalVisible] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);

  const handleCreateMeetingModalOpen = () => {
    setIsCreateModalVisible(true);
  };

  const handleEmpUploadModalOpen = () => {
    setIsEmpUploadModalVisible(true);
  };

  const handleCreateMeetingModalClose = () => {
    setIsCreateModalVisible(false);
  };

  const handleEmpUploadModalClose = () => {
    setIsEmpUploadModalVisible(false);
  };

  const refreshMeetingList = () => {
    setRefreshKey((prevKey) => prevKey + 1);
  };

  return (
    <div>
      <div
        className="header-container"
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: "10px",
        }}
      >
        <Title
          level={5}
          style={{ fontWeight: "bold", color: "#013578", margin: "0" }}
        >
          Training Dashboard
        </Title>
        <div style={{ display: "flex", gap: "10px" }}>
          <Button
            type="primary"
            className="create-button"
            icon={<PlusOutlined />}
            onClick={handleCreateMeetingModalOpen}
          >
            Training
          </Button>
          <Button
            type="primary"
            className="create-button"
            onClick={handleEmpUploadModalOpen}
            icon={<CloudUploadOutlined />}
          >
            Employee Info
          </Button>
        </div>
      </div>

      <Box className="attendance-dashboard-bordered-box">
        <MeetingListV2 key={refreshKey} />
        {/* remove key={refreshKey} */}
        <Button
          type="primary"
          className="inprogress-page-button"
          style={{ marginTop: 10, marginLeft: 20, marginBottom: 20 }}
          onClick={() => navigate("/")}
        >
          Back to Home
        </Button>
      </Box>

      <Modal
        open={isCreateModalVisible}
        onCancel={handleCreateMeetingModalClose}
        width={800}
        footer={null}
      >
        <CreateMeetingForm
          onClose={handleCreateMeetingModalClose}
          onSaveSuccess={refreshMeetingList}
        />
      </Modal>
      <Modal
        open={isEmpUploadModalVisible}
        onCancel={handleEmpUploadModalClose}
        width={800}
        footer={null}
      >
        <EmployeeUploadPage onClose={handleEmpUploadModalClose} />
      </Modal>
    </div>
  );
};

export default TrainingDashboardPageV2;
