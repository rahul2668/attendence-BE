import React, { useState, useEffect } from "react";
import {
  Table,
  message,
  Button,
  Modal,
  Tag,
  Typography,
  Checkbox,
} from "antd";
import {
  EyeOutlined,
  PlusOutlined,
} from "@ant-design/icons";
import axiosInstance from "../../axiosInstance";
import { BASE_URL } from "../../config";
import Offcanvas from "react-bootstrap/Offcanvas";
import AssessmentResultsPageV2 from "./AssessmentResultPageV2";
import AssessmentFormCreationPageV2 from "./AssessmentFormCreationPageV2";
import Box from "@mui/material/Box";
import { useNavigate } from "react-router-dom";
const { Title } = Typography;
const { confirm } = Modal;

const AssessmentListPageV2 = () => {
  const navigate = useNavigate();
  const [meetings, setMeetings] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [showOffcanvas, setShowOffcanvas] = useState(false);
  const [offcanvasMode, setOffcanvasMode] = useState("view");
  const [statusFilters, setStatusFilters] = useState({
    in_progress: true,
    completed: true,
  });
  const [filterVisible, setFilterVisible] = useState(false);
  useEffect(() => {
    fetchItems();
  }, []);

  const fetchItems = async () => {
    setLoading(true);
    try {
      const response = await axiosInstance.get(
        `${BASE_URL}/api/meetingListV2/`
      );
      setMeetings(response.data);
    } catch (error) {
      if (error.response) {
        message.error(
          `Error ${error.response.status}: ${
            error.response.data.message || "Failed to fetch items."
          }`
        );
      } else if (error.request) {
        message.error("No response from server. Please try again later.");
      } else {
        message.error("Error: " + error.message);
      }
    } finally {
      setLoading(false);
    }
  };
  const filteredMeetings = meetings.filter((meeting) => {
    if (!statusFilters.in_progress && meeting.status === "in_progress")
      return false;
    if (!statusFilters.completed && meeting.status === "completed")
      return false;
    return true;
  });
  const trainerColumnWidth = 450;
  const tableStyles = {
    header: {
      height: "42px",
      lineHeight: "5px",
      fontSize: "14px",
      textAlign: "center",
    },
    cell: {
      height: "auto",
      lineHeight: "20px",
      fontSize: "12px",
      padding: "5px 5px",
      whiteSpace: "normal",
      textAlign: "center",
    },
  };

  const columns = [
    {
      title: "Training Name",
      dataIndex: "meeting_name",
      key: "meeting_name",
      onCell: () => ({
        style: tableStyles.cell,
      }),
    },
    {
      title: "Trainer",
      dataIndex: "trainer_name",
      key: "trainer_name",
      render: (trainers) => trainers.map((trainer) => trainer.name).join(", "),
      onCell: () => ({
        style: tableStyles.cell,
        textAlign: "left",
        height: "auto",
        whiteSpace: "normal",
      }),
      onHeaderCell: () => ({
        style: tableStyles.header,
      }),
      width: trainerColumnWidth,
    },
    {
      title: "Course",
      dataIndex: ["course", "course_name"],
      key: "course_name",
      onCell: () => ({
        style: tableStyles.cell,
      }),
      onHeaderCell: () => ({
        style: tableStyles.header, 
      }),
    },
    {
      title: "Start Date",
      dataIndex: "start_date",
      key: "start_date",
      onCell: () => ({
        style: tableStyles.cell,
      }),
      onHeaderCell: () => ({
        style: tableStyles.header,
      }),
    },
    {
      title: "End date",
      dataIndex: "end_date",
      key: "end_date",
      onCell: () => ({
        style: tableStyles.cell,
      }),
      onHeaderCell: () => ({
        style: tableStyles.header,
      }),
    },
    // {
    //   title: "Status",
    //   dataIndex: "status",
    //   key: "status",
    //   render: (status) => (
    //     <Tag color={getStatusColor(status)} style={{ color: "#000" }}>
    //       {getStatusDisplayName(status)}
    //     </Tag>
    //   ),
    //   onCell: () => ({
    //     style: tableStyles.cell,
    //   }),
    //   onHeaderCell: () => ({
    //     style: tableStyles.header, // Apply header styles here
    //   }),
    //   filters: [
    //     { text: "In Progress", value: "in_progress" },
    //     { text: "Completed", value: "completed" },
    //   ],
    //   onFilter: (value, record) => record.status.includes(value),
    //   filterMultiple: true,
    //   //   filterDropdown: ({ setSelectedKeys, selectedKeys, confirm }) => (
    //   //     <div style={{ padding: 8, width: 200 }}>
    //   //       <Checkbox.Group
    //   //         options={[
    //   //           { label: "In Progress", value: "in_progress" },
    //   //           { label: "Completed", value: "completed" },
    //   //         ]}
    //   //         value={selectedKeys}
    //   //         onChange={(values) => {
    //   //           setSelectedKeys(values);
    //   //           confirm();
    //   //         }}
    //   //         style={{ display: "flex", flexDirection: "column" }}
    //   //       />
    //   //     </div>
    //   //   ),
    // },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (status) => (
        <Tag color={getStatusColor(status)} style={{ color: "#000" }}>
          {getStatusDisplayName(status)}
        </Tag>
      ),
      onCell: () => ({
        style: tableStyles.cell,
      }),
      onHeaderCell: () => ({
        style: tableStyles.header,
      }),
      filters: [
        { text: "In Progress", value: "in_progress" },
        { text: "Completed", value: "completed" },
      ],
      onFilter: (value, record) => record.status.includes(value),
      filterMultiple: true,
      filterDropdown: ({ setSelectedKeys, selectedKeys, confirm }) => {
        if (selectedKeys.length === 0) {
          setSelectedKeys(["in_progress", "completed"]);
        }

        return (
          <div style={{ padding: 8, width: 200 }}>
            <Checkbox.Group
              options={[
                { label: "In Progress", value: "in_progress" },
                { label: "Completed", value: "completed" },
              ]}
              value={selectedKeys}
              onChange={(values) => {
                setSelectedKeys(values);
                confirm();
              }}
              style={{ display: "flex", flexDirection: "column" }}
            />
          </div>
        );
      },
    },
    {
      title: "Action",
      key: "action",
      render: (_, record) => (
        <span>
          <Button
            icon={<EyeOutlined />}
            onClick={() => handleView(record)}
            style={{ marginRight: 8 }}
          />
          <Button
            icon={<PlusOutlined />}
            onClick={() => handleCreate(record.id)}
            style={{ marginRight: 8 }}
          />
        </span>
      ),
      onCell: () => ({
        style: tableStyles.cell,
      }),
      onHeaderCell: () => ({
        style: tableStyles.header,
      }),
    },
  ];

  const handleView = (item) => {
    setSelectedItem(item);
    setOffcanvasMode("view");
    setShowOffcanvas(true);
  };

  const handleCreate = (meetingId) => {
    setSelectedItem({ id: meetingId });
    setOffcanvasMode("create");
    setShowOffcanvas(true);
  };

  const handleOffcanvasClose = () => {
    setShowOffcanvas(false);
    setSelectedItem(null);
  };

  const getStatusDisplayName = (status) => {
    const statusMap = {
      in_progress: "In Progress",
      completed: "Completed",
    };
    return statusMap[status] || status;
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "in_progress":
        return "#faad14";
      case "completed":
        return "#52c41a";
      default:
        return "#d9d9d9";
    }
  };
  const handleFilterChange = (checkedValues) => {
    const newFilters = {
      in_progress: checkedValues.includes("in_progress"),
      completed: checkedValues.includes("completed"),
    };
    setStatusFilters(newFilters);
  };
  return (
    <div>
      <div
        className="header-container"
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: "10px",
        }}
      >
        <Title
          level={5}
          style={{ fontWeight: "bold", color: "#013578", margin: "0" }}
        >
          Assessment Dashboard
        </Title>
      </div>
      <Box className="attendance-dashboard-bordered-box">
        {filterVisible && (
          <div style={{ marginBottom: 16 }}>
            <Checkbox.Group
              options={[
                { label: "In Progress", value: "in_progress" },
                { label: "Completed", value: "completed" },
              ]}
              onChange={handleFilterChange}
              defaultValue={Object.keys(statusFilters).filter(
                (key) => statusFilters[key]
              )}
            />
          </div>
        )}
        <Table
          className="custom-table"
          dataSource={filteredMeetings}
          columns={columns}
          rowKey="id"
          loading={loading}
          pagination={{ pageSize: 10 }}
          locale={{ emptyText: "No items found" }}
        />
        <Button
          type="primary"
          className="inprogress-page-button"
          style={{ marginTop: 10, marginLeft: 20, marginBottom: 20 }}
          onClick={() => navigate("/")}
        >
          Back to Home
        </Button>
        <Offcanvas
          show={showOffcanvas}
          onHide={handleOffcanvasClose}
          className="custom-offcanvas"
          placement="end"
        >
          <Offcanvas.Header closeButton style={{ padding: "10px" }}>
            <Offcanvas.Title style={{ fontSize: "15px", fontWeight: "bold" }}>
              {offcanvasMode === "view"
                ? "Assessment Details"
                : "Create Assessment"}
            </Offcanvas.Title>
          </Offcanvas.Header>

          <div
            style={{
              width: "95%",
              margin: "0 auto",
              borderBottom: "1px solid #ccc",
            }}
          ></div>
          <Offcanvas.Body>
            {offcanvasMode === "view" && selectedItem ? (
              <div>
                <AssessmentResultsPageV2 meetingId={selectedItem.id} />
              </div>
            ) : offcanvasMode === "create" && selectedItem ? (
              <div>
                <AssessmentFormCreationPageV2 meetingId={selectedItem.id} />
              </div>
            ) : (
              <p>No item selected</p>
            )}
          </Offcanvas.Body>
        </Offcanvas>
      </Box>
    </div>
  );
};

export default AssessmentListPageV2;
