import React, { useState, useEffect } from "react";
import { Select, Button, notification, message } from "antd";
import "../../css/FormFill.css";
import { CopyOutlined } from "@ant-design/icons";
import { generateOtp } from "../../services/api_list";

const GenerateOTPPageV2 = ({ meetingId, onClose }) => {
  const [otp, setOtp] = useState(null);
  const [meetingName, setMeetingName] = useState("");
  const [url, setUrl] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [validationMinutes, setValidationMinutes] = useState(null);
  const { Option } = Select;

  useEffect(() => {
    if (!meetingId) {
      setError("Meeting ID is not provided");
      setLoading(false);
    } else {
      setLoading(false);
    }
  }, [meetingId]);

  const handleValidationMinutesChange = (value) => {
    setValidationMinutes(value);
  };

  const handleGenerateOtp = async (e) => {
    e.preventDefault();
    if (meetingId && validationMinutes) {
      try {
        const response = await generateOtp(meetingId, validationMinutes);
        setOtp(response.otp);
        setMeetingName(response.meeting_name);
        setUrl(response.url);
      } catch (error) {
        setError("Failed to generate OTP");
        notification.error({
          message: "Error",
          description: "Failed to generate OTP",
          placement: "topRight",
        });
      }
    } else {
      notification.warning({
        message: "Warning",
        description: "Please select validation minutes",
        placement: "topRight",
      });
    }
  };

  const handleNavigateToFormFill = () => {
    window.open(url, "_blank");
  };

  if (loading) return <p>Loading...</p>;
  if (error) return <p>{error}</p>;

  return (
    <div>
      <div className="header-container"></div>

      <div>
        {/* className="bordered-box" */}
        <div>
          <div>
            <label
              htmlFor="validation-minutes-select"
              style={{
                // fontWeight: "bold",
                display: "block",
                marginBottom: "8px",
              }}
            >
              Select Timeout Minutes:{" "}
            </label>

            <Select
              id="validation-minutes-select"
              value={validationMinutes}
              onChange={handleValidationMinutesChange}
              placeholder="Select validation minutes"
              style={{ width: 250, marginBottom: 20 }}
              required
            >
              <Option value={120}>2 Min</Option>
              <Option value={300}>5 Min</Option>
              <Option value={600}>10 Min</Option>
              <Option value={900}>15 Min</Option>
              <Option value={1200}>20 Min</Option>
            </Select>
          </div>
          <Button
            type="primary"
            onClick={handleGenerateOtp}
            style={{ marginTop: "16px" }}
            className="inprogress-page-button"
          >
            Generate OTP
          </Button>
        </div>

        {otp && (
          <div style={{ marginTop: "20px" }}>
            <p>
              Your OTP for the meeting "{meetingName}" is:{" "}
              <strong style={{ fontSize: "25px" }}>{otp}</strong>
            </p>
            <p>
              Access the form using this URL:{" "}
              <a href={url} target="_blank" rel="noopener noreferrer">
                <br />
                {url}
              </a>
              <CopyOutlined
                onClick={() => {
                  navigator.clipboard.writeText(url);
                  message.success("URL copied to clipboard!");
                }}
                style={{
                  cursor: "pointer",
                  marginLeft: "15px",
                  fontSize: "20px",
                  color: "#1890ff",
                }}
                title="Copy to clipboard"
              />
            </p>
            <Button
              onClick={handleNavigateToFormFill}
              className="inprogress-page-button"
            >
              Go to Form Fill
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default GenerateOTPPageV2;
