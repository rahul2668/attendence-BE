import React, { useState, useEffect } from "react";
import { Table, message, DatePicker, Button } from "antd";
import axiosInstance from "../../axiosInstance";
import { BASE_URL } from "../../config";
import ExcelJS from "exceljs";
import "../../css/MeetingListV2.css";
import { CopyOutlined } from "@ant-design/icons";

const AssessmentResultsPageV2 = ({ meetingId }) => {
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [totalMarks, setTotalMarks] = useState(0);
  const [trainerName, setTrainerName] = useState("");
  const [meetingName, setMeetingName] = useState("");
  const [creationDate, setCreationDate] = useState("");
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");
  const [selectedDate, setSelectedDate] = useState(null);
  const [url, setUrl] = useState("");

  useEffect(() => {
    if (meetingId && selectedDate) {
      fetchResults(meetingId, selectedDate);
    }
  }, [meetingId, selectedDate]);

  const handleDateChange = (date, dateString) => {
    setSelectedDate(dateString);
    if (meetingId) {
      fetchResults(meetingId, dateString);
    }
  };

  const fetchResults = async (meetingId, date) => {
    if (!meetingId || !date) return;
    setLoading(true);
    try {
      const response = await axiosInstance.get(
        `${BASE_URL}/api/assessment-results/${meetingId}/${date}`
      );

      setTotalMarks(response.data.total_marks);
      setResults(response.data.employee_detail);
      setTrainerName(response.data.trainer_name);
      setMeetingName(response.data.meeting_name);
      setCreationDate(response.data.creationDate);
      setStartTime(response.data.start_time);
      setEndTime(response.data.end_time);
      setUrl(response.data.url);
    } catch (error) {
      message.error("Failed to fetch assessment results");
      setResults([]);
    }
    setLoading(false);
  };

  const columns = [
    {
      title: "Emp ID",
      dataIndex: "employee_id",
      key: "employee_id",
    },
    {
      title: "Name",
      dataIndex: "name",
      key: "name",
    },
    {
      title: "Designation",
      dataIndex: "designation",
      key: "designation",
    },
    {
      title: "Vertical",
      dataIndex: "vertical",
      key: "vertical",
    },
    {
      title: `Total Marks (${totalMarks})`,
      dataIndex: "marks",
      key: "marks",
    },
  ];

  const downloadExcel = async () => {
    const formatDate = (date) => {
      const options = { day: "2-digit", month: "long", year: "numeric" };
      return new Date(date).toLocaleDateString("en-GB", options);
    };
    const formattedDate = formatDate(creationDate);
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet("Assessment Results");

    const headers = [
      "Emp ID",
      "Name",
      "Email",
      "Designation",
      "Vertical",
      `Total Marks (${totalMarks})`,
    ];

    worksheet.mergeCells("A1", "F1");
    const titleCell = worksheet.getCell("A1");
    titleCell.value = `${meetingName} - Assessment Results`;
    titleCell.alignment = { horizontal: "center" };
    titleCell.font = { bold: true };

    worksheet.mergeCells("A2", "F2");
    const infoCell = worksheet.getCell("A2");
    infoCell.value = `Trainer: ${trainerName}, Date: ${formattedDate}, Time: ${startTime} - ${endTime}`;
    infoCell.alignment = { horizontal: "center" };
    infoCell.font = { bold: true };

    const fillStyle = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "FFF5F5DC" },
    };

    titleCell.fill = fillStyle;
    infoCell.fill = fillStyle;

    const headerRow = worksheet.addRow(headers);
    headerRow.eachCell((cell) => {
      cell.font = { bold: true };
      cell.border = {
        top: { style: "thin", color: { argb: "FF000000" } },
        left: { style: "thin", color: { argb: "FF000000" } },
        bottom: { style: "thin", color: { argb: "FF000000" } },
        right: { style: "thin", color: { argb: "FF000000" } },
      };
    });

    results.forEach((item) => {
      const row = [
        item.employee_id,
        item.name,
        item.email,
        item.designation,
        item.vertical,
        item.marks,
      ];

      const dataRow = worksheet.addRow(row);

      dataRow.eachCell((cell) => {
        cell.border = {
          top: { style: "thin", color: { argb: "FF000000" } },
          left: { style: "thin", color: { argb: "FF000000" } },
          bottom: { style: "thin", color: { argb: "FF000000" } },
          right: { style: "thin", color: { argb: "FF000000" } },
        };
      });
    });
    const MAX_COLUMN_WIDTH = 20;
    worksheet.columns.forEach((column) => {
      let maxLength = 0;
      column.eachCell({ includeEmpty: true }, (cell) => {
        const cellLength = cell.value ? cell.value.toString().length : 0;
        maxLength = Math.max(maxLength, cellLength);
      });
      column.width = Math.min(maxLength + 2, MAX_COLUMN_WIDTH);
    });

    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `assessment_results_${meetingName}_${formattedDate}.xlsx`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };

  return (
    <div>
      <div className="header-container"></div>

      <div className="bordered-box">
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            marginBottom: "16px",
          }}
        >
          <label htmlFor="date-picker" style={{ display: "block" }}>
            Select Date:
          </label>
          <div style={{ display: "flex", alignItems: "center" }}>
            <DatePicker
              id="date-picker"
              onChange={handleDateChange}
              format="YYYY-MM-DD"
              style={{ width: 250, marginRight: "16px" }}
              disabled={!meetingId}
            />
            <div style={{ display: "flex", alignItems: "center" }}>
              <label htmlFor="url-display" style={{ marginRight: "8px" }}>
                URL:
              </label>
              <div id="url-display">
                {url ? (
                  <>
                    <a
                      href={url}
                      style={{ color: "blue", marginRight: "15px" }}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      {url}
                    </a>
                    <CopyOutlined
                      style={{
                        cursor: "pointer",
                        fontSize: "20px",
                        color: "#1890ff",
                      }}
                      onClick={() => {
                        navigator.clipboard.writeText(url);
                        message.success("URL copied to clipboard!");
                      }}
                    />
                  </>
                ) : (
                  <span></span>
                )}
              </div>
            </div>
          </div>
        </div>

        {results.length > 0 ? (
          <>
            <div
              style={{ flex: 1, display: "flex", justifyContent: "flex-end" }}
            >
              <Button
                type="primary"
                className="inprogress-page-button"
                onClick={downloadExcel}
              >
                Download Excel
              </Button>
            </div>
            <br />

            <div style={{ overflowX: "auto" }}>
              <Table
                // className="custom-table"
                dataSource={results}
                columns={columns}
                rowKey="employee_id"
                pagination={false}
                loading={loading}
                style={{ fontSize: "12px" }}
                components={{
                  header: {
                    cell: (props) => (
                      <th
                        {...props}
                        style={{ padding: "4px", fontSize: "12px" }}
                      />
                    ),
                  },
                  body: {
                    cell: (props) => (
                      <td
                        {...props}
                        style={{ padding: "4px", fontSize: "12px" }}
                      />
                    ),
                  },
                }}
              />
            </div>
          </>
        ) : (
          <Table
            dataSource={[]}
            columns={columns}
            locale={{ emptyText: "No Data Found" }}
            pagination={false}
            loading={loading}
          />
        )}
      </div>
    </div>
  );
};

export default AssessmentResultsPageV2;
