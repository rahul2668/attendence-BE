import React, { useState, useEffect } from "react";
import {
  Input,
  Select,
  TimePicker,
  Button,
  Row,
  Col,
  notification,
} from "antd";
import moment from "moment";
import DatePicker from "react-datepicker";
import "bootstrap/dist/css/bootstrap.min.css";
import "react-datepicker/dist/react-datepicker.css";
import { BASE_URL } from "../../config";
import "../../css/UpdateMeetingNew.css";
import axiosInstance from "../../axiosInstance";

const { Option } = Select;

const UpdateMeetingPageV2 = ({ meetingId, onClose }) => {
  const [courses, setCourses] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [locations, setLocations] = useState([]);
  const [selectedLocation, setSelectedLocation] = useState(null);

  const [onlineUrl, setOnlineUrl] = useState("");
  const [meetingType, setMeetingType] = useState(null);

  const [meetingName, setMeetingName] = useState("");
  const [course, setCourse] = useState(null);
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [startTime, setStartTime] = useState(null);
  const [endTime, setEndTime] = useState(null);
  const [trainerName, setTrainerName] = useState(null);
  const [status, setStatus] = useState(null);
  const [requiredParticipants, setRequiredParticipants] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedMeeting, setSelectedMeeting] = useState(null);

  useEffect(() => {
    axiosInstance
      .get(`${BASE_URL}/api/get_courses/`)
      .then((response) => setCourses(response.data));
    axiosInstance
      .get(`${BASE_URL}/api/get_employees/`)
      .then((response) => setEmployees(response.data));
    axiosInstance.get(`${BASE_URL}/api/get_locations/`).then((response) => {
      setLocations(response.data);
    });

    if (meetingId) {
      setLoading(true);
      axiosInstance
        .get(`${BASE_URL}/api/meetings_inprogress_list/${meetingId}/`)
        .then((response) => {
          const meeting = response.data;
          setSelectedMeeting(meeting);
          setMeetingName(meeting.meeting_name);
          setCourse(meeting.course.id);
          setStartDate(
            meeting.start_date ? new Date(meeting.start_date) : null
          );
          setEndDate(meeting.end_date ? new Date(meeting.end_date) : null);
          setStartTime(
            meeting.start_time ? moment(meeting.start_time, "HH:mm:ss") : null
          );
          setEndTime(
            meeting.end_time ? moment(meeting.end_time, "HH:mm:ss") : null
          );
          setTrainerName(meeting.trainer_name.map((t) => t.id));
          setStatus(meeting.status);
          setRequiredParticipants(meeting.required_employees.map((e) => e.id));
          setSelectedLocation(
            meeting.location ? meeting.location.location_name : null
          );
          setOnlineUrl(meeting.online_url || "");
          setMeetingType(meeting.type);
          setLoading(false);
        });
    }
  }, [meetingId]);

  const handleUpdate = () => {
    const payload = {
      meeting_name: meetingName,
      course: course,
      start_date: startDate ? moment(startDate).format("YYYY-MM-DD") : null,
      end_date: endDate ? moment(endDate).format("YYYY-MM-DD") : null,
      start_time: startTime ? startTime.format("HH:mm") : null,
      end_time: endTime ? endTime.format("HH:mm") : null,
      required_employees: requiredParticipants,
      trainer_name: trainerName,
      type: meetingType,
      status: status,
      location: locations?.filter(
        (data) => data.location_name === selectedLocation
      )[0].id,
      online_url: onlineUrl,
    };

    axiosInstance
      .post(`${BASE_URL}/api/update_meeting/${meetingId}/`, payload)
      .then(() => {
        notification.success({
          message: "Success",
          description: "Meeting updated Successfully",
          placement: "topRight",
        });

        setSelectedMeeting(null);
        onClose();
      })
      .catch((error) => {
        if (error.response && error.response.data.error) {
          const errorMessage = error.response.data.error;
          const conflictingEmployees =
            error.response.data.conflicting_employees;

          if (conflictingEmployees && conflictingEmployees.length > 0) {
            const employeeNames = conflictingEmployees.join(", ");
            notification.error({
              message: "Error",
              description: `${errorMessage} ${employeeNames}`,
              placement: "topRight",
            });
          } else {
            notification.error({
              message: "Error",
              description: errorMessage,
              placement: "topRight",
            });
          }
        } else {
          notification.error({
            message: "Error",
            description: "Failed to Update meeting. Please try again.",
            placement: "topRight",
          });
        }
      });
  };

  return (
    <div>
      <div className="updateMeeting-bordered-box">
        {/* <div className="bordered-box"> */}
        <Row gutter={16}>
          {selectedMeeting && (
            <>
              <Col span={12}>
                <div>
                  <label style={{ display: "block" }}>
                    Training Name <span style={{ color: "red" }}>*</span>
                  </label>
                  <Input
                    value={meetingName}
                    style={{ width: 250, height: 30 }}
                    onChange={(e) => setMeetingName(e.target.value)}
                    disabled
                  />
                </div>
              </Col>

              <Col span={12}>
                <div>
                  <label style={{ display: "block" }}>
                    Course <span style={{ color: "red" }}>*</span>
                  </label>
                  <Select
                    value={course}
                    style={{ width: 250 }}
                    onChange={(value) => setCourse(value)}
                    placeholder="Select a course"
                    disabled
                  >
                    {courses.map((c) => (
                      <Option key={c.id} value={c.id}>
                        {c.course_name}
                      </Option>
                    ))}
                  </Select>
                </div>
              </Col>

              <Col span={12}>
                <div>
                  <label style={{ display: "block" }}>
                    Trainer Name <span style={{ color: "red" }}>*</span>
                  </label>
                  <Select
                    mode="multiple"
                    value={trainerName}
                    style={{ width: 250 }}
                    onChange={(values) => setTrainerName(values)}
                    placeholder="Select trainers"
                    showSearch
                    filterOption={(input, option) =>
                      option.children
                        .toLowerCase()
                        .includes(input.toLowerCase())
                    }
                  >
                    {employees.map((e) => (
                      <Option key={e.id} value={e.id}>
                        {e.name}
                      </Option>
                    ))}
                  </Select>
                </div>
              </Col>

              <Col span={12}>
                <div>
                  <label style={{ display: "block" }}>
                    Status <span style={{ color: "red" }}>*</span>
                  </label>
                  <Select
                    value={status}
                    onChange={(value) => setStatus(value)}
                    style={{ width: 250 }}
                  >
                    <Select.Option value="in_progress">
                      In Progress
                    </Select.Option>
                    <Select.Option value="completed">Completed</Select.Option>
                  </Select>
                </div>
              </Col>

              <Col span={12}>
                <label style={{ display: "block" }}>
                  Type <span style={{ color: "red" }}>*</span>
                </label>
                <Select
                  value={meetingType}
                  className="input-field"
                  placeholder="Select type"
                  onChange={(value) => setMeetingType(value)}
                  style={{ width: 250 }}
                >
                  <Option value="Offline">Offline</Option>
                  <Option value="Online">Online</Option>
                </Select>
              </Col>

              {meetingType === "Offline" && (
                <Col span={12}>
                  <div>
                    <label style={{ display: "block" }}>
                      Location Name <span style={{ color: "red" }}>*</span>
                    </label>
                    <Select
                      className="input-field"
                      placeholder="Select a location"
                      value={selectedLocation}
                      onChange={(value) => setSelectedLocation(value)}
                      style={{ width: 250 }}
                    >
                      {locations.map((loc) => (
                        <Option key={loc.id} value={loc.location_name}>
                          {loc.location_name}
                        </Option>
                      ))}
                    </Select>
                  </div>
                </Col>
              )}

              {meetingType === "Online" && (
                <Col span={12}>
                  <div>
                    <label style={{ display: "block" }}>
                      Online URL <span style={{ color: "red" }}>*</span>
                    </label>
                    <Input
                      value={onlineUrl}
                      onChange={(e) => setOnlineUrl(e.target.value)}
                      placeholder="Enter online URL"
                      style={{ width: 250 }}
                    />
                  </div>
                </Col>
              )}

              <Col span={12}>
                <div>
                  <label style={{ display: "block" }}>
                    Start Date <span style={{ color: "red" }}>*</span>
                  </label>
                  <DatePicker
                    selected={startDate}
                    onChange={(date) => setStartDate(date)}
                    dateFormat="yyyy/MM/dd"
                    style={{ width: 250 }}
                  />
                </div>
              </Col>

              <Col span={12}>
                <div>
                  <label style={{ display: "block" }}>
                    End Date <span style={{ color: "red" }}>*</span>
                  </label>
                  <DatePicker
                    selected={endDate}
                    onChange={(date) => setEndDate(date)}
                    dateFormat="yyyy/MM/dd"
                    style={{ width: 250 }}
                  />
                </div>
              </Col>

              <Col span={12}>
                <div>
                  <label style={{ display: "block" }}>
                    Start Time <span style={{ color: "red" }}>*</span>
                  </label>
                  <TimePicker
                    value={startTime}
                    onChange={(time) => setStartTime(time)}
                    format="HH:mm"
                    style={{ width: 250 }}
                  />
                </div>
              </Col>

              <Col span={12}>
                <div>
                  <label style={{ display: "block" }}>
                    End Time <span style={{ color: "red" }}>*</span>
                  </label>
                  <TimePicker
                    value={endTime}
                    onChange={(time) => setEndTime(time)}
                    format="HH:mm"
                    style={{ width: 250 }}
                  />
                </div>
              </Col>

              <Col span={12}>
                <div>
                  <label style={{ display: "block" }}>
                    Required Participants{" "}
                    <span style={{ color: "red" }}>*</span>
                  </label>
                  <Select
                    mode="multiple"
                    value={requiredParticipants}
                    onChange={(values) => setRequiredParticipants(values)}
                    style={{ width: 550, marginBottom: "10px" }}
                    placeholder="Select required Participants"
                    showSearch
                    filterOption={(input, option) =>
                      option.children
                        .toLowerCase()
                        .includes(input.toLowerCase())
                    }
                  >
                    {employees.map((e) => (
                      <Option key={e.id} value={e.id}>
                        {e.name}
                      </Option>
                    ))}
                  </Select>
                </div>
              </Col>

              <Col span={24}>
                <Button
                  type="primary"
                  className="create-button"
                  onClick={handleUpdate}
                  loading={loading}
                >
                  Update Meeting
                </Button>
              </Col>
            </>
          )}
        </Row>
      </div>
    </div>
  );
};

export default UpdateMeetingPageV2;
