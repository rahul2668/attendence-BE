import React, { useState, useEffect } from "react";
import {
  Button,
  Input,
  Select,
  Radio,
  Rate,
  Space,
  Form,
  Card,
  notification,
  Modal,
  Typography,
} from "antd";
import { PlusOutlined, LoadingOutlined, CopyOutlined } from "@ant-design/icons";
import "../../css/FormCreationComponent.css";
import { BASE_URL, LOCAL_FE_URL } from "../../config";
import axiosInstance from "../../axiosInstance";
const { Option } = Select;

const { Title } = Typography;

const AssessmentFormCreationPageV2 = ({ meetingId }) => {
  const [meetingsList, setMeetingsList] = useState([]);
  const [questions, setQuestions] = useState([]);
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const [loading, setLoading] = useState(false);

  const creationDate = new Date().toISOString().split("T")[0];

  useEffect(() => {
    const fetchMeetings = async () => {
      try {
        const response = await axiosInstance.get(
          `${BASE_URL}/api/get_meetings_inprogress/`
        );
        const data = response.data;
        const formattedMeetings = data.map((meeting) => ({
          id: meeting.id,
          name: meeting.meeting_name,
        }));
        setMeetingsList(formattedMeetings);
      } catch (error) {
        notification.error({
          message: "Error",
          description: "Failed to fetch meetings list",
        });
      }
    };

    fetchMeetings();
  }, []);

  const addQuestion = () => {
    if (!meetingId) {
      notification.error({
        message: "No Meeting Selected",
        description: "Please select a meeting before adding questions.",
      });
      return;
    }

    const nextSequenceNumber = questions.length + 1;

    setQuestions((prevQuestions) => [
      ...prevQuestions,
      {
        id: nextSequenceNumber,
        type: "text",
        question: "",
        options: [],
        acceptedAnswer: "",
        required: false,
      },
    ]);
  };

  const handleTypeChange = (id, value) => {
    const updatedQuestions = questions.map((q) =>
      q.id === id ? { ...q, type: value, options: [], acceptedAnswer: "" } : q
    );
    setQuestions(updatedQuestions);
  };
  const handleQuestionChange = (id, value) => {
    const updatedQuestions = questions.map((q) =>
      q.id === id ? { ...q, question: value } : q
    );
    setQuestions(updatedQuestions);
  };

  const handleAddOption = (id) => {
    const updatedQuestions = questions.map((q) =>
      q.id === id ? { ...q, options: [...q.options, ""] } : q
    );
    setQuestions(updatedQuestions);
  };

  const handleRemoveOption = (id, index) => {
    const updatedQuestions = questions.map((q) =>
      q.id === id
        ? { ...q, options: q.options.filter((_, i) => i !== index) }
        : q
    );
    setQuestions(updatedQuestions);
  };

  const handleOptionChange = (id, value, index) => {
    const updatedQuestions = questions.map((q) =>
      q.id === id
        ? {
            ...q,
            options: q.options.map((opt, i) => (i === index ? value : opt)),
          }
        : q
    );
    setQuestions(updatedQuestions);
  };

  const handleDeleteQuestion = (id) => {
    const updatedQuestions = questions.filter((q) => q.id !== id);
    setQuestions(updatedQuestions);
  };
  const handleCopyUrl = (url) => {
    navigator.clipboard.writeText(url);
    notification.success({
      message: "Success",
      description: "URL copied to clipboard",
    });
  };
  const handleRequiredToggle = (id, value) => {
    const updatedQuestions = questions.map((q) =>
      q.id === id ? { ...q, required: value } : q
    );
    setQuestions(updatedQuestions);
  };

  const handleAnswerChange = (id, value) => {
    const updatedQuestions = questions.map((q) =>
      q.id === id ? { ...q, acceptedAnswer: value } : q
    );
    setQuestions(updatedQuestions);
  };
  const handlePreviewForm = async () => {
    if (!meetingId) {
      notification.warning({
        message: "No Meeting Selected",
        description: "Please select a meeting before generating a preview.",
      });
      return;
    }

    if (questions.length === 0) {
      notification.warning({
        message: "No Questions Added",
        description: "Please add at least one question to preview.",
      });
      return;
    }
    setLoading(true);

    try {
      setIsPreviewMode(true);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    if (!meetingId) {
      notification.warning({
        message: "No Meeting Selected",
        description: "Please select a meeting before generating a preview.",
      });
      return;
    }

    if (questions.length === 0) {
      notification.warning({
        message: "No Questions Added",
        description: "Please add at least one question to preview.",
      });
      return;
    }

    const previewPayload = {
      meeting_id: meetingId,
      creationDate: creationDate,
      questions: questions.map(
        ({ id, type, question, options, required, acceptedAnswer }) => ({
          id,
          type,
          question,
          options,
          required,
          acceptedAnswer,
        })
      ),
    };

    setLoading(true);

    try {
      const response = await axiosInstance.post(
        `${BASE_URL}/api/save_questions/`,
        previewPayload,
        {
          headers: {
            "Content-Type": "application/json",
          },
          // body: JSON.stringify(previewPayload),
        }
      );

      if (response.status >= 200 && response.status < 300) {
        const formUrl = `${LOCAL_FE_URL}/form-fill/${meetingId}/${creationDate}`;

        Modal.success({
          title: "Form Created Successfully!",
          content: (
            <div>
              <p>
                You can access the form at the link below. Copy and paste it
                into your browser:
              </p>
              <div style={{ display: "flex", alignItems: "center" }}>
                <a href={formUrl} target="_blank" rel="noopener noreferrer">
                  {formUrl}
                </a>
                <Button
                  icon={<CopyOutlined />}
                  style={{ marginLeft: "10px" }}
                  onClick={() => handleCopyUrl(formUrl)}
                >
                  Copy
                </Button>
              </div>
            </div>
          ),
          centered: true,
        });
        setIsPreviewMode(true);
      } else {
        const errorData = response.data;
        notification.error({
          message: "Save Failed",
          description: errorData.error || "Failed to save the questions.",
        });
      }
    } catch (error) {
      const errorMessage =
        error.response?.data?.error ||
        "An error occurred while saving the question";
      notification.error({
        message: "Error",
        description: errorMessage,
      });
    } finally {
      setLoading(false);
    }
  };

  return isPreviewMode ? (
    <div>
      <div className="header-container">
        <Title level={4} style={{ fontWeight: "bold", color: "#013578" }}>
          Preview
        </Title>
      </div>
      <div className="bordered-box">
        <h5
          className="form_creation_header"
          style={{
            fontWeight: "bold",
            color: "#013578",
          }}
        >
          Trainer Fill The Answer
        </h5>
        {questions.map((q) => (
          <Card key={q.id} className="form_creation_preview_question_card">
            <h3>
              {q.question}{" "}
              {q.required && (
                <span className="form_creation_required_field">*</span>
              )}
            </h3>
            {q.type === "text" && (
              <Input
                value={q.acceptedAnswer}
                onChange={(e) => handleAnswerChange(q.id, e.target.value)}
                placeholder="Enter your answer"
                disabled={q.question.toLowerCase() === "employee id"}
              />
            )}
            {q.type === "choice" && (
              <Radio.Group
                onChange={(e) => handleAnswerChange(q.id, e.target.value)}
                value={q.acceptedAnswer}
              >
                <Space direction="vertical">
                  {q.options.map((opt, index) => (
                    <Radio key={index} value={opt}>
                      {opt}
                    </Radio>
                  ))}
                </Space>
              </Radio.Group>
            )}
            {q.type === "multichoice" && (
              <Select
                mode="multiple"
                placeholder="Select options"
                value={q.acceptedAnswer}
                onChange={(value) => handleAnswerChange(q.id, value)}
                style={{ width: "100%" }}
              >
                {q.options.map((opt, index) => (
                  <Option key={index} value={opt}>
                    {opt}
                  </Option>
                ))}
              </Select>
            )}
            {q.type === "rating" && (
              <Rate
                onChange={(value) => handleAnswerChange(q.id, value)}
                value={q.acceptedAnswer}
                disabled
              />
            )}
          </Card>
        ))}
        <div style={{ marginTop: "20px" }}>
          <Button
            type="primary"
            className="inprogress-page-button"
            style={{ marginBottom: 20 }}
            onClick={() => setIsPreviewMode(false)}
          >
            Back to Form Creation
          </Button>
          <br />
          <Button
            className="inprogress-page-button"
            style={{ marginBottom: 20 }}
            type="primary"
            onClick={handleSubmit}
            disabled={loading}
            icon={loading ? <LoadingOutlined /> : null}
          >
            {loading ? "Submitting..." : "Submit"}
          </Button>
        </div>
      </div>
    </div>
  ) : (
    <div style={{ marginTop: "20px" }}>
      <div className="bordered-box">
        <div>
          <h5
            className="form_creation_header"
            style={{ fontWeight: "bold", color: "#013578" }}
          >
            Create New Form
          </h5>
          {questions.map((q) => (
            <Card key={q.id} className="form_creation_question_card">
              <div>
                <Select
                  value={q.type}
                  onChange={(value) => handleTypeChange(q.id, value)}
                  style={{
                    width: "120px",
                    marginRight: "10px",
                  }}
                >
                  <Option value="text">Text</Option>
                  <Option value="choice">Single Choice</Option>
                  <Option value="multichoice">Multiple Choice</Option>
                  {/* <Option value="rating">Rating</Option> */}
                </Select>
                <Input
                  value={q.question}
                  onChange={(e) => handleQuestionChange(q.id, e.target.value)}
                  placeholder="Enter your question"
                  style={{ width: "300px", marginRight: "10px" }}
                />
                <Button
                  onClick={() => handleDeleteQuestion(q.id)}
                  className="inprogress-page-button"
                  style={{ marginBottom: 20, marginLeft: 30 }}
                  type="primary"
                >
                  Delete
                </Button>
              </div>

              {q.type === "choice" || q.type === "multichoice" ? (
                <>
                  {q.options.map((option, index) => (
                    <div key={index} style={{ marginBottom: "5px" }}>
                      <Input
                        value={option}
                        onChange={(e) =>
                          handleOptionChange(q.id, e.target.value, index)
                        }
                        placeholder="Enter option"
                        style={{ width: "250px", marginRight: "10px" }}
                      />
                      <Button
                        onClick={() => handleRemoveOption(q.id, index)}
                        // type="danger"
                        className="inprogress-page-button"
                        style={{ marginBottom: 20 }}
                        type="primary"
                      >
                        Remove
                      </Button>
                    </div>
                  ))}
                  <Button
                    icon={<PlusOutlined />}
                    onClick={() => handleAddOption(q.id)}
                    style={{ margin: "10px 0" }}
                    type="primary"
                  >
                    Add Option
                  </Button>
                </>
              ) : null}
              <Form.Item label="Required">
                <Radio.Group
                  onChange={(e) => handleRequiredToggle(q.id, e.target.value)}
                  value={q.required}
                >
                  <Radio value={true}>Yes</Radio>

                  <Radio value={false}>No</Radio>
                </Radio.Group>
              </Form.Item>
            </Card>
          ))}

          <Button
            className="inprogress-page-button"
            style={{ marginBottom: 20 }}
            onClick={addQuestion}
            icon={<PlusOutlined />}
            type="primary"
          >
            Add Question
          </Button>
          <br />
          <Button
            className="inprogress-page-button"
            style={{ marginBottom: 20 }}
            type="primary"
            onClick={handlePreviewForm}
            disabled={loading}
            loading={loading}
          >
            {loading ? "Generating Preview..." : "Preview Form"}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default AssessmentFormCreationPageV2;
