import React, { useState, useEffect } from "react";
import {
  Table,
  message,
  Button,
  notification,
  Modal,
  Tag,
  Checkbox,
} from "antd";
import {
  EditOutlined,
  EyeOutlined,
  DeleteOutlined,
  SendOutlined,
} from "@ant-design/icons";
import { BASE_URL } from "../../config";
import UpdateMeetingPageV2 from "./TrainingUpdatePageV2";
import GenerateOTPPageV2 from "./GenerateOTPPageV2";
import Offcanvas from "react-bootstrap/Offcanvas";
import moment from "moment";
import "../../css/MeetingListV2.css";
import TrainingViewDetailsPageV2 from "./TrainingViewDetailsPageV2";
import axiosInstance from "../../axiosInstance";
const { confirm } = Modal;
const TrainingListPageV2 = () => {
  const [meetings, setMeetings] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedMeeting, setSelectedMeeting] = useState(null);
  const [showOffcanvas, setShowOffcanvas] = useState(false);
  const [showViewOffcanvas, setShowViewOffcanvas] = useState(false);
  const [showOTPOffcanvas, setShowOTPOffcanvas] = useState(false);
  const [viewingMeeting, setViewingMeeting] = useState(null);
  const [filterVisible, setFilterVisible] = useState(false);
  const [statusFilters, setStatusFilters] = useState({
    in_progress: true,
    completed: true,
  });

  useEffect(() => {
    const fetchData = async () => {
      await fetchMeetings();
    };
    fetchData();
  }, []);

  const fetchMeetings = async () => {
    setLoading(true);
    try {
      const response = await axiosInstance.get(
        `${BASE_URL}/api/meetingListV2/`
      );
      // const response = await axios.get(`${BASE_URL}/api/meetingListV2/`); // Use the Axios instance
      setMeetings(response.data);
    } catch (error) {
      console.error("Error fetching meetings:", error);
      message.error("Failed to fetch meetings. Please try again later.");
    }
    setLoading(false);
  };

  const handleFilterChange = (checkedValues) => {
    const newFilters = {
      in_progress: checkedValues.includes("in_progress"),
      completed: checkedValues.includes("completed"),
    };
    setStatusFilters(newFilters);
  };

  const filteredMeetings = meetings.filter((meeting) => {
    if (!statusFilters.in_progress && meeting.status === "in_progress")
      return false;
    if (!statusFilters.completed && meeting.status === "completed")
      return false;
    return true;
  });
  const trainerColumnWidth = 450;
  const tableStyles = {
    header: {
      // height: "10px",
      // fontSize: "13px",
      // fontWeight: "bold",
      // textAlign: "center",
      height: "40px",
      lineHeight: "5px",
      fontSize: "14px",
      textAlign: "center",
    },
    cell: {
      height: "auto",
      lineHeight: "20px",
      fontSize: "12px",
      padding: "5px 5px",
      whiteSpace: "normal",
      textAlign: "center",
    },
  };
  const columns = [
    {
      title: "Training Name",
      dataIndex: "meeting_name",
      key: "meeting_name",
      onCell: () => ({
        style: tableStyles.cell,
      }),
      onHeaderCell: () => ({
        style: tableStyles.header,
      }),
    },
    {
      title: "Course",
      dataIndex: "course",
      key: "course_name",
      render: (course) => course.course_name,
      onCell: () => ({
        style: tableStyles.cell,
      }),
      onHeaderCell: () => ({
        style: tableStyles.header,
      }),
    },
    {
      title: "Trainer",
      dataIndex: "trainer_name",
      key: "trainer_name",
      render: (trainers) => trainers.map((trainer) => trainer.name).join(", "),
      onCell: () => ({
        style: tableStyles.cell,
        textAlign: "left",
        height: "auto",
        whiteSpace: "normal",
      }),
      onHeaderCell: () => ({
        style: tableStyles.header,
      }),
      width: trainerColumnWidth,
    },
    {
      title: "Start Date",
      dataIndex: "start_date",
      key: "start_date",
      render: (date) => moment(date).format("YYYY-MM-DD"),
      onCell: () => ({
        style: tableStyles.cell,
      }),
      onHeaderCell: () => ({
        style: tableStyles.header,
      }),
    },
    {
      title: "End Date",
      dataIndex: "end_date",
      key: "end_date",
      render: (date) => moment(date).format("YYYY-MM-DD"),
      onCell: () => ({
        style: tableStyles.cell,
      }),
      onHeaderCell: () => ({
        style: tableStyles.header,
      }),
    },

    // {
    //   title: "Status",
    //   dataIndex: "status",
    //   key: "status",
    //   render: (status) => (
    //     <Tag color={getStatusColor(status)} style={{ color: "#000" }}>
    //       {getStatusDisplayName(status)}
    //     </Tag>
    //   ),
    //   onCell: () => ({
    //     style: tableStyles.cell,
    //   }),
    //   onHeaderCell: () => ({
    //     style: tableStyles.header, // Apply header styles here
    //   }),
    //   filters: [
    //     { text: "In Progress", value: "in_progress" },
    //     { text: "Completed", value: "completed" },
    //   ],
    //   onFilter: (value, record) => record.status.includes(value),
    //   filterMultiple: true,
    //   filterDropdown: ({ setSelectedKeys, selectedKeys, confirm }) => (
    //     <div style={{ padding: 8, width: 200 }}>
    //       <Checkbox.Group
    //         options={[
    //           { label: "In Progress", value: "in_progress" },
    //           { label: "Completed", value: "completed" },
    //         ]}
    //         value={selectedKeys}
    //         onChange={(values) => {
    //           setSelectedKeys(values);
    //           confirm();
    //         }}
    //         style={{ display: "flex", flexDirection: "column" }}
    //       />
    //     </div>
    //   ),
    // },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (status) => (
        <Tag color={getStatusColor(status)} style={{ color: "#000" }}>
          {getStatusDisplayName(status)}
        </Tag>
      ),
      onCell: () => ({
        style: tableStyles.cell,
      }),
      onHeaderCell: () => ({
        style: tableStyles.header,
      }),
      filters: [
        { text: "In Progress", value: "in_progress" },
        { text: "Completed", value: "completed" },
      ],
      onFilter: (value, record) => record.status.includes(value),
      filterMultiple: true,
      filterDropdown: ({ setSelectedKeys, selectedKeys, confirm }) => {
        if (selectedKeys.length === 0) {
          setSelectedKeys(["in_progress", "completed"]);
        }

        return (
          <div style={{ padding: 8, width: 200 }}>
            <Checkbox.Group
              options={[
                { label: "In Progress", value: "in_progress" },
                { label: "Completed", value: "completed" },
              ]}
              value={selectedKeys}
              onChange={(values) => {
                setSelectedKeys(values);
                confirm();
              }}
              style={{ display: "flex", flexDirection: "column" }}
            />
          </div>
        );
      },
    },
    {
      title: "Action",
      key: "action",
      render: (text, record) => (
        <span>
          <Button
            icon={<EyeOutlined />}
            onClick={() => handleView(record.id)}
            style={{ marginRight: 8 }}
          />
          <Button
            icon={<EditOutlined />}
            onClick={() => handleEdit(record)}
            style={{ marginRight: 8 }}
          />
          <Button
            icon={<DeleteOutlined />}
            onClick={() => showDeleteConfirm(record)}
            style={{ marginRight: 8 }}
          />
          <Button icon={<SendOutlined />} onClick={() => handleOTP(record)} />
        </span>
      ),
      onCell: () => ({
        style: tableStyles.cell,
      }),
      onHeaderCell: () => ({
        style: tableStyles.header,
      }),
    },
  ];

  const handleEdit = (meeting) => {
    setSelectedMeeting(meeting);
    setShowOffcanvas(true);
  };

  const handleView = (meetingId) => {
    const meeting = meetings.find((m) => m.id === meetingId);
    setViewingMeeting(meeting);
    setShowViewOffcanvas(true);
  };
  const handleOTP = (meeting) => {
    setSelectedMeeting(meeting);
    setShowOTPOffcanvas(true);
  };

  const closeOffcanvas = () => {
    setShowOffcanvas(false);
    setSelectedMeeting(null);
  };
  const closeViewOffcanvas = () => {
    setShowViewOffcanvas(false);
    setViewingMeeting(null);
  };
  const closeShowOTPOffcanvas = () => {
    setShowOTPOffcanvas(false);
  };
  const handleMeetingUpdate = () => {
    fetchMeetings();
    closeOffcanvas();
  };
  const handleGenerateOTP = () => {
    fetchMeetings();
    closeShowOTPOffcanvas();
  };
  const getStatusDisplayName = (status) => {
    const statusMap = {
      in_progress: "In Progress",
      completed: "Completed",
    };
    return statusMap[status] || status;
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "in_progress":
        return "#faad14";
      case "completed":
        return "#52c41a";
      default:
        return "#d9d9d9";
    }
  };

  const handleDelete = (meetingId) => {
    axiosInstance
      .post(`${BASE_URL}/api/delete_meeting/${meetingId}/`)
      .then(() => {
        notification.success({
          message: "Success",
          description: "Meeting deleted Successfully",
          placement: "topRight",
        });
        setSelectedMeeting(null);
        fetchMeetings();
        // onClose();
      })
      .catch((error) => {
        notification.error({
          message: "Error",
          description: "Failed to delete meeting.",
        });
      });
  };
  const showDeleteConfirm = (record) => {
    confirm({
      title: "Are you sure you want to delete this meeting?",
      content: "Once deleted, the meeting cannot be recovered.",
      okText: "Yes",
      okType: "danger",
      cancelText: "No",
      onOk() {
        handleDelete(record.id);
      },
    });
  };
  return (
    <div>
      {filterVisible && (
        <div style={{ marginBottom: 16 }}>
          <Checkbox.Group
            options={[
              { label: "In Progress", value: "in_progress" },
              { label: "Completed", value: "completed" },
            ]}
            onChange={handleFilterChange}
            defaultValue={Object.keys(statusFilters).filter(
              (key) => statusFilters[key]
            )}
          />
        </div>
      )}
      <Table
        className="custom-table"
        dataSource={filteredMeetings}
        columns={columns}
        rowKey="id"
        loading={loading}
        pagination={{ pageSize: 10 }}
        locale={{ emptyText: "No meetings found" }}
      />
      <Offcanvas
        show={showViewOffcanvas}
        onHide={closeViewOffcanvas}
        className="custom-offcanvas"
        placement="end"
      >
        <Offcanvas.Header closeButton style={{ padding: "10px" }}>
          <Offcanvas.Title style={{ fontSize: "15px", fontWeight: "bold" }}>
            Training Details
          </Offcanvas.Title>
        </Offcanvas.Header>
        <div
          style={{
            width: "95%",
            margin: "0 auto",
            borderBottom: "1px solid #ccc",
          }}
        ></div>

        <Offcanvas.Body style={{ marginLeft: "20px" }}>
          {viewingMeeting ? (
            <div>
              <div className="row">
                <div className="col-6 p-0">
                  <p className="small-text">
                    <strong>Training Name:</strong>{" "}
                    {viewingMeeting.meeting_name}
                  </p>
                </div>
                <div className="col-6 p-0">
                  <p className="small-text">
                    <strong>Course:</strong> {viewingMeeting.course.course_name}
                  </p>
                </div>
              </div>
              <div className="row">
                <div className="col-6 p-0">
                  <p className="small-text">
                    <strong>Status:</strong>{" "}
                    {getStatusDisplayName(viewingMeeting.status)}
                  </p>
                </div>
                <div className="col-6 p-0">
                  <p className="small-text">
                    <strong>Trainers:</strong>{" "}
                    {viewingMeeting.trainer_name
                      .map((trainer) => trainer.name)
                      .join(", ")}
                  </p>
                </div>
              </div>
              <div className="row">
                <div className="col-6 p-0">
                  <p className="small-text">
                    <strong>Type:</strong> {viewingMeeting.type}
                  </p>
                </div>
                <div className="col-6 p-0">
                  {viewingMeeting.type === "Offline" ? (
                    <p className="small-text">
                      <strong>Location:</strong>{" "}
                      {viewingMeeting.location.location_name}
                    </p>
                  ) : (
                    <p className="small-text">
                      <strong>URL:</strong> {viewingMeeting.online_url}
                    </p>
                  )}
                </div>
              </div>
              <div className="row">
                <div className="col-6 p-0">
                  <p className="small-text">
                    <strong>Start Date:</strong>{" "}
                    {moment(viewingMeeting.start_date).format("YYYY-MM-DD")}
                  </p>
                </div>
                <div className="col-6 p-0">
                  <p className="small-text">
                    <strong>End Date:</strong>{" "}
                    {moment(viewingMeeting.end_date).format("YYYY-MM-DD")}
                  </p>
                </div>
              </div>
              <div className="row">
                <div className="col-6 p-0">
                  <p className="small-text">
                    <strong>Start Time:</strong>{" "}
                    {moment(viewingMeeting.start_time, "HH:mm:ss").format(
                      "HH:mm"
                    )}
                  </p>
                </div>
                <div className="col-6 p-0">
                  <p className="small-text">
                    <strong>End Time:</strong>{" "}
                    {moment(viewingMeeting.end_time, "HH:mm:ss").format(
                      "HH:mm"
                    )}
                  </p>
                </div>
              </div>
              <div
                style={{
                  width: "100%",
                  // margin: "0 auto",
                  marginTop: "10px",
                  borderBottom: "1px solid #ccc",
                }}
              ></div>
              <br />
              <TrainingViewDetailsPageV2
                selectedMeetingId={viewingMeeting.id}
              />
            </div>
          ) : (
            <p>No meeting selected for viewing.</p>
          )}
        </Offcanvas.Body>
      </Offcanvas>

      <Offcanvas
        show={showOffcanvas}
        onHide={closeOffcanvas}
        className="custom-offcanvas"
        placement="end"
      >
        <Offcanvas.Header closeButton style={{ padding: "10px" }}>
          <Offcanvas.Title style={{ fontSize: "15px", fontWeight: "bold" }}>
            Update Meeting
          </Offcanvas.Title>
        </Offcanvas.Header>
        <div
          style={{
            width: "95%",
            margin: "0 auto",
            borderBottom: "1px solid #ccc",
          }}
        ></div>
        <Offcanvas.Body>
          {selectedMeeting ? (
            <UpdateMeetingPageV2
              meetingId={selectedMeeting.id}
              onClose={handleMeetingUpdate}
            />
          ) : (
            <p>No meeting selected for update.</p>
          )}
        </Offcanvas.Body>
      </Offcanvas>
      <Offcanvas
        show={showOTPOffcanvas}
        onHide={closeShowOTPOffcanvas}
        className="custom-offcanvas"
        placement="end"
      >
        <Offcanvas.Header closeButton style={{ padding: "10px" }}>
          <Offcanvas.Title style={{ fontSize: "15px", fontWeight: "bold" }}>
            Generate OTP
          </Offcanvas.Title>
        </Offcanvas.Header>
        <div
          style={{
            width: "95%",
            margin: "0 auto",
            borderBottom: "1px solid #ccc",
          }}
        ></div>
        <Offcanvas.Body>
          {selectedMeeting ? (
            <GenerateOTPPageV2
              meetingId={selectedMeeting.id}
              onClose={handleGenerateOTP}
            />
          ) : (
            <p>No meeting selected for OTP generation.</p>
          )}
        </Offcanvas.Body>
      </Offcanvas>
    </div>
  );
};

export default TrainingListPageV2;
