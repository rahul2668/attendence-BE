import React, { useState, useEffect } from "react";
import { Typography, Button, notification } from "antd";
import { useLocation } from "react-router-dom"; //useNavigate
import axios from "axios";
import { BASE_URL } from "../config";
import "../css/FormFill.css";

const FormFill = () => {
  const { Title } = Typography;
  const [meetingName, setMeetingName] = useState("");
  const [otp, setOtp] = useState("");
  const [isVerified, setIsVerified] = useState(false);
  const [meetingId, setMeetingId] = useState("");
  const [employeeId, setEmployeeId] = useState("");
  const location = useLocation();
  // const navigate = useNavigate();

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const name = params.get("meeting_name");
    const otpValue = params.get("otp");
    const id = params.get("id");

    if (name) {
      setMeetingName(name);
    }
    if (otpValue) {
      setOtp(otpValue);
    }
    if (id) {
      setMeetingId(id);
    }
  }, [location]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(`${BASE_URL}/api/verify_otp/`, {
        meeting_id: meetingId,
        otp: otp,
      });

      if (response.data.message === "OTP verified successfully") {
        setIsVerified(true);
        notification.success({
          message: "Success",
          description: response.data.message,
          placement: "topRight",
        });
      } else {
        notification.error({
          message: "Error",
          description: response.data.message,
          placement: "topRight",
        });
      }
    } catch (error) {
      const errorMessage =
        error.response?.data?.message || "An error occurred.";
      notification.error({
        message: "Error",
        description: errorMessage,
        placement: "topRight",
      });
    }
  };

  const handleEmployeeSubmit = async () => {
    try {
      const response = await axios.post(
        `${BASE_URL}/api/attendance-submit-by-employee_id/`,
        {
          meeting_id: meetingId,
          employee_id: employeeId,
        }
      );

      if (response.data.message) {
        notification.success({
          message: "Success",
          description: response.data.message,
          placement: "topRight",
        });
      }
    } catch (error) {
      const errorMessage =
        error.response?.data?.error || "Error submitting Employee ID.";
      notification.error({
        message: "Error",
        description: errorMessage,
        placement: "topRight",
      });
    }
  };

  // const handlePreviousClick = () => {
  //   navigate("/previous-form");
  // };

  return (
    <div>
      <div className="header-container">
        <Title level={4} style={{ fontWeight: "bold", color: "#013578" }}>
          Form Fill Up old
        </Title>
      </div>

      <div className="bordered-box">
        <form onSubmit={handleSubmit}>
          <div>
            <label htmlFor="meeting-name">Selected Meeting Name:</label>
            <input id="meeting-name" type="text" value={meetingName} disabled />
          </div>

          {!isVerified && (
            <>
              <div>
                <label htmlFor="otp">Your OTP:</label>
                <input
                  id="otp"
                  type="text"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value)}
                />
              </div>
              <Button
                type="primary"
                className="inprogress-page-button"
                htmlType="submit"
              >
                Verify OTP
              </Button>
            </>
          )}

          {isVerified && (
            <div style={{ marginTop: "20px" }}>
              <h4>OTP Verified!</h4>
              <label htmlFor="additional-field">Employee ID</label>
              <input
                id="additional-field"
                type="text"
                placeholder="Enter Employee ID"
                value={employeeId}
                onChange={(e) => setEmployeeId(e.target.value)}
              />
              <Button
                type="primary"
                onClick={handleEmployeeSubmit}
                style={{ marginTop: "10px" }}
              >
                Submit Employee ID
              </Button>
            </div>
          )}
        </form>

        {/* <Button
          type="primary"
          className="inprogress-page-button"
          onClick={handlePreviousClick}
          style={{ marginTop: "20px" }}
        >
          Previous
        </Button> */}
      </div>
    </div>
  );
};

export default FormFill;
