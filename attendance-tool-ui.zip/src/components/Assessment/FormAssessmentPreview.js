import React, { useEffect, useState } from "react";
import axios from "axios";
import axiosInstance from "../../axiosInstance";
import { useParams } from "react-router-dom";
import {
  Card,
  Input,
  Radio,
  Select,
  Rate,
  Button,
  Space,
  notification,
  Modal,
  Typography,
} from "antd";
import { LoadingOutlined } from "@ant-design/icons";

import { BASE_URL } from "../../config";

const { Option } = Select;
const { Title } = Typography;
const FormFillPage = () => {
  const { id: meetingId, currentDate: creationDate } = useParams();
  const [meetingName, setMeetingName] = useState("");
  const [questions, setQuestions] = useState([]);
  const [formData, setFormData] = useState({});
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchMeetingData = async () => {
      try {
        const response = await axiosInstance.get(
          `${BASE_URL}/api/meeting_question_detail/${meetingId}/${creationDate}/`
        );
        setMeetingName(response.data.meeting.meeting_name);
        setQuestions(response.data.questions);

        const initialFormData = {};
        response.data.questions.forEach((question) => {
          initialFormData[question.question_sqn_id] = "";
        });
        setFormData(initialFormData);
      } catch (error) {
        console.error("Error fetching meeting data:", error);
      }
    };

    fetchMeetingData();
  }, [meetingId, creationDate]);

  const handleAnswerChange = (id, value) => {
    setFormData({
      ...formData,
      [id]: value,
    });
  };

  const validateRequiredFields = () => {
    for (const question of questions) {
      if (question.required && !formData[question.question_sqn_id]) {
        notification.error({
          message: "Validation Error",
          description: `Please answer the required question: ${question.question_text}`,
        });
        return false;
      }
    }
    return true;
  };

  const handleSubmit = async () => {
    const isValid = validateRequiredFields();
    if (!isValid) return;

    setLoading(true);
    try {
      const response = await axiosInstance.post(
        `${BASE_URL}/api/submit-answers/`,
        {
          meeting_id: meetingId,
          creationDate: creationDate,
          questions: questions.map((q) => ({
            question_sqn_id: q.question_sqn_id,
            question_text: q.question_text,
            answer: formData[q.question_sqn_id],
          })),
        }
      );

      if (response.data.status === "success") {
        Modal.success({
          title: "Submission Successful",
          content: (
            <div>
              <p>Your answers have been submitted successfully!</p>
            </div>
          ),
          onOk() {
            setFormData({});
          },
        });
      }
    } catch (error) {
      console.error("Error submitting answers:", error);
      if (error.response && error.response.data) {
        const errorMessage = error.response.data.message;
        notification.error({
          message: "Error",
          description:
            errorMessage || "Error submitting answers. Please try again.",
        });
      } else {
        notification.error({
          message: "Error",
          description: "Error submitting answers. Please try again.",
        });
      }
    } finally {
      setLoading(false);
    }
  };
  return (
    <div>
      <div className="header-container">
        <Title level={4} style={{ fontWeight: "bold", color: "#013578" }}>
          Form Fill Up
        </Title>
      </div>

      <div className="bordered-box">
        <h4
          style={{
            fontWeight: "bold",
            color: "#013578",
            textAlign: "center",
          }}
        >
          {meetingName
            ? `Training: ${meetingName}`
            : "Unable to load meeting name"}
        </h4>
        {questions.map((q) => (
          <Card
            key={q.question_sqn_id}
            className="form_creation_preview_question_card"
          >
            <h3>
              {q.question_text}{" "}
              {q.required && (
                <span className="form_creation_required_field">*</span>
              )}
            </h3>

            {q.question_type === "text" && (
              <Input
                value={formData[q.question_sqn_id] || ""}
                onChange={(e) =>
                  handleAnswerChange(q.question_sqn_id, e.target.value)
                }
                placeholder="Enter your answer"
              />
            )}
            {q.question_type === "choice" && (
              <Radio.Group
                onChange={(e) =>
                  handleAnswerChange(q.question_sqn_id, e.target.value)
                }
                value={formData[q.question_sqn_id] || ""}
              >
                <Space direction="vertical">
                  {q.options.map((opt, index) => (
                    <Radio key={index} value={opt}>
                      {opt}
                    </Radio>
                  ))}
                </Space>
              </Radio.Group>
            )}
            {q.question_type === "multichoice" && (
              <Select
                mode="multiple"
                placeholder="Select options"
                value={formData[q.question_sqn_id] || []}
                onChange={(value) =>
                  handleAnswerChange(q.question_sqn_id, value)
                }
                style={{ width: "100%" }}
              >
                {q.options.map((opt, index) => (
                  <Option key={index} value={opt}>
                    {opt}
                  </Option>
                ))}
              </Select>
            )}
            {q.question_type === "rating" && (
              <Rate
                onChange={(value) =>
                  handleAnswerChange(q.question_sqn_id, value)
                }
                value={formData[q.question_sqn_id] || 0}
              />
            )}
          </Card>
        ))}
        <Button
          className="inprogress-page-button"
          style={{ marginBottom: 20 }}
          onClick={handleSubmit}
          disabled={loading}
          icon={loading ? <LoadingOutlined /> : null}
        >
          {loading ? "Submitting..." : "Submit"}
        </Button>
      </div>
    </div>
  );
};

export default FormFillPage;
