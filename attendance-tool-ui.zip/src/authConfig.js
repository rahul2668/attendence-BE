import { LogLevel } from "@azure/msal-browser";
const ua = window.navigator.userAgent;
const msie = ua.indexOf("MSIE ");
const msie11 = ua.indexOf("Trident/");
const msedge = ua.indexOf("Edge/");
const firefox = ua.indexOf("Firefox");
const isIE = msie > 0 || msie11 > 0;
const isEdge = msedge > 0;
const isFirefox = firefox > 0;
export const msalConfig = {
  auth: {
    clientId: "ce82faf1-2a43-4bc8-beda-e1347f79c066",
    // clientId: "858b70ef-0bfe-4812-ab5e-a07d68cd43a6",
    authority: "https://login.microsoftonline.com/common", // Replace with your tenant ID if needed
    redirectUri: window.location.origin,
    // postLogoutRedirectUri: window.location.origin,
  },
  cache: {
    cacheLocation: "localStorage", // Where to store the cache
    storeAuthStateInCookie: isIE || isEdge || isFirefox, // Set to true if using IE
    // storeAuthStateInCookie: true,
  },
  system: {
    allowNativeBroker: false,
    loggerOptions: {
      loggerCallback: (level, message, containsPii) => {
        if (containsPii) {
          return;
        }
        switch (level) {
          case LogLevel.Error:
            console.error(message);
            return;
          case LogLevel.Info:
            console.info(message);
            return;
          case LogLevel.Verbose:
            console.debug(message);
            return;
          case LogLevel.Warning:
            console.warn(message);
            return;
          default:
            return;
        }
      },
    },
  },
};

// Scopes for id token to be used at MS Identity Platform endpoints.
// export const loginRequest = {
//   scopes: ["openid", "profile", msalConfig.auth.clientId + "/.default"], // Replace with your scopes
// };
export const loginRequest = {
  scopes: [msalConfig.auth.clientId + "/.default"],
};

// Graph API endpoints for user information
export const graphConfig = {
  graphMeEndpoint: "https://graph.microsoft.com/v1.0/me",
};

export const graphLoginRequest = {
  scopes: ["https://graph.microsoft.com/.default"],
};
