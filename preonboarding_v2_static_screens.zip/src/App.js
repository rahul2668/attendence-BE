import React from 'react';
import './App.css';
import './constants.css'
import EmployeeDetails from './Components/EmployeeDetails/EmployeeDetails';
import AppRouter from "./Router/PreOnboardingRoutes";
import { Provider } from 'react-redux';

const App = () => (
  <div className="App">
  
    <AppRouter />
  </div>
);
export default App;