import { combineReducers } from "redux";
import auth from "./auth";
// import management from "./ManagementReducer";
// import usertypes from "./UserType";
// import addCandidates from "./AddCandidateReducer";
// import designation from "./Designation";
// import formFieldValuesReducer from "./BasicdetailsReducer";
// import Worklist from "./WorklistReducer";
// import Formfield from "./FormfieldReducer";
// import CandidateStatus from "./CandidateStatusReducer";
export default combineReducers({
  auth,
  // management,
  // usertypes,
  // addCandidates,
  // designation,
  // formFieldValuesReducer,
  // Worklist,
  // Formfield,
  // CandidateStatus,
});
