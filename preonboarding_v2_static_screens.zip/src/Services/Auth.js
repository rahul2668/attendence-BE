import { Api } from "../Interceptor/Interceptor";

const requestOTPService = (email) => {
  return Api.post(`/login/login-form?emailId=${email}`);
};

const validateOTPService = (email, oneTimePassword) => {
  const url = `/login/validateOTP?emailId=${email}&OneTimePassword=${oneTimePassword}`;

  return Api.post(url);
};

const getCandidateFormStatus = (candidateId) => {
  const url = `/candidate-form-status/candidate-latest-form-status-mapping/${candidateId}`;
  return Api.get(url);
};

const AuthServices = {
  requestOTPService,
  validateOTPService,
  getCandidateFormStatus,
};
export default AuthServices;
