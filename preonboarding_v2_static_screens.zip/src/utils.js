const steps = [
  "Basic Details",
  "Employee Joining Report",
  "Employee Non-Disclosure And Confidentiality Agreement",
  "Letter Of Authorization",
  "Letter Of Authorization ",
  "Letter Of Candidate Declaration Form",
  "Composite Declaration Form-11",
  "SODEXO Meal Passes",
];

export { steps };

export const USER = "user";
export const CHECK_BOX = "CHECK BOX";
export const PERMANENT_ADDRESS = "Permanent Address";
export const PERMANENT_ADDRESS_SECTION = "permenentAddressSection";
export const CHECK_BOX_VALUES = "apiCheckBoxValues";
export const AGE = "Age";
export const Date_Of_Birth = "Date Of Birth";
export const FORM_FIELD_ID_DOB = 6;
export const CURRENT_ADDRESS = "Current Address";
export const ID = "id";
export const FIELD_NAME = "fieldName";
export const FIELD_VALUE = "fieldValue";
export const CANDIDATE_ID = "candidateId";
export const CURRENT = "current";
export const PERMANENT = "permanent";


export const CANDIDATE_DETAILS = "candidateDtls";
export const USER_TYPE = "userType";
export const HR = "HR";
export const IN_PROGRESS = "IN_PROGRESS";
export const CLICK_AWAY = "clickaway";
export const CANDIDATE_STATUS = "candidateStatus";
export const USER_EMAIL_LENGTH = 10;
export const USER_EMAIL_VALIDATION = "@";
export const USER_EMAIL_VALIDATION_RESTRICTION = ".";
export const SUCCESS_MESSAGE = 200;
export const LATERAL = "LATERAL";
export const FRESHER = "FRESHER";
export const OTP_LENGTH = 6;
export const EMAIL_VALIDATION =
  "Please enter your email before requesting OTP.";

