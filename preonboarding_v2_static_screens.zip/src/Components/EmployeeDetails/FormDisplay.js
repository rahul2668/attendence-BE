import React, { useState, useEffect } from "react";
import { Button, Form, Input, DatePicker, Row, Col, Card, Select } from "antd";

import dummyResponse1 from "./res1.json";
import dummyResponse2 from "./res2.json";
import dummyResponse3 from "./res3.json";
import dummyResponse4 from "./res4.json";
import dummyResponse5 from "./res5.json";
import dummyResponse6 from "./res6.json";
import dummyResponse7 from "./res7.json";
import dummyResponse8 from "./res8.json";
import calander from "../../Assets/calander.svg";

let dummyObj = {
  dummyResponse1: dummyResponse1,
  dummyResponse2: dummyResponse2,
  dummyResponse3: dummyResponse3,
  dummyResponse4: dummyResponse4,
  dummyResponse5: dummyResponse5,
  dummyResponse6: dummyResponse6,
  dummyResponse7: dummyResponse7,
  dummyResponse8: dummyResponse8,
};

const { Option } = Select;
function FormDisplay(props) {
  const [form] = Form.useForm();
  const [responseData, setResponseData] = useState([]);

  const { currentStep, setCurrentStep } = props;

  useEffect(() => {
    setResponseData(dummyObj[`dummyResponse${currentStep}`]);
  }, [currentStep]);

  useEffect(() => {
    setResponseData(dummyResponse1);
  }, []);

  const handleSave = async () => {
    try {
      const values = await form.validateFields();
      console.log("Form Values:", values);
    } catch (errorInfo) {
      console.log("Failed:", errorInfo);
    }
  };

  const handleNext = async () => {
    try {
      const values = await form.validateFields();
      console.log("Form Values:", values);

      setCurrentStep(currentStep + 1);
    } catch (errorInfo) {
      console.log("Failed:", errorInfo);
    }
  };

  const handleBack = () => {
    setCurrentStep(currentStep - 1);
  };

  return (
    <Form name="basic" form={form} colon={false}>
      <div className="form-title">{responseData?.[0]?.formName}</div>
      {responseData.map((formSectionItem) => (
        <Card className="margin-small form-card" key={formSectionItem.id}>
          <div className="form-section-title mb-2 mt-2">
            {formSectionItem?.sectionName}
          </div>
          <Row gutter={16} key={formSectionItem.id}>
            {formSectionItem.formFieldValueMapping.map((formItem) => (
              <>
                <Col span={8} key={formItem.formFieldId}>
                  {formItem.fieldTypeName === "TEXT BOX" ? (
                    <Form.Item
                      name={formItem.fieldId}
                      // labelAlign="left"
                      labelCol={{ span: 24 }}
                      wrapperCol={{ span: 24 }}
                      label={
                        <>
                          <span>{formItem.fieldName}</span>
                          {formItem.isMandatory ? (
                            <span className="requiredCls">*</span>
                          ) : (
                            ""
                          )}
                        </>
                      }
                      rules={[
                        {
                          required: formItem.isMandatory,
                          message: `Please input your ${formItem.fieldName}!`,
                        },
                      ]}
                      className="form-item"
                      colon={false}
                    >
                      <Input
                        className="form-item-input"
                        placeholder={`Enter`}
                      />
                    </Form.Item>
                  ) : null}

                  {formItem.fieldTypeName === "DROPDOWN" ? (
                    <Form.Item
                      name={formItem.fieldId}
                      labelAlign="left"
                      colon={false}
                      labelCol={{ span: 24 }}
                      wrapperCol={{ span: 24 }}
                      rules={[
                        {
                          required: formItem.isMandatory,
                          message: `Please input your ${formItem.fieldName}!`,
                        },
                      ]}
                      className="form-item"
                      label={
                        <>
                          <span>{formItem.fieldName}</span>
                          {formItem.isMandatory ? (
                            <span className="requiredCls">*</span>
                          ) : (
                            ""
                          )}
                        </>
                      }
                    >
                      <Select
                        style={{ width: "100%" }}
                        showSearch
                        placeholder={<p className="antd-placeholder">Select</p>}
                        optionFilterProp="children"
                        filterOption={(input, option) =>
                          option.children
                            .toLowerCase()
                            .indexOf(input.toLowerCase()) >= 0
                        }
                        className="custom-select form-item-input"
                      >
                        {formItem.formFieldOptionMapping.map((option) => (
                          <Option key={option.id} value={option.optionName}>
                            {option.optionName}
                          </Option>
                        ))}
                      </Select>
                    </Form.Item>
                  ) : null}

                  {formItem.fieldTypeName === "DATE" ? (
                    <Form.Item
                      name={formItem.fieldId}
                      labelAlign="left"
                      colon={false}
                      labelCol={{ span: 24 }}
                      wrapperCol={{ span: 24 }}
                      rules={[
                        {
                          required: formItem.isMandatory,
                          message: `Please input your ${formItem.fieldName}!`,
                        },
                      ]}
                      className="form-item"
                      label={
                        <>
                          <span>{formItem.fieldName}</span>
                          {formItem.isMandatory ? (
                            <span className="requiredCls">*</span>
                          ) : (
                            ""
                          )}
                        </>
                      }
                    >
                      <DatePicker
                        className="custom-date-picker form-item-input"
                        suffixIcon={<img src={calander} alt="icon" />}
                      />
                    </Form.Item>
                  ) : null}
                </Col>
              </>
            ))}
          </Row>
        </Card>
      ))}

      <Card className="margin-small form-card">
        <div className="btn-group">
          <Button className="btn-primary-form">Reset</Button>
          <div className="btn-right-group">
            <Button className="btn-primary-form" onClick={handleBack}>
              Back
            </Button>
            <Button className="btn-primary-form" onClick={handleSave}>
              Save
            </Button>
            <Button
              type="primary"
              htmlType="submit"
              className="btn-secondary-form"
              onClick={handleNext}
            >
              Next
            </Button>
          </div>
        </div>
      </Card>
    </Form>
  );
}

export default FormDisplay;
