import React, { useState } from "react";
import "./employeeDetails.css";
import Header from "../Header/Header";
import { Col, Row } from "antd";
import FormDisplay from "./FormDisplay";
import Stepper from "../Stepper/Stepper";
import aeroplane from "../../Assets/aeroplane.svg";

function EmployeeDetails() {
  const [currentStep, setCurrentStep] = useState(1);
  return (
    <div className="employee-details">
      <Header />
      <div className="container">
        <Row>
          <Col span={4} className="left-div">
            <div className="fixed-container">
              <div className="d-flex">
                <img src={aeroplane} />
                <div className="text-container">
                  <h3 className="m-0 ml-4 font-weight-bold">Start</h3>{" "}
                  <h5 className="m-0 font-weight-bold">a new</h5>{" "}
                  <h5 className="m-0 font-weight-bold">journey</h5>{" "}
                  <h6 className="m-0 mt-2 font-weight-bold">
                    at <span className="font-color">Bilvantis</span>
                  </h6>
                </div>
              </div>
              <Stepper currentStep={currentStep} />
            </div>

          </Col>
          <Col span={20} className="right-div">
            <FormDisplay
              currentStep={currentStep}
              setCurrentStep={setCurrentStep}
            />
            {/* <Footer /> */}
          </Col>
        </Row>
      </div>
    </div>
  );
}

export default EmployeeDetails;
