import Snackbar from "@mui/material/Snackbar";
import Alert from "@mui/material/Alert";
import React, { useState, useEffect } from "react";

const WarnSnack = ({ open, onClose, successMessage }) => {
  const [snackOpen, setSnackOpen] = useState(open);

  useEffect(() => {
    setSnackOpen(open);
  }, [open]);

  const handleClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    setSnackOpen(false);

    if (onClose) {
      onClose();
    }
  };

  return (
    <Snackbar
      open={snackOpen}
      onClose={handleClose}
      anchorOrigin={{ vertical: "top", horizontal: "" }}
      style={{ position: "relative", width: "100%" }}
    >
      <Alert
        onClose={handleClose}
        severity="warning"
        sx={{
          width: "30%",
          // height:"40px",
          position: "fixed",
          boxShadow: "none",
          backgroundColor: "#F5C518",
          color: "black",
        }}
        className="me-5"
      >
        {successMessage}
      </Alert>
    </Snackbar>
  );
};

export default WarnSnack;
