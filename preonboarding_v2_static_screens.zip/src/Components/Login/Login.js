import React, { useState, useEffect } from "react";
import logo from "../../Assets/login_img.svg";
import onboarding from "../../Assets/onboarding_logo.svg";
import bilvantis from "../../Assets/bilvantis_logo.svg";
import OtpInput from "react-otp-input";
import { useNavigate } from "react-router-dom";
import "./Login.css";
import WarnSnack from "../../Components/Login/Warning-Snack";
import {
  requestOTPAction,
  validateOTPAction,
  getCandidateFormStatusAction,
} from "../../Actions/Auth";

import {
  OTPEXPIRED_MESSAGE,
  OTPWARNING_MESSAGE,
  TIMER_TIME,
} from "../../ActionTypes/LoginTypes";
import { useDispatch } from "react-redux";

import {
  CANDIDATE_DETAILS,
  CANDIDATE_STATUS,
  CLICK_AWAY,
  EMAIL_VALIDATION,
  FRESHER,
  HR,
  IN_PROGRESS,
  LATERAL,
  OTP_LENGTH,
  SUCCESS_MESSAGE,
  USER,
  USER_EMAIL_LENGTH,
  USER_EMAIL_VALIDATION,
  USER_EMAIL_VALIDATION_RESTRICTION,
  USER_TYPE,
} from "../../utils";

const Login = () => {
  const [isDivVisible, setIsDivVisible] = useState(false);

  const [signInForm, setSignInForm] = useState({
    userName: "",
    password: "",
    valid: false,
  });

  const isEmailAddressValid =
    signInForm.userName.length >= USER_EMAIL_LENGTH &&
    signInForm.userName.includes(USER_EMAIL_VALIDATION) &&
    signInForm.userName.includes(USER_EMAIL_VALIDATION_RESTRICTION);

  const [open, setOpen] = React.useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [otp, setOtp] = useState("");
  const [warnOpen, setWarnOpen] = React.useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [seconds, setSeconds] = useState(TIMER_TIME);
  const [warnMsg, setWarnMsg] = useState("");
  const [timeout, setTimeout] = useState("");

  const Timer = () => {
    const intervalId = setInterval(() => {
      setSeconds((prevSeconds) => {
        if (prevSeconds === 0) {
          clearInterval(intervalId);
          setTimeout(true);
          setWarnMsg(OTPEXPIRED_MESSAGE);

          return TIMER_TIME;
        }
        return prevSeconds - 1;
      });
    }, 1000);

    return () => {
      clearInterval(intervalId);
    };
  };

  const resendOTP = () => {
    setOtp("");
    dispatch(requestOTPAction(signInForm.userName)).then(
      (response) => {
        if (response.status === SUCCESS_MESSAGE) {
          setTimeout(false);
          setWarnMsg(OTPWARNING_MESSAGE);

          Timer();
          setWarnOpen(true);
        }
      },
      (error) => {
        setOpen(true);
      }
    );
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setSignInForm({
      ...signInForm,
      [name]: value,
      valid: value.trim() !== "",
    });
  };
  let navigate = useNavigate();
  const dispatch = useDispatch();
  useEffect(() => {
    const candidateDtls = JSON.parse(sessionStorage.getItem(CANDIDATE_DETAILS));
    const candidateStatus = sessionStorage.getItem(CANDIDATE_STATUS);
    const userType = sessionStorage.getItem(USER_TYPE);
    if (userType === HR) {
      navigate("/management");
    } else if (candidateStatus === IN_PROGRESS) {
      navigate("/basicdetails");
    } else if (candidateDtls?.id) {
      navigate("/new-page", { params: candidateDtls?.id });
    }
  }, []);
  const handleWarnClose = (event, reason) => {
    if (reason === CLICK_AWAY) {
      return;
    }
    setWarnOpen(false);
  };
  const handleClose = (event, reason) => {
    if (reason === CLICK_AWAY) {
      return;
    }
    setOpen(false);
  };

  const onLogin = (e) => {
    e.preventDefault();
  };

  const handleButtonClick = () => {
    dispatch(requestOTPAction(signInForm.userName)).then(
      (response) => {
        if (response.status === SUCCESS_MESSAGE) {
          setWarnMsg(OTPWARNING_MESSAGE);
          setWarnOpen(true);
          Timer();
          setIsDivVisible(!isDivVisible);
        } else if (!response.status) {
        }
      },
      (error) => {}
    );
  };

  const onOtpEnter = (otpValue) => {
    setOtp(otpValue);
    setIsLoading(true);
    if (otpValue.length === OTP_LENGTH) {
      dispatch(validateOTPAction(signInForm.userName, otpValue)).then(
        (response) => {
          setIsLoading(true);
          if (response.status === SUCCESS_MESSAGE) {
            Timer();
            sessionStorage.setItem(
              CANDIDATE_DETAILS,
              JSON.stringify(response.data.body)
            );
            const sessionModel = {
              firstName: response.data.body.firstName,
              lastName: response.data.body.lastName,
              email: response.data.body.email,
              mobileNumber: response.data.body.mobileNumber,
              doj: response.data.body.doj,
              id: response.data.body.id,
              designation: response.data.body.designation.designation,
            };
            const jsonString = JSON.stringify(sessionModel);
            sessionStorage.setItem(USER, jsonString);

            sessionStorage.setItem(
              USER_TYPE,
              response.data.body.userTypes.userType
            );
            let path = "";
            if (
              response.data.body.userTypes.userType === LATERAL ||
              response.data.body.userTypes.userType === FRESHER
            ) {
              const candidateId = sessionModel.id;

              dispatch(getCandidateFormStatusAction(candidateId)).then(
                (response) => {
                  const status = response.data.status;
                  const formId = response.data.formId;
                  const formName = response.data.formName;

                  if (status === IN_PROGRESS) {
                    sessionStorage.setItem("formId", formId);
                    sessionStorage.setItem("formName", formName);

                    const path = "/basicdetails";
                    navigate(path);
                  } else {
                    const candidateDetails = JSON.parse(
                      sessionStorage.getItem(CANDIDATE_DETAILS)
                    );
                    navigate("/new-page", { params: candidateId });
                  }
                }
              );
            } else if (response.data.body.userTypes.userType === HR) {
              path = "/management";
              navigate(path);
            }
          } else {
            alert(EMAIL_VALIDATION);
          }
        },
        (error) => {
          setErrorMsg(error);
          setOpen(true);
          setWarnOpen(false);
        }
      );
    }
  };

  return (
    <div className="img-colour">
      <div className="login w-100 ">
        <div className=" img-height d-flex justify-content-around">
          <img
            src={onboarding}
            alt=""
            className="mt-3 ms-4 img-size img-width"
          ></img>
          <img
            src={bilvantis}
            alt=""
            className="mt-3 ms-4 img-size bilvantis-img"
          ></img>
        </div>
        <div className="col-12  d-flex justify-content-center">
          <img src={logo} alt="" className=" firs-div"></img>
        </div>
        <div className=" p-0 m-0 d-flex  justify-content-center align-items-center">
          <div>
            <div>
              <div className=" p-0 m-0 mb-5 ms-4 mb-2 d-flex  justify-content-center align-items-center">
                <form onSubmit={onLogin}>
                  {!isDivVisible && (
                    <div className="login_innerbox">
                      <div className="ms-5"></div>
                      <div className="text-center">
                        <text className="login-head m-0 p-0 login-heading-style">
                          Employee Login
                        </text>
                        <span className="login-head m-0 p-0 login-subtitle-style">
                          Hey, Enter your details to get sign in <br />
                          <div className="login-head login-naming-style">
                            to your account
                          </div>
                        </span>
                      </div>
                      <div>
                        <input
                          className="form-control login-input login-input-style inputfocus mt-1"
                          placeholder="Enter Email"
                          name="userName"
                          onChange={(e) => handleInputChange(e)}
                          value={signInForm.userName}
                        />
                        <button
                          onClick={handleButtonClick}
                          disabled={!isEmailAddressValid}
                          className="login-btn mt-3"
                        >
                          Send OTP
                        </button>
                        <div className="login-head signin-title-style">
                          Having trouble in sign in?
                          <span className="sigin-style"> Contact us</span>
                        </div>
                      </div>
                    </div>
                  )}
                  {isDivVisible && (
                    <div className="sigin-innerbox">
                      <div className="warnstyle">
                        <>
                          <WarnSnack
                            open={warnOpen}
                            onClose={handleWarnClose}
                            successMessage={warnMsg}
                          />
                        </>
                      </div>
                      <text className="login-head m-0 p-0 login-heading-style">
                        Employee Login
                      </text>
                      <span className="login-head m-0 p-0 signin-heading">
                        We have sent{" "}
                        <span className="login_name">One Time Password</span> to
                        your email <br />
                        <div className="signin-otp-style">Please Enter OTP</div>
                      </span>

                      <OtpInput
                        value={otp}
                        onChange={(e) => onOtpEnter(e)}
                        numInputs={6}
                        inputType="tel"
                        name="password"
                        renderSeparator={<span className="otp-img-box"></span>}
                        renderInput={(props) => (
                          <input {...props} className="otp-style" />
                        )}
                      />

                      <div className="button-container">
                        <button
                          className="login-downcalladmin resend-otp-style"
                          onClick={resendOTP}
                        >
                          Resend OTP
                        </button>

                        <button
                          className="verify-btn mt-3 verify-otp-style"
                          onClick={onOtpEnter}
                          style={{
                            fontSize: "10px",
                            backgroundColor: isLoading ? "#b7dfec" : "",
                            color: isLoading ? "#ffffff" : "",
                          }}
                        >
                          {isLoading ? "....Verify OTP" : "Verify OTP"}
                        </button>
                      </div>
                    </div>
                  )}
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
