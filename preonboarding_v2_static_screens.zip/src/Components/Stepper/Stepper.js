import React from "react";
import "./stepper.css";
import circle from "../../Assets/circle.svg";
import checked from "../../Assets/checked.svg";
import grey_circle from "../../Assets/grey_circle.svg";

const steps = [
  "Basic Details",
  "Employee Joining Report",
  "Employee Non-Disclosure And Confidentiality Agreement",
  "Letter Of Authorization",
  "Letter Of Authorization Hello Verify rename as Authorisation Letter for BGC",
  "Candidate Declaration",
  "Composite Declaration Form",
  "SODEXO Meal Passes"
];

const VerticalStepper = ({ currentStep }) => {
  currentStep = currentStep - 1;
  return (
    <div className="vertical-stepper">
      {steps.map((step, index) => {
        let status = "upcoming";
        if (index < currentStep) {
          status = "completed";
        } else if (index === currentStep) {
          status = "current";
        }

        return (
          <div key={index} className={`step ${status}`}>
            <div className={`circle ${status}`}>
              {status === "completed" ? <img src={checked} /> : ""}
              {status === "current" ? <img src={circle} /> : ""}
              {status === "upcoming" ? <img src={grey_circle} /> : ""}
            </div>
            <div className="label">{step}</div>
          </div>
        );
      })}
    </div>
  );
};

export default VerticalStepper;
