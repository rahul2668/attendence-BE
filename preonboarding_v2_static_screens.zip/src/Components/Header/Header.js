import React from "react";
import "./header.css";
import onboardinglogo from "../../Assets/onboardinglogo.svg";

const Header = () => {
  return (
    <header className="header">
      <div className="d-flex">
      <img src={onboardinglogo} />
      <p className="header-text">Onboarding</p>
      </div>
    </header>
  );
};

export default Header;
