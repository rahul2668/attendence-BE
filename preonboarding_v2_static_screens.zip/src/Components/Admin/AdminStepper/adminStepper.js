import React, { useEffect } from "react";
import { Divider, Steps } from "antd";
import { useNavigate, useLocation } from "react-router-dom";
import "./adminStepper.css";

const AdminVerticalStepper = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const getCurrentStep = () => {
    switch (location.pathname) {
      case "/dashboard/candidate-management":
        return 0;
      case "/dashboard/candidate-status":
        return 1;
      case "/dashboard/worklist":
        return 2;
      default:
        return 0;
    }
  };

  const [current, setCurrent] = React.useState(getCurrentStep());

  useEffect(() => {
    setCurrent(getCurrentStep());
  }, [location.pathname]);

  const onChange = (value) => {
    setCurrent(value);
    switch (value) {
      case 0:
        navigate("/dashboard/candidate-management");
        break;
      case 1:
        navigate("/dashboard/candidate-status");
        break;
      case 2:
        navigate("/dashboard/worklist");
        break;
      default:
        break;
    }
  };

  return (
    <>
      <Divider />
      <div className="vertical-stepper">
        <Steps
          current={current}
          onChange={onChange}
          direction="vertical"
          size="small"
          items={[
            {
              title: "Candidate Management",
              status: current > 0 ? "wait" : "process",
            },
            {
              title: "Candidate Status",
              status: current > 1 ? "wait" : current === 1 ? "process" : "wait",
            },
            {
              title: "Worklist",
              status: current === 2 ? "process" : "wait",
            },
          ]}
        />
      </div>
    </>
  );
};

export default AdminVerticalStepper;
