// import React from "react";

// const Worklist = () => {
//   return (
//     <div>
//       <h2>Worklist</h2>
//       <p>Content for Worklist page.</p>
//     </div>
//   );
// };

// export default Worklist;

import React, { useState, useEffect } from "react";
import {
  Input,
  Radio,
  List,
  Typography,
  Button,
  Table,
  Modal,
  Form,
  Input as AntInput,
} from "antd";
import {
  DownloadOutlined,
  FilePdfOutlined,
  StopOutlined,
  EyeOutlined,
  CheckOutlined,
  CloseOutlined,
  InfoCircleOutlined,
  CloseCircleOutlined,
} from "@ant-design/icons";
import "./worklist.css";
import { worklistData, worklistGetData } from "./worklistData";

const { Search } = Input;
const { Text } = Typography;

const Worklist = () => {
  const [selectedCandidate, setSelectedCandidate] = useState(null);
  const [formsSubmitted, setFormsSubmitted] = useState([]);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [modalActionType, setModalActionType] = useState("");
  const [form] = Form.useForm();

  useEffect(() => {
    const fetchFormsSubmitted = async (candidateId) => {
      const candidateForms = worklistData
        .filter((form) => form.candidate.id === candidateId)
        .map((form) => ({
          id: form.forms.id,
          formName: form.forms.formName,
          submittedDate: form.createdDate,
          status: form.status,
        }));
      setFormsSubmitted(candidateForms);
    };

    if (selectedCandidate) {
      fetchFormsSubmitted(selectedCandidate.id);
    }
  }, [selectedCandidate]);

  const candidates = worklistGetData.body.map((item) => item.candidate);

  const handleClick = (candidate) => {
    setSelectedCandidate(candidate);
  };

  const handleActionClick = (actionType) => {
    setModalActionType(actionType);
    setIsModalVisible(true);
  };

  const handleModalOk = () => {
    form.validateFields().then((values) => {
      console.log(`${modalActionType} Comment:`, values.comment);
      setIsModalVisible(false);
      form.resetFields();
    });
  };

  const handleModalCancel = () => {
    setIsModalVisible(false);
    form.resetFields();
  };

  const handleCloseDetails = () => {
    setSelectedCandidate(null);
  };

  const columns = [
    {
      title: "S.No.",
      dataIndex: "id",
      key: "id",
      render: (text, record, index) => index + 1,
    },
    {
      title: "Form Name",
      dataIndex: "formName",
      key: "formName",
    },
    {
      title: "Status",
      dataIndex: "submittedDate",
      key: "submittedDate",
      render: (text) => "Submitted", // Assuming all forms are submitted
    },
    {
      title: "Actions",
      key: "actions",
      render: (text, record) => (
        <div className="worklist-icon-container">
          <EyeOutlined onClick={() => console.log("Download", record)} />
          <CheckOutlined onClick={() => handleActionClick("Approve")} />
          <StopOutlined onClick={() => handleActionClick("Reject")} />
          <InfoCircleOutlined onClick={() => handleActionClick("Info check")} />
        </div>
      ),
    },
  ];

  return (
    <div className="worklist-container">
      <div className="worklist-search-container">
        <Search
          placeholder="Search candidates..."
          style={{ width: 200, borderRadius: "1.5rem" }}
        />
      </div>
      <div className="worklist-row-container">
        <div className="worklist-column worklist-col1">
          <List
            dataSource={candidates}
            renderItem={(candidate) => (
              <List.Item
                key={candidate.id}
                className={`worklist-candidate-item ${
                  selectedCandidate && selectedCandidate.id === candidate.id
                    ? "active"
                    : ""
                }`}
                onClick={() => handleClick(candidate)}
              >
                {candidate.firstName} {candidate.lastName}
              </List.Item>
            )}
          />
        </div>
        <div className="worklist-column worklist-col2" style={{ width: "70%" }}>
          {selectedCandidate && (
            <div className="worklist-candidate-details">
              <div className="worklist-close-icon-container">
                <CloseOutlined onClick={handleCloseDetails} />
              </div>
              <div className="worklist-details-grid">
                <div>
                  <Text className="key">Candidate Name: </Text>{" "}
                  <Text>
                    {selectedCandidate.firstName} {selectedCandidate.middleName}{" "}
                    {selectedCandidate.lastName}
                  </Text>
                </div>
                <div>
                  <Text className="key">Joining Date: </Text>{" "}
                  <Text>
                    {new Date(
                      selectedCandidate.joiningDate
                    ).toLocaleDateString()}
                  </Text>
                </div>
                <div>
                  <Text className="key">Designation: </Text>{" "}
                  <Text>{selectedCandidate.designation.designation}</Text>
                </div>
                <div>
                  <Text className="key">Forms Submitted On: </Text>{" "}
                  <Text>
                    {new Date(
                      selectedCandidate.createdDate
                    ).toLocaleDateString()}
                  </Text>
                </div>
              </div>
              <hr />

              <div className="worklist-forms-table">
                <Table
                  dataSource={formsSubmitted}
                  columns={columns}
                  rowKey="id"
                  pagination={false}
                  style={{ marginTop: "1rem" }}
                />
              </div>
            </div>
          )}
          {!selectedCandidate && (
            <div className="worklist-candidate-details-placeholder">
              <p>Please select a candidate to see details.</p>
            </div>
          )}
        </div>
      </div>

      {/* Modal for comments */}
      <Modal
        visible={isModalVisible}
        title={
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <span>Comments</span>
          </div>
        }
        onOk={handleModalOk}
        onCancel={handleModalCancel}
        footer={[
          <Button key="cancel" onClick={handleModalCancel}>
            Cancel
          </Button>,
          <Button key="submit" type="primary" onClick={handleModalOk}>
            Send
          </Button>,
        ]}
      >
        <Form form={form} layout="vertical">
          <Form.Item
            name="comment"
            rules={[{ required: true, message: "Please input your comment!" }]}
          >
            <AntInput.TextArea
              rows={4}
              placeholder={`Enter ${modalActionType.toLowerCase()} comments here...`}
            />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default Worklist;
