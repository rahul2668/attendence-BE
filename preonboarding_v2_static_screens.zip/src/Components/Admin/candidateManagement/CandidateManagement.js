// import React, { useState } from "react";
// import "bootstrap/dist/css/bootstrap.min.css";
// import "./candidateManagement.css";
// import { EditOutlined, DeleteOutlined, CloseOutlined } from "@ant-design/icons";
// import { Select, Button, List, Input, Typography, Modal } from "antd";
// import candidateData from "./candidateManagementData";

// const { Option } = Select;
// const { Search } = Input;
// const { Text } = Typography;

// const CandidateManagement = () => {
//   const [modalOpen, setModalOpen] = useState(false);
//   const [selectedCandidate, setSelectedCandidate] = useState(null);
//   const [isEditing, setIsEditing] = useState(false);
//   const [isModalVisible, setIsModalVisible] = useState(false);

//   const candidates = candidateData.body.map((item) => item.candidateDTO);

//   const handleClick = (candidate) => {
//     setSelectedCandidate(candidate);
//     setIsEditing(false);
//   };

//   const handleEditClick = () => {
//     setIsEditing(!isEditing);
//   };

//   const handleDeleteClick = () => {
//     setIsModalVisible(true); // Show confirmation popup
//   };

//   const handleConfirmDelete = () => {
//     console.log("Delete confirmed");
//     setSelectedCandidate(null);
//     setIsModalVisible(false);
//   };

//   const handleCancelDelete = () => {
//     setIsModalVisible(false);
//   };

//   const handleUpdateClick = () => {
//     console.log("Update clicked");
//     setIsEditing(false);
//   };

//   const handleCloseClick = () => {
//     setSelectedCandidate(null);
//     setIsEditing(false);
//   };

//   return (
//     <div className="candidate-management-container">
//       <div className="candidate-management-search-container">
//         <Search
//           placeholder="Search candidates..."
//           style={{ width: 200, borderRadius: "1.5rem" }}
//         />
//         <Button type="primary" onClick={() => setModalOpen(true)}>
//           Add +
//         </Button>
//       </div>
//       <Modal
//         title="Vertically centered modal dialog"
//         centered
//         open={modalOpen}
//         onOk={() => setModalOpen(false)}
//         onCancel={() => setModalOpen(false)}
//       >
//         <p>some contents...</p>
//         <p>some contents...</p>
//         <p>some contents...</p>

//       </Modal>

//       <div className="candidate-management-row-container">
//         <div className="candidate-management-column candidate-management-col1">
//           <List
//             dataSource={candidates}
//             renderItem={(candidate) => (
//               <List.Item
//                 key={candidate.id}
//                 className={`candidate-management-candidate-item ${
//                   selectedCandidate && selectedCandidate.id === candidate.id
//                     ? "active"
//                     : ""
//                 }`}
//                 onClick={() => handleClick(candidate)}
//               >
//                 {/* <input
//                   type="radio"
//                   id={`candidate-${candidate.id}`}
//                   name="selectedCandidate"
//                   checked={
//                     selectedCandidate && selectedCandidate.id === candidate.id
//                   }
//                   readOnly
//                   style={{ marginRight: "8px" }}
//                 /> */}
//                 {candidate.firstName} {candidate.lastName}
//               </List.Item>
//             )}
//           />
//         </div>
//         <div className="candidate-management-column candidate-management-col2">
//           {selectedCandidate ? (
//             <div className="candidate-management-candidate-details">
//               <div className="candidate-management-close-icon-container">
//                 <CloseOutlined onClick={handleCloseClick} />
//               </div>
//               {/* <div
//                 className="candidate-management-icon-container"
//                 style={{ visibility: isEditing ? "hidden" : "visible" }}
//               >
//                 <Button type="primary" onClick={handleEditClick}>
//                   Edit
//                 </Button>
//                 <Button type="primary" onClick={handleDeleteClick}>
//                   Delete
//                 </Button>
//               </div> */}
//               <div className="field">
//                 <Text strong>First Name: </Text>
//                 {isEditing ? (
//                   <Input defaultValue={selectedCandidate.firstName} />
//                 ) : (
//                   <Text>{selectedCandidate.firstName}</Text>
//                 )}
//               </div>
//               <div className="field">
//                 <Text strong>Middle Name: </Text>
//                 {isEditing ? (
//                   <Input defaultValue={selectedCandidate.middleName} />
//                 ) : (
//                   <Text>{selectedCandidate.middleName}</Text>
//                 )}
//               </div>
//               <div className="field">
//                 <Text strong>Last Name: </Text>
//                 {isEditing ? (
//                   <Input defaultValue={selectedCandidate.lastName} />
//                 ) : (
//                   <Text>{selectedCandidate.lastName}</Text>
//                 )}
//               </div>
//               <div className="field">
//                 <Text strong>Email: </Text>
//                 {isEditing ? (
//                   <Input defaultValue={selectedCandidate.email} />
//                 ) : (
//                   <Text>{selectedCandidate.email}</Text>
//                 )}
//               </div>
//               <div className="field">
//                 <Text strong>Phone Number: </Text>
//                 {isEditing ? (
//                   <Input defaultValue={selectedCandidate.phoneNumber} />
//                 ) : (
//                   <Text>{selectedCandidate.phoneNumber}</Text>
//                 )}
//               </div>
//               <div className="field">
//                 <Text strong>Joining Date: </Text>
//                 {isEditing ? (
//                   <Input
//                     defaultValue={new Date(
//                       selectedCandidate.joiningDate
//                     ).toLocaleDateString()}
//                   />
//                 ) : (
//                   <Text>
//                     {new Date(
//                       selectedCandidate.joiningDate
//                     ).toLocaleDateString()}
//                   </Text>
//                 )}
//               </div>
//               <div className="field">
//                 <Text strong>Designation: </Text>
//                 {isEditing ? (
//                   <Select
//                     defaultValue={selectedCandidate.designation.designation}
//                     style={{ width: "100%" }}
//                   >
//                     <Option value="Director">Director</Option>
//                     <Option value="Manager">Manager</Option>
//                     <Option value="Developer">Developer</Option>
//                   </Select>
//                 ) : (
//                   <Text>{selectedCandidate.designation.designation}</Text>
//                 )}
//               </div>
//               <div className="field">
//                 <Text strong>User Type: </Text>
//                 {isEditing ? (
//                   <Select
//                     value={selectedCandidate.userTypes.userType}
//                     disabled
//                     style={{ width: "100%" }}
//                   >
//                     <Option value="HR">HR</Option>
//                     <Option value="Admin">Admin</Option>
//                     <Option value="User">User</Option>
//                   </Select>
//                 ) : (
//                   <Text>{selectedCandidate.userTypes.userType}</Text>
//                 )}
//               </div>

//               {/* <div
//                 className="candidate-management-icon-container"
//                 style={{ visibility: isEditing ? "hidden" : "visible" }}
//               > */}
//               <div
//                 className={`candidate-management-icon-container ${
//                   isEditing ? "hidden" : ""
//                 }`}
//               >
//                 <Button type="primary" onClick={handleEditClick}>
//                   Edit
//                 </Button>
//                 <Button type="primary" onClick={handleDeleteClick}>
//                   Delete
//                 </Button>
//               </div>
//               {isEditing && (
//                 <div className="candidate-management-update-button-container">
//                   <Button type="primary" onClick={handleUpdateClick}>
//                     Update
//                   </Button>
//                 </div>
//               )}
//             </div>
//           ) : (
//             // <p>Select a candidate to see details.</p>
//             <div className="candidate-management-details-placeholder">
//               <p>Please select a candidate to see details.</p>
//             </div>
//           )}
//         </div>
//       </div>

//       <Modal
//         title="Confirm Deletion"
//         visible={isModalVisible}
//         onOk={handleConfirmDelete}
//         onCancel={handleCancelDelete}
//         okText="Yes"
//         cancelText="No"
//       >
//         <p>Are you sure you want to delete this candidate?</p>
//       </Modal>
//     </div>
//   );
// };

// export default CandidateManagement;

import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "./candidateManagement.css";
import { EditOutlined, DeleteOutlined, CloseOutlined } from "@ant-design/icons";
import {
  Select,
  Button,
  List,
  Input,
  Typography,
  Modal,
  Form,
  DatePicker,
  Row,
  Col,
} from "antd";
import candidateData from "./candidateManagementData";

const { Option } = Select;
const { Search } = Input;
const { Text } = Typography;

const CandidateManagement = () => {
  const [modalOpen, setModalOpen] = useState(false);
  const [originalCandidate, setOriginalCandidate] = useState(null);
  const [selectedCandidate, setSelectedCandidate] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [form] = Form.useForm();

  const candidates = candidateData.body.map((item) => item.candidateDTO);

  const handleClick = (candidate) => {
    setSelectedCandidate(candidate);
    setIsEditing(false);
  };

  const handleEditClick = () => {
    setOriginalCandidate({ ...selectedCandidate });
    setIsEditing(true);
  };
  const handleResetClick = () => {
    setSelectedCandidate({ ...originalCandidate }); // Revert to original values
  };

  const handleDeleteClick = () => {
    setIsModalVisible(true); // Show confirmation popup
  };

  const handleConfirmDelete = () => {
    console.log("Delete confirmed");
    setSelectedCandidate(null);
    setIsModalVisible(false);
  };

  const handleCancelDelete = () => {
    setIsModalVisible(false);
  };

  const handleUpdateClick = () => {
    console.log("Update clicked");
    setIsEditing(false);
  };

  const handleCloseClick = () => {
    setSelectedCandidate(null);
    setIsEditing(false);
  };

  const handleCreate = () => {
    form
      .validateFields()
      .then((values) => {
        console.log("Form values: ", values);
        form.resetFields();
        setModalOpen(false);
      })
      .catch((info) => {
        console.log("Validate Failed:", info);
      });
  };

  const handleClear = () => {
    form.resetFields();
  };

  return (
    <div className="candidate-management-container">
      <div className="candidate-management-search-container">
        <Search
          placeholder="Search candidates..."
          style={{ width: 200, borderRadius: "1.5rem" }}
        />
        <div className="add-button">
          <Button type="primary" onClick={() => setModalOpen(true)}>
            Add +
          </Button>
        </div>
      </div>

      <Modal
        title="Add New Candidate"
        centered
        open={modalOpen}
        onCancel={() => setModalOpen(false)}
        footer={[
          <div className="modal_footer">
            <Button key="clear" type="primary" onClick={handleClear}>
              Clear
            </Button>

            <Button key="create" type="primary" onClick={handleCreate}>
              Create
            </Button>
          </div>,
        ]}
      >
        <Form form={form} layout="vertical">
          <Row gutter={16}>
            <Col span={12}>
              <Form.Item
                name="firstName"
                label="First Name"
                rules={[{ required: true, message: "Please enter first name" }]}
              >
                <Input />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name="middleName" label="Middle Name">
                <Input />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={16}>
            <Col span={12}>
              <Form.Item
                name="lastName"
                label="Last Name"
                rules={[{ required: true, message: "Please enter last name" }]}
              >
                <Input />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                name="email"
                label="Email"
                rules={[{ required: true, message: "Please enter email" }]}
              >
                <Input />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={16}>
            <Col span={12}>
              <Form.Item
                name="phoneNumber"
                label="Mobile Number"
                rules={[
                  { required: true, message: "Please enter mobile number" },
                ]}
              >
                <Input />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                name="joiningDate"
                label="Joining Date"
                rules={[{ required: true, message: "Please select a date" }]}
              >
                <DatePicker style={{ width: "100%" }} />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={16}>
            <Col span={12}>
              <Form.Item
                name="designation"
                label="Designation"
                rules={[
                  { required: true, message: "Please select a designation" },
                ]}
              >
                <Select placeholder="Select a designation">
                  <Option value="Director">Director</Option>
                  <Option value="Manager">Manager</Option>
                  <Option value="Developer">Developer</Option>
                </Select>
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                name="userType"
                label="User Type"
                rules={[
                  { required: true, message: "Please select a user type" },
                ]}
              >
                <Select placeholder="Select a user type">
                  <Option value="HR">HR</Option>
                  <Option value="Admin">Admin</Option>
                  <Option value="User">User</Option>
                </Select>
              </Form.Item>
            </Col>
          </Row>
        </Form>
      </Modal>

      <div className="candidate-management-row-container">
        <div className="candidate-management-column candidate-management-col1">
          <List
            dataSource={candidates}
            renderItem={(candidate) => (
              <List.Item
                key={candidate.id}
                className={`candidate-management-candidate-item ${
                  selectedCandidate && selectedCandidate.id === candidate.id
                    ? "active"
                    : ""
                }`}
                onClick={() => handleClick(candidate)}
              >
                {candidate.firstName} {candidate.lastName}
              </List.Item>
            )}
          />
        </div>
        <div className="candidate-management-column candidate-management-col2">
          {selectedCandidate ? (
            <div className="candidate-management-candidate-details">
              <div className="candidate-management-close-icon-container">
                <CloseOutlined onClick={handleCloseClick} />
              </div>
              <div className="field">
                <Text strong>First Name: </Text>
                {isEditing ? (
                  <Input
                    value={selectedCandidate.firstName}
                    onChange={(e) =>
                      setSelectedCandidate({
                        ...selectedCandidate,
                        firstName: e.target.value,
                      })
                    }
                  />
                ) : (
                  <Text>{selectedCandidate.firstName}</Text>
                )}
              </div>
              <div className="field">
                <Text strong>Middle Name: </Text>
                {isEditing ? (
                  <Input
                    value={selectedCandidate.middleName}
                    onChange={(e) =>
                      setSelectedCandidate({
                        ...selectedCandidate,
                        middleName: e.target.value,
                      })
                    }
                  />
                ) : (
                  <Text>{selectedCandidate.middleName}</Text>
                )}
              </div>
              <div className="field">
                <Text strong>Last Name: </Text>
                {isEditing ? (
                  <Input
                    value={selectedCandidate.lastName}
                    onChange={(e) =>
                      setSelectedCandidate({
                        ...selectedCandidate,
                        lastName: e.target.value,
                      })
                    }
                  />
                ) : (
                  <Text>{selectedCandidate.lastName}</Text>
                )}
              </div>
              <div className="field">
                <Text strong>Email: </Text>
                {isEditing ? (
                  <Input
                    value={selectedCandidate.email}
                    onChange={(e) =>
                      setSelectedCandidate({
                        ...selectedCandidate,
                        email: e.target.value,
                      })
                    }
                  />
                ) : (
                  <Text>{selectedCandidate.email}</Text>
                )}
              </div>
              <div className="field">
                <Text strong>Phone Number: </Text>
                {isEditing ? (
                  <Input
                    value={selectedCandidate.phoneNumber}
                    onChange={(e) =>
                      setSelectedCandidate({
                        ...selectedCandidate,
                        phoneNumber: e.target.value,
                      })
                    }
                  />
                ) : (
                  <Text>{selectedCandidate.phoneNumber}</Text>
                )}
              </div>
              <div className="field">
                <Text strong>Joining Date: </Text>
                {isEditing ? (
                  <Input
                    value={new Date(
                      selectedCandidate.joiningDate
                    ).toLocaleDateString()}
                    onChange={(e) =>
                      setSelectedCandidate({
                        ...selectedCandidate,
                        joiningDate: new Date(e.target.value).toISOString(),
                      })
                    }
                  />
                ) : (
                  <Text>
                    {new Date(
                      selectedCandidate.joiningDate
                    ).toLocaleDateString()}
                  </Text>
                )}
              </div>
              <div className="field">
                <Text strong>Designation: </Text>
                {isEditing ? (
                  <Select
                    value={selectedCandidate.designation.designation}
                    onChange={(value) =>
                      setSelectedCandidate({
                        ...selectedCandidate,
                        designation: { designation: value },
                      })
                    }
                    style={{ width: "100%" }}
                  >
                    <Option value="Director">Director</Option>
                    <Option value="Manager">Manager</Option>
                    <Option value="Developer">Developer</Option>
                  </Select>
                ) : (
                  <Text>{selectedCandidate.designation.designation}</Text>
                )}
              </div>
              <div className="field">
                <Text strong>User Type: </Text>
                {isEditing ? (
                  <Select
                    value={selectedCandidate.userTypes.userType}
                    disabled
                    style={{ width: "100%" }}
                  >
                    <Option value="HR">HR</Option>
                    <Option value="Admin">Admin</Option>
                    <Option value="User">User</Option>
                  </Select>
                ) : (
                  <Text>{selectedCandidate.userTypes.userType}</Text>
                )}
              </div>

              <div
                className={`candidate-management-icon-container ${
                  isEditing ? "hidden" : ""
                }`}
              >
                <Button type="primary" onClick={handleEditClick}>
                  Edit
                </Button>
                <Button type="primary" onClick={handleDeleteClick}>
                  Delete
                </Button>
              </div>
              {isEditing && (
                <div className="candidate-management-update-button-container">
                  <Button type="primary" onClick={handleResetClick}>
                    Reset
                  </Button>
                  <Button type="primary" onClick={handleUpdateClick}>
                    Update
                  </Button>
                </div>
              )}
            </div>
          ) : (
            <div className="candidate-management-details-placeholder">
              <p>Please select a candidate to see details.</p>
            </div>
          )}
        </div>
      </div>

      <Modal
        title="Confirm Deletion"
        visible={isModalVisible}
        onOk={handleConfirmDelete}
        onCancel={handleCancelDelete}
        okText="Yes"
        cancelText="No"
      >
        <p>Are you sure you want to delete this candidate?</p>
      </Modal>
    </div>
  );
};

export default CandidateManagement;
