import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "./candidateStatus.css";
import { CloseOutlined } from "@ant-design/icons";
import { List, Input, Typography, Modal, Table } from "antd";
import { candidatestatusGetData } from "./candidatestatusData";

const { Search } = Input;
const { Text } = Typography;

const CandidateStatus = () => {
  const [selectedCandidate, setSelectedCandidate] = useState(null);
  const [isModalVisible, setIsModalVisible] = useState(false);

  const findCandidateById = (id) => {
    return candidatestatusGetData.find(
      (candidate) => candidate.candidateId === id
    );
  };

  const candidates = candidatestatusGetData.map((item) => ({
    id: item.candidateId,
    firstName: item.candidateName.split(" ")[0],
    lastName: item.candidateName.split(" ")[1],
    ...item.formsStatusDTOS[0],
  }));

  const handleClick = (candidate) => {
    setSelectedCandidate(findCandidateById(candidate.id));
  };

  const handleDeleteClick = () => {
    setIsModalVisible(true);
  };

  const handleConfirmDelete = () => {
    console.log("Delete confirmed");
    setSelectedCandidate(null);
    setIsModalVisible(false);
  };

  const handleCancelDelete = () => {
    setIsModalVisible(false);
  };

  const handleCloseClick = () => {
    setSelectedCandidate(null);
  };

  const columns = [
    {
      title: "S.No.",
      dataIndex: "id",
      key: "id",
      render: (text, record, index) => index + 1,
    },
    {
      title: "Form Name",
      dataIndex: "formName",
      key: "formName",
      render: (text) => <Text>{text}</Text>,
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (text) => (
        <Text
          className={
            text === "IN_PROGRESS"
              ? "status-in-progress"
              : text === "OPEN"
              ? "status-open"
              : text === "COMPLETED"
              ? "status-completed"
              : ""
          }
        >
          {text}
        </Text>
      ),
    },
  ];

  return (
    <div className="candidate-status-container">
      <div className="candidate-status-search-container">
        <Search
          placeholder="Search candidates..."
          style={{ width: 200, borderRadius: "1.5rem" }}
        />
      </div>
      <div className="candidate-status-row-container">
        <div className="candidate-status-column candidate-status-col1">
          <List
            dataSource={candidates}
            renderItem={(candidate) => (
              <List.Item
                key={candidate.id}
                className={`candidate-status-candidate-item ${
                  selectedCandidate &&
                  selectedCandidate.candidateId === candidate.id
                    ? "active"
                    : ""
                }`}
                onClick={() => handleClick(candidate)}
              >
                {candidate.firstName} {candidate.lastName}
              </List.Item>
            )}
          />
        </div>
        <div className="candidate-status-column candidate-status-col2">
          {selectedCandidate ? (
            <div className="candidate-status-candidate-details">
              <div className="candidate-status-close-icon-container">
                <CloseOutlined onClick={handleCloseClick} />
              </div>
              <Text className="status-key">Candidate Name:</Text>{" "}
              <Text>{selectedCandidate.candidateName}</Text>
              <hr />
              <div className="candidate-status-forms-list">
                <Table
                  dataSource={selectedCandidate.formsStatusDTOS}
                  columns={columns}
                  rowKey="formId"
                  pagination={false}
                  style={{ marginTop: "1rem" }}
                />
              </div>
            </div>
          ) : (
            <div className="candidate-status-details-placeholder">
              <p>Please select a candidate to see details.</p>
            </div>
          )}
        </div>
      </div>

      <Modal
        title="Confirm Deletion"
        open={isModalVisible}
        onOk={handleConfirmDelete}
        onCancel={handleCancelDelete}
        okText="Yes"
        cancelText="No"
      >
        <p>Are you sure you want to delete this candidate?</p>
      </Modal>
    </div>
  );
};

export default CandidateStatus;
