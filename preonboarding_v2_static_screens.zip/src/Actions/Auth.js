import {
  REGISTER_FAIL,
  SET_MESSAGE,
  LOGIN_FAIL,
} from "../ActionTypes/LoginTypes";

import AuthService from "../Services/Auth";

export const requestOTPAction = (email) => (dispatch) => {
  return AuthService.requestOTPService(email).then(
    (response) => {
      return Promise.resolve(response);
    },
    (error) => {
      const message =
        (error.response &&
          error.response.data &&
          error.response.data.message) ||
        error.message ||
        error.toString();

      dispatch({
        type: REGISTER_FAIL,
      });

      dispatch({
        type: SET_MESSAGE,
        payload: message,
      });

      return Promise.resolve(error.response.data.message);
    }
  );
};
export const validateOTPAction = (email, oneTimePassword) => (dispatch) => {
  return AuthService.validateOTPService(email, oneTimePassword).then(
    (response) => {
      sessionStorage.setItem("sessionObject", response);
      return Promise.resolve(response);
    },
    (error) => {
      const message =
        (error.response && error.response.data && error.response.data.detail) ||
        error.message ||
        error.toString();

      dispatch({
        type: LOGIN_FAIL,
      });

      dispatch({
        type: SET_MESSAGE,
        payload: message,
      });

      return Promise.reject();
    }
  );
};
export const getCandidateFormStatusAction = (candidateId) => (dispatch) => {
  return AuthService.getCandidateFormStatus(candidateId).then(
    (response) => {
      sessionStorage.setItem("candidateStatus", response?.data?.status);
      return Promise.resolve(response);
    },
    (error) => {
      console.error(error);
      return Promise.reject(error);
    }
  );
};
