import axios from "axios";
import React, { useState } from "react";
import Backdrop from "@mui/material/Backdrop";
import Swal from "sweetalert2";
import CircularProgress from "@mui/material/CircularProgress";

// const REACT_APP_ONBOARDING_API_URL = window.location.hostname.includes("qa")
//   ? "https://pre-onboarding-api-rbq3pjoy7q-uc.a.run.app"
//   : window.location.hostname.includes("dev")
//   ? "https://pre-onboarding-api-ksfgonz3qq-uc.a.run.app"
//   : "https://pre-onboarding-api-xwd2usm2vq-uc.a.run.app";

// export const Api = axios.create({
//   baseURL: REACT_APP_ONBOARDING_API_URL,
// });
export const Api = axios.create({
  baseURL: "https://pre-onboarding-api-rbq3pjoy7q-uc.a.run.app",
  // baseURL: "http://localhost:8085",
});
const Loader = () => {
  const [loading, setLoading] = useState(false);

  Api.interceptors.request.use(
    function (config) {
      setLoading(true);

      return config;
    },
    function (error) {
      setLoading(false);
      return Promise.reject(error);
    }
  );

  Api.interceptors.response.use(
    function (response) {
      setLoading(false);
      return response;
    },
    function (error) {
      setLoading(false);
      if (error.response) {
        const status = error.response.status;
        if (status === 401 || status === 403) {
          sessionStorage.clear();
          window.location.href = "/login";
        } else if (status === 400 || status === 404 || status === 500) {
          const errorData = error.response.data;
          if (Array.isArray(errorData)) {
            errorData.forEach((errorItem) => {
              Swal.fire({
                title: "",
                text: errorItem.message,
                icon: "error",
                confirmButtonColor: "#3085d6",
                confirmButtonText: "OK",
              });
            });
          } else if (typeof errorData === "object" && errorData.message) {
            Swal.fire({
              title: "",
              text: errorData.message,
              icon: "error",
              confirmButtonColor: "#3085d6",
              confirmButtonText: "OK",
            });
          } else {
            Swal.fire({
              title: "",
              text: "An error occurred",
              icon: "error",
              confirmButtonColor: "#3085d6",
              confirmButtonText: "OK",
            });
          }
        } else if (status === 503) {
          console.error("503 occurred :: ", error);
          Swal.fire({
            title: "",
            text: "Backend Services are Temporarily Unavailable",
            icon: "error",
            confirmButtonColor: "#3085d6",
            confirmButtonText: "OK",
          });
        }
      } else {
        Swal.fire({
          title: "",
          text: "Network Error: Please check your internet connection",
          icon: "error",
          confirmButtonColor: "#3085d6",
          confirmButtonText: "OK",
        });
      }
      return Promise.reject(error);
    }
  );
  return (
    <Backdrop
      sx={{
        color: "#fff",
        zIndex: (theme) => theme.zIndex.drawer + 1,
        backgroundColor: "rgba(0,0,0,0.2)",
      }}
      open={loading}
    >
      <CircularProgress color="inherit" />
    </Backdrop>
  );
};

export default Loader;
