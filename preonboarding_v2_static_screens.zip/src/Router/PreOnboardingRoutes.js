// import React from "react";
// import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
// import { Navigate } from "react-router-dom";
// import Login from "../Components/Login/Login";
// import EmployeeDetails from "../Components/EmployeeDetails/EmployeeDetails";
// import DashboardDetails from "../Components/EmployeeDetails/dashboard";
// import CandidateManagement from "../Components/Admin/CandidateManagement";
// import CandidateStatus from "../Components/Admin/CandidateStatus";
// import Worklist from "../Components/Admin/Worklist";

// const AppRouter = () => {
//   return (
//     <Router>
//       <Routes>
//         <Route path="/" element={<Navigate to="/login" />} />
//         <Route path="/login" element={<Login />} />
//         <Route path="/employee-details" element={<EmployeeDetails />} />
//         <Route path="/dashboard" element={<DashboardDetails />} />
//         <Route path="/candidate-management" element={<CandidateManagement />} />
//         <Route path="/candidate-status" element={<CandidateStatus />} />
//         <Route path="/worklist" element={<Worklist />} />
//       </Routes>
//     </Router>
//   );
// };

// export default AppRouter;

import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { Navigate } from "react-router-dom";
import Login from "../Components/Login/Login";
import EmployeeDetails from "../Components/EmployeeDetails/EmployeeDetails";
import DashboardDetails from "../Components/Admin/adminDashboard";
import CandidateManagement from "../Components/Admin/candidateManagement/CandidateManagement";
import CandidateStatus from "../Components/Admin/candidateStatus/CandidateStatus";
import Worklist from "../Components/Admin/worklist/Worklist";

const AppRouter = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Navigate to="/login" />} />
        <Route path="/login" element={<Login />} />
        <Route path="/employee-details" element={<EmployeeDetails />} />
        <Route path="/dashboard" element={<DashboardDetails />}>
          <Route path="" element={<Navigate to="candidate-management" />} />
          <Route
            path="candidate-management"
            element={<CandidateManagement />}
          />
          <Route path="candidate-status" element={<CandidateStatus />} />
          <Route path="worklist" element={<Worklist />} />
        </Route>
      </Routes>
    </Router>
  );
};

export default AppRouter;
