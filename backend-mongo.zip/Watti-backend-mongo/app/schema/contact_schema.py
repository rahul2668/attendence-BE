from pydantic import BaseModel, EmailStr, Field
from typing import Optional, Any
from datetime import datetime, timezone


class ContactBase(BaseModel):
    """
    Base schema for Contact, used for shared fields.
    """
    name: str
    phone_number: Optional[str] = None
    email: Optional[EmailStr] = None
    broadcast: Optional[bool] = False
    sms: Optional[bool] = False
    attributes: Optional[Any] = None
    created_date: datetime = datetime.now(timezone.utc)# JSON-like data for attributes


class ContactCreate(ContactBase):
    """
    Schema for creating a new contact.
    """
    pass


class ContactInDataBase(ContactBase):
    """
    Schema for a contact stored in the database.
    """
    id: str = Field(..., alias="_id")
    user_id: str
    created_date: datetime
    updated_date: Optional[datetime] = None

    class Config:
        from_attributes = True


