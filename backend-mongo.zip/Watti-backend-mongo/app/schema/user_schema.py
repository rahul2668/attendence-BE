from pydantic import BaseModel, EmailStr
from typing import Optional


class UserBase(BaseModel):
    username: str
    first_name: str
    last_name: str
    email: EmailStr
    password: str
    address: str
    phone_number: str
    is_active: bool = True
    is_superuser: bool = False


class UserCreate(UserBase):
    pass

class UserAuth(BaseModel):
    identifier: str
    password: str


class UserUpdate(BaseModel):
    username: Optional[str]
    first_name: Optional[str]
    last_name: Optional[str]
    email: Optional[EmailStr]
    password: Optional[str]
    address: Optional[str]
    phone_number: Optional[str]
    is_active: Optional[bool]
    is_superuser: Optional[bool]


class UserInDataBase(UserBase):
    id: str

    class Config:
        from_attributes = True
