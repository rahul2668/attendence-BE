from pymongo import MongoClient
from app.core.config import settings

client = MongoClient(settings.MONGODB_URI)
db = client[settings.MONGODB_DB_NAME]
user_collection = db["users"]
contact_collection = db["contacts"]
attributes_collection = db["attributes"]