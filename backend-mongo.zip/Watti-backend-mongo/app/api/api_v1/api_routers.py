from fastapi import APIRouter
from app.api.api_v1.endpoints import user, authentication, contact

api_router = APIRouter()

api_router.include_router(authentication.router, tags=["Authentication"])
api_router.include_router(user.router, prefix="/user", tags=["user"])
api_router.include_router(contact.router, prefix="/contact", tags=["Contact"])
