from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.encoders import jsonable_encoder

from app.api.dependency import get_current_active_user
from app.repositories.contact_repository import contact_repository
from app.schema.contact_schema import ContactCreate

router = APIRouter()


@router.post("/create-contact")
async def create_contact(contact_data: ContactCreate, current_user: dict = Depends(get_current_active_user)):
    """
    Create a new contact.
    """
    contact_repository.create_contact(contact_data=contact_data, creator_id=current_user['_id'])
    return {"message": "Contact created successfully"}


@router.get("/get-contacts")
async def get_contacts(current_user: dict = Depends(get_current_active_user)):
    """
    Retrieve all contacts created by the authenticated user.
    """
    contacts = contact_repository.get_contacts_with_attributes(current_user['_id'])
    if not contacts:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="No contacts found")
    return jsonable_encoder(contacts)


@router.post("/update-attributes")
async def update_contact_attributes(contact_id: str, new_attributes: dict, current_user: dict = Depends(get_current_active_user)):
    contact_repository.get_contacts_with_attributes(current_user['_id'])
    return contact_repository.update_contact_attribute(contact_id, new_attributes)

