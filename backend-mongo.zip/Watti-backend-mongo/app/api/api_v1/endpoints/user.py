from typing import List
from fastapi import HTTPException, APIRouter, Depends

from app.api.dependency import get_current_active_superuser
from app.repositories.user_repository import user_repository
from app.schema.user_schema import UserCreate, UserInDataBase, UserAuth

router = APIRouter()


@router.get("/admin/get_users", response_model=List[UserInDataBase])
async def get_all_users(current_user: dict = Depends(get_current_active_superuser)):
    """
    Retrieve all active users.
    """
    users = user_repository.get_all_users()
    return users


@router.post("/register", response_model=UserInDataBase)
async def create_user(user_in: UserCreate):
    """
    Register a new user.
    """
    if user_repository.get_user_by_username(user_in.username):
        raise HTTPException(status_code=400, detail="User already exists")
    user = user_repository.create_user(user_in)
    return user
