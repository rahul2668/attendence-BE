from datetime import timedelta
from typing import Any
from fastapi import APIRouter, HTTPException, Depends
from fastapi.security import OAuth2PasswordRequestForm

from app import schema
from app.core import security
from app.core.config import settings
from app.repositories.user_repository import user_repository

router = APIRouter()


@router.post("/login/access-token", response_model=schema.Token)
def login_access_token(user_auth: OAuth2PasswordRequestForm = Depends()) -> Any:
    identifier = user_auth.username

    is_authenticated, user = user_repository.authenticate_user(identifier, user_auth.password)
    print(user.id)
    if not is_authenticated:
        raise HTTPException(status_code=401, detail="Invalid credentials")

    access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = security.create_access_token(subject=str(user.id), expire_delta=access_token_expires)

    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user": user,
    }
