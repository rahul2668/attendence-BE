from pydantic import BaseModel, EmailStr
from typing import Optional

class UserModel(BaseModel):
    id: Optional[str]
    username: str
    first_name: str
    last_name: str
    email: EmailStr
    password: str
    address: str
    phone_number: str
    is_active: bool = True
    is_superuser: bool = False

    class Setting:
        name = "users"