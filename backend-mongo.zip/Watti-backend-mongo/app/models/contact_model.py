from datetime import datetime, timezone
from pydantic import BaseModel, EmailStr
from typing import Optional, Any


class ContactModel(BaseModel):
    id: Optional[str]
    user_id: str
    name: str
    email: EmailStr
    phone_number: str
    attributes: Any
    broadcast: bool
    sms: bool

    class Settings:
        name = "contacts"