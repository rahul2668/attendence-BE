from typing import List, Any
from bson import ObjectId
from pymongo.collection import Collection

from app.core.security import get_hashed_password, verify_password
from app.db.database import user_collection
from app.models.user_model import UserModel
from app.schema.user_schema import UserInDataBase
from app.serializers.user_serializer import serialize_user, serialize_users


class UserRepository:
    def __init__(self, collection: Collection):
        self.collection = collection

    def get_user_by_username(self, username: str) -> dict:
        return self.collection.find_one({"username": username})

    def get_user_by_email(self, email: str) -> dict:
        return self.collection.find_one({"email": email})

    def get_user_by_id(self, user_id: str) -> dict:
        return self.collection.find_one({"_id": ObjectId(user_id)})

    def create_user(self, user_data: UserModel) -> UserInDataBase:
        """
        Create a new user and return the created user data.
        """
        user_data.password = get_hashed_password(user_data.password)
        user_data_dict = user_data.model_dump(exclude_unset=True)
        result = self.collection.insert_one(user_data_dict)
        user_data_dict["_id"] = result.inserted_id
        return serialize_user(user_data_dict)

    def get_all_users(self) -> List[UserInDataBase]:
        """
        Retrieve all active users.
        """
        users = list(self.collection.find({"is_active": True}))
        return serialize_users(users)

    def authenticate_user(self, identifier: str, password: str) -> Any:
        """
        Authenticate user by username or email.
        """
        user = self.get_user_by_username(identifier) or self.get_user_by_email(identifier)
        if user and verify_password(password, user["password"]):
            return True, serialize_user(user)
        return False, None


user_repository = UserRepository(user_collection)
