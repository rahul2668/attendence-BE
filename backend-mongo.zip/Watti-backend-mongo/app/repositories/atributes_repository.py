from pymongo.collection import Collection
from bson import ObjectId

from app.db.database import attributes_collection


class AttributesRepository:
    def __init__(self, collection: Collection):
        self.attributes_collection = collection

    def create_attribute(self, contact_id: ObjectId, attributes: dict) -> ObjectId:
        """
        Create a new entry for attributes metadata.
        """
        result = self.attributes_collection.insert_one({
            "contact_id": contact_id,
            "attributes": attributes
        })
        print(result)
        return result.inserted_id

    def get_attributes_by_contact_id(self, contact_id: ObjectId) -> list[dict]:
        """
        Retrieve attributes metadata for a specific contact.
        """
        try:
            result = list(self.attributes_collection.find({"contact_id": str(contact_id)}))
            if not result:
                print("No attributes found for this contact_id.")
                return []
            return [document.get("attributes", {}) for document in result]

        except Exception as e:
            print(f"Error retrieving attributes for contact_id {contact_id}: {e}")
            return []

    def update_attribute(self, contact_id: ObjectId, new_attributes: dict):
        """
        Update attributes metadata for a specific contact.
        """
        result = self.attributes_collection.find_one({"contact_id": str(contact_id)})
        if result:
            updated_attributes = {**result.get("attributes", {}), **new_attributes}
            self.attributes_collection.update_one(
                {"contact_id": str(contact_id)},
                {"$set": {"attributes": updated_attributes}}
            )
        else:
            updated_attributes = new_attributes
            self.create_attribute(contact_id=contact_id, attributes=new_attributes)
        return updated_attributes


attributes_repository = AttributesRepository(attributes_collection)
