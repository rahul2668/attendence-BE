from bson import ObjectId
from pymongo.collection import Collection

from app.db.database import contact_collection
from app.schema.contact_schema import ContactCreate
from app.repositories.atributes_repository import attributes_repository


class ContactRepository:
    def __init__(self, collection: Collection):
        self.contact_collection = collection

    def create_contact(self, contact_data: ContactCreate, creator_id: str) -> dict:
        """
        Create a new contact and store attributes in a separate collection.
        """
        attributes = contact_data.attributes
        contact_data_dict = contact_data.model_dump(exclude={"attributes"}, by_alias=True)
        contact_data_dict["user_id"] = creator_id

        result = self.contact_collection.insert_one(contact_data_dict)
        contact_data_dict["_id"] = str(result.inserted_id)

        if attributes:
            attributes_repository.create_attribute(contact_id=str(result.inserted_id), attributes=attributes)

        return contact_data_dict

    def get_contacts_with_attributes(self, contact_id: ObjectId) -> list[dict]:
        """
        Retrieve all contacts and their associated attributes using AttributeRepository.
        """
        contacts_data = list(self.contact_collection.find({'user_id': contact_id}))
        for contact in contacts_data:
            contact['_id'] = str(contact['_id'])
            contact['user_id'] = str(contact['user_id'])
            contact['attributes'] = attributes_repository.get_attributes_by_contact_id(contact["_id"])

        return contacts_data

    def update_contact_attribute(self, contact_id: ObjectId, new_attributes: dict) -> list[dict]:
        attributes_repository.update_attribute(contact_id, new_attributes)
        return self.get_contacts_with_attributes(contact_id)

contact_repository = ContactRepository(contact_collection)
