from typing import List, Optional, Union
from pydantic import AnyHttpUrl, validator
from pydantic_settings import BaseSettings
from urllib.parse import quote_plus
from dataclasses import field

class Settings(BaseSettings):
    PROJECT_NAME: str
    API_V1_STR: str = "/api/v1"
    BACKEND_CORS_ORIGINS: List[AnyHttpUrl] = field(
        default_factory=lambda: [
            "http://localhost",
            "http://localhost:8000",
            "http://localhost:3000",
            "http://127.0.0.1:8000",
            "http://127.0.0.1:5000",
        ]
    )
    MONGODB_DB_NAME: str
    MONGODB_USER: str
    MONGODB_PASSWORD: str
    MONGODB_URI: Optional[str] = None
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24
    SECRET_KEY: str

    @validator("BACKEND_CORS_ORIGINS", pre=True)
    def assemble_cors_origins(cls, value: Union[str, List[str]]) -> Union[str, List[str]]:
        if isinstance(value, str) and not value.startswith("["):
            return [i.strip() for i in value.split(",")]
        elif isinstance(value, (list, str)):
            return value
        raise ValueError(value)

    @validator("MONGODB_URI", pre=True, always=True)
    def assemble_mongodb_uri(cls, value: Optional[str], values: dict) -> str:
        if value:
            return value
        return f"mongodb+srv://{quote_plus(values.get('MONGODB_USER'))}:{quote_plus(values.get('MONGODB_PASSWORD'))}@wattipoc.h6s7p.mongodb.net/?retryWrites=true&w=majority&appName=WattiPOC"

    class Config:
        env_file = ".env"
        case_sensitive = True

settings = Settings()
