from typing import List
from app.schema.user_schema import UserInDataBase

def serialize_user(user_data: dict) -> UserInDataBase:
    """
    Serialize a single user record into the UserInDataBase schema.
    """
    return UserInDataBase(
        id=str(user_data["_id"]),  # Convert MongoDB ObjectId to string
        username=user_data["username"],
        first_name=user_data["first_name"],
        last_name=user_data["last_name"],
        email=user_data["email"],
        password=user_data["password"],  # Be cautious; omit if sensitive
        address=user_data["address"],
        phone_number=user_data["phone_number"],
        is_active=user_data["is_active"],
        is_superuser=user_data["is_superuser"],
    )


def serialize_users(users: List[dict]) -> List[UserInDataBase]:
    """
    Serialize a list of user records into a list of UserInDataBase schemas.
    """
    return [serialize_user(user) for user in users]
