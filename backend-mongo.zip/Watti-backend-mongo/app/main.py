from fastapi import FastAPI

from app.api.api_v1.api_routers import api_router
from app.core.config import settings

app = FastAPI(title=settings.PROJECT_NAME, version=settings.API_V1_STR)

app.include_router(api_router, prefix=settings.API_V1_STR)
