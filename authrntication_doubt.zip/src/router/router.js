import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { CssBaseline } from "@mui/material";
import { Navigate } from "react-router-dom";
import { useSelector } from "react-redux";

import Login from "../components/Login";
import Config from "../components/Config";
import Sidebars from "../components/Sidebar";
import Topbar from "../components/Topbar";
import Run from "../components/Run";
import Footer from "../components/Footer";

function RouterPaths() {
	const { user: currentUser } = useSelector((state) => state.auth);
	return (
		<Router>
			{currentUser ? (
				<>
					<CssBaseline />
					<div className="app">
						<Sidebars />
						<main className="content">
							<Topbar />
							<Routes>
								<Route
									path="/"
									element={<Navigate to="/config" />}
								/>
								<Route path="/config" element={<Config />} />
								<Route path="/run" element={<Run />} />
							</Routes>
							<Footer />
						</main>
					</div>
				</>
			) : (
				<Routes>
					<Route path="/login" element={<Login />} />
					<Route path="/" element={<Navigate to="/login" />} />
					<Route path="/config" element={<Navigate to="/login" />} />
					<Route path="/run" element={<Navigate to="/login" />} />
				</Routes>
			)}
		</Router>
	);
}
export default RouterPaths;
