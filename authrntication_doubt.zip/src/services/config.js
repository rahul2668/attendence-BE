import axios from "axios";
import authHeader from "./auth-header";
// const API_URL = "http://127.0.0.1:8000/tool/";
const BASE_URL = process.env.REACT_APP_BASE_URL;
const API_URL = BASE_URL + "tool/";

const createConfig = (data) => {
	return axios.post(API_URL + "config/create", data, {
		headers: authHeader(),
	});
};
const getConfigs = () => {
	return axios.get(API_URL + "config/list", { headers: authHeader() });
};

const getConfigFromTableName = (table_name) => {
	let obj = {
		table_name: table_name,
	};
	return axios.post(API_URL + "config/data", obj, { headers: authHeader() });
};

const configServices = {
	createConfig,
	getConfigs,
	getConfigFromTableName,
};

export default configServices;
