import axios from "axios";
// const API_URL = "http://127.0.0.1:8000/tool/";
const BASE_URL = process.env.REACT_APP_BASE_URL;
const API_URL = BASE_URL + "tool/";

const register = (username, email, password) => {
	return axios.post(API_URL + "create", {
		username,
		email,
		password,
	});
};

const login = (username, password) => {
	let obj = {
		username: username,
		password: password,
	};
	return axios.post(API_URL + "login", obj).then((response) => {
		if (response.data.access) {
			localStorage.setItem("user", JSON.stringify(response.data));
		}

		return response.data;
	});
};

const logout = () => {
	localStorage.removeItem("user");
};

export default {
	register,
	login,
	logout,
};
