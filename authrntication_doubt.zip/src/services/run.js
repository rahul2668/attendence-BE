import axios from "axios";
import authHeader from "./auth-header";
const BASE_URL = process.env.REACT_APP_BASE_URL;
const API_URL = BASE_URL + "tool/";

const runConfigPost = () => {
	return axios.post(
		API_URL + "config/run",
		{
			job_id: 492855501020397,
			notebook_params: {
				myinput: "Hello vamsi",
				myinput2: "Hello shiva",
			},
		},
		{ headers: authHeader() }
	);
};

const runConfigPostRunID = (data) => {
	return axios.post(
		API_URL + "config/run/run-id",
		{
			run_id: data,
		},
		{ headers: authHeader() }
	);
};

const runServices = {
	runConfigPost,
	runConfigPostRunID,
};

export default runServices;
