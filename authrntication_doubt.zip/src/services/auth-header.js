export default function authHeader() {
	const user = JSON.parse(localStorage.getItem("user"));
	if (user.username && user.access) {
		return { Authorization: "Bearer " + user.access };
	} else {
		return {};
	}
}
