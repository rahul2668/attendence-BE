import {
	RETRIEVED_CONFIGS_SUCCESS,
	RETRIEVED_CONFIGS_FAIL,
	RETRIEVED_TABLE_DATA_SUCCESS,
	RETRIEVED_TABLE_DATA_FAIL,
	CREATED_CONFIG_SUCCESS,
	CREATED_CONFIG_FAIL,
	LOGOUT,
} from "../actions/types";

const initialState = {
	configs: [],
	tableData: null,
};

export default function configReducer(state = initialState, action) {
	const { type, payload } = action;
	switch (type) {
		case RETRIEVED_CONFIGS_SUCCESS:
			return {
				...state,
				configs: payload.configs,
			};
		case RETRIEVED_CONFIGS_FAIL:
			return {
				...state,
				configs: [],
			};
		case RETRIEVED_TABLE_DATA_SUCCESS:
			return {
				...state,
				tableData: payload.tableData,
			};
		case RETRIEVED_TABLE_DATA_FAIL:
			return {
				...state,
				tableData: null,
			};

		case CREATED_CONFIG_SUCCESS:
			return {
				...state,
			};
		case LOGOUT:
			return {
				...state,
				configs: [],
				tableData: null,
			};
		default:
			return state;
	}
}
