import { combineReducers } from "redux";
import auth from "./auth";
import configReducer from "./config";
import runReducer from "./run";
import message from "./message";

const appReducer = combineReducers({
	auth,
	configReducer,
	runReducer,
	message,
});

const rootReducer = (state, action) => {
	if (action.type === "LOGOUT") {
		return appReducer(undefined, action);
	}

	return appReducer(state, action);
};

export default rootReducer;
