import {
	RETRIEVED_RESPONSE_FAIL,
	RETRIEVED_RESPONSE_SUCCESS,
	CLEAR_RESPONSE,
	LOGOUT,
} from "../actions/types";

const initialState = {
	response: null,
};

export default function runReducer(state = initialState, action) {
	const { type, payload } = action;
	switch (type) {
		case RETRIEVED_RESPONSE_SUCCESS:
			return {
				...state,
				response: payload.response,
			};
		case RETRIEVED_RESPONSE_FAIL:
			return {
				...state,
				response: null,
			};
		case CLEAR_RESPONSE:
			return {
				...state,
				response: null,
			};
		case LOGOUT:
			return {
				...state,
				response: null,
			};
		default:
			return state;
	}
}
