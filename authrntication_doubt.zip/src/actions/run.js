import runServices from "../services/run";
import { RETRIEVED_RESPONSE_SUCCESS } from "./types";

export const applyRun = () => (dispatch) => {
	return runServices.runConfigPost().then((response) => {
		dispatch(postRun(response.data["run_id"]));
		return Promise.resolve();
	});
};

export const postRun = (data) => (dispatch) => {
	return runServices.runConfigPostRunID(data).then((response) => {
		dispatch({
			type: RETRIEVED_RESPONSE_SUCCESS,
			payload: { response: response.data },
		});
		if (response.data.error) {
			console.log("*************post run response ***********", response);
		}
	});
};
