import {
	RETRIEVED_CONFIGS_FAIL,
	RETRIEVED_CONFIGS_SUCCESS,
	RETRIEVED_TABLE_DATA_SUCCESS,
	RETRIEVED_TABLE_DATA_FAIL,
	CREATED_CONFIG_SUCCESS,
	CREATED_CONFIG_FAIL,
	SET_MESSAGE,
} from "./types";
import configServices from "../services/config";
import { logout } from "./auth";

export const createConfig = (data) => (dispatch) => {
	return configServices.createConfig(data).then(
		() => {
			dispatch({
				type: CREATED_CONFIG_SUCCESS,
			});
			return Promise.resolve();
		},
		(error) => {
			const message =
				(error.response &&
					error.response.data &&
					error.response.data.message) ||
				error.message ||
				error.toString();

			dispatch({
				type: CREATED_CONFIG_FAIL,
			});

			dispatch({
				type: SET_MESSAGE,
				payload: message,
			});

			return Promise.reject();
		}
	);
};
export const getConfigs = () => (dispatch) => {
	return configServices.getConfigs().then(
		(data) => {
			dispatch({
				type: RETRIEVED_CONFIGS_SUCCESS,
				payload: { configs: data.data },
			});
			return Promise.resolve();
		},
		(error) => {
			const message =
				(error.response &&
					error.response.data &&
					error.response.data.message) ||
				error.message ||
				error.toString();
			if (error.response.status === 401) {
				dispatch(logout());
				window.location.reload();
			}
			dispatch({
				type: RETRIEVED_CONFIGS_FAIL,
			});

			dispatch({
				type: SET_MESSAGE,
				payload: message,
			});
			// return message;
			return Promise.reject();
		}
	);
};

export const getConfigData = (table_name) => (dispatch) => {
	return configServices.getConfigFromTableName(table_name).then(
		(data) => {
			dispatch({
				type: RETRIEVED_TABLE_DATA_SUCCESS,
				payload: { tableData: data.data },
			});
			return Promise.resolve();
		},
		(error) => {
			const message =
				(error.response &&
					error.response.data &&
					error.response.data.message) ||
				error.message ||
				error.toString();
			if (error.response.status === 401) {
				dispatch(logout());
				window.location.reload();
			}
			dispatch({
				type: RETRIEVED_TABLE_DATA_FAIL,
			});

			dispatch({
				type: SET_MESSAGE,
				payload: message,
			});
			return Promise.reject();
		}
	);
};

export const clearData = () => ({ type: RETRIEVED_TABLE_DATA_FAIL });
