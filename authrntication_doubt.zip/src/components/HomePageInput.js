import React, { forwardRef } from "react";
import { Input, InputProps, inputClasses } from "@mui/base/Input";
import { styled } from "@mui/system";

const CustomInput = React.forwardRef(function CustomInput(props, ref) {
	const { slots, ...other } = props;
	return (
		<div style={{ display: "flex", alignItems: "baseline" }}>
			<div style={{ marginRight: "10px", width: "150px" }}>
				<span
					style={{
						fontWeight: "600",
					}}
				>
					{props.placeholder}
				</span>
				<span
					style={{
						color: "red",
						marginLeft: "5px",
					}}
				>
					*
				</span>
			</div>
			<Input
				slots={{
					root: StyledInputRoot,
					input: StyledInputElement,
					...slots,
				}}
				{...other}
				ref={ref}
				readOnly={props.readOnly}
				value={props.value}
			/>
		</div>
	);
});

const StyledInputRoot = styled("div")(
	({ theme }) => `
	font-family: IBM Plex Sans, sans-serif;
	font-weight: 400;
	width:250px;
    height:40px;
	color: none;
	margin-bottom: 10px;
	background: '#fff';
	border: 1px solid #DDDDDD;
	display: flex;
	align-items: center;
	justify-content: center;
  
  
	&.${inputClasses.focused} {
	  border-color: none;
	}
  
	&:hover {
	  border-color: none;
	}
  
	// firefox
	&:focus-visible {
	  outline: 0;
	}
  `
);

const StyledInputElement = styled("input")(
	({ theme }) => `
	font-size: 0.875rem;
	font-family: inherit;
	font-weight: 400;
	width:210px;
	line-height: 1.5;
	flex-grow: 1;
    padding-left:10px;
	color: none;
	background: inherit;
	border: none;
	border-radius: inherit;
	outline: 0;
  `
);

export { CustomInput };
