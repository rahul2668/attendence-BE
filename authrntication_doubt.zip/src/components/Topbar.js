import { useCallback } from "react";
import { Box, useTheme } from "@mui/material";
import { logout } from "../actions/auth";

import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";

const Topbar = () => {
	const theme = useTheme();

	let navigate = useNavigate();
	const dispatch = useDispatch();
	const logOut = useCallback(() => {
		dispatch(logout());
		navigate("/");
		window.location.reload();
	}, [dispatch]);
	const { user } = useSelector((state) => state.auth);
	return (
		<Box
			display="flex"
			justifyContent="space-between"
			p={2}
			sx={{
				border: "1px solid transaparent",
				backgroundColor: "#ffffff",
				height: "8vh",
				borderBottom: "1px solid #f3f4f4",
			}}
		>
			{/* Search Bar */}
			<Box
				component="img"
				sx={{
					ml: 6.5,
				}}
				alt="The house from the offer."
				src={require(`../static/main_logo.png`)}
			/>
			{/* Icons */}
			{user ? <Box display="flex">{user.user}</Box> : null}
		</Box>
	);
};

export default Topbar;
