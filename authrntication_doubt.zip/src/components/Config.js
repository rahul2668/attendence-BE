import React, { useMemo, useState, useEffect } from "react";

import { styled } from "@mui/material/styles";
import MuiGrid from "@mui/material/Grid";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";

import MaterialReactTable from "material-react-table";
import { getConfigs } from "../actions/config";
import { useDispatch, connect, useSelector } from "react-redux";

import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";

import CreateModal from "./CreateConfigModal";
import LoadingIndicator from "./LoadingIndicator";

import Swal from "sweetalert2";
import { useNavigate } from "react-router-dom";
import { logout } from "../actions/auth";

const Grid = styled(MuiGrid)(({ theme }) => ({
	width: "100%",
	...theme.typography.body2,
	'& [role="separator"]': {
		margin: theme.spacing(0, 2),
	},
}));

function Config(props) {
	const rows = props.config.configs;
	const dispatch = useDispatch();
	const [isLoadingData, setIsLoadingData] = useState(false);
	useEffect(() => {
		if (rows.length === 0) {
			setIsLoadingData(true);
			dispatch(getConfigs());
			setTimeout(() => {
				setIsLoadingData(false);
			}, 2000);
		}
	}, []);

	const [showModal, setShowModal] = useState(false);
	const handleModalClose = () => {
		setShowModal(false);
	};
	const handleOpen = () => {
		setShowModal(true);
	};

	const columns = useMemo(
		() => [
			{
				accessorKey: "target_table_name",
				header: "Target Table Name",
				size: 150,
			},
			{
				accessorKey: "source_table_name",
				header: "Source Table Name",
				size: 150,
			},
			{
				accessorKey: "key_columns",
				header: "Key Columns",
				size: 150,
			},
			{
				accessorKey: "incremental_fields",
				header: "Incremental Fields",
				size: 200,
			},
			{
				accessorKey: "exclude_columns",
				header: "Exclude Columns",
				size: 150,
			},
			{
				accessorKey: "created_by_user",
				header: "Created By",
				size: 150,
			},
		],
		[]
	);
	let navigate = useNavigate();
	const { isLoggedIn } = useSelector((state) => state.auth);
	if (!isLoggedIn) {
		// Swal.fire({
		// 	title: "Session Timed Out",
		// 	text: "Click on Ok to Log Out",
		// 	icon: "warning",
		// 	confirmButtonColor: "#3085d6",
		// 	confirmButtonText: "Ok!",
		// }).then((result) => {
		// 	if (result.isConfirmed) {
		// 		navigate("/");
		// 	}
		// });
	}

	return (
		<div
			style={{
				marginLeft: "60px",
				height: "84vh",
				background: "#ffffff",
				overflow: "auto",
			}}
		>
			{isLoadingData ? (
				<LoadingIndicator size={24} />
			) : (
				<div>
					<div
						style={{
							borderBottom: "1px solid #f3f4f4",
						}}
					>
						<Grid
							container
							sx={{
								p: 1,
							}}
						>
							<Grid
								item
								xs={6}
								md={6}
								sx={{
									display: "flex",
									justifyContent: "left",
									alignItems: "center",
									textAlign: "center",
								}}
							>
								<Typography
									color="Black"
									sx={{
										fontFamily: "Open Sans",
										fontSize: "20px",
										fontWeight: "700",
									}}
								>
									CONFIG
								</Typography>
							</Grid>
							<Grid
								item
								xs={6}
								md={6}
								sx={{
									display: "flex",
									justifyContent: "right",
									alignItems: "center",
								}}
							>
								<Button
									variant="outlined"
									onClick={(e) => handleOpen()}
									sx={{
										fontFamily: "Open Sans",
										fontWeight: "700",
										color: "#33bbed",
										border: "1px solid #33bbed",
										mr: 2,
									}}
								>
									Create Config
								</Button>
								<CreateModal
									showModal={showModal}
									setShowModal={setShowModal}
									handleModalClose={handleModalClose}
								/>
								<Button
									variant="outlined"
									// onClick={(e) => handleOpen()}
									sx={{
										fontFamily: "Open Sans",
										fontWeight: "700",
										color: "#33bbed",
										border: "1px solid #33bbed",
									}}
									disabled={true}
								>
									Upload File
								</Button>
							</Grid>
						</Grid>
					</div>
					<Box>
						<Paper
							elevation={3}
							sx={{
								m: 2,
								height: "100%",
							}}
						>
							<MaterialReactTable
								columns={columns}
								data={rows}
								enableColumnActions={false}
								muiTableContainerProps={{
									sx: {
										minHeight: "300px",
									},
								}}
								// state={{
								// 	isLoading: isLoadingData,
								// }}
							/>
						</Paper>
					</Box>
				</div>
			)}
		</div>
	);
}

function mapStateToProps(state) {
	return { config: state.configReducer };
}

export default connect(mapStateToProps)(Config);
