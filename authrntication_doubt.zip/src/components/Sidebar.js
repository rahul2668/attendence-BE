import { useState, useCallback } from "react";
import "../styles/sidebar.css";
import { Sidebar, Menu, MenuItem } from "react-pro-sidebar";
import { Link } from "react-router-dom";
import { Box, ListItemIcon } from "@mui/material";
import SettingsIcon from "@mui/icons-material/Settings";
import PlayCircleOutlineIcon from "@mui/icons-material/PlayCircleOutline";
import LogoutIcon from "@mui/icons-material/Logout";
import DensityMediumIcon from "@mui/icons-material/DensityMedium";
import CloseIcon from "@mui/icons-material/Close";

import ListItem from "@mui/material/ListItem";
import ListItemText from "@mui/material/ListItemText";

import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { logout } from "../actions/auth";

import Tooltip from "@mui/material/Tooltip";
import Fade from "@mui/material/Fade";

function Sidebars() {
	const dispatch = useDispatch();
	const [collapsed, setCollapsed] = useState(true);

	const [toggled, setToggled] = useState(false);

	const handleCollapsedChange = () => {
		if (!collapsed) {
			setCollapsed(collapsed);
		}
		setCollapsed(!collapsed);
	};
	const handleMenuCollapsedChange = () => {
		if (!collapsed) {
			setCollapsed(collapsed);
		}
		setCollapsed(!collapsed);
	};
	const handleToggleSidebar = (value) => {
		setToggled(value);
	};
	let navigate = useNavigate();

	const logOut = useCallback(() => {
		dispatch(logout());
		navigate("/");
	}, [dispatch]);

	return (
		<div>
			<Sidebar
				backgroundColor="#013579"
				style={{
					height: "100%",
					position: "absolute",
					borderRight: "None",
				}}
				collapsed={collapsed}
				toggled={toggled}
				// handleToggleSidebar={handleToggleSidebar}
				// handleCollapsedChange={handleCollapsedChange}
				collapsedWidth="60px"
				width="220px"
			>
				<main>
					<Menu
						renderMenuItemStyles={() => ({
							".menu-anchor": {
								backgroundColor: "#013579",
								"&:hover": {
									backgroundColor: "#013579",
								},
							},
						})}
					>
						{collapsed ? (
							<MenuItem
								icon={<DensityMediumIcon />}
								onClick={handleMenuCollapsedChange}
								style={{
									color: "white",
									justifyContent: "center",
								}}
							></MenuItem>
						) : (
							<MenuItem
								suffix={<CloseIcon />}
								onClick={handleMenuCollapsedChange}
								style={{
									color: "white",
								}}
							>
								<Box
									component="img"
									src={require(`../static/sidebar_logo.png`)}
								/>
							</MenuItem>
						)}
						<hr />
						<Box>
							<ListItem component={Link} to={"/config"}>
								<Tooltip
									title="Config"
									arrow
									placement="right"
									TransitionComponent={Fade}
									TransitionProps={{ timeout: 600 }}
								>
									<ListItemIcon
										sx={{
											minWidth: "10px",
											marginRight: "15px",
										}}
									>
										<SettingsIcon
											style={{
												color: "#ffffff",
												fontSize: 22,
												width: "20px",
											}}
										/>
									</ListItemIcon>
								</Tooltip>

								<ListItemText
									onClick={handleCollapsedChange}
									sx={{
										flex: "None",
										paddingLeft: "10px",
										width: "100%",
									}}
									primaryTypographyProps={{
										fontFamily: "poppins",
										color: "white",
									}}
									primary="Config"
								/>
							</ListItem>
							<ListItem component={Link} to={"/run"}>
								<Tooltip
									title="Run"
									arrow
									placement="right"
									TransitionComponent={Fade}
									TransitionProps={{ timeout: 600 }}
								>
									<ListItemIcon
										sx={{
											minWidth: "10px",
											marginRight: "15px",
										}}
									>
										<PlayCircleOutlineIcon
											style={{
												color: "#ffffff",
												fontSize: 22,
											}}
										/>
									</ListItemIcon>
								</Tooltip>

								<ListItemText
									onClick={handleCollapsedChange}
									sx={{
										flex: "None",
										paddingLeft: "10px",
										width: "100%",
									}}
									primaryTypographyProps={{
										fontFamily: "poppins",
										color: "white",
									}}
									primary="Run"
								/>
							</ListItem>
							<ListItem>
								<Tooltip
									title="Log Out"
									arrow
									placement="right"
									TransitionComponent={Fade}
									TransitionProps={{ timeout: 600 }}
								>
									<ListItemIcon
										onClick={logOut}
										sx={{
											minWidth: "10px",
											marginRight: "15px",
										}}
									>
										<LogoutIcon
											style={{
												color: "#ffffff",
												fontSize: 22,
												cursor: "pointer",
											}}
										/>
									</ListItemIcon>
								</Tooltip>

								<ListItemText
									onClick={logOut}
									sx={{
										flex: "None",
										paddingLeft: "10px",
									}}
									primaryTypographyProps={{
										fontFamily: "poppins",
										color: "white",
									}}
									primary="Logout"
								/>
							</ListItem>
						</Box>
					</Menu>
				</main>
			</Sidebar>
		</div>
	);
}
export default Sidebars;
