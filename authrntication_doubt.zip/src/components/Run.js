import React, { useState } from "react";
import OutlinedInput from "@mui/material/OutlinedInput";
import MenuItem from "@mui/material/MenuItem";
import Select from "@mui/material/Select";

import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormControl from "@mui/material/FormControl";
import FormLabel from "@mui/material/FormLabel";

import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";

import dayjs from "dayjs";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DateTimePicker } from "@mui/x-date-pickers/DateTimePicker";
import { renderTimeViewClock } from "@mui/x-date-pickers/timeViewRenderers";
import TextField from "@mui/material/TextField";

import { CustomInput } from "./HomePageInput";
import LoadingIndicator from "./LoadingIndicator";
import { useDispatch, connect } from "react-redux";

import { getConfigData } from "../actions/config";
import { applyRun, postRun } from "../actions/run";

import JsonView from "react18-json-view";
import "react18-json-view/src/style.css";

import Divider from "@mui/material/Divider";
import { styled } from "@mui/material/styles";
import MuiGrid from "@mui/material/Grid";
import { CLEAR_RESPONSE } from "../actions/types";

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
	PaperProps: {
		style: {
			maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
			width: 250,
		},
	},
};

const Grid = styled(MuiGrid)(({ theme }) => ({
	width: "100%",
	...theme.typography.body2,
	'& [role="separator"]': {
		margin: theme.spacing(0, 2),
	},
}));

function Run(props) {
	const [showDatePicker, setShowDatePicker] = useState(false);
	const [radioButtonValue, setRadioButtonValue] = useState("");
	const [disabled, setDisabled] = useState(true);
	const [loading, setLoading] = useState(false);
	const [date, setDate] = useState({
		date: "",
	});
	const [sourceFilePath, setSourceFilePath] = useState("");
	const [selectedTable, setSelectedTable] = useState("");
	const handleRadioButtonChange = (event) => {
		setDisabled(true);
		if (event.target.value == "full") {
			setShowDatePicker(false);
			setRadioButtonValue(event.target.value);
			if (selectedTable) {
				setDisabled(false);
			}
		} else {
			setShowDatePicker(true);
			setRadioButtonValue(event.target.value);
		}
	};

	const dispatch = useDispatch();
	const handleSourceFilePath = (event) => {
		const {
			target: { value },
		} = event;
		setSourceFilePath(value);
	};
	const handleChange = (event) => {
		setLoading(true);
		const {
			target: { value },
		} = event;
		dispatch({
			type: CLEAR_RESPONSE,
		});
		dispatch(getConfigData(value));
		setSelectedTable(value);
		if (radioButtonValue) {
			setDisabled(false);
		}
		setTimeout(() => {
			setLoading(false);
		}, 2000);
		// setLoading(false);
	};

	const handleClear = () => {
		setSelectedTable("");
		setRadioButtonValue("");
		setShowDatePicker(false);
		dispatch({
			type: CLEAR_RESPONSE,
		});
	};

	const handleChangeDatePicker = (e, t) => {
		if (t === "date") {
			setDate((prevState) => ({
				...prevState,
				[t]: dayjs(new Date(e.$d)).format("YYYY-MM-DD HH:mm"),
			}));
		}
		if (selectedTable.table_name !== null) {
			setDisabled(false);
		}
	};

	const handleRun = () => {
		dispatch(applyRun());
	};

	const handleReRun = () => {
		dispatch({
			type: CLEAR_RESPONSE,
		});
		dispatch(postRun(props.json_response.response.metadata.run_id));
	};
	return (
		<div
			style={{
				marginLeft: "60px",
				height: "84vh",
				overflowY: "auto",
				background: "#ffffff",
				paddingLeft: "10px",
				padding: "10px",
			}}
		>
			<div style={{ display: "flex", alignItems: "baseline" }}>
				<Typography sx={{ mr: 2, fontWeight: "600" }}>
					Table Name
				</Typography>
				<FormControl sx={{ m: 1, width: 300, mt: 3 }}>
					<Select
						sx={{
							marginLeft: "64px",
							height: "40px",
							borderRadius: "none",
							minWidth: "250px",
						}}
						displayEmpty
						value={selectedTable}
						onChange={handleChange}
						input={<OutlinedInput />}
						renderValue={(selected) => {
							if (selected.length === 0) {
								return <em>Placeholder</em>;
							}

							return selected;
						}}
						MenuProps={MenuProps}
						inputProps={{ "aria-label": "Without label" }}
					>
						<MenuItem disabled value="">
							<em>select table name</em>
						</MenuItem>
						{props.config.configs.map((name) => (
							<MenuItem
								key={name.target_table_name}
								value={name.target_table_name}
							>
								{name.target_table_name}
							</MenuItem>
						))}
					</Select>
				</FormControl>
				{loading ? <LoadingIndicator size={24} /> : null}

				<Button
					onClick={handleClear}
					variant="contained"
					disableElevation
					sx={{
						marginLeft: "35px",
					}}
				>
					Clear
				</Button>
			</div>
			<div style={{ marginTop: "5px" }}>
				<CustomInput
					placeholder="Source Table Name"
					value={
						selectedTable && props.config.tableData !== null
							? props.config.tableData.source_table_name
							: ""
					}
					readOnly={true}
				/>
				<CustomInput
					placeholder="Key Column Name"
					value={
						selectedTable && props.config.tableData !== null
							? props.config.tableData.key_columns
							: ""
					}
					readOnly={true}
				/>
				<CustomInput
					placeholder="Excluded Columns List"
					value={
						selectedTable && props.config.tableData !== null
							? props.config.tableData.exclude_columns
							: ""
					}
					readOnly={true}
				/>
				<CustomInput
					placeholder="Increment Field"
					value={
						selectedTable && props.config.tableData
							? props.config.tableData.incremental_fields
							: ""
					}
					readOnly={true}
				/>
				<CustomInput
					placeholder="Source File Path"
					value={sourceFilePath}
					onChange={handleSourceFilePath}
				/>
			</div>
			<div style={{ marginTop: "20px" }}>
				<FormControl>
					<FormLabel id="demo-row-radio-buttons-group-label">
						Select Type
					</FormLabel>
					<RadioGroup
						row
						aria-labelledby="demo-row-radio-buttons-group-label"
						name="row-radio-buttons-group"
					>
						<FormControlLabel
							value="full"
							control={<Radio />}
							checked={radioButtonValue === "full"}
							label="Full"
							onChange={handleRadioButtonChange}
						/>
						<FormControlLabel
							value="incremental"
							control={<Radio />}
							checked={radioButtonValue === "incremental"}
							label="Incremental"
							onChange={handleRadioButtonChange}
						/>
					</RadioGroup>
				</FormControl>
			</div>
			{showDatePicker ? (
				<div style={{ marginTop: "20px" }}>
					<Typography sx={{ mr: 2, fontWeight: "600", mb: 1 }}>
						Select Date
					</Typography>
					<LocalizationProvider dateAdapter={AdapterDayjs}>
						<DateTimePicker
							label="Selected Date"
							id="next_followup_date"
							format="YYYY-MM-DD: HH:mm"
							ampm={false}
							onChange={(e) => handleChangeDatePicker(e, "date")}
							viewRenderers={{
								hours: renderTimeViewClock,
								minutes: renderTimeViewClock,
								seconds: renderTimeViewClock,
							}}
							renderInput={(params) => <TextField {...params} />}
						/>
					</LocalizationProvider>
				</div>
			) : null}

			<div
				style={{
					marginTop: "10px",
					marginLeft: "20px",
				}}
			>
				<Button
					variant="contained"
					disableElevation
					disabled={disabled}
					onClick={handleRun}
				>
					Run
				</Button>
			</div>
			{props.json_response.response !== null ? (
				<div
					style={{
						display: "flex",
						padding: "10px",
					}}
				>
					<Grid
						container
						sx={{
							mt: 3,
						}}
					>
						<Grid item xs={12}>
							<Typography
								color="Black"
								sx={{
									fontFamily: "Open Sans",
									fontSize: "15px",
									fontWeight: "500",
								}}
							>
								Response
							</Typography>
						</Grid>
						<Grid item xs={4}>
							<div
								style={{
									marginTop: "10px",
									height: "300px",
									overflowY: "auto",
									backgroundColor: "#f3f4f4",
								}}
							>
								<JsonView
									src={props.json_response.response}
									dark={true}
									collapseObjectsAfterLength={4}
								/>
							</div>
						</Grid>
						<Divider orientation="vertical" flexItem></Divider>
						<Grid item xs={6}>
							<div
								style={{
									marginTop: "10px",
									marginLeft: "60px",
								}}
							>
								<Button
									variant="contained"
									disableElevation
									onClick={handleReRun}
									color="success"
								>
									Re Check Status
								</Button>
							</div>
						</Grid>
					</Grid>
				</div>
			) : null}
		</div>
	);
}

function mapStateToProps(state) {
	return { config: state.configReducer, json_response: state.runReducer };
}

export default connect(mapStateToProps)(Run);
