import React, { useState } from "react";
import "../styles/login.css";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Card from "@mui/material/Card";
import Grid from "@mui/material/Unstable_Grid2";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import { CustomInput, InputAdornment } from "./CustomInput";
import PersonIcon from "@mui/icons-material/Person";
import HttpsIcon from "@mui/icons-material/Https";
import { Navigate, useNavigate } from "react-router-dom";
import { useDispatch, useSelector, connect } from "react-redux";

import { login } from "../actions/auth.js";
import { clearMessage } from "../actions/message";

import LoadingIndicator from "./LoadingIndicator";

function Login(props) {
	const [credentials, setCredentials] = useState({
		username: "",
		password: "",
	});

	const [isLoading, setIsLoading] = useState(false);
	const handleChange = (e) => {
		dispatch(clearMessage());
		const { id, value } = e.target;
		setCredentials((prevState) => ({
			...prevState,
			[id]: value,
		}));
	};

	const dispatch = useDispatch();
	let navigate = useNavigate();

	const handleLogin = (e) => {
		e.preventDefault();
		dispatch(login(credentials.username, credentials.password))
			.then(() => {
				navigate("/config");
			})
			.catch(function (error) {
				console.log("***Login error", error);
			});
	};
	const { isLoggedIn } = useSelector((state) => state.auth);
	if (isLoggedIn) {
		return <Navigate to="/config" />;
	}
	return (
		<div className="login-main">
			<Card sx={{ width: 700, height: 400 }}>
				<CardContent
					sx={{ height: "100%", p: 0, "&:last-child": { pb: 0 } }}
				>
					<Grid container spacing={0} sx={{ height: "100%" }}>
						<Grid
							xs={6}
							md={6}
							sx={{
								background:
									"linear-gradient(180deg, rgba(0,84,192,1) 8%, rgba(19,95,203,1) 33%, rgba(1,92,217,1) 71%, rgba(11,73,163,1) 86%)",
								// backgroundImage:
								// 	"url('../static/picture-1.png')",
							}}
						>
							<Box
								component="img"
								sx={{
									mt: 3,
									ml: 5,
								}}
								alt="The house from the offer."
								src={require(`../static/bilvantis-logo-white.png`)}
							/>
							{/* <Box
								component="img"
								sx={{
									mt: 3,
									ml: 5,
								}}
								alt="The house from the offer."
								src={require(`../static/bilvantis-logo-white.png`)}
							/>
							<Box
								component="img"
								sx={{
									ml: 1.5,
								}}
								alt="The house from the offer."
								src={require(`../static/picture-2.png`)}
							/> */}
						</Grid>
						<Grid xs={6} md={6}>
							<Box
								sx={{
									mt: 3,
									ml: 5,
									mb: 5,
									display: "flex",
								}}
							>
								<Typography
									sx={{
										fontFamily: '"Open Sans", "sans-serif"',
										fontSize: "30px",
										fontWeight: "600",
										color: "#044196",
										spacing: 0,
										mr: 1,
									}}
								>
									Log
								</Typography>
								<Typography
									sx={{
										fontFamily: '"Open Sans", "sans-serif"',
										fontSize: "30px",
										fontWeight: "600",
										color: "#01ABE8",
										spacing: 0,
									}}
								>
									In
								</Typography>
							</Box>
							<Box
								sx={{
									ml: 5,
								}}
							>
								<Typography
									color="Black"
									sx={{
										fontFamily: '"Open Sans", "sans-serif"',
										fontSize: "15px",
										fontWeight: "600",
										spacing: 0,
										mr: 1,
									}}
								>
									Welcome Back!
								</Typography>
								<Typography
									color="Black"
									sx={{
										fontFamily: '"Open Sans", "sans-serif"',
										fontSize: "15px",
										fontWeight: "400",
										spacing: 0,
									}}
								>
									Login by giving below credentials
								</Typography>
							</Box>
							<Box
								sx={{
									display: "flex",
									flexDirection: { xs: "column", sm: "row" },
									gap: 2,
									ml: 5,
									mt: 2,
								}}
							>
								<CustomInput
									id="username"
									placeholder="User Name"
									onChange={handleChange}
									startAdornment={
										<InputAdornment>
											<div
												style={{
													borderRight: "1px solid",
													paddingRight: "10px",
												}}
											>
												<PersonIcon />
											</div>
										</InputAdornment>
									}
								/>
							</Box>
							<Box
								sx={{
									display: "flex",
									flexDirection: { xs: "column", sm: "row" },
									gap: 2,
									ml: 5,
									mt: 2,
								}}
							>
								<CustomInput
									id="password"
									onChange={handleChange}
									placeholder="Password"
									type="password"
									startAdornment={
										<InputAdornment>
											<div
												style={{
													borderRight: "1px solid",
													paddingRight: "10px",
												}}
											>
												<HttpsIcon />
											</div>
										</InputAdornment>
									}
								/>
							</Box>
							<Box
								sx={{
									display: "flex",
									flexDirection: { xs: "column", sm: "row" },
									gap: 2,
									ml: 5,
									mt: 2,
								}}
							>
								<Button
									variant="contained"
									sx={{
										width: 220,
										borderRadius: "8px",
										ml: 2,
										p: 1.3,
									}}
									onClick={handleLogin}
								>
									<span className="font">Login</span>
								</Button>
							</Box>
							{props.message ? (
								<Box
									sx={{
										display: "flex",
										flexDirection: {
											xs: "column",
											sm: "row",
										},
										gap: 2,
										ml: 5,
										mt: 2,
									}}
								>
									<Typography
										color="red"
										sx={{
											fontFamily:
												'"Open Sans", "sans-serif"',
											fontSize: "12px",
											fontWeight: "400",
											spacing: 0,
										}}
									>
										{props.message}
									</Typography>
								</Box>
							) : null}
						</Grid>
					</Grid>
				</CardContent>
			</Card>
			{isLoading ? <LoadingIndicator size={24} /> : null}
		</div>
	);
}
function mapStateToProps(state) {
	return { message: state.message.message, user: state.auth };
}
export default connect(mapStateToProps)(Login);
