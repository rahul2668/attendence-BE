import React, { useState } from "react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Modal from "@mui/material/Modal";
import { useDispatch, connect } from "react-redux";
import MuiGrid from "@mui/material/Grid";
import { styled } from "@mui/material/styles";
import Typography from "@mui/material/Typography";

import { createConfig, getConfigs } from "../actions/config";
import { clearMessage } from "../actions/message";

import { CustomInput } from "./HomePageInput";

const style = {
	position: "absolute",
	top: "50%",
	left: "50%",
	transform: "translate(-50%, -50%)",
	width: 400,
	bgcolor: "background.paper",
	border: "1px solid #f3f4f4",
	boxShadow: 24,
	p: 1.5,
};

const Grid = styled(MuiGrid)(({ theme }) => ({
	width: "100%",
	...theme.typography.body2,
	'& [role="separator"]': {
		margin: theme.spacing(0, 2),
	},
}));

function CreateModal(props) {
	const [configData, setConfigData] = useState({
		target_table_name: "",
		source_table_name: "",
		exclude_columns: "",
		key_columns: "",
		incremental_fields: "",
	});
	const [disabled, setDisabled] = useState(true);
	const dispatch = useDispatch();

	const handleChange = (e) => {
		dispatch(clearMessage());
		const { id, value } = e.target;
		setConfigData((prevState) => ({
			...prevState,
			[id]: value,
		}));
		if (
			configData.target_table_name.length > 0 &&
			configData.source_table_name.length > 0 &&
			configData.exclude_columns.length > 0 &&
			configData.key_columns.length > 0 &&
			configData.incremental_fields.length > 0
		) {
			setDisabled(false);
		}
	};
	const handleSubmit = () => {
		dispatch(createConfig(configData))
			.then(() => {
				dispatch(getConfigs());
				props.handleModalClose();
			})
			.catch(function (error) {
				console.log("***create config error", error);
			});
	};

	return (
		<div>
			<Modal
				open={props.showModal}
				onClose={props.handleModalClose}
				aria-labelledby="modal-modal-title"
				aria-describedby="modal-modal-description"
			>
				<Box sx={style}>
					<div
						style={{
							display: "flex",
							padding: "10px",
							height: "50vh",
						}}
					>
						<Grid container>
							<Grid>
								<Typography
									color="Black"
									sx={{
										fontFamily: "Open Sans",
										fontSize: "20px",
										fontWeight: "700",
									}}
								>
									New Config
								</Typography>
							</Grid>
							<Grid item xs={12}>
								<CustomInput
									placeholder="Traget Table Name"
									id="target_table_name"
									onChange={handleChange}
								/>
								<CustomInput
									placeholder="Source Table Name"
									id="source_table_name"
									onChange={handleChange}
								/>
								<CustomInput
									placeholder="Key Columns"
									id="key_columns"
									onChange={handleChange}
								/>
								<CustomInput
									placeholder="Excluded Columns List"
									id="exclude_columns"
									onChange={handleChange}
								/>
								<CustomInput
									placeholder="Increment Field"
									id="incremental_fields"
									onChange={handleChange}
								/>
								<div
									style={{
										display: "flex",
										justifyContent: "center",
										marginTop: "20px",
									}}
								>
									<Button
										variant="contained"
										sx={{
											width: 100,
											borderRadius: "8px",
											ml: 2,
											p: 1.3,
										}}
										disabled={disabled}
										onClick={handleSubmit}
									>
										<span className="font">Submit</span>
									</Button>
								</div>

								{props.message ? (
									<div
										style={{
											display: "flex",
											justifyContent: "center",
											marginTop: "10px",
										}}
									>
										<Typography
											color="red"
											sx={{
												fontFamily: "Open Sans",
												fontSize: "12px",
												fontWeight: "400",
											}}
										>
											{props.message}
										</Typography>
									</div>
								) : null}
							</Grid>
						</Grid>
					</div>
				</Box>
			</Modal>
		</div>
	);
}

function mapStateToProps(state) {
	return { message: state.message.message };
}
export default connect(mapStateToProps)(CreateModal);
