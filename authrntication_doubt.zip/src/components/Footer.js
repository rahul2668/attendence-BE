import CopyrightIcon from "@mui/icons-material/Copyright";

export default function Footer() {
	const year = new Date().getFullYear();
	return (
		<div
			style={{
				marginLeft: "60px",
				height: "8vh",
				background: "#ffffff",
				border: "1px solid #f3f4f4",
				display: "flex",
				justifyContent: "center",
				alignItems: "end",
			}}
		>
			<div>
				<div
					style={{
						textAlign: "center",
					}}
				>
					<CopyrightIcon
						sx={{
							fontSize: "14px",
							verticalAlign: "middle",
							color: "#013579",
						}}
					/>
					<span
						style={{
							paddingLeft: "10px",
							color: "#013579",
						}}
					>
						Bilvantis {year}
					</span>
				</div>
				<div
					style={{
						color: "#013579",
					}}
				>
					Powered By Bilvantis Technologies
				</div>
			</div>
		</div>
	);
}
